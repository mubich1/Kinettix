import { Injectable } from "@angular/core";
import { Action, State, StateContext } from "@ngxs/store";
import { BehaviorSubject, catchError, EMPTY, Observable, tap, throwError } from "rxjs";
import { ClientService } from "src/app/services/client/client.service";
import { ProjectActivityResourceService } from "src/app/services/project-activity-resources/project-activity-resources.service";
import { LoadingState } from "../loading-state.enum";
import { ClientContractsModel, ContractsStateModel, TruncatedClient } from "./contracts-state.model";

export class LoadContractsAction {
  static readonly type = '[Contracts] Load';
}

export class LoadContractsForClient {
  static readonly type = '[Contracts] Load contracts for client';

  constructor(public readonly client: TruncatedClient, public readonly force?: boolean | null, public readonly showClosedContracts?: boolean | null) {}
}

export class ClientSearch {
  static readonly type = '[Contracts] Client search';

  constructor(public readonly query: string) {}
}

export class LoadAdditionalClients {
  static readonly type = '[Contracts] Load additional clients';
}

@State<ContractsStateModel>({
  name: 'contractsState',
  defaults: {
    state: LoadingState.loading,
    currentPage: 1,
    clients: null,
    finalClientsLoaded: false,
  }
})
@Injectable()
export class ContractsState {

  constructor(private clientService: ClientService, private projectActivityResourceService: ProjectActivityResourceService) {}

  private static clientsReturnedPerRequest = 20;

  private getClients(page: number, query?: string | null) {
    return this.clientService.getClients({
      pageNumber: page,
      name: query,
      hasContract: true,
    });
  }

  @Action(LoadContractsAction)
  loadContracts(ctx: StateContext<ContractsStateModel>) {
    const currentState = ctx.getState();

    if(currentState.state !== LoadingState.loaded) {
      return this.getClients(1).pipe(
        tap((value) => {
          const rawResults = value.results as any[];
          const clients: TruncatedClient[] = rawResults.map((rawClient) => {
            return {
              id: rawClient.id,
              name: rawClient.name,
              contractsState: new BehaviorSubject<ClientContractsModel>({
                state: LoadingState.loading,
                showClosedContracts: false,
              }),
            }
          });

          ctx.patchState({
            state: LoadingState.loaded,
            clients: clients,
            finalClientsLoaded: clients.length < ContractsState.clientsReturnedPerRequest,
          });
        }),
        catchError(() => {
          ctx.patchState({
            state: LoadingState.error
          });

          return EMPTY;
        }),
      );
    }

    // If content has already been loaded, return without a value
    return;
  }

  @Action(LoadContractsForClient)
  loadContractsForClient(ctx: StateContext<ClientContractsModel>, action: LoadContractsForClient) {
    const contractsState = action.client.contractsState;

    // Prevent reloads
    if(contractsState.value.state !== LoadingState.loaded || (action.force ?? false)) {
      if(action.force && contractsState.value.state === LoadingState.loaded) {
        contractsState.next({
          state: LoadingState.loading,
          showClosedContracts: action.showClosedContracts ?? false,
          contracts: null,
        });

        ctx.patchState({});
      }

      return this.projectActivityResourceService.getClientContratsByClientId(action.client.id, action.showClosedContracts ?? false).pipe(
        tap((value) => {
          contractsState.next({
            state: LoadingState.loaded,
            showClosedContracts: action.showClosedContracts ?? false,
            contracts: value.results,
          });

          // Trigger rebuild
          ctx.patchState({});
        }),
        catchError((error) => {
          contractsState.next({
            state: LoadingState.error,
            showClosedContracts: action.showClosedContracts ?? false,
          });

          return throwError(() => error);
        })
      );
    }

    return;
  }

  @Action(ClientSearch)
  clientSearch(ctx: StateContext<ContractsStateModel>, action: ClientSearch) {
    ctx.patchState({
      state: LoadingState.loading,
      clients: null,
      searchQuery: action.query,
      currentPage: 1,
      finalClientsLoaded: false,
    });

    return this.getClients(1, action.query).pipe(
      tap((value) => {
        const rawResults = value.results as any[];
        const clients: TruncatedClient[] = rawResults.map((rawClient) => {
          return {
            id: rawClient.id,
            name: rawClient.name,
            contractsState: new BehaviorSubject<ClientContractsModel>({
              state: LoadingState.loading,
              showClosedContracts: false,
            }),
          }
        });

        ctx.patchState({
          state: LoadingState.loaded,
          clients: clients,
          finalClientsLoaded: clients.length < ContractsState.clientsReturnedPerRequest,
        });
      }),
      catchError(() => {
        ctx.patchState({
          state: LoadingState.error
        });

        return EMPTY;
      }),
    );
  }

  @Action(LoadAdditionalClients)
  loadAdditionalClients(ctx: StateContext<ContractsStateModel>) {
    const currentState = ctx.getState();

    if(currentState.finalClientsLoaded || currentState.state === LoadingState.loading) {
      return;
    }

    ctx.patchState({
      state: LoadingState.loading,
    });

    return this.getClients(currentState.currentPage + 1, currentState.searchQuery).pipe(
      tap((value) => {
        const rawResults = value.results as any[];
        const clients: TruncatedClient[] = rawResults.map((rawClient) => {
          return {
            id: rawClient.id,
            name: rawClient.name,
            contractsState: new BehaviorSubject<ClientContractsModel>({
              state: LoadingState.loading,
              showClosedContracts: false,
            }),
          }
        });

        ctx.patchState({
          state: LoadingState.loaded,
          clients: [
            ...currentState.clients!,
            ...clients,
          ],
          currentPage: currentState.currentPage + 1,
          finalClientsLoaded: clients.length < ContractsState.clientsReturnedPerRequest,
        });
      }),
      catchError(() => {
        ctx.patchState({
          state: LoadingState.error,
        });

        return EMPTY;
      }),
    );
  }
}
