import { BehaviorSubject } from "rxjs";
import { ClientContractsGetDto } from "src/app/models/project/project";
import { LoadingState } from "../loading-state.enum";

export interface ContractsStateModel {
  state: LoadingState,
  finalClientsLoaded: boolean,
  currentPage: number,
  clients?: TruncatedClient[] | null,
  searchQuery?: string | null,
}

export interface TruncatedClient {
  id: number,
  name: string,
  contractsState: BehaviorSubject<ClientContractsModel>,
}

export interface ClientContractsModel {
  state: LoadingState,

  showClosedContracts: boolean,
  contracts?: ClientContractsGetDto[] | null,
}
