// Used to track asynchronous actions in state containers
export enum LoadingState {
  loading = 'LOADING',
  loaded = 'LOADED',
  error = 'ERROR',
}
