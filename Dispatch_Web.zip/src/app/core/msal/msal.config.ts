import { LogLevel, Configuration, BrowserCacheLocation } from '@azure/msal-browser';
import { environment } from 'src/environments/environment';

const isIE = window.navigator.userAgent.indexOf("MSIE ") > -1 || window.navigator.userAgent.indexOf("Trident/") > -1;
 
export const b2cPolicies = {
     names: {
         signUpSignIn: environment.signUpSignInB2cPolicy,
         editProfile: environment.editProfileB2cPolicy
     },
     authorities: {
         signUpSignIn: {
             authority: `${environment.b2cAuthority}${environment.signUpSignInB2cPolicy}`,
         },
         editProfile: {
             authority: `${environment.b2cAuthority}${environment.editProfileB2cPolicy}`
         }
     },
     authorityDomain: environment.authorityDomain
 };
 
 
export const msalConfig: Configuration = {
     auth: {
         clientId: environment.b2cClientId,
         authority: b2cPolicies.authorities.signUpSignIn.authority ,
         knownAuthorities: [b2cPolicies.authorityDomain],
         redirectUri: environment.b2cRedirectUri, 
     },
     cache: {
         cacheLocation: BrowserCacheLocation.LocalStorage,
         storeAuthStateInCookie: isIE, 
     },
     system: {
         loggerOptions: {
            loggerCallback: (logLevel, message, containsPii) => {
             },
             logLevel: LogLevel.Verbose,
             piiLoggingEnabled: false
         }
     }
 }

