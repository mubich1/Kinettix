import { Component, OnInit } from '@angular/core';
import { MsalService } from '@azure/msal-angular';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ProfileService } from 'src/app/services/profile.service';
import { DomSanitizer } from '@angular/platform-browser';
import { UtilityService } from 'src/app/services/utility/utility.service';
import { ProfileType } from 'src/app/models/user/user';
import { environment } from 'src/environments/environment';
import { UserService } from 'src/app/services/user/user.service';

@Component({
  selector: 'app-sales-header',
  templateUrl: './sales-header.component.html',
  styleUrls: ['./sales-header.component.css'],
  providers: [ProfileService],
})
export class SalesHeaderComponent implements OnInit {
  userRights = {
    agreementTemplate: false,
    terms: true,
    teams: true,
  };

  isHamburger = false;
  isLoggedIn = true;
  profile: ProfileType = new ProfileType() ;
  isImageLoading = true;
  imageToShow: any;
  userId:string;

  constructor(
    private msalService: MsalService,
    private router: Router,
    private http: HttpClient,
    private _profileService: ProfileService,
    private domSanitizer: DomSanitizer,
    private utility: UtilityService,
    private userService: UserService
  ) {}

  ngOnInit() {
    this.isLoggedIn = this.msalService.instance.getAllAccounts().length > 0;
    this.userId = JSON.parse(localStorage.getItem('userId') || '');

    if (
      this.msalService.instance.getAllAccounts().length <= 0 &&
      this.router.url !== 'login' &&
      this.router.url !== ''
    ) {
      this.router.navigate(['']);
    }
    var profile = this.getData('user_profile');
    if (profile.displayName == undefined) {
      this.getProfile();
    } else {
      this.profile = profile;
    }

    this.userRights.agreementTemplate = this.utility.hasPermission(
      'View Agreement Template'
    );
    this.userRights.terms = this.utility.hasPermission('View Global Terms');
    this.userRights.teams = this.utility.hasPermission('View Team');
  }

  logout() {
    this.userService.logout();
    this.router.navigate(['/login']);
  }

  getData(key: string): any {
    return JSON.parse(localStorage.getItem(key) || '{}');
  }

  getProfile() {
    this.userService.getCurrentUserProfile()
    .subscribe((profile) => {
      this.profile = profile?.results;
      localStorage.setItem('user_profile', JSON.stringify(this.profile));
    });
  }

  onImgError(event: any) {
    this.imageToShow = '/assets/images/user.png';
    event.target.src = '/assets/images/user.png';
  }

  matchRoute(route: string) {
    return route === this.router.url || this.router.url.includes(route); //  /routename)
  }

  expanded() {
    this.isHamburger = !this.isHamburger;
  }

  navigateToEditProfilePage() {
    const win: Window = window;
    win.location = `/users/settings/register-user/${this.userId}`;  
  }
}
