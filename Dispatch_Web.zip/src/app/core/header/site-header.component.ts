import { Component, OnInit } from '@angular/core';
import { MsalService } from '@azure/msal-angular';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ProfileService } from 'src/app/services/profile.service';
import { DomSanitizer } from '@angular/platform-browser';
import { UtilityService } from 'src/app/services/utility/utility.service';
import { environment } from 'src/environments/environment';
import { UserService } from 'src/app/services/user/user.service';
import { ProfileType } from 'src/app/models/user/user';
import { Permission } from 'src/app/services/utility/permission-constant';


@Component({
  selector: 'app-site-header',
  templateUrl: './site-header.component.html',
  styleUrls: ['./site-header.component.css'],
  providers: [ProfileService],
})
export class SiteHeaderComponent implements OnInit {
  isHamburger = false;
  isLoggedIn = true;
  profile: ProfileType = new ProfileType();
  isImageLoading = true;
  imageToShow: any;
  isClientView: boolean;
  userId: string;
  constructor(
    private msalService: MsalService,
    private router: Router,
    private http: HttpClient,
    private _profileService: ProfileService,
    private domSanitizer: DomSanitizer,
    private utility: UtilityService,
    private userService: UserService
  ) {}

  ngOnInit() {
    this.isLoggedIn = this.msalService.instance.getAllAccounts().length > 0;

    if (
      this.msalService.instance.getAllAccounts().length <= 0 &&
      this.router.url !== 'login' &&
      this.router.url !== ''
    ) {
      this.isClientView = this.utility.hasPermission(Permission.ViewClientModule);
      this.router.navigate(['']);
    }

    const getUserFromLocalStorage = () => {
      try {
        return JSON.parse(localStorage.getItem('userId') || '');
      } catch (error) {
        return null;
      }
    };
    this.userId = getUserFromLocalStorage();
    var profile = this.getData('user_profile');
    if (profile.displayName == undefined) {
      this.getProfile();
    } else {
      this.profile = profile;
      this.isClientView = this.utility.hasPermission(Permission.ViewClientModule);
    }
  }

  logout() {
    this.userService.logout();
    this.router.navigate(['/login']);
  }

  getData(key: string): any {
    return JSON.parse(localStorage.getItem(key) || '{}');
  }
  getProfile() {
    this.userService.getCurrentUserProfile().subscribe((profile) => {
      this.profile = profile?.results;

      //determine where to redirect the user after logging in
      var roles = this.profile["roles"].map(s=>s.name)
      this.determineUserLandingPage(roles)

      localStorage.setItem('user_profile', JSON.stringify(this.profile));
      this.utility.setUserPermissions();
      this.isClientView = this.utility.hasPermission(Permission.ViewClientModule);
    });
  }

  onImgError(event: any) {
    this.imageToShow = '/assets/images/user.png';
    event.target.src = '/assets/images/user.png';
  }

  matchRoute(route: string) {
    return route === this.router.url || this.router.url.includes(route); //  /routename)
  }

  expanded() {
    this.isHamburger = !this.isHamburger;
  }

  navigateToEditProfilePage() {
    const win: Window = window;
    win.location = `/users/settings/register-user/${this.userId}`;
  }

  determineUserLandingPage(roles : String[]){
    var isGoToAssignedTasks = roles.includes("Project Coordinator");
    if (isGoToAssignedTasks == true) {
        this.router.navigate(['/delivery-dashboard/my-assigned-task']);
    }

    var isGoToUnAssignedTasks = (roles.includes("Project Manager") || roles.includes("Team Lead") || roles.includes("Admin"));
    if (isGoToUnAssignedTasks == true) {
        this.router.navigate(['/delivery-dashboard/unassigned-task']);
    }
  }
}
