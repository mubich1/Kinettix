import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-settings-content-header',
  templateUrl: './settings-content-header.component.html',
  styleUrls: ['./settings-content-header.component.css']
})
export class SettingsContentHeaderComponent implements OnInit {
  @Input('title') public title: string = '';
  @Input('subTitle') public subTitle: string = '';
  constructor() { }

  ngOnInit(): void {
  }

}
