import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SiteHeaderComponent } from './header/site-header.component';
import { RouterModule } from '@angular/router';
import { SiteFooterComponent } from './footer/site-footer.component';
import { SiteLayoutComponent } from './layout/site-layout.component';
import {
  UIShellModule,
  IconModule,
  PlaceholderModule,
} from 'carbon-components-angular';
import { httpInterceptorProviders } from './interceptors';
import { SalesHeaderComponent } from './header/sales-header/sales-header.component';
import { SalesLayoutComponent } from './layout/sales-layout/sales-layout/sales-layout.component';
import { CarbonModule } from '@carbon/icons-angular';
import { SettingsContentHeaderComponent } from './header/settings-content-header/settings-content-header.component';

@NgModule({
  declarations: [
    SiteLayoutComponent,
    SiteHeaderComponent,
    SiteFooterComponent,
    SalesHeaderComponent,
    SalesLayoutComponent,
    SettingsContentHeaderComponent
  ],
  imports: [
    CommonModule,
    PlaceholderModule,
    RouterModule,
    UIShellModule,
    IconModule,
  ],
  exports: [SiteLayoutComponent, SiteHeaderComponent, SiteFooterComponent, SettingsContentHeaderComponent],
  providers: [httpInterceptorProviders],
})
export class CoreModule {}
