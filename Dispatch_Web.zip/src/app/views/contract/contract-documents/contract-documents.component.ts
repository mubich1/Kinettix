import { DatePipe } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { TableModel, TableHeaderItem, TableItem } from 'carbon-components-angular';
import { ToastrService } from 'ngx-toastr';
import { _ } from 'numeral';
import { Subject, Subscription, takeUntil } from 'rxjs';
import { contractDocuments, ContractDocumentsType } from 'src/app/models/contract-documents/contract-document';
import { CommonService } from 'src/app/services/common/common.service';
import { ContractDocumentService } from 'src/app/services/contract/contract-document.service';
import { DealDocumentService } from 'src/app/services/document/deal-document.service';
import { LoaderService } from 'src/app/services/loader/loader.service';
import { AngularUtility } from 'src/app/shared/common/angular-utitilty';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';
import * as pdfjsLib from 'pdfjs-dist';
import { AllowdDocTypes } from 'src/app/models/common/common';
import { TableFilters } from 'src/app/shared/common/tableFilters';
import { UtilityService } from 'src/app/services/utility/utility.service';
import { Permission } from 'src/app/services/utility/permission-constant';
import { ModuleNameEnum } from 'src/app/shared/enum/module-name-enum';

@Component({
  selector: 'app-contract-documents',
  templateUrl: './contract-documents.component.html',
  styleUrls: ['./contract-documents.component.css']
})
export class ContractDocumentsComponent implements OnInit {

  @ViewChild('customHeaderTemplate', { static: true })
  customHeaderTemplate: ElementRef;
  @ViewChild('customViewDoc', { static: true }) customViewDoc: ElementRef;
  @ViewChild('customViewDocIsInternal', { static: true }) customViewDocIsInternal: ElementRef;

  docList: contractDocuments[] = [];
  showSkeleton: boolean = true;
  tableModel = new TableModel();
  tableData: any = [];
  carbonUtility = new CarbonUtility();
  isOpenDeleteModal = false;
  selectedDeleteTypeId: number = 0;
  ngUnsubscribe = new Subject<void>();
  docForm: FormGroup;
  isEdit: boolean = false;
  isAddEdit = false;
  isLoading = false;
  submitted: boolean;
  isCheckBoxClicked: boolean = true;
  dateFormat = 'm/d/Y';
  language = 'en';
  expireDate: any;
  angularUtility = new AngularUtility();
  contractId: number = 0;
  clientId: number = 0;
  documentList: any;
  documentListTable: TableItem[][] = [];
  documnetTypeList: ContractDocumentsType[];
  showTypeSkeleton: boolean = true;
  showform: boolean = false;
  files = new Set<any>();
  isUpload: boolean = false;
  isOpenAddModal = false;
  EditDoc: any;
  userID: string;
  resetUpload: boolean = false;
  fileTypes: string[] = AllowdDocTypes.extensions;
  subscription$: Subscription = new Subscription();
  tableFilters: TableFilters = new TableFilters();
  isAscending: boolean = false;
  isSorted: boolean = false;
  sortIndex: number = 0;
  pageNo: any;
  protected model = new Set();
  isAddDeliveryContractDocumentAllowed = true;
  isEditDeliveryContractDocumentAllowed = true;
  isDeleteDeliveryContractDocumentAllowed = true;

  constructor(
    private commonService: CommonService,
    private contractDocumentService: ContractDocumentService,
    private documentService: DealDocumentService,
    public datepipe: DatePipe,
    private toastr: ToastrService,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private loaderService: LoaderService,
    private router: Router,
    private utilityService:UtilityService
  ) { }

  ngOnInit(): void {
    this.isAddDeliveryContractDocumentAllowed = this.utilityService.hasPermission(Permission.AddDeliveryContractDocument);
    this.isDeleteDeliveryContractDocumentAllowed = this.utilityService.hasPermission(Permission.DeleteDeliveryContractDocument);
    this.isEditDeliveryContractDocumentAllowed =this.utilityService.hasPermission(Permission.EditDeliveryContractDocument);

    this.route.parent?.params.subscribe((params: any) => {
      if (params.hasOwnProperty('contractId')) {
        this.contractId = params['contractId'];

        this.docForm = this.formBuilder.group({
          id: [null],
          name: ['', Validators.required],
          date: [null],
          docType: ['', Validators.required],
          document: [''],
          url: new FormControl(''),
          isExpireable: new FormControl(false),
          isInternal : [true]
        });
      }

      this.userID = JSON.parse(localStorage.getItem('userId') || '');
    });
    this.initializeTable();
    this.getDocumentTypes();
    this.loadTableData();
  }

  // this is for reset fields.
  intializeForm() {
    this.docForm = this.formBuilder.group({
      id: [0],
      name: ['', Validators.required],
      date: [null],
      docType: ['', Validators.required],
      url: [''],
      isExpireable: [false],
      isInternal: [true],
    });
  }

  get f() {
    return this.docForm.controls;
  }
  onDownload(data)
  {
    this.commonService.downloadDocument(data.url,data.name)
  }

  initializeTable() {
    if (this.documentList && this.documentList.length) {
      for (let document of this.documentList) {
        let rows: any = [];
        this.carbonUtility.setTableItem(rows, document.name);
        this.carbonUtility.setTableItem(rows, document.createdDate ? this.datepipe.transform(document.createdDate, 'MM/dd/yyyy') : '');

        rows.push(new TableItem({ data: { url: document?.url }, template: this.customViewDoc }));
        rows.push(new TableItem({data: document, template: this.customViewDocIsInternal}))
        rows.push(new TableItem({ data: document, template: this.customHeaderTemplate }));
        this.tableData.push(rows);
      };
    }

    const headers = ["Name", "Created Date", "View","Internal", "Action"];
    this.tableModel = this.carbonUtility.setTableModel(headers, this.tableModel, this.tableData, this.tableModel.pageLength, this.tableModel.currentPage, this.tableModel.totalDataLength);
    this.tableModel.header[this.tableModel.header.length - 1].sortable = false;
    this.tableModel.header[this.tableModel.header.length - 2].sortable = false;

    this.tableModel.header[this.tableModel.header.length - 1].style = { "backgroundColor": "#f4f4f4" };
    this.tableModel.header[this.tableModel.header.length - 2].style = { "backgroundColor": "#f4f4f4," };
    this.documentListTable = [...this.tableModel.data];
  }

  formreset() {
    this.files = new Set();
    this.docForm = this.formBuilder.group({
      id: [0],
      name: new FormControl(null, Validators.required),
      date: new FormControl(null),
      url: new FormControl(null),
      docType: new FormControl(''),
      isExpireable: [false],
    });
  }

  addDocument() {
    this.isAddEdit = true;
    this.ShowForm();
  }

  ShowForm() {
    if (!this.showform) {
      this.intializeForm();
    }

    this.showform = !this.showform;
  }

  selectPage(page: any) {
    this.tableModel.currentPage = page;
    this.tableFilters.pageSize = this.tableModel.pageLength;
    this.tableFilters.page = page;
    this.loadTableData(this.isSorted, this.sortIndex);
  }

  populateTable(docList: contractDocuments[]) {
    this.tableData = [];
    this.tableModel.data = [];
    this.tableModel.totalDataLength = docList.length;
    if (docList != null && docList.length > 0) {
      docList.forEach((el) => {
        this.tableData.push([
          new TableItem({ data: el.id }),
          new TableItem({ data: el.name }),
          new TableItem({
            data: this.datepipe.transform(el.createdDate, 'MM/dd/yyyy'),
          }),
          new TableItem ({ data: el.isInternal, template: this.customViewDocIsInternal }),

          new TableItem({ data: el.url, template: this.customViewDoc }),

          new TableItem({ data: el, template: this.customHeaderTemplate }),
        ]);
      });
    }
    this.initializeTable();
    this.showSkeleton = false;
  }

  getDocumentTypes() {
    this.commonService
      .getDocumentDefinitionTypes()
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          //Todo Add codition after config Update
          //res.status == "Success" &&
          if (res != null) {
            this.documnetTypeList = res.results;
          }
        },
        error: (e) => {
          this.showTypeSkeleton = false;
          console.log(e);
        },
        complete: () => {
          this.showTypeSkeleton = false;
        },
      });
  }
  deleteDoc(value: contractDocuments) {
    const term = value.id!;
    if (term > 0) {
      this.selectedDeleteTypeId = term;
      this.openParentModal();
    } else {
      this.selectedDeleteTypeId = 0;
    }
  }
  onConfirmationDelete() {
    this.contractDocumentService
      .deleteDocument(this.selectedDeleteTypeId)
      .subscribe({
        next: (res) => {
          this.toastr.success('Deleted Successfully');
          this.loadTableData();
        },
        error: (e) => {
          console.log(e);
          this.toastr.error('Something went wrong');
        },
        complete: () => this.closeParentModal(),
      });
  }

  openParentModal() {
    this.isOpenDeleteModal = true;
  }
  closeParentModal() {
    this.isOpenDeleteModal = false;
    this.selectedDeleteTypeId = 0;
  }
  closeSaveModal() {
    this.files = new Set();
    this.isCheckBoxClicked = true;
    this.formreset();
    this.isAddEdit = false;
    this.showform = false;
  }

  loadTableData(sort = false, index: number = 0) {
    this.loaderService.show();
    this.subscription$.add(this.contractDocumentService.getPagedContractDocumentsByContractId(this.tableFilters, this.contractId).subscribe((res) => {
      this.loaderService.hide();
      if (res) {
        this.tableData = [];
        this.documentList = res.results.data;
        this.tableModel.totalDataLength = res.results.total;
        this.initializeTable();

        if (sort) {
          this.tableModel.header[index].descending = !this.isAscending;
          this.tableModel.sort(index);
        }
      }
    }, (err) => {
      this.loaderService.hide();
      this.initializeTable();
      this.toastr.error('Error occurred in loading countries list.', 'Error');
    }));
  }

  onSort(index: number) {
    this.isAscending = !this.isAscending;
    this.sortIndex = index;
    this.isSorted = true;
    this.tableFilters.sort = this.tableModel.header[index].data;
    this.tableFilters.isAscending = this.isAscending;
    this.loadTableData(true, index);
  }

  onSearch(event: any) {
    this.tableFilters.search = event?.target?.value;
    this.tableModel.currentPage = 1;
    this.tableFilters.page = 1;
    this.loadTableData(this.isSorted, this.sortIndex);
  }

  onClearSearch() {
    this.tableFilters.search = '';
    this.loadTableData(this.isSorted, this.sortIndex);
  }

  clickCheckBox() {
    if (this.isCheckBoxClicked == true) {
      this.isCheckBoxClicked = false;
      this.docForm.get('date')?.setValidators([Validators.required]);
      this.docForm.get('date')?.updateValueAndValidity();
    } else {
      this.docForm.get('date')?.setValidators([]);
      this.docForm.get('date')?.updateValueAndValidity();
      this.docForm.patchValue({ date: null });
      this.isCheckBoxClicked = true;
    }
  }

  handleSaveSuccess() {
    this.files = new Set();
    this.isCheckBoxClicked = true;
    this.formreset();
    this.loaderService.hide();
    this.toastr.success(`Document ${this.isEdit ? 'updated' : 'created'} successfully.`, 'Success');
    this.loadTableData();
  }

  handleSaveError(err: any) {
    this.loaderService.hide();
    const message = this.isEdit ? 'Error occurred in updating document.' : 'Error occurred in creating new document.';
    this.toastr.error((err.error.message || message), 'Error');
  }

  onClickRow(value: contractDocuments) {
    const docId = value.id!;
    if (docId > 0) {
      this.showform = true;
      this.isAddEdit = true;
      this.updateDocument(docId);
    } else {
      this.onUpload();
    }
  }

  updateDocument(docId) {
    this.contractDocumentService
      .getDocumentsById(docId)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          if (res !== null) {
            this.EditDoc = res;
            if (this.EditDoc != null) {
              this.isCheckBoxClicked = this.EditDoc.results.expiration == null ? true : false,

                this.docForm.get('isInternal')?.setValue(res.results["isInternal"]);

                this.intializeForm();

                this.docForm.patchValue({
                  id: this.EditDoc.results.id,
                  name: this.EditDoc.results.name,
                  docType: this.EditDoc.results.documentType,
                  date: this.EditDoc.results.expiration == null ? null : new Date(this.EditDoc.results.expiration),
                  url: this.EditDoc.results.url,
                  isExpireable: this.EditDoc.results.expiration == null ? false : true,
                  isInternal : this.EditDoc.results["isInternal"]
                });

            }
          }
        },
        error: (e) => {
          console.log(e);

          this.toastr.error(
            'Something went wrong while loading vendor documents'
          );
        },
        complete: () => { },
      });
  }

  createDocument(document) {

    this.documentService
      .uploadDocument(document)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          const Doc: contractDocuments = {
            id: 0,
            contractId: this.contractId,
            name: document.name,
            url: res.document.path,
            documentType: document.docType,
            expiration: this.docForm.value.date ? new Date(this.docForm.value.date) : null,
            isInternal : document.isInternal,
            createdBy: this.userID
          };
          this.contractDocumentService
            .saveDocument(this.contractId, Doc)
            .pipe(takeUntil(this.ngUnsubscribe))
            .subscribe({
              next: (res) => {
                if (res !== null) {
                  this.isLoading = false;
                  this.isAddEdit = false;
                  this.handleSaveSuccess();
                  this.loadTableData();
                  // this.getDataFromPDF(document.filebase64string);
                }
              },
              error: (err) => {
                this.toastr.error((err.error.message || "Something went wrong."), 'Error');
              },
              complete: () => { },
            });
        },
      });
  }

  getDataFromPDF(url: string) {
    const pdf = {
      meta: {},
      content: [] as any,
    };

    // If absolute URL from the remote server is provided, configure the CORS
    // header on that server.

    // The workerSrc property shall be specified.
    pdfjsLib.GlobalWorkerOptions.workerSrc = '../../../../assets/pdf.worker.js';

    const loadingMilestone = pdfjsLib.getDocument(url);
    loadingMilestone.promise.then(function (doc) {
      const promises = [
        doc.getMetadata().then((data) => {
          pdf.meta = {
            info: data.info,
            metadata: data.metadata ? data.metadata.getAll() || null : null,
          };
        }),
      ];

      doc.getPage(1).then(function (page) {
        const viewport = page.getViewport({ scale: 1.0 });
        page.getTextContent().then(function (textContent: any) {
          pdf.content = textContent.items.map((item) => {
            const tm = item.transform;
            let x = tm[4];
            let y = viewport.height - tm[5];
            if (viewport.rotation === 90) {
              x = tm[5];
              y = tm[4];
            }
            // see https://github.com/mozilla/pdf.js/issues/8276
            const height = Math.sqrt(tm[2] * tm[2] + tm[3] * tm[3]);
            return {
              x: x,
              y: y,
              str: item.str,
              dir: item.dir,
              width: item.width,
              height: height,
              fontName: item.fontName,
            };
          });
        });
      });
    });
  }

  updateDocumentSave(document) {
    this.isEdit = true;
    this.contractDocumentService
      .updateDocument(this.contractId, document)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          if (res !== null) {
            this.isLoading = false;
            this.showform = false;
            this.isAddEdit = false;
            this.handleSaveSuccess();
            this.loadTableData();
          }
        },
        error: (err) => {
          this.toastr.error(err.error || 'Something went wrong.', 'Error');
        },
        complete: () => { },
      });
  }

  updateDocumentSaveWithFile(document) {

    this.isEdit = true;
    this.documentService
      .uploadDocument(document)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          const Doc: contractDocuments = {
            id: this.docForm.value.id,
            contractId: this.contractId,
            name: document.name,
            url: res.document.path,
            documentType: document.docType,
            expiration: this.docForm.value.date ? new Date(this.docForm.value.date) : null,
            modifiedBy: this.userID,
            isInternal : this.docForm.value.isInternal
          };
          this.contractDocumentService
            .updateDocument(this.contractId, Doc)
            .pipe(takeUntil(this.ngUnsubscribe))
            .subscribe({
              next: (res) => {
                if (res !== null) {
                  this.isLoading = false;
                  this.isAddEdit = false;
                  this.handleSaveSuccess();
                  this.loadTableData();
                }
              },
              error: (err) => {
                this.toastr.error((err.error.message || "Something went wrong."), 'Error');
              },
              complete: () => { },
            });
        },
      });
  }

  onUpload() {
    const document = {
    id: this.docForm.value.id,
    contractId: this.contractId,
    name: this.docForm.value.name,
    url: this.docForm.value.url,
    documentType: this.docForm.value.docType,
    expiration: this.docForm.value.date ? new Date(this.docForm.value.date) : null,
    isInternal: this.docForm.value.isInternal,
    moduleName: ModuleNameEnum.Contract
  };

    var docName = this.docForm.value.name.trim();
    if (!this.docForm.valid || docName?.length == 0) {
      this.toastr.error('Name is invalid');
      return;
    }
    else if (this.files.size == 0) {

      if (this.docForm.value.id > 0) {
        this.updateDocumentSave(document);
      } else {
        this.toastr.error('Please add document.');
      }
    } else {
      this.files.forEach((fileItem) => {

        const extension = fileItem.file.name.split('.').pop().toLowerCase();

        if (!this.fileTypes.some(s => s.includes(extension))) {
          this.toastr.error('Invalid File Extension.');
          return;
        }

        if (fileItem.file.size < 50000000) {
          setTimeout(() => {
            fileItem.state = 'complete';
            fileItem.uploaded = true;
          }, 1500);

          const reader = new FileReader();

          reader.readAsDataURL(fileItem.file);
          reader.onload = () => {
            let base64 = reader.result?.toString();
            const document = {
              id: this.docForm.value.id,
              name: `${this.docForm.value.name.split('.')[0]}.${extension}`,
              filebase64string: base64 !== undefined ? base64.toString() : null,
              docType: this.docForm.value.docType,
              expiration: this.docForm.value.date ? new Date(this.docForm.value.date) : null,
              isInternal: this.docForm.value.isInternal,
              moduleName: ModuleNameEnum.Contract
            };

            if (
              this.docForm.value.id !== null &&
              this.docForm.value.id !== 0
            ) {

              this.updateDocumentSaveWithFile(document);
            } else {
              this.createDocument(document);
            }
          };
        }
      });
      this.isUpload = true;
    }
  }
  getTypeId() {
    return this.documnetTypeList.filter(x => x.name == this.docForm.value.docType)[0].id;
  }
  getTypeName(id: number) {
    return this.documnetTypeList.filter((x) => x.id == id)[0].name;
  }
  ngOnDestroy(): void {
    this.loaderService.hide();
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

}
