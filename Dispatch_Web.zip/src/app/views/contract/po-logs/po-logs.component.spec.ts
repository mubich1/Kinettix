import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PoLogsComponent } from './po-logs.component';

describe('PoLogsComponent', () => {
  let component: PoLogsComponent;
  let fixture: ComponentFixture<PoLogsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PoLogsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PoLogsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
