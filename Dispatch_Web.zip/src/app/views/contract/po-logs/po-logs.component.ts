import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-po-logs',
  templateUrl: './po-logs.component.html',
  styleUrls: ['./po-logs.component.css']
})
export class PoLogsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
