import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PoNotesLogsComponent } from './po-notes-logs.component';

describe('PoNotesLogsComponent', () => {
  let component: PoNotesLogsComponent;
  let fixture: ComponentFixture<PoNotesLogsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PoNotesLogsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PoNotesLogsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
