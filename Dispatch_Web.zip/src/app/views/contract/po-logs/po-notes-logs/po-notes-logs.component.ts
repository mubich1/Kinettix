import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { TableModel, TableItem } from 'carbon-components-angular';
import { ToastrService } from 'ngx-toastr';
import { Subject, Subscription, tap } from 'rxjs';
import { PoNotesLogs } from 'src/app/models/po-logs/po-notes-logs';
import { LoaderService } from 'src/app/services/loader/loader.service';
import { PurchaseOrderService } from 'src/app/services/purchase-order/purchase-order.service';
import { VendorTechniciansService } from 'src/app/services/vendor-technicians/vendor-technicians.service';
import { VendorService } from 'src/app/services/vendor/vendor.service';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';
import { TableFilters } from 'src/app/shared/common/tableFilters';

@Component({
  selector: 'app-po-notes-logs',
  templateUrl: './po-notes-logs.component.html',
  styleUrls: ['./po-notes-logs.component.css'],
})
export class PoNotesLogsComponent implements OnInit {
  @Output() onTableDataEmission = new EventEmitter();
  @Input() set poNotesData(poNotesData: any) {
    if (poNotesData) {
      this.initializeInputValues(poNotesData);
    }
  }

  @Input() poId: number = 0;
  @ViewChild('editButtonTemplate', { static: false })
  editButtonTemplate: ElementRef;

  poNoteForm: FormGroup;
  currentPoNote: PoNotesLogs;
  isOpenFormModal = false;
  vendors: any = [];
  loadingVendors = true;
  technicians: any = [];
  loadingTechnicians = true

  tableModel = new TableModel();
  carbonUtility = new CarbonUtility();
  poNotesList: TableItem[][] = []; // formatted data for table
  tableData: TableItem[][] = []; // formatted temp data for table search
  poNotes: PoNotesLogs[] = []; // to store api response
  ngUnsubscribe = new Subject<void>();
  subscription$: Subscription = new Subscription();
  tableFilters: TableFilters = new TableFilters();
  isAscending: boolean = false;
  isSorted: boolean = false;
  sortIndex: number = 0;
  PurchaseOrderId: number;

  constructor(
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private purchaseOrderService: PurchaseOrderService,
    private loaderService: LoaderService,
    private route: ActivatedRoute,
    private vendorService: VendorService,
    private vendorTechniciansService: VendorTechniciansService
  ) {}

  ngOnInit(): void {
    this.initilizePoNoteForm();
    this.getVendors();
    this.initializeTable();
  }

  ngOnDestroy() {
    this.subscription$.unsubscribe();
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  initializeTable() {
    if (this.poNotes && this.poNotes.length) {
      for (let poNote of this.poNotes) {
        let rows: any = [];
        this.carbonUtility.setTableItem(rows, poNote.notes);
        this.carbonUtility.setTableItem(rows, poNote.vendorName);
        this.carbonUtility.setTableItem(rows, poNote.techName);
        this.carbonUtility.setTableItem(rows, poNote.userName);
        rows.push(
          new TableItem({ data: poNote, template: this.editButtonTemplate })
        );
        this.tableData.push(rows);
      }
    }

    const headers = ['Notes', 'Vendor Name', 'Technician Name', 'Created By', 'Option'];
    this.tableModel = this.carbonUtility.setTableModel(
      headers,
      this.tableModel,
      this.tableData,
      this.tableModel.pageLength,
      this.tableModel.currentPage,
      this.tableModel.totalDataLength
    );
    this.poNotesList = [...this.tableModel.data];
  }

  selectPage(page: any) {
    this.tableModel.currentPage = page;
    this.tableFilters.pageSize = this.tableModel.pageLength;
    this.tableFilters.page = page;
    this.loadTableData();
  }

  onSearch(event: any) {
    this.tableFilters.search = event?.target?.value;
    this.tableModel.currentPage = 1;
    this.tableFilters.page = 1;
    this.loadTableData();
  }

  onClearSearch() {
    this.tableFilters.search = '';
    this.loadTableData();
  }

  onSort(index: number) {
    this.isAscending = !this.isAscending;
    this.sortIndex = index;
    this.isSorted = true;
    this.tableFilters.sort = this.tableModel.header[index].data;
    this.tableFilters.isAscending = this.isAscending;
    this.loadTableData();
  }

  loadTableData() {
    this.onTableDataEmission.emit(this.tableFilters);
  }

  initializeInputValues(poNotesData) {
    this.poNotes = poNotesData.data;
    this.tableData = [];
    this.tableModel.totalDataLength = poNotesData.total;

    this.initializeTable();
    if (this.isSorted) {
      this.tableModel.header[this.sortIndex].descending = !this.isAscending;
      this.tableModel.sort(this.sortIndex);
    }
  }

  onAddNewPoNote() {
    this.initilizePoNoteForm()
    this.currentPoNote = {} as PoNotesLogs;
    this.isOpenFormModal = true;
  }

  getVendors() {
    this.loadingVendors = true;
    this.loaderService.show();
    let vendorId;
    this.vendorService.getAllVendors().pipe(tap(() => this.loadingVendors = false)).subscribe({
      next: (res) => {
        this.loaderService.hide();
        this.vendors = res;
      },
      error: (err) => {
        this.loaderService.hide();
        console.log(err);
      },
    });
  }
  onVendorchange(selectedVendorId, isFromEdit = false, editValue = 0) {
    var vendorId = ( isFromEdit == true ? editValue : selectedVendorId.id )
    this.currentPoNote.vendorId = vendorId
    if (vendorId) {
      this.loadingTechnicians = true;
      this.vendorTechniciansService.getAllTechnicians(vendorId).pipe(tap(()=>this.loadingTechnicians = false)).subscribe({
        next: (res) => {
          this.technicians = res;
        },
        error: (err) => {
          console.log(err);
        },
      });
    }
  }

  onTechnicianChange(selectedTech) {
    var techid = selectedTech.id;
    this.currentPoNote.techId = techid;
  }

  onSubmitPoNote() {
    this.loaderService.show();
    this.currentPoNote.purchaseOrderId = this.poId;
    var ponote: any = this.currentPoNote;

    this.subscription$.add(
      this.purchaseOrderService.addPONotes(this.poId, ponote).subscribe({
        next: (res) => {
          this.isOpenFormModal = false;
          this.loaderService.hide();
          if (res) {
            this.toastr.success('Notes added Successfully', 'Success');

            this.poNotes.push(this.currentPoNote);
            this.initializeTable();
            this.loadTableData();

            this.currentPoNote = {} as PoNotesLogs;
          }
        },
        error: (error) => {
          this.toastr.error('An Error occurred in adding notes', 'Error');
        },
      })
    );
  }

  onEdit(data: PoNotesLogs) {
    this.loaderService.show();
    this.isOpenFormModal = true;
    this.currentPoNote = data;

    const control = this.poNoteForm as FormGroup;
    control.controls['note'].setValue(data.notes);
    control.controls['vendorId'].setValue(data.vendorId);
    this.onVendorchange(null,true,data.vendorId)
    control.controls['technicianId'].setValue(data.techId);
    this.loaderService.hide();
  }

  initilizePoNoteForm() {
    this.poNoteForm = this.formBuilder.group({
      note: '',
      vendorId: [0],
      technicianId: [0],
    });
  }
}
