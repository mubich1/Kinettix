import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { TableModel, TableItem } from 'carbon-components-angular';
import * as moment from 'moment';
import { ToastrService } from 'ngx-toastr';
import { Subject, Subscription, debounceTime, distinctUntilChanged, takeUntil } from 'rxjs';
import { PoCallLogs } from 'src/app/models/po-logs/po-call-logs';
import { LoaderService } from 'src/app/services/loader/loader.service';
import { PurchaseOrderService } from 'src/app/services/purchase-order/purchase-order.service';
import { VendorTechniciansService } from 'src/app/services/vendor-technicians/vendor-technicians.service';
import { VendorService } from 'src/app/services/vendor/vendor.service';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';
import { TableFilters } from 'src/app/shared/common/tableFilters';

@Component({
  selector: 'app-po-call-logs',
  templateUrl: './po-call-logs.component.html',
  styleUrls: ['./po-call-logs.component.css'],
})
export class PoCallLogsComponent implements OnInit {
  @Output() onTableDataEmission = new EventEmitter();
  @Input() set poCallsData(poCallsData: any) {
    if (poCallsData) {
      this.initializeInputValues(poCallsData);
    }
  }

  @Input() poId: number = 0;
  @ViewChild('editButtonTemplate', { static: false })
  editButtonTemplate: ElementRef;

  isOpenFormModal = false;
  poCallForm: FormGroup;
  currentPoCallLog: PoCallLogs;
  vendors: any = [];
  technicians: any = [];

  tableModel = new TableModel();
  carbonUtility = new CarbonUtility();
  poCallsList: TableItem[][] = []; // formatted data for table
  tableData: TableItem[][] = []; // formatted temp data for table search
  poCalls: PoCallLogs[] = []; // to store api response
  ngUnsubscribe = new Subject<void>();
  subscription$: Subscription = new Subscription();
  tableFilters: TableFilters = new TableFilters();
  isAscending: boolean = false;
  isSorted: boolean = false;
  sortIndex: number = 0;
  PurchaseOrderId: number;

  componentDestroyed$ = new Subject<void>();
  query: string = '';
  queryInput$ = new Subject<string>();

  constructor(
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private purchaseOrderService: PurchaseOrderService,
    private loaderService: LoaderService,
    private route: ActivatedRoute,
    private vendorService: VendorService,
    private vendorTechniciansService: VendorTechniciansService
  ) {}

  ngOnInit(): void {
    this.initilizePoCallForm();
    this.getVendors();
    this.initializeTable();

    this.queryInput$.pipe(
      distinctUntilChanged(),
      debounceTime(300),
      takeUntil(this.componentDestroyed$),
    ).subscribe((query) => {
        this.tableFilters.search = this.query
        this.tableModel.currentPage = 1;
        this.tableFilters.page = 1;
        this.loadTableData();
    });
  }

  ngOnDestroy() {
    this.subscription$.unsubscribe();
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  initializeTable() {
    if (this.poCalls && this.poCalls.length) {
      for (let poCall of this.poCalls) {
        let rows: any = [];
        this.carbonUtility.setTableItem(rows, poCall.lastCallDate);
        this.carbonUtility.setTableItem(rows, poCall.vendorName);
        this.carbonUtility.setTableItem(rows, poCall.techName);
        this.carbonUtility.setTableItem(rows, poCall.userName);
        rows.push(
          new TableItem({ data: poCall, template: this.editButtonTemplate })
        );
        this.tableData.push(rows);
      }
    }

    const headers = [
      'Last Call Date',
      'Vendor Name',
      'Technician Name',
      'Created By',
      'Option',
    ];
    this.tableModel = this.carbonUtility.setTableModel(
      headers,
      this.tableModel,
      this.tableData,
      this.tableModel.pageLength,
      this.tableModel.currentPage,
      this.tableModel.totalDataLength
    );
    this.poCallsList = [...this.tableModel.data];
  }

  selectPage(page: any) {
    this.tableModel.currentPage = page;
    this.tableFilters.pageSize = this.tableModel.pageLength;
    this.tableFilters.page = page;
    this.loadTableData();
  }

  onSearch(event: any) {
    this.tableFilters.search = event?.target?.value;
    this.tableModel.currentPage = 1;
    this.tableFilters.page = 1;
    this.loadTableData();
  }

  searchFieldChanged(): void {
    this.queryInput$.next(this.query);
  }

  onClearSearch() {
    this.tableFilters.search = '';
    this.loadTableData();
  }

  onSort(index: number) {
    this.isAscending = !this.isAscending;
    this.sortIndex = index;
    this.isSorted = true;
    this.tableFilters.sort = this.tableModel.header[index].data;
    this.tableFilters.isAscending = this.isAscending;
    this.loadTableData();
  }

  loadTableData() {
    this.onTableDataEmission.emit(this.tableFilters);
  }

  initializeInputValues(poCallsData) {
    this.poCalls = poCallsData.data;
    this.tableData = [];
    this.tableModel.totalDataLength = poCallsData.total;

    this.initializeTable();
    if (this.isSorted) {
      this.tableModel.header[this.sortIndex].descending = !this.isAscending;
      this.tableModel.sort(this.sortIndex);
    }
  }

  onAddNewPoCall() {
    this.initilizePoCallForm();
    this.currentPoCallLog = {} as PoCallLogs;
    this.isOpenFormModal = true;
  }

  getVendors() {
    this.loaderService.show();
    let vendorId;
    this.vendorService.getAllVendors().subscribe({
      next: (res) => {
        this.loaderService.hide();
        this.vendors = res;
      },
      error: (err) => {
        this.loaderService.hide();
        console.log(err);
      },
    });
  }
  onVendorchange(selectedVendorId, isFromEdit = false, editValue = 0) {
    var vendorId = isFromEdit == true ? editValue : selectedVendorId.id;
    this.currentPoCallLog.vendorId = vendorId;
    if (vendorId) {
      this.vendorTechniciansService.getAllTechnicians(vendorId).subscribe({
        next: (res) => {
          this.technicians = res;
        },
        error: (err) => {
          console.log(err);
        },
      });
    }
  }

  onTechnicianChange(selectedTech) {
    var techid = selectedTech.id;
    this.currentPoCallLog.techId = techid;
  }

  onSubmitPoCall() {
    this.loaderService.show();
    this.currentPoCallLog.purchaseOrderId = this.poId;
    var poCallLog: any = this.currentPoCallLog;
    var lastCallDateString = String(this.poCallForm.value.lastCallDate[0])
    poCallLog.lastCallDate = new Date(lastCallDateString)
    this.subscription$.add(
      this.purchaseOrderService.lastDateCallPurchaseOrder(this.poId, poCallLog).subscribe({
        next: (res) => {
          this.isOpenFormModal = false;
          this.loaderService.hide();
          if (res) {
            if(poCallLog.id > 0){
                this.toastr.success('Call updated successfully', 'Success');
            }else{
                this.toastr.success('Call added successfully', 'Success');
            }

            this.poCalls.push(this.currentPoCallLog);
            this.initializeTable();
            this.loadTableData();

            this.currentPoCallLog = {} as PoCallLogs;
          }
        },
        error: (error) => {
          this.toastr.error('An Error occurred in adding calls', 'Error');
        },
      })
    );
  }

  onEdit(data: PoCallLogs) {
    this.loaderService.show();
    this.isOpenFormModal = true;
    this.currentPoCallLog = data;

    const control = this.poCallForm as FormGroup;
    control.controls['lastCallDate'].setValue(data.lastCallDate);
    control.controls['vendorId'].setValue(data.vendorId);
    this.onVendorchange(null, true, data.vendorId);
    control.controls['technicianId'].setValue(data.techId);
    this.loaderService.hide();
  }

  initilizePoCallForm() {
    this.poCallForm = this.formBuilder.group({
      lastCallDate: null,
      vendorId: [0],
      technicianId: [0],
    });
  }
}
