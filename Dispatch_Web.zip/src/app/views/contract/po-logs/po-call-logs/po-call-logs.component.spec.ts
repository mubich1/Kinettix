import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PoCallLogsComponent } from './po-call-logs.component';

describe('PoCallLogsComponent', () => {
  let component: PoCallLogsComponent;
  let fixture: ComponentFixture<PoCallLogsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PoCallLogsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PoCallLogsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
