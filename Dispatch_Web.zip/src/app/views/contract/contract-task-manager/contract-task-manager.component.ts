import { HttpStatusCode } from '@angular/common/http';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';
import { ContractMilstonesStatusIdEnum, ContractTaskStatus } from 'src/app/models/contract/contract';
import { MilestoneStatusEnum } from 'src/app/models/po-task/po-tasks';
import { ContractTaskManagerService } from 'src/app/services/contract-task-manager/contract-task-manager.service';
import { LoaderService } from 'src/app/services/loader/loader.service';
import { UserService } from 'src/app/services/user/user.service';

@Component({
  selector: 'app-contract-task-manager',
  templateUrl: './contract-task-manager.component.html',
  styleUrls: ['./contract-task-manager.component.css'],
})
export class ContractTaskManagerComponent implements OnInit, OnDestroy {
  isAssign: boolean = false;
  isComplete: boolean = false;
  isFail: boolean = false;
  stagedTasks: any[] = [];
  inWorkTasks: any[] = [];
  wrapUpTasks: any[] = [];
  users: any[] = [];
  statusId: number;
  isOpenTaskModal = false;
  isOpenTaskDeleteConfirmationModal = false;
  currentSelectedContractTask: any;
  currentSelectedActiveContractTask: any;
  contractId: number;
  staged_ContractTasks: any = [];
  inwork_ContractTasks: any = [];
  wrapup_ContractTasks: any = [];
  tasks: any = [];
  tasks_default: any = [];
  tasksToBeAdded: any = [];
  currentUserId: string;
  ngUnsubscribe = new Subject<void>();
  activeCard: any;
  cards = {
    staged: 'Draft',
    inWork: 'InWork',
    wrapUp: 'WrapUp',
    completed: 'Complete',
  };
  isStagedCompleted: boolean = true;
  isInworkCompleted: boolean = false;
  isWrapupCompleted: boolean = false;
  isStagedDelete: boolean = false;
  isWrapUpDelete: boolean = false;
  isInWorkDelete: boolean = false;
  stagedStatus: boolean = false;
  inWorkStatus: boolean = false;
  wrapUpStatus: boolean = false;
  selectedStageTab: boolean = false;
  selectedInWorkTab: boolean;
  selectedWrapupTab: boolean;
  getAllTask: any[] = [];
  selectedTask: any;
  isAllowToAddTask: boolean = false;
  poStatusId: any;
  isDisabled: boolean = true;
  contractTaskStatus = ContractTaskStatus;
  constructor(
    private contractTaskManagerService: ContractTaskManagerService,
    private activatedRoute: ActivatedRoute,
    private toastr: ToastrService,
    private loaderService: LoaderService,
    private userService: UserService
  ) { }

  ngOnInit(): void {
    this.getRoutingParams();
    this.activeCard = this.cards.staged;
    this.getAllTasks();
    this.getAllUsers();
  }

  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  getRoutingParams() {
    this.activatedRoute.parent?.params.subscribe((params) => {
      if (params.hasOwnProperty('contractId')) {
        this.contractId = params['contractId'];
      }
    });

    this.getCurrentUserId();
  }

  onCardSelection(card) {
    this.activeCard = card;
  }

  getCurrentUserId() {
    const getUserFromLocalStorage = () => {
      try {
        return JSON.parse(localStorage.getItem('userId') || '');
      } catch (error) {
        return null;
      }
    };
    this.currentUserId = getUserFromLocalStorage();
  }

  public OnSelectTask(task: any): void {
    if (task) {
      this.getAllTask.forEach((item) => (item.selected = false));
      task.selected = true;
      this.selectedTask = task;
      this.isAllowToAddTask = true;
    }
  }

  public AddTask(status: number): void {
    this.isAllowToAddTask = false;

    const payload = {
      contractTaskId: 0,
      statusId: status,
      taskId: this.selectedTask.id,
      contractMilestones: this.selectedTask.milestones.map((milestone) => {
        return {
          contractMilestoneId: 0,
          milestoneId: milestone.id,
        };
      }),
    };
    this.loaderService.show();
    this.contractTaskManagerService
      .createContractTask(this.contractId, payload)
      .subscribe({
        next: (res) => {
          this.isOpenTaskModal = false;
          this.loaderService.hide();
          this.selectedTask.contractTaskId = res.results.contractTaskId;
          res.results.contractMilestones.forEach((response) => {
            this.selectedTask.milestones.forEach((milestone) => {
              if (milestone.id == response.milestoneId) {
                milestone.contractMilestoneId = response.contractMilestoneId;
                milestone.statusId = response.milestoneStatusId;
                milestone.status = this.getMileStoneStatus(response.milestoneStatusId);
              }
            });
          });

          switch (status) {
            case ContractTaskStatus.Staged:
              this.stagedTasks.push({ ...this.selectedTask, statusId: status });

              break;
            case ContractTaskStatus.InWork:
              this.inWorkTasks.push({ ...this.selectedTask, statusId: status });
              this.isStagedDelete = true;

              break;
            case ContractTaskStatus.WrapUp:
              this.wrapUpTasks.push({ ...this.selectedTask, statusId: status });
              this.isStagedDelete = true;
              this.isInWorkDelete = true;
              break;

            default:
              break;
          }
          this.checkStatusOnCompletion(true);

        },

        error: (e) => {
          this.loaderService.hide();
          this.handleError(e);
        },
        complete: () => { },
      });
    this.isOpenTaskModal = false

  }

  openTaskListModal(statusId) {
    this.statusId = statusId;
    this.isOpenTaskModal = true;
  }

  onRemoveTaskFromStatus(contractTask: any, statusId) {
    this.statusId = statusId;
    this.currentSelectedContractTask = contractTask;
    this.isOpenTaskDeleteConfirmationModal = true;
  }

  onRemoveTaskFromStatusConfirm() {
    this.onDelete();
  }


  getMileStoneStatus(statusId) {
    switch (statusId) {
      case 1:
        return 'Active';
      case 2:
        return 'Failed';
      case 3:
        return 'Complete';
      case 4:
        return 'Pending';
      default:
        return '';
    }
  }
  resetDeletedTaskState() {
    this.currentSelectedContractTask.milestones.forEach((milestone, index) => {
      if (index == 0) {
        milestone.status = MilestoneStatusEnum.Active;
        milestone.statusId = ContractMilstonesStatusIdEnum.Active;
        milestone.completedDate = null;
        milestone.completedByName = null;
        milestone.assignToName = null;
        milestone.assignTo = null;
      } else {
        milestone.status = MilestoneStatusEnum.Pending;
        milestone.statusId = ContractMilstonesStatusIdEnum.Pending;
        milestone.completedDate = null;
        milestone.completedByName = null;
        milestone.assignToName = null;
        milestone.assignTo = null;
      }
    });

  }

  onDelete() {
    const payload = {
      contractTaskId: this.currentSelectedContractTask.contractTaskId,
      contractMilestoneIds: this.currentSelectedContractTask.milestones.map(
        (res) => {
          return res.contractMilestoneId;
        }
      ),
    };
    this.loaderService.show();
    this.contractTaskManagerService
      .deleteContractTaskManager(this.contractId, payload)
      .subscribe({
        next: (res) => {
          this.loaderService.hide();
          this.resetDeletedTaskState();
          switch (this.statusId) {
            case ContractTaskStatus.Staged:
              let stagedIndex = this.stagedTasks.findIndex((item) => item.id == this.currentSelectedContractTask.id);
              if (stagedIndex > -1) {
                this.stagedTasks.splice(stagedIndex, 1);
                this.statusModificationOnDelete(this.stagedTasks, stagedIndex);
              }
              break;
            case ContractTaskStatus.InWork:
              let inWorkIndex = this.inWorkTasks.findIndex((item) => item.id == this.currentSelectedContractTask.id);
              if (inWorkIndex > -1) {
                this.inWorkTasks.splice(inWorkIndex, 1);
                this.statusModificationOnDelete(this.inWorkTasks, inWorkIndex);
              }
              break;
            case ContractTaskStatus.WrapUp:
              let index = this.wrapUpTasks.findIndex((item) => item.id == this.currentSelectedContractTask.id);
              if (index > -1) {
                this.wrapUpTasks.splice(index, 1);
                this.statusModificationOnDelete(this.wrapUpTasks, index);
              }
              break;

            default:
              break;
          }
          this.checkStatusOnCompletion();
        },
        error: (e) => {
          this.loaderService.hide();
          this.handleError(e);
        },
      });
    this.isOpenTaskDeleteConfirmationModal = false;
  }

  statusModificationOnDelete(tasks, index) {
    if (tasks.length && tasks[index]?.milestones.length) {
      tasks[index].milestones[0].status = MilestoneStatusEnum.Active;
    }

  }

  getAllUsers() {
    this.userService.getUsers().pipe(takeUntil(this.ngUnsubscribe)).subscribe({
      next: (res) => {
        this.users = res.results.data;
      },
      error: (e) => {
        this.handleError(e);
      },
      complete: () => { },
    });
  }

  getAllTasks() {
    this.loaderService.show();
    this.contractTaskManagerService.getContractTask().subscribe((res) => {
      this.getAllTask = res.results;
      this.getContractTasks();
    });
  }

  getContractTasks() {
    this.loaderService.show();
    this.contractTaskManagerService
      .getSavedContractMilestones(this.contractId)
      .subscribe({
        next: (res) => {
          this.loaderService.hide();

          this.stagedTasks = this.filterByStatus(res.results.tasks, ContractTaskStatus.Staged);
          this.inWorkTasks = this.filterByStatus(res.results.tasks, ContractTaskStatus.InWork);
          console.log('this.inWorkTasks: ', this.inWorkTasks);
          this.wrapUpTasks = this.filterByStatus(res.results.tasks, ContractTaskStatus.WrapUp);
          this.checkStatusOnCompletion(false);
        },
        error: (e) => {
          this.loaderService.hide();
          this.handleError(e);
        },
        complete: () => { },
      });
  }

  filterByStatus(payloadTasks: any, status: ContractTaskStatus): any {
    switch (status) {
      case ContractTaskStatus.Staged: {
        return payloadTasks.filter((res) => res?.statusId == ContractTaskStatus.Staged);
      }
      case ContractTaskStatus.InWork: {
        return payloadTasks.filter((res) => res?.statusId == ContractTaskStatus.InWork);
      }
      case ContractTaskStatus.WrapUp: {
        return payloadTasks.filter((res) => res?.statusId == ContractTaskStatus.WrapUp);
      }
    }
  }

  handleError(error: any, message?: string) {
    this.loaderService.hide();
    if (
      error?.error?.statusCode === HttpStatusCode.NotFound ||
      error?.error?.statusCode === HttpStatusCode.Conflict
    ) {
      this.toastr.error(error.error.message, 'Error');
    } else {
      this.toastr.error(message, 'Error');
    }
  }

  checkStatusOnCompletion(isTaskFetched = true) {
    this.stagedStatus = this.checkTaskStatus(this.stagedTasks);
    this.inWorkStatus = this.checkTaskStatus(this.inWorkTasks);
    this.wrapUpStatus = this.checkTaskStatus(this.wrapUpTasks);
    if (this.inWorkStatus) {
      if (isTaskFetched && this.wrapUpTasks[0]?.milestones[0]?.status == MilestoneStatusEnum.Pending) {
        this.wrapUpTasks[0].milestones[0].status = MilestoneStatusEnum.Active;
        this.wrapUpTasks[0].milestones[0].statusId = ContractMilstonesStatusIdEnum.Active;
      }
      this.isStagedCompleted = true;
      this.isInworkCompleted = true;
      this.isWrapupCompleted = true;
      this.isInWorkDelete = true;
      this.isStagedDelete = true;
      this.isWrapUpDelete = true;
    }
    else if (this.stagedStatus) {
      if (isTaskFetched && this.inWorkTasks[0]?.milestones[0]?.status == MilestoneStatusEnum.Pending) {
        this.inWorkTasks[0].milestones[0].status = MilestoneStatusEnum.Active;
        this.inWorkTasks[0].milestones[0].statusId = ContractMilstonesStatusIdEnum.Active;
      }
      this.isStagedCompleted = true;
      this.isInworkCompleted = true;
      this.isWrapupCompleted = false;
      this.isStagedDelete = true;

    }
    else {
      this.isStagedCompleted = true;
      this.isInworkCompleted = false;
      this.isWrapupCompleted = false;
    }
  }

  checkTaskStatus(tasks) {
    if (tasks.length == 0) return false;
    let failedMilestoneLength = 0;
    let completedMilestoneLength = 0;
    let totalMilestoneLength = 0;
    tasks.forEach((task) => {
      let completedMilestones = task.milestones.filter((m) => m.statusId === ContractMilstonesStatusIdEnum.Completed);
      let failedMilestones = task.milestones.filter((m) => m.statusId === ContractMilstonesStatusIdEnum.Failed);
      failedMilestoneLength += failedMilestones.length;
      completedMilestoneLength += completedMilestones.length;
      totalMilestoneLength += task.milestones.length;
    });
    if (totalMilestoneLength === failedMilestoneLength + completedMilestoneLength) {
      return true;
    } else {
      return false;
    }
  }

  onAssignSubmit(assignUser: any) {
    const assignedUser = {
      id: assignUser.contractMilestoneId,
      assignTo: assignUser.assignTo,
    };

    const selectedUser = this.users.find((user) => user.id === assignUser.assignTo);
    this.loaderService.show();
    this.contractTaskManagerService
      .saveAssignUser(this.contractId, assignedUser)
      .subscribe({
        next: (res) => {
          this.loaderService.hide();
          this.isAssign = false;
          this.toastr.success('User Assigned Successfully!');
          switch (assignUser.statusId) {
            case ContractTaskStatus.Staged:
              this.mapTasksOnUserAssignation(this.stagedTasks, assignUser, selectedUser, res);
              break;
            case ContractTaskStatus.InWork:
              this.mapTasksOnUserAssignation(this.inWorkTasks, assignUser, selectedUser, res);
              break;
            case ContractTaskStatus.WrapUp:
              this.mapTasksOnUserAssignation(this.wrapUpTasks, assignUser, selectedUser, res);
              break;
            default:
              break;
          }
        },
        error: (err) => {
          this.loaderService.hide();
          this.handleError(err);
        },
      });
  }


  onCompleteSubmit(completeMilestone) {
    console.log('completeMilestone: ', completeMilestone);
    const completedMilestone = {
      id: completeMilestone.contractMilestoneId,
      completedDate: completeMilestone.completedDate,
    };


    this.loaderService.show();
    this.contractTaskManagerService
      .saveCompleteTaskMilestone(this.contractId, completedMilestone)
      .subscribe({
        next: (res) => {
          this.loaderService.hide();
          this.poStatusId = res.results.poStatusId;
          this.isComplete = false;
          this.toastr.success('Completed Successfully!');
          switch (completeMilestone.statusId) {
            case ContractTaskStatus.Staged:

              this.mapTasksOnCompletion(this.stagedTasks, completeMilestone, res);
              break;
            case ContractTaskStatus.InWork:
              this.mapTasksOnCompletion(this.inWorkTasks, completeMilestone, res);
              break;
            case ContractTaskStatus.WrapUp:
              this.mapTasksOnCompletion(this.wrapUpTasks, completeMilestone, res);
              break;
            default:
              break;
          }
          this.checkStatusOnCompletion();

        },
        error: (err) => {
          this.loaderService.hide();
          this.handleError(err);
        },
      });
  }

  onFailSubmit(failMilestone: any) {
    const failedMilestone = {
      id: failMilestone.contractMilestoneId,
      failDate: new Date(failMilestone.failDate),
      failReason: failMilestone.failReason,
    };

    this.loaderService.show();
    this.contractTaskManagerService
      .saveFailTaskMilestone(this.contractId, failedMilestone)
      .subscribe({
        next: (res) => {
          this.loaderService.hide();
          this.toastr.success('Failed Status Updated!');
          switch (failMilestone.statusId) {
            case ContractTaskStatus.Staged:
              this.mapTasksOnFail(this.stagedTasks, failMilestone, res);
              break;
            case ContractTaskStatus.InWork:
              this.mapTasksOnFail(this.inWorkTasks, failMilestone, res);
              break;
            case ContractTaskStatus.WrapUp:
              this.mapTasksOnFail(this.wrapUpTasks, failMilestone, res);
              break;
            default:
              break;
          }
          this.checkStatusOnCompletion();
        },
        error: (err) => {
          this.loaderService.hide();
          this.handleError(err);
        },
      });
  }


  mapTasksOnUserAssignation(tasks, assignUser, selectedUser, res) {
    tasks = tasks.map((task) => {
      if (task.id === assignUser.taskId) {
        task.milestones.map((milestone) => {
          if (milestone.id === assignUser.milestoneId) {
            milestone.assignToName = selectedUser.displayName;
            milestone.assignTo = assignUser.assignTo;

          }
        });
      }
      return task;
    });
  }

  mapTasksOnCompletion(tasks, completeMilestone, res) {
    const index = tasks.findIndex((item) => item.id == completeMilestone.taskId);
    tasks = tasks.map((task) => {
      if (task.id === completeMilestone.taskId) {
        task.milestones.map((milestone) => {
          if (milestone.id === completeMilestone.milestoneId) {
            milestone.completedDate = new Date(res.results.completedDate);
            milestone.failDate = null;
            milestone.status = MilestoneStatusEnum.Completed;
            milestone.statusId = ContractMilstonesStatusIdEnum.Completed;
            milestone.completedByName = res?.results?.completedByName;
            milestone.lastCompletedOrFailedDate = res?.results?.lastCompletedOrFailedDate;
            milestone.assignToName = res?.results?.assignToName;
            milestone.assignTo = res?.results?.assignTo;
          }
        });
        if (task.milestones.length > 1 && completeMilestone.milestoneIndex !== task.milestones.length - 1) {
          task.milestones[completeMilestone.milestoneIndex + 1].status = MilestoneStatusEnum.Active;
        }
      }
      return task;
    });


    if (this.checkTaskStatus([tasks[index]])) {
      if (tasks && tasks[index + 1]) {
        tasks[index + 1].milestones[0].status = MilestoneStatusEnum.Active;
      }
    }

  }


  mapTasksOnFail(tasks, failMilestone, res) {
    const index = tasks.findIndex((item) => item.id == failMilestone.taskId);
    tasks = tasks.map((task) => {
      if (task.id === failMilestone.taskId) {
        task.milestones.map((milestone) => {
          if (milestone.id === failMilestone.milestoneId) {
            milestone.status = MilestoneStatusEnum.Failed;
            milestone.statusId = ContractMilstonesStatusIdEnum.Failed;
            milestone.failDate = new Date(res.results.failDate);
            milestone.failReason = res.results.failReason;
            milestone.completedDate = null;
            milestone.failedByName = res.results.failedByName;
            milestone.lastCompletedOrFailedDate = res?.results?.lastCompletedOrFailedDate;
            milestone.assignToName = res?.results?.assignToName;
            milestone.assignTo = res?.results?.assignTo;
          }
        });
        if (task.milestones.length > 1 && failMilestone.milestoneIndex !== task.milestones.length - 1) {
          task.milestones[failMilestone.milestoneIndex + 1].status = MilestoneStatusEnum.Active;
        }
      }

      return task;
    });

    if (this.checkTaskStatus([tasks[index]])) {
      if (tasks && tasks[index + 1]) {
        tasks[index + 1].milestones[0].status = MilestoneStatusEnum.Active;
      }
    }
  }


}
