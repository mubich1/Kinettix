import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';
import { Client } from 'src/app/models/client/client';
import { Contracts, RiskActualization,ContractStatus } from 'src/app/models/contract/contract';
import { ClientService } from 'src/app/services/client/client.service';
import { ContractService } from 'src/app/services/contract/contract.service';
import { LoaderService } from 'src/app/services/loader/loader.service';
import { TeamService } from 'src/app/services/teams/team.service';
import { DatePipe } from '@angular/common';
import { UtilityService } from 'src/app/services/utility/utility.service';
import { Permission } from 'src/app/services/utility/permission-constant';
import { UserService } from 'src/app/services/user/user.service';

@Component({
  selector: 'app-contract-overview',
  templateUrl: './contract-overview.component.html',
  styleUrls: ['./contract-overview.component.css']
})
export class ContractOverviewComponent implements OnInit {

  @ViewChild('customHeaderTemplate', { static: true })
  customHeaderTemplate: ElementRef;
  @ViewChild('customItemNameTemplate', { static: true })
  customItemNameTemplate: ElementRef;
  ContractTitle: string = "";
  ContractID: number = 0;
  ConHubSpotID: string = "";
  ConProductType: string = "";
  ConProductTypeValue?: string;
  ConEntityInvoice: string = "";
  Platform: string = "";
  SecondaryClient: string = "";
  OnsiteEntity: string = "";
  conAccExecutive?: string = "";
  conAccManager?: string = "";
  pmoLead?: string = "";
  backupPmoLead?: string = "";
  fsoLead?: string = "";
  preVisitTeam?: string = "";
  dayOfTeam?: string = "";

  OverView: string = "";
  endDate: string;
  startDate: string;
  status: string;
  contractId: number = 0;
  clientId: number = 0;

  contractDetailEdit: boolean = false;
  clientRelationEdit: boolean = false;
  dispatchDetailEdit: boolean = false;
  deliveriesEdit: boolean = false;
  usersList: any[];
  preVisitTeamList: any[];
  dayTeamList: any[];
  categoryList: any[];
  contractForm: FormGroup;
  isAddEdit = false;
  userId: string;
  NumberOfPilotSites: number = 0;
  TotalNumberOfSites: number = 0;
  EngagementInstructions?: string;
  minimumLaborHours: number = 0;
  minimumTravelHours: number = 0;
  clients: Client[] = [];
  updateType: string;
  isDispatchEdit = false;
  ngUnsubscribe = new Subject<void>();
  riskActualization: RiskActualization;
  riskActualizationEnum = RiskActualization;

  constructor(
    public datepipe: DatePipe,
    private route: ActivatedRoute,
    private clientService: ClientService,
    private contractService: ContractService,
    private teamService: TeamService,
    private toaster: ToastrService,
    private formBuilder: FormBuilder,
    private loaderService: LoaderService,
    private userService: UserService,
    private utitlityService: UtilityService) { }

  isEditDeilveryContractAllowed = true;

  ngOnInit(): void {
    this.isEditDeilveryContractAllowed = this.utitlityService.hasPermission(Permission.EditDeliveryContract);
    this.route.parent?.params.subscribe((params: any) => {
      if (params.hasOwnProperty('clientId')) {
        this.clientId = params['clientId'];
        //this.loadContract(this.contractId);
      }
    });
    this.route.parent?.params.subscribe((params: any) => {
      if (params.hasOwnProperty('contractId')) {
        this.contractId = params['contractId'];
        this.userId = JSON.parse(localStorage.getItem('b2CUserId') || '');
        this.createForm();
        if (this.contractId) {
          this.getContractById(this.contractId);
        }
        this.getUsers();
        this.getAllTeams();
        this.getAllClients();
      }
    });
  }
  get f() {
    return this.contractForm.controls;
  }

  createForm() {
    this.contractForm = this.formBuilder.group({
      id: [null],
      accExecutive: ['null'],
      accMgr: ['null'],
      pmoLead: [null],
      backupPmoLead: [null],
      fsoLead: [null],
      pvisitTeam: [null],
      dayTeam: [null],
      title: [null],
      overview: [null],
      startDate: [null],
      endDate: [null],
      onsiteEntity: [null],
      secondaryClient: [null],
      platform: [null],
      engagementInstructions: [null],
      riskActualization: [null],
      numberOfPilotSites: [null],
      totalNumberOfSites: [null],
      minimumLaborHours: [null],
      minimumTravelHours: [null],

    });
  }
  onCancel() {
    this.isAddEdit = false;
    this.isDispatchEdit = false;
  }
  async getUsers() {
    await this.userService.getUsers()
      .pipe(takeUntil(this.ngUnsubscribe)).subscribe({
        next: res => {
          this.usersList = res.results.data;
        },
        error: e => console.log("Error while loading", e)
      });
  }

  getAllTeams() {
    this.teamService.getTeams()
      .pipe(takeUntil(this.ngUnsubscribe)).subscribe({
        next: res => {
          this.preVisitTeamList = res.results;
          this.dayTeamList = res.results;
          console.log("res", res);
        },
        error: e => console.log("Error while loading", e)
      });
  }

  onEdit() {
    this.contractService.getContractById(this.contractId)
      .pipe(takeUntil(this.ngUnsubscribe)).subscribe(res => {
        if (res.statusCode == 200 && res.results != null) {
          this.contractForm.patchValue({
            id: res.results.id,
            accExecutive: res.results.accExecutiveId,
            accMgr: res.results.accMgrId,
            pmoLead: res.results.pmoleadId,
            fsoLead: res.results.fsoleadId,
            backupPmoLead: res.results.backupPmoleadId,
            pvisitTeam: res.results.preVisitTeamId,
            dayTeam: res.results.dayOfVisitTeamId,
            title: res.results.title,
            startDate: new Date(res.results.startDate!),
            onsiteEntity: res.results.onsiteEntity,
            secondaryClient: res.results.secondaryClient,
            platform: res.results.platform,
            overview: res.results.overView,
            endDate: res.results.endDate,
            engagementInstructions: res.results.engagementInstructions,
            riskActualization: res.results.riskActualization,
            totalNumberOfSites: res.results.totalNumberOfSites,
            numberOfPilotSites: res.results.numberOfPilotSites,
            minimumLaborHours: res.results.minimumLaborHours,
            minimumTravelHours: res.results.minimumTravelHours
          });

        }
      });
    this.contractDetailEdit = true;
    this.dispatchDetailEdit = true;
    this.clientRelationEdit = true;
    this.deliveriesEdit = false;
    this.isAddEdit = true;
    this.dispatchDetailEdit = true;
    this.isDispatchEdit = false;

  }

  onContractDetailEdit() {
    this.contractService.getContractById(this.contractId)
      .pipe(takeUntil(this.ngUnsubscribe)).subscribe(res => {
        if (res.statusCode == 200 && res.results != null) {
          this.contractForm.patchValue({
            id: res.results.id,
            accExecutive: res.results.accExecutiveId,
            accMgr: res.results.accMgrId,
            pmoLead: res.results.pmoleadId,
            fsoLead: res.results.fsoleadId,
            backupPmoLead: res.results.backupPmoleadId,
            pvisitTeam: res.results.preVisitTeamId,
            dayTeam: res.results.dayOfVisitTeamId,
            title: res.results.title,
            startDate: new Date(res.results.startDate!),
            onsiteEntity: res.results.onsiteEntity,
            secondaryClient: res.results.secondaryClient,
            platform: res.results.platform,
            overview: res.results.overView,
            endDate: new Date(res.results.endDate!),
            totalNumberOfSites: res.results.totalNumberOfSites,
            engagementInstructions: res.results.engagementInstructions,
            riskActualization: res.results.riskActualization,
            numberOfPilotSites: res.results.numberOfPilotSites,
            minimumLaborHours: res.results.minimumLaborHours,
            minimumTravelHours: res.results.minimumTravelHours

          });

        }
      });
    this.contractDetailEdit = false;;
    this.dispatchDetailEdit = false;;
    this.clientRelationEdit = true;
    this.deliveriesEdit = true;
    this.isAddEdit = true;
    this.isDispatchEdit = false;

  }

  onClientRelationEdit() {
    this.contractService.getContractById(this.contractId)
      .pipe(takeUntil(this.ngUnsubscribe)).subscribe(res => {
        if (res.statusCode == 200 && res.results != null) {
          this.contractForm.patchValue({
            id: res.results.id,
            accExecutive: res.results.accExecutiveId,
            accMgr: res.results.accMgrId,
            pmoLead: res.results.pmoleadId,
            fsoLead: res.results.fsoleadId,
            backupPmoLead: res.results.backupPmoleadId,
            pvisitTeam: res.results.preVisitTeamId,
            dayTeam: res.results.dayOfVisitTeamId,
            title: res.results.title,
            startDate: new Date(res.results.startDate!),
            onsiteEntity: res.results.onsiteEntity,
            secondaryClient: res.results.secondaryClient,
            platform: res.results.platform,
            overView: res.results.overView,
            endDate: res.results.endDate,
            minimumLaborHours: res.results.minimumLaborHours,
            minimumTravelHours: res.results.minimumTravelHours

          });

        }
      });
    this.contractDetailEdit = true;
    this.dispatchDetailEdit = false;
    this.clientRelationEdit = false;
    this.deliveriesEdit = true;

    this.isAddEdit = true;
    this.isDispatchEdit = false;

  }
  ///** Get Clients START  */
  getAllClients() {
    this.clientService.getAllClients().subscribe((res) => {
      if (res.statusCode == 200) {
        this.clients = res.results;
      } else {
        this.toaster.error('Something went wrong while loading clients');
      }
    });
  }
  ///** Get Clients  END  */
  getContractById(contractId: number) {
    this.contractService.getContractById(contractId)
      .pipe(takeUntil(this.ngUnsubscribe)).subscribe(res => {
        this.conAccExecutive = res.results.accExecutiveName;
        this.conAccManager = res.results.accMgrName;
        this.pmoLead = res.results.pmoleadName;
        this.fsoLead = res.results.fsoleadName;
        this.backupPmoLead = res.results.backupPmoleadName;
        this.preVisitTeam = res.results.preVisitTeamName;
        this.dayOfTeam = res.results.dayOfVisitTeamName,
          this.ContractTitle = res.results.title!;
        this.OnsiteEntity = res.results.onSiteEntityName!;
        if (res.results.secondaryClient == 0) {
          this.SecondaryClient = "None";
        }
        else {
          this.SecondaryClient = res.results.secondryClientName!;
        }
        if (res.results.platform == 0) {
          this.Platform = "None";
        }
        else {
          this.Platform = res.results.platFromClientName!;
        }

        this.OverView = res.results.overView!;
        this.endDate = this.datepipe.transform(res.results.endDate, 'MM/dd/yyyy')!;
        this.startDate = this.datepipe.transform(res.results.startDate, 'MM/dd/yyyy')!;
        this.ConProductType = res.results.productType!;
        this.ConProductTypeValue = res.results.productTypeValue!;
        this.status = res.results.statusName!;
        this.status= ContractStatus[this.status];
        this.ConEntityInvoice = res.results.primaryClient!;
        this.ConHubSpotID = res.results.dealId!;
        this.NumberOfPilotSites = res.results.numberOfPilotSites!;
        this.TotalNumberOfSites = res.results.totalNumberOfSites!;
        this.EngagementInstructions = res.results.engagementInstructions!;
        this.riskActualization = res.results.riskActualization!;
        this.minimumLaborHours = res.results.minimumLaborHours!;
        this.minimumTravelHours = res.results.minimumTravelHours!;
      });
  }

  onSubmit() {
    if (!this.contractForm.valid) {
      return;
    }
    else {
      const startDate = new Date(this.contractForm.value.startDate!);
      const endDate = new Date(this.contractForm.value.endDate!);
      if (endDate.getTime() - startDate.getTime() < 0) {
        this.toaster.error('"End Date" must occur after "Start Date"');

        return;
      }

      const template: Contracts = {
        id: this.contractId,
        accExecutiveId: this.contractForm.value.accExecutive === 'null' ? null : this.contractForm.value.accExecutive,
        accMgrId: this.contractForm.value.accMgr === 'null' ? null : this.contractForm.value.accMgr,
        pmoleadId: this.contractForm.value.pmoLead === 'null' ? null : this.contractForm.value.pmoLead,
        fsoleadId: this.contractForm.value.fsoLead === 'null' ? null : this.contractForm.value.fsoLead,
        preVisitTeamId: this.contractForm.value.pvisitTeam === 'null' ? null : this.contractForm.value.pvisitTeam,
        dayOfVisitTeamId: this.contractForm.value.dayTeam,
        backupPmoleadId: this.contractForm.value.backupPmoLead === 'null' ? null : this.contractForm.value.backupPmoLead,
        title: this.contractForm.value.title,
        startDate: startDate,
        onsiteEntity: this.contractForm.value.onsiteEntity,
        secondaryClient: this.contractForm.value.secondaryClient === 'null' ? null : this.contractForm.value.secondaryClient,
        platform: this.contractForm.value.platform === 'null' ? null : this.contractForm.value.platform,
        overView: this.contractForm.value.overview,
        endDate: endDate,
        numberOfPilotSites: this.contractForm.value.numberOfPilotSites,
        totalNumberOfSites: this.contractForm.value.totalNumberOfSites,
        engagementInstructions: this.contractForm.value.engagementInstructions,
        riskActualization: this.contractForm.value.riskActualization,
        updateType: this.updateType,
        minimumLaborHours: this.contractForm.value.minimumLaborHours,
        minimumTravelHours: this.contractForm.value.minimumTravelHours,

      };
      if (template.id != null && template.id > 0) {
        this.contractService.updateClientContract(this.contractId, template)
          .subscribe({
            next: (res) => {
              this.isAddEdit = false;
              this.isDispatchEdit = false;
              this.handleSaveSuccess();
            },
            error: (err) => {
              this.handleSaveError(err);
            }
          });
      }
    }
  }

  handleSaveSuccess() {
    this.loaderService.hide();
    this.toaster.success(`Details updated successfully.`);
    this.getContractById(this.contractId);
  }

  handleSaveError(err: any) {
    this.loaderService.hide();
    const message = 'Error occurred in updating information.';
    this.toaster.error((err.error.message || message), 'Error');
  }
  onDispatchDetailEdit() {
    this.contractService.getContractById(this.contractId)
      .pipe(takeUntil(this.ngUnsubscribe)).subscribe(res => {
        if (res.statusCode == 200 && res.results != null) {
          this.contractForm.patchValue({
            id: res.results.id,
            accExecutive: res.results.accExecutiveId,
            accMgr: res.results.accMgrId,
            pmoLead: res.results.pmoleadId,
            fsoLead: res.results.fsoleadId,
            backupPmoLead: res.results.backupPmoleadId,
            pvisitTeam: res.results.preVisitTeamId,
            dayTeam: res.results.dayOfVisitTeamId,
            title: res.results.title,
            startDate: new Date(res.results.startDate!),
            onsiteEntity: res.results.onsiteEntity,
            secondaryClient: res.results.secondaryClient,
            platform: res.results.platform,
            overview: res.results.overView,
            endDate: new Date(res.results.endDate!),
            totalNumberOfSites: res.results.totalNumberOfSites,
            engagementInstructions: res.results.engagementInstructions,
            riskActualization: res.results.riskActualization,
            numberOfPilotSites: res.results.numberOfPilotSites,
            minimumLaborHours: res.results.minimumLaborHours,
            minimumTravelHours: res.results.minimumTravelHours

          });
        }
      },
        (err) => {
          this.handleSaveError(err);
        });
    this.dispatchDetailEdit = true;;
    this.contractDetailEdit = false;;
    this.clientRelationEdit = false;
    this.deliveriesEdit = true;
    this.isAddEdit = false;
    this.isDispatchEdit = true;
  }
}
