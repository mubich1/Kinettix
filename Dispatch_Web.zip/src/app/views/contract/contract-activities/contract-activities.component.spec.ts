import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContractActivitiesComponent } from './contract-activities.component';

describe('ContractActivitiesComponent', () => {
  let component: ContractActivitiesComponent;
  let fixture: ComponentFixture<ContractActivitiesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContractActivitiesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContractActivitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
