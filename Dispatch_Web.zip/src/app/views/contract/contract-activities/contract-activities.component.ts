import {
  AfterContentInit,
  Component,
  ElementRef,
  OnInit,
  ViewChild,
  ViewChildren,
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {
  ListItem,
  ModalService,
  TableHeaderItem,
  TableItem,
  TableModel,
} from 'carbon-components-angular';
import { ToastrService } from 'ngx-toastr';
import { Subject, Subscription, takeUntil } from 'rxjs';
import { Activity, ActivityExtended } from 'src/app/models/activity/activity';
import { ProposalService } from 'src/app/services/proposal/proposal.service';
import { AngularUtility } from 'src/app/shared/common/angular-utitilty';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';
import * as _ from 'lodash';
import { KinettixMath } from 'src/app/models/KinettixMath';
import { TicketService } from 'src/app/services/ticket/ticket.service';
import { ActivityService } from 'src/app/services/activity/activity.service';
import { TableFilters } from 'src/app/shared/common/tableFilters';
import { LoaderService } from 'src/app/services/loader/loader.service';
import { TicketActivity } from 'src/app/models/deliveryContract/delivery-contract.model';
import { UtilityService } from 'src/app/services/utility/utility.service';
import { Permission } from 'src/app/services/utility/permission-constant';
import { FormBuilder, FormGroup } from '@angular/forms';
import { NgSelectComponent } from '@ng-select/ng-select';
import { CurrencyPipe } from '@angular/common';
import { ActivityResourcesComponent } from '../../settings/activity/activity-resources/activity-resources.component';
@Component({
  selector: 'app-contract-activities',
  templateUrl: './contract-activities.component.html',
  styleUrls: ['./contract-activities.component.css'],
})
export class ContractActivitiesComponent implements OnInit, AfterContentInit {
  @ViewChild('customHeaderDoc', { static: true }) customHeaderDoc: ElementRef;
  @ViewChild('deactivateContractActivityButton', { static: true }) deactivateContractActivityButton: ElementRef;
  @ViewChildren('filterDropdown') filterDropdown: NgSelectComponent[];
  @ViewChild('resourceTableTemplate', { static: true })
  resourceTableTemplate: ElementRef;
  filterForm: FormGroup;
  typeFilterList: any = [];
  categoryFilterList: any = [];
  nameFilterList: any = [];
  regionFilterList: any = [];
  currencyFilterList: any = [];
  totalVariableCostFilterList: any = [];
  Filter_CurrentSelectedTypeId: any;
  Filter_CurrentSelectedCategoryId: any;
  Filter_CurrentSelectedName: any;
  Filter_CurrentSelectedRegion: any;
  Filter_CurrentSelectedCurrency: any;
  Filter_CurrentSelectedTotalVariableCost: any;

  globalActivitiesTableModel = new TableModel();
  globalActivitiesTableData: TableItem[][] = [];
  globalActivitiesList: any;
  currentContractActivities: Activity[] = [];
  globalActivitiesToBeAssigned_List: Activity[] = [];
  globalTicketActivitiesToBeAdded_List: TicketActivity[] = [];

  tableFilters: TableFilters = new TableFilters();
  subscription$: Subscription = new Subscription();

  activityTableModel = new TableModel();
  activityTableData: TableItem[][] = [];

  /** Selected Activities Start */
  selectedActivityTableModel = new TableModel();
  selectedActivityTableData: TableItem[][] = [];
  showSelectedActivitiesSkeleton: boolean = true;
  SelectedActivityList: Activity[] = [];
  /** Selected Activities End */
  ngUnsubscribe = new Subject<void>();
  showActivitiesSkeleton: boolean = true;
  activityList: Activity[] = [];
  tempActivityList: Activity[] = [];
  kinettixmath = new KinettixMath();
  totalRevenue: number = 0;
  currentContractActivityToDeactivate: ActivityExtended;
  @ViewChild('customHeaderTargetCost', { static: true })
  customHeaderTargetCost: ElementRef;
  showStripe:boolean = true;
  isOpenAddActivityModel: boolean = false;
  isOpenAddNewActivityModel: boolean = false;
  isCancelAddNewActivityModel: boolean = false;
  activityForm: any;
  activityFormValidation: boolean = true;
  tableFilter: TableFilters = new TableFilters();
  constructor(
    private proposalService: ProposalService,
    private toastr: ToastrService,
    private activatedRoute: ActivatedRoute,
    private activityService: ActivityService,
    private utilityService: UtilityService,
    private formBuilder: FormBuilder,
    private currencyPipe:CurrencyPipe,
    private loaderService: LoaderService,
    private modalService: ModalService
  ) { }
  carbonUtility = new CarbonUtility();
  angularUtility = new AngularUtility();
  proposalId;
  activityId: number = 0;
  isOpenGlobalActivitiesModal = false;
  isOpenDeactivateContractActivityModal = false;
  showSkeleton = false;
  isAscending: boolean = false;
  searchString: string = '';

  isAddDeliveryContractActivityAllowed = true;
  isDeactivateActivityAllowed = true;

  @ViewChild('activitiesTags', { static: true }) activitiesTags: ElementRef;
  ngAfterContentInit(): void { }

  ngOnInit(): void {
    this.initilizeFilterForm();
    this.isAddDeliveryContractActivityAllowed =
      this.utilityService.hasPermission(Permission.AddDeliveryContractActivity);
    this.isDeactivateActivityAllowed = this.utilityService.hasPermission(
      Permission.DeactivateActivity

    );
    // Getting query params.
    this.activatedRoute.parent?.params.subscribe((params) => {
      if (params.hasOwnProperty('contractId')) {
        this.proposalId = params['contractId'];

      }

      if (this.proposalId > 0) {
        this.getProposalActivities();
      }
    });

    this.initializeGlobalActivitiesTable();
    this.getGlobalActivities();
  }

  getProposalActivities() {
    this.loaderService.show();
    this.showActivitiesSkeleton = true;
    this.proposalService
      .getProposalActivitiesByProposalId(this.proposalId,'contract',false,this.tableFilter)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          this.loaderService.hide();
          this.tempActivityList = res.results;
          this.SelectedActivityList = _.filter(this.tempActivityList, [
            'isUsed',
            true,
          ]);
          this.populateDocumentTable(this.tempActivityList);
          this.populateSelectedActivityTable(this.SelectedActivityList);
        },
        error: (e) => {
          this.loaderService.hide();
          this.toastr.error('Something went wrong');
        },
        complete: () => {
          this.loaderService.hide();
        },
      });
  }

  InitializeDocumentActivityTable() {
    this.activityTableModel.data = [];
    let headers = [
      new TableHeaderItem({
        data: 'Option',
        visible: this.isDeactivateActivityAllowed,
      }),
      new TableHeaderItem({ data: 'ID', visible: false }),
      new TableHeaderItem({ data: 'Name' }),
      new TableHeaderItem({ data: 'Availability' }),

      new TableHeaderItem({ data: 'Budget' }),
      new TableHeaderItem({ data: 'Risk' }),
      new TableHeaderItem({ data: 'Total Budget' }),
      new TableHeaderItem({ data: 'Budget Margin%' }),
      new TableHeaderItem({ data: 'Target Cost' }),
      new TableHeaderItem({ data: 'Target Margin%' }),
      new TableHeaderItem({ data: 'Price' }),
    ];
    this.activityTableModel = this.carbonUtility.initializeTable(
      headers,
      this.activityTableModel,
      this.activityTableData
    );

    this.selectPageDocument(1);
  }

  populateDocumentTable(activitiesList: Activity[]) {
    this.activityTableData = [];
    this.activityTableModel.totalDataLength = activitiesList.length;
    if (activitiesList != null && activitiesList.length > 0) {
      activitiesList.forEach((el, index) => {
        let resourceModel = new TableModel();
        let resourceData: TableItem[][] = [];

        this.populateResourceTable(
          el.resources,
          resourceModel,
          resourceData
        );
        this.activityTableData.push([
          new TableItem({
            data: { data: el, index: index },
            template: this.deactivateContractActivityButton,

            expandedData: [
              [
                new TableItem({
                  data: resourceModel,
                  colSpan: 12,
                  template: this.resourceTableTemplate,
                }),
              ],
            ],
            expandAsTable: true,
          }),
          new TableItem({ data: el.id }),
          new TableItem({ data: el.name }),
          new TableItem({ data: {isUsed :el.isUsed,isContractActivity:el.isContractActivity}, template: this.activitiesTags }),
          new TableItem({
            data:
              el.totalVariableCost == undefined
                ? '$' + 0
                : '$' + el.totalVariableCost,
          }),
          new TableItem({
            data: el.riskPercent == undefined ? 0 : '$' + el.riskPercent,
          }),
          new TableItem({
            data:
              '$' + (el.totalVariableCost! + el.riskPercent) == undefined ||
                Number.isNaN(el.totalVariableCost! + el.riskPercent) == true
                ? 0
                : '$' + (el.totalVariableCost! + el.riskPercent),
          }),
          new TableItem({
            data:
              this.kinettixmath.CalculateBudgetMargin(
                el.price,
                el.totalVariableCost,
                el.riskPercent
              ) + '%',
          }),
          new TableItem({
            data: { data: el, index: index },
            template: this.customHeaderTargetCost,
          }),
          new TableItem({
            data:
              this.kinettixmath.CalculateMarginPercentage(
                el.targetCost,
                el.price
              ) + '%',
          }),
          new TableItem({ data: el.price != null ? '$' + el.price : '$0.00' }),
        ]);
      });
    }
    this.InitializeDocumentActivityTable();
    this.showActivitiesSkeleton = false;
  }
  populateResourceTable(
    resources: any[],
    resourceModel: TableModel,
    resourceData: TableItem[][]
  ) {
    resourceModel.data = [];
    resourceData = [];
    resourceModel.totalDataLength = 0;

    if (resources != null && resources.length > 0) {
      resourceModel.totalDataLength = resources.length;
      resources.forEach((element) => {
        resourceData.push([
          new TableItem({ data: element.resourceDisplayTitle || '' }),
          new TableItem({ data: element.resourceName || '' }),
          new TableItem({
            data: element.category != null ? element.category.name : '',
          }),
          new TableItem({ data: element.quantity }),
          new TableItem({
            data: this.currencyPipe.transform(element.totalCost, 'USD'),
          }),
          new TableItem({
            data: this.currencyPipe.transform(element.price, 'USD'),
          }),
        ]);
      });
    }

    this.initializeResourceTable(resourceModel, resourceData);
  }

  initializeResourceTable(
    resourceModel: TableModel,
    resourceData: TableItem[][]
  ) {
    resourceModel.header = [];
    resourceModel.data = [];

    let headers = [
      new TableHeaderItem({ data: 'TITLE' }),
      new TableHeaderItem({ data: 'NAME' }),
      new TableHeaderItem({ data: 'CATEGORY' }),
      new TableHeaderItem({ data: 'QUANTITY' }),
      new TableHeaderItem({ data: 'TOTAL COST' }),
      new TableHeaderItem({ data: 'PRICE' }),
    ];

    resourceModel = this.carbonUtility.initializeTable(
      headers,
      resourceModel,
      resourceData
    );

    this.selectResourcePage(1, resourceModel, resourceData);
  }


  selectResourcePage(
    page: any,
    resourceModel: TableModel,
    resourceData: TableItem[][]
  ) {
    resourceModel = this.carbonUtility.selectPage(
      page,
      resourceModel,
      resourceData
    );
  }

  selectPageDocument(page: any) {
    this.activityTableModel = this.carbonUtility.selectPage(
      page,
      this.activityTableModel,
      this.activityTableData
    );
  }

  changeNumber(event, index) {
    this.activityList[index].targetCost = event.value;
    this.activityService.updateActivity(this.activityList[index]).subscribe({
      next: (res) => {
        if (res.statusCode == 200) {
          this.populateDocumentTable(this.activityList);
          this.toastr.success('Target cost update successfully');
        }
      },
      error: (err) => {
        if (err.status == 409) {
          this.toastr.error('Activity already exists');
          return;
        } else {
          this.toastr.error('Something went wrong');
        }
      },
    });
  }

  /** Selected Activity Start */
  InitializeSelectedActivityTable() {
    this.selectedActivityTableModel.data = [];

    let headers = [
      new TableHeaderItem({ data: 'Name' }),
      new TableHeaderItem({ data: 'ID', visible: false }),
      new TableHeaderItem({ data: 'Billable' }),
      new TableHeaderItem({ data: 'Non-billable' }),
      new TableHeaderItem({ data: 'Total Revenue' }),
    ];
    this.selectedActivityTableModel = this.carbonUtility.initializeTable(
      headers,
      this.selectedActivityTableModel,
      this.selectedActivityTableData
    );

    this.selectActivityPageDocument(1);
  }

  populateSelectedActivityTable(activitiesList: Activity[]) {
    this.selectedActivityTableData = [];
    this.selectedActivityTableModel.totalDataLength = activitiesList.length;
    this.totalRevenue = Number(this.angularUtility.getSum(
      activitiesList,
      'totalRevenue'
    ).toFixed(2));

    if (activitiesList != null && activitiesList.length > 0) {
      activitiesList.forEach((el) => {
        let resourceModel = new TableModel();
        let resourceData: TableItem[][] = [];

        this.populateResourceTable(
          el.resources,
          resourceModel,
          resourceData
        );
        if (el.resources != null && el.resources.length > 0) {
          el.budget = this.angularUtility.getSum(el.resources, 'unitCost');
          el.riskFee = this.angularUtility.getSum(el.resources, 'riskFee');
          el.price = this.angularUtility.getSum(el.resources, 'price');
        }
        this.selectedActivityTableData.push([
          new TableItem({ data: el.name ,
            expandedData: [
              [
                new TableItem({
                  data: resourceModel,
                  colSpan: 12,
                  template: this.resourceTableTemplate,
                }),
              ],
            ],
            expandAsTable: true,}),
          new TableItem({ data: el.id }),
          new TableItem({ data: el.isBillAble }),
          new TableItem({ data: el.isNonBillAble }),
          new TableItem({ data: this.currencyPipe.transform(el.totalRevenue, 'USD') }),
        ]);
      });
    }
    this.InitializeSelectedActivityTable();
    this.showSelectedActivitiesSkeleton = false;
  }

  selectActivityPageDocument(page: any) {
    this.selectedActivityTableModel = this.carbonUtility.selectPage(
      page,
      this.selectedActivityTableModel,
      this.selectedActivityTableData
    );
  }

  toggleGlobalActivitiesModal(action: boolean) {
    this.isOpenGlobalActivitiesModal = action;
  }

  initializeGlobalActivitiesTable() {
    this.globalActivitiesTableModel.data = [];
    let headers = [
      new TableHeaderItem({ data: 'ID', visible: false }),
      new TableHeaderItem({ data: 'Assign', sortable: false }),
      new TableHeaderItem({ data: 'Type', sortable: true }),
      new TableHeaderItem({ data: 'Category', sortable: true }),
      new TableHeaderItem({ data: 'Name', sortable: true }),
      new TableHeaderItem({ data: 'Region', sortable: true }),
      new TableHeaderItem({ data: 'Currency', sortable: true }),
      new TableHeaderItem({ data: 'Total Variable Cost', sortable: true }),
      new TableHeaderItem({ data: 'Price', sortable: true }),
    ];
    this.globalActivitiesTableModel = this.carbonUtility.initializeTable(
      headers,
      this.globalActivitiesTableModel,
      this.globalActivitiesTableData
    );

    this.selectPage(1);
  }

  selectPage(page: any) {
    this.globalActivitiesTableModel = this.carbonUtility.selectPage(
      page,
      this.globalActivitiesTableModel,
      this.globalActivitiesTableData
    );
  }

  getContractActivitiesByContractId() {
    this.activityService
      .getContractActivitiesByContractId(this.proposalId)
      .subscribe((res) => {
        if (res.statusCode == 200) {
          this.currentContractActivities = res.results;
        } else {
          this.toastr.error(
            'Something went wrong while loading contract activities'
          );
        }
      });
  }

  getGlobalActivities() {
    this.getContractActivitiesByContractId();

    this.activityService.getAllGlobelActivities(true).subscribe((res) => {
      if (res.statusCode == 200) {
        this.globalActivitiesList = res.results;
        this.globalActivitiesList = res.results.filter(
          (activity) =>
            activity.activityResources?.length != null &&
            activity.activityResources?.length > 0
        );
        this.populateGlobalActivitiesTable(this.globalActivitiesList);

        //populate the filter dropdowns
        this.populateFilterDropdowns(this.globalActivitiesList);
      } else {
        this.toastr.error('Something went wrong while loading activities');
      }
    });
  }

  populateGlobalActivitiesTable(activities: any) {
    this.globalActivitiesList = activities;
    this.globalActivitiesTableModel.data = [];
    this.globalActivitiesTableData = [];

    this.globalActivitiesTableModel.totalDataLength =
      this.globalActivitiesList.length;
    if (
      this.globalActivitiesList != null &&
      this.globalActivitiesList.length > 0
    ) {
      activities.forEach((el) => {
        this.globalActivitiesTableData.push([
          new TableItem({ data: el.id }),
          new TableItem({ data: el, template: this.customHeaderDoc }),
          new TableItem({ data: el.type.type }),
          new TableItem({ data: el.category.name }),
          new TableItem({ data: el.name }),
          new TableItem({ data: el.region }),
          new TableItem({ data: el.currency }),
          new TableItem({ data: el.totalVariableCost }),
          new TableItem({ data: el.price }),
        ]);
      });
    }
    this.initializeGlobalActivitiesTable();
    this.showSkeleton = false;
  }

  onSearch(event) {
    let filteredActivityList = this.globalActivitiesList;
    if (!this.angularUtility.isEmptyOrSpaces(event)) {
      filteredActivityList = this.globalActivitiesList.filter((x) => {
        return (
          x.name?.toLocaleLowerCase().includes(event.toLocaleLowerCase()) ||
          x.type.type
            ?.toLocaleLowerCase()
            .includes(event.toLocaleLowerCase()) ||
          x.currency?.toLocaleLowerCase().includes(event.toLocaleLowerCase()) ||
          x.region?.toLocaleLowerCase().includes(event.toLocaleLowerCase()) ||
          x.totalVariableCost
            ?.toLocaleLowerCase()
            .includes(event.toLocaleLowerCase()) ||
          x.category.name
            ?.toLocaleLowerCase()
            .includes(event.toLocaleLowerCase())
        );
      });
    }

    this.populateGlobalActivitiesTable(filteredActivityList);
    this.initializeGlobalActivitiesTable();
  }

  onClearSearch() {
    this.searchString = '';
    return '';
  }

  onToggleGlobalActivityCheckBox(event, data) {
    if (event.checked == true) {
      this.globalActivitiesToBeAssigned_List.push(data);
    } else {
      var newlist = this.globalActivitiesToBeAssigned_List.filter(
        (s) => s.id != data.id
      );
      this.globalActivitiesToBeAssigned_List = newlist;
    }
  }

  addSelectedActivities() {
    this.loaderService.show();
    this.globalActivitiesToBeAssigned_List.forEach((item) => {
      item.contractId = this.proposalId;
    });

    this.activityService
      .saveActivities(this.globalActivitiesToBeAssigned_List)
      .subscribe({
        next: (res: any) => {
          this.loaderService.hide();
          const isSuccess = res.some((result) => result.statusCode == 200)
          if (isSuccess) {
            this.toastr.success("Activities save successfully");
          }
          else {
            this.toastr.error("Activities already exist");
          }
          this.toggleGlobalActivitiesModal(false);
          this.globalActivitiesToBeAssigned_List = [];
          this.getProposalActivities();
        },
        error: (err) => {
          this.loaderService.hide();
          this.toastr.error(err.error.message);
        },
        complete: () => { },
      });
  }

  cancelAssigningofActivities() {
    this.toggleGlobalActivitiesModal(false);
  }

  onDeactivateContractActivity(data: any) {
    this.isOpenDeactivateContractActivityModal = true;
    this.currentContractActivityToDeactivate = data.data;
    console.log(this.currentContractActivityToDeactivate);
  }

  onDeactivateContractActivityConfirm() {
    this.currentContractActivityToDeactivate.deactivated = true;
    this.activityService
      .updateActivity(this.currentContractActivityToDeactivate)
      .subscribe({
        next: (res) => {
            this.toastr.success('Activity deactivated successfully');
            this.isOpenDeactivateContractActivityModal = false;
            this.getProposalActivities();
            this.getGlobalActivities();
        },
        error: (err) => {
          this.toastr.error('Something went wrong');
          console.log(err);
        },
      });
  }

  populateFilterDropdowns(activities: any) {
    var categories = activities.map((s) => s.category);
    this.categoryFilterList = [];
    var cat = {
      id: 0,
      name: '[SELECT]',
    };
    this.categoryFilterList.push(cat);
    categories.forEach((element) => {
      var addedList = this.categoryFilterList.filter((s) => s.id == element.id);
      if (addedList.length <= 0) {
        this.categoryFilterList.push(element);
      }
    });

    var types = activities.map((s) => s.type);
    this.typeFilterList = [];
    var type = {
      id: 0,
      type: '[SELECT]',
    };
    this.typeFilterList.push(type);
    types.forEach((element) => {
      var addedList = this.typeFilterList.filter((s) => s.id == element.id);
      if (addedList.length <= 0) {
        this.typeFilterList.push(element);
      }
    });

    var names = activities.map((s) => s.name);
    this.nameFilterList = [];
    for (let index = 0; index < names.length; index++) {
      const element = names[index];
      var addedList = this.nameFilterList.filter((s) => s == element);
      if (addedList.length <= 0) {
        this.nameFilterList.push(element);
      }
    }

    var regions = activities.map((s) => s.region);
    this.regionFilterList = [];
    for (let index = 0; index < regions.length; index++) {
      const element = regions[index] == null ? '' : regions[index];
      var addedList = this.regionFilterList.filter((s) => s == element);
      if (addedList.length <= 0) {
        this.regionFilterList.push(element);
      }
    }

    var currencies = activities.map((s) => s.currency);
    this.currencyFilterList = [];
    for (let index = 0; index < currencies.length; index++) {
      const element = currencies[index] == null ? '' : currencies[index];
      var addedList = this.currencyFilterList.filter((s) => s == element);
      if (addedList.length <= 0) {
        this.currencyFilterList.push(element);
      }
    }

    var totalvariablecosts = activities.map((s) => s.totalVariableCost);
    this.totalVariableCostFilterList = [];
    for (let index = 0; index < totalvariablecosts.length; index++) {
      const element =
        totalvariablecosts[index] == null
          ? '<blank>'
          : totalvariablecosts[index];
      var addedList = this.totalVariableCostFilterList.filter(
        (s) => s == element
      );
      if (addedList.length <= 0) {
        this.totalVariableCostFilterList.push(element);
      }
    }
  }

  onChangeFilter_Type(event) {
    var selectedCategory = event;
    this.Filter_CurrentSelectedTypeId = selectedCategory.id;
    this.filterActivityList();
  }
  onChangeFilter_Category(event) {
    var selectedCategory = event;
    this.Filter_CurrentSelectedCategoryId = selectedCategory.id;
    this.filterActivityList();
  }
  onChangeFilter_Name(event) {
    this.Filter_CurrentSelectedName = event;
    this.filterActivityList();
  }
  onChangeFilter_Region(event) {
    this.Filter_CurrentSelectedRegion = event;
    this.filterActivityList();
  }
  onChangeFilter_Currency(event) {
    this.Filter_CurrentSelectedCurrency = event;
    this.filterActivityList();
  }
  onChangeFilter_TotalVariableCost(event) {
    this.Filter_CurrentSelectedTotalVariableCost = event;
    this.filterActivityList();
  }

  filterActivityList() {
    var newlist: any = [];
    if (this.Filter_CurrentSelectedTypeId > 0) {
      newlist = this.globalActivitiesList.filter(
        (s) => s.type.id == this.Filter_CurrentSelectedTypeId
      );
      this.populateGlobalActivitiesTable(newlist);
    }

    if (this.Filter_CurrentSelectedCategoryId > 0) {
      newlist = this.globalActivitiesList.filter(
        (s) => s.category.id == this.Filter_CurrentSelectedCategoryId
      );
      this.populateGlobalActivitiesTable(newlist);
    }

    if (this.Filter_CurrentSelectedName != null) {
      newlist = this.globalActivitiesList.filter(
        (s) => s.name == this.Filter_CurrentSelectedName
      );
      this.populateGlobalActivitiesTable(newlist);
    }

    if (this.Filter_CurrentSelectedRegion != null) {
      newlist = this.globalActivitiesList.filter(
        (s) => s.region == this.Filter_CurrentSelectedRegion
      );
      this.populateGlobalActivitiesTable(newlist);
    }

    if (this.Filter_CurrentSelectedCurrency != null) {
      newlist = this.globalActivitiesList.filter(
        (s) => s.currency == this.Filter_CurrentSelectedCurrency
      );
      this.populateGlobalActivitiesTable(newlist);
    }

    if (this.Filter_CurrentSelectedTotalVariableCost > 0) {
      newlist = this.globalActivitiesList.filter(
        (s) => s.totalVariableCost == this.Filter_CurrentSelectedTotalVariableCost
      );
      this.populateGlobalActivitiesTable(newlist);
    }
  }

  initilizeFilterForm() {
    this.filterForm = this.formBuilder.group({
      typeId: [0],
      categoryId: [0],
      name: [null],
      region: [null],
      currencyId: [null],
      totalVariableCostId: [null],
    });
  }

  clearFilter() {
    this.filterDropdown.forEach((e) => e.handleClearClick());
    this.filterForm.controls['typeId'].setValue(0);
    this.filterForm.controls['categoryId'].setValue(0);
    this.filterForm.controls['name'].setValue(null);
    this.filterForm.controls['region'].setValue(null);
    this.filterForm.controls['currencyId'].setValue(null);
    this.filterForm.controls['totalVariableCostId'].setValue(0);
    this.Filter_CurrentSelectedTypeId = 0;
    this.Filter_CurrentSelectedCategoryId = 0;
    this.Filter_CurrentSelectedName = null;
    this.Filter_CurrentSelectedRegion = null;
    this.Filter_CurrentSelectedCurrency = null;
    this.Filter_CurrentSelectedTotalVariableCost = 0;
    this.getGlobalActivities();
  }

  closeActivityModel() {
    this.isOpenAddActivityModel = false;
  }

  addNewActivity() {
    this.isOpenAddActivityModel = true;
  }

  assignExisitingActivity() {
    this.isOpenGlobalActivitiesModal = true;
    this.isOpenAddActivityModel = false;
  }

  openAddNewActivityModel() {
    this.isOpenAddNewActivityModel = true;
  }

  closeAddNewActivityModel() {
    this.isCancelAddNewActivityModel = true;
  }

  openCancelConfirmationModel() {
    this.activityFormValidation = true;
    this.activityForm = '';
    this.isOpenAddNewActivityModel = false;
    this.isCancelAddNewActivityModel = false;
    this.isOpenAddActivityModel = false;
  }

  closeCancelConfirmationModel() {
    this.isCancelAddNewActivityModel = false;
  }

  openResourceModel() {
    let activityData = {
      data: this.activityForm,
      contractId: this.proposalId
    }
    this.modalService.create({
      component: ActivityResourcesComponent,
      inputs: { data: activityData, activityId: this.activityId, resourceEdit: false, addContractActivityResource: true },
    }).instance.emitModel.subscribe(res => {
      this.isOpenAddNewActivityModel = false;
      this.isOpenAddActivityModel = false;
      this.activityForm = '';
      this.activityFormValidation = true;
      this.getProposalActivities();
    })
  }

  FormValue(event?: any) {
    this.activityForm = event;
  }

  emitFormValidation(event) {
    if (event === "VALID") this.activityFormValidation = false;
  }
}
