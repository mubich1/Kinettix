import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';
import { Client } from 'src/app/models/client/client';
import { Contracts } from 'src/app/models/contract/contract';
import { TicketFinancialsDto } from 'src/app/models/deliveryContract/delivery-contract.model';
import { ClientService } from 'src/app/services/client/client.service';
import { ContractService } from 'src/app/services/contract/contract.service';
import { DeliveryContractService } from 'src/app/services/deliveryContract/delivery-contract.service';
import { LoaderService } from 'src/app/services/loader/loader.service';
import { TeamService } from 'src/app/services/teams/team.service';
import { UserService } from 'src/app/services/user/user.service';

@Component({
  selector: 'app-contract-financials',
  templateUrl: './contract-financials.component.html',
  styleUrls: ['./contract-financials.component.css']
})
export class ContractFinancialsComponent implements OnInit {

  @ViewChild('customHeaderTemplate', { static: true })
  customHeaderTemplate: ElementRef;
  @ViewChild('customItemNameTemplate', { static: true })
  customItemNameTemplate: ElementRef;
ContractTitle: string="";
ContractID:number=0;
ConHubSpotID: string="";
ConProductType: string="";
ConEntityInvoice: string="";
Platform: string="";
SecondaryClient: string="";
OnsiteEntity: string="";
conAccExecutive?: string="";
conAccManager?: string="";
pmoLead?: string="";
backupPmoLead?: string="";
fsoLead?: string="";
preVisitTeam?: string="";
dayOfTeam?: string="";

OverView:string="";
endDate:Date;
contractId:number=0;
clientId:number=0;

contractDetailEdit:boolean=false;
clientRelationEdit:boolean=false;
deliveriesEdit:boolean=false;
pmoList:any[];
fsoList:any[];
backupPmoList:any[];
preVisitTeamList:any[];
accExecutiveList:any[];
accMgrList:any[];
dayTeamList:any[];
categoryList:any[];
contractForm: FormGroup;
isAddEdit = false;
userId:string;
grossProfitDiffInAmount:boolean=false;
grossMarginDiffInPercent:boolean=false;
netIncomeDiffInAmount:boolean=false;
netMarginDiffInPercent:boolean=false;
clients: Client[] = [];

contractFinancials:TicketFinancialsDto;
isContractFinancialsAvailable:boolean = false;
ngUnsubscribe = new Subject<void>();
  constructor(
    private route: ActivatedRoute,
    private clientService: ClientService,
    private contractService: ContractService,
    private teamService: TeamService,
    private toaster: ToastrService,
    private formBuilder: FormBuilder,
    private router: Router,
    private loaderService: LoaderService,
    private deliveryService:DeliveryContractService,
    private userService: UserService) { }

  ngOnInit(): void {
    this.route.parent?.params.subscribe((params: any) => {
      if (params.hasOwnProperty('clientId')) {
        this.clientId = params['clientId'];
        //this.loadContract(this.contractId);
      }
    });
    this.route.parent?.params.subscribe((params: any) => {
      if (params.hasOwnProperty('contractId')) {
        this.contractId = params['contractId'];
        this.userId = JSON.parse(localStorage.getItem('userId') || '{}');
        this.createForm();
        this.getContractById(this.contractId);
        this.getAllUsers();
        this.getAllTeams();
        this.getAllClients();
        this.getContractFinancials(params['contractId']);
      }
    });
  }

  getContractFinancials(contractId:number){
    this.loaderService.show();
    this.deliveryService.getContractFinancialsById(contractId).subscribe({
      next:(res)=>{
        this.contractFinancials = res.results
        this.isContractFinancialsAvailable = true;
        console.log(this.contractFinancials);
        if(this.contractFinancials.deltaDto.grossMarginDiffInPercent!=null && this.contractFinancials.deltaDto.grossMarginDiffInPercent<0)
        {
          this.grossMarginDiffInPercent=true;
          this.contractFinancials.deltaDto.grossMarginDiffInPercent=this.contractFinancials.deltaDto.grossMarginDiffInPercent*-1;
        }
        if(this.contractFinancials.deltaDto.grossProfitDiffInAmount!=null && this.contractFinancials.deltaDto.grossProfitDiffInAmount<0)
        {
          this.grossProfitDiffInAmount=true;
          this.contractFinancials.deltaDto.grossProfitDiffInAmount=this.contractFinancials.deltaDto.grossProfitDiffInAmount* -1;
        }
        if(this.contractFinancials.deltaDto.netIncomeDiffInAmount!=null && this.contractFinancials.deltaDto.netIncomeDiffInAmount<0)
        {
          this.netIncomeDiffInAmount=true;
          this.contractFinancials.deltaDto.netIncomeDiffInAmount=this.contractFinancials.deltaDto.netIncomeDiffInAmount* -1;
        }
        if(this.contractFinancials.deltaDto.netMarginDiffInPercent!=null && this.contractFinancials.deltaDto.netMarginDiffInPercent<0)
        {
          this.netMarginDiffInPercent=true;
          this.contractFinancials.deltaDto.netMarginDiffInPercent=this.contractFinancials.deltaDto.netMarginDiffInPercent* -1;
        }
        this.loaderService.hide();
      },
      error:(err)=>{
        this.toaster.error('Something went wrong.');
        this.loaderService.hide();
      }
    })
  }
  createForm(){
    this.contractForm = this.formBuilder.group({
      id: [null],
      accExecutive: ['null'],
      accMgr: ['null'],
      pmoLead:[null],
      backupPmoLead:[null],
      fsoLead:[null],
      pvisitTeam:[null],
      dayTeam:[null],
      title:[null],
      overview:[null],
      startDate:[null],
      endDate:[null],
      onsiteEntity:[null],
      secondaryClient:[null],
      platform:[null],

    });
  }
  onCancel() {
    this.isAddEdit = false;
    //this.contractForm.reset();
  }
  getAllUsers() {
    this.userService.getUsers()
      .pipe(takeUntil(this.ngUnsubscribe)).subscribe({
        next: res => {
          this.pmoList = res.results.data;
          this.fsoList=res.results.data;
          this.backupPmoList=res.results.data;
          this.accExecutiveList=res.results.data;
          this.accMgrList=res.results.data;
        },
        error: e => console.log("Error while loading",e)
      })
  }

  getAllTeams() {
    this.teamService.getTeams()
      .pipe(takeUntil(this.ngUnsubscribe)).subscribe({
        next: res => {
          this.preVisitTeamList = res.results;
          this.dayTeamList=res.results;
          console.log("res", res);
        },
        error: e => console.log("Error while loading",e)
      })
  }

  onEdit() {
    this.contractService.getContractById(this.contractId)
      .pipe(takeUntil(this.ngUnsubscribe)).subscribe(res => {
        if (res.statusCode == 200 && res.results != null) {
          this.contractForm.patchValue({
            id: res.results.id,
            accExecutive:res.results.accExecutiveId,
            accMgr:res.results.accMgrId,
            pmoLead: res.results.pmoleadId,
            fsoLead:res.results.fsoleadId,
            backupPmoLead:res.results.backupPmoleadId,
            pvisitTeam:res.results.preVisitTeamId,
            dayTeam:res.results.dayOfVisitTeamId,
            title:res.results.title,
            startDate:new Date(res.results.startDate!),
            onsiteEntity:res.results.onsiteEntity,
            secondaryClient:res.results.secondaryClient,
            platform:res.results.platform,
            overview:res.results.overView,
            endDate:res.results.endDate,



          });

        }
      });
      this.contractDetailEdit=true;
      this.clientRelationEdit=true;
      this.deliveriesEdit=false;
    this.isAddEdit = true;
  }

  onContractDetailEdit() {
    this.contractService.getContractById(this.contractId)
      .pipe(takeUntil(this.ngUnsubscribe)).subscribe(res => {
        if (res.statusCode == 200 && res.results != null) {
          this.contractForm.patchValue({
            id: res.results.id,
            accExecutive:res.results.accExecutiveId,
            accMgr:res.results.accMgrId,
            pmoLead: res.results.pmoleadId,
            fsoLead:res.results.fsoleadId,
            backupPmoLead:res.results.backupPmoleadId,
            pvisitTeam:res.results.preVisitTeamId,
            dayTeam:res.results.dayOfVisitTeamId,
            title:res.results.title,
            startDate:new Date(res.results.startDate!),
            onsiteEntity:res.results.onsiteEntity,
            secondaryClient:res.results.secondaryClient,
            platform:res.results.platform,
            overview:res.results.overView,
            endDate:res.results.endDate,


          });

        }
      });
      this.contractDetailEdit=false;;
      this.clientRelationEdit=true;
      this.deliveriesEdit=true;
    this.isAddEdit = true;
  }

  onClientRelationEdit() {
    this.contractService.getContractById(this.contractId)
      .pipe(takeUntil(this.ngUnsubscribe)).subscribe(res => {
        if (res.statusCode == 200 && res.results != null) {
          this.contractForm.patchValue({
            id: res.results.id,
            accExecutive:res.results.accExecutiveId,
            accMgr:res.results.accMgrId,
            pmoLead: res.results.pmoleadId,
            fsoLead:res.results.fsoleadId,
            backupPmoLead:res.results.backupPmoleadId,
            pvisitTeam:res.results.preVisitTeamId,
            dayTeam:res.results.dayOfVisitTeamId,
            title:res.results.title,
            startDate:new Date(res.results.startDate!),
            onsiteEntity:res.results.onsiteEntity,
            secondaryClient:res.results.secondaryClient,
            platform:res.results.platform,
            overView:res.results.overView,
            endDate:res.results.endDate,


          });

        }
      });
      this.contractDetailEdit=true;
      this.clientRelationEdit=false;
      this.deliveriesEdit=true;

    this.isAddEdit = true;
  }
   ///** Get Clients START  */
   getAllClients() {
    this.clientService.getAllClients().subscribe((res) => {
      if (res.statusCode == 200) {
        this.clients = res.results.sort((a, b) => a.name.localeCompare(b.name));
      } else {
        this.toaster.error('Something went wrong while loading clients');
      }
    });
  }
  ///** Get Clients  END  */
  getContractById(contractId:number)
  {
    this.contractService.getContractById(contractId)
      .pipe(takeUntil(this.ngUnsubscribe)).subscribe(res => {

        this.conAccExecutive=res.results.accExecutiveName;
        this.conAccManager=res.results.accMgrName;
        this.pmoLead=res.results.pmoleadName;
        this.fsoLead=res.results.fsoleadName;
        this.backupPmoLead=res.results.backupPmoleadName;
        this.preVisitTeam=res.results.preVisitTeamName;
        this.dayOfTeam=res.results.dayOfVisitTeamName,
        this.ContractTitle=res.results.title!
        this.OnsiteEntity=res.results.onSiteEntityName!
        this.SecondaryClient=res.results.secondryClientName!
        this.SecondaryClient=res.results.secondryClientName!
        this.Platform=res.results.platFromClientName!;
        this.OverView=res.results.overView!;
        this.endDate=res.results.endDate!;


      });
  }

  onSubmit(){

    if(!this.contractForm.valid){
      return;
    }
    else{
      const template: Contracts = {
        id: this.contractId,
        accExecutiveId:this.contractForm.value.accExecutive,
        accMgrId:this.contractForm.value.accMgr,
        pmoleadId: this.contractForm.value.pmoLead,
        fsoleadId: this.contractForm.value.fsoLead,
        preVisitTeamId: this.contractForm.value.pvisitTeam,
        dayOfVisitTeamId: this.contractForm.value.dayTeam,
        backupPmoleadId:this.contractForm.value.backupPmoLead,
        modifiedBy:this.userId,
        title: this.contractForm.value.title,
        startDate: new Date(this.contractForm.value.startDate!),
        onsiteEntity:this.contractForm.value.onsiteEntity,
        secondaryClient:this.contractForm.value.secondaryClient,
        platform:this.contractForm.value.platform,
        overView:this.contractForm.value.overview,
        endDate: new Date(this.contractForm.value.endDate!),
      };
      if (template.id != null && template.id > 0)
      {
        this.contractService.updateClientContract(this.contractId,template)
        .subscribe({next:(res) => {
          this.isAddEdit=false;
          this.handleSaveSuccess();
          },
          error: (err) => {
            this.handleSaveError(err);
          }
        });
      }
    }
  }

  handleSaveSuccess() {
    this.loaderService.hide();
    this.toaster.success(`Details updated successfully.`);
    this.getContractById(this.contractId)
  }

  handleSaveError(err: any) {
    this.loaderService.hide();
    const message = 'Error occurred in updating information.';
    this.toaster.error((err.error.message || message), 'Error');
  }

}
