import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContractFinancialsComponent } from './contract-financials.component';

describe('ContractFinancialsComponent', () => {
  let component: ContractFinancialsComponent;
  let fixture: ComponentFixture<ContractFinancialsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContractFinancialsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContractFinancialsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
