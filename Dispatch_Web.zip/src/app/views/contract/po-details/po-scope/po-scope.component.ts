import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';
import { ContractTicketSchedule } from 'src/app/models/deliveryContract/delivery-contract.model';
import {
  ActivityCompetency,
  POScope,
} from 'src/app/models/purchaseOrder/purchase-order';
import { PurchaseOrderService } from 'src/app/services/purchase-order/purchase-order.service';
import { TicketService } from 'src/app/services/ticket/ticket.service';

@Component({
  selector: 'app-po-scope',
  templateUrl: './po-scope.component.html',
  styleUrls: ['./po-scope.component.css'],
})
export class PoScopeComponent implements OnInit {
  ngUnsubscribe = new Subject<void>();
  @Output() savePoScope = new EventEmitter();
  @Output() onClose = new EventEmitter();
  @Input() poId: number;
  @Input() set poScope(poScope: POScope) {
    this.getScope();
    if (poScope) {
      this.selectedScheduleId = poScope.ticketScheduleId;
      this.isEditorValidated(poScope.scope, false);
      this.isEditorValidated(poScope.specialInstructions, false);
      this.initializeForm(poScope);
    } else {
      this.form?.reset();
    }
  }
  @Input() activityCompetencies: ActivityCompetency[];
  @Input() tinyMCESettings;
  @Input() tinyMCECApiKey: string;
  @Input() set isClosed(isClosed: boolean) {
    this.form?.reset();
  }
  isScopeValid: boolean = true;
  isInstructionValid: boolean = true;
  form: FormGroup;
  ticketId: number = 0;
  ticketSchedules: ContractTicketSchedule[] = [];
  selectedScheduleId: number = 0;
  constructor(
    private formBuilder: FormBuilder,
    private ticketService: TicketService,
    private route: ActivatedRoute,
    private toastr: ToastrService,
    private poScopeService: PurchaseOrderService
  ) {

  }

  ngOnInit(): void {
    this.initializeForm();
    this.getTicketIdFromRoute();
    this.getTicketSchedulesByTicketId()
  }

  getTicketIdFromRoute() {
    this.route.parent?.parent?.params.subscribe((params: any) => {
      if (params.hasOwnProperty('ticketId')) {
        this.ticketId = params['ticketId'];
      }
    });
  }

  initializeForm(poScope?) {
    this.form = this.formBuilder.group({
      ticketScheduleId: [poScope?.ticketScheduleId ? poScope.ticketScheduleId : null, Validators.required],
      scope: [poScope?.scope ? poScope?.scope : null, Validators.required],
      activityCompetencyIds: [poScope?.competencies ? poScope.competencies?.map((item) => item.id) : null],
      specialInstructions: [poScope?.specialInstructions ? poScope.specialInstructions : null, Validators.required],
    });
  }

  get registerFormControl() {
    return this.form?.controls;
  }

  onSubmit(form) {
    if (this.selectedScheduleId <= 0 || this.selectedScheduleId.toString() == "") {
      this.toastr.error('Please select a schedule')
      return;
    }
    const formData = this.setFormData(form);
    this.savePoScope.emit(formData);
  }

  closeModal() {
    this.onClose.emit();
    this.form.reset();
  }

  isEditorValidated(value?: string, isScope?: boolean) {
    const editorValue = value?.replace(/<[^>]*>|&nbsp;|\s/g, '');
    const isValid = editorValue?.length ? true : false;
    isScope
      ? (this.isScopeValid = isValid)
      : (this.isInstructionValid = isValid);
  }

  setFormData(form) {
    return {
      ticketScheduleId: this.selectedScheduleId,
      competencies: this.setSelectedCompetencies(form.value.activityCompetencyIds),
      specialInstructions: form.value.specialInstructions,
      scope: form.value.scope,
    };
  }

  setSelectedCompetencies(activityCompetencyIds) {
    let selectedCompetencies: ActivityCompetency[] = [];
    this.activityCompetencies.forEach((item: any) => {
      activityCompetencyIds.forEach((x: any) => {
        if (item.id == x) {
          selectedCompetencies.push(item);
        }
      })
    })
    return selectedCompetencies;

  }


  getTicketSchedulesByTicketId() {
    this.ticketService
      .GetTicketSchedule(this.ticketId)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          this.ticketSchedules = res.results;
        },
        error: (e) => { },
        complete: () => { },
      });
  }

  onSelectedSchedule(event: any) {
    this.selectedScheduleId = event.target.value
  }

  getDateString(dateTime: Date) {
    var date = new Date(dateTime).toLocaleDateString();
    var time = new Date(dateTime).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    return `${date}-${time}`;
  }
  getScope() {
    this.poScopeService.getPoScope(this.poId).subscribe(po => {
      if (po) {
        this.initializeForm(po.results);
      }
    });
  }
}
