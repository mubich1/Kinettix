import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PoScopeComponent } from './po-scope.component';

describe('PoScopeComponent', () => {
  let component: PoScopeComponent;
  let fixture: ComponentFixture<PoScopeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PoScopeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PoScopeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
