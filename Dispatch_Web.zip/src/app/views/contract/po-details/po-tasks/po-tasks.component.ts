import { DatePipe } from '@angular/common';
import { HttpStatusCode } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';
import { PoTaskDto, SavePoMilestoneAssignUserDto, MilestoneStatusEnum, TaskStatusIdEnum, MilestoneStatusIdEnum, POStatus } from 'src/app/models/po-task/po-tasks';
import { TicketMilestoneStatus } from 'src/app/models/tickets/tickets';
import { LoaderService } from 'src/app/services/loader/loader.service';
import { PoTaskService } from 'src/app/services/po-task/po-task.service';
import { UserService } from 'src/app/services/user/user.service';

@Component({
  selector: 'app-po-tasks',
  templateUrl: './po-tasks.component.html',
  styleUrls: ['./po-tasks.component.css', './po-tasks.component.scss'],
})
export class PoTasksComponent implements OnInit {
  @Input() set poDetails(poDetails: any) {
    if (poDetails) {
      console.log('poDetails: ', poDetails);
      this.poId = poDetails.id
      this.getAllTasks();
    }
  };

  tasks: PoTaskDto[];
  poId: number;
  users: any;
  ngUnsubscribe = new Subject<void>();
  assignUser: SavePoMilestoneAssignUserDto;
  failMilestone: any;
  completeMilestone: any;
  assignForm: FormGroup;
  completeForm: FormGroup;
  failForm: FormGroup;
  submitted: boolean;
  contractId: number = 0;
  ticketId: number = 0;
  userId: any;
  isDeleteOpen: boolean = false;
  milestones: any[] = [];
  payloadTasks: any[] = [];
  selectedTask: any;
  isAllowToAddTask: boolean = false;
  getAllTask: any;
  deletedTask: any;
  statusId: number;
  defaultValue = '';
  stagedTasks: any[] = [];
  inWorkTasks: any[] = [];
  wrapUpTasks: any[] = [];
  poStatusId: number;
  isOpenTaskModal = false;
  isOpenTaskDeleteConfirmationModal = false;
  currentSelectedContractTask: any;
  currentSelectedActiveContractTask: any;
  stagedStatus: boolean = false;
  inWorkStatus: boolean = false;
  wrapUpStatus: boolean = false;
  isStagedDelete: boolean = false;
  isWrapUpDelete: boolean = false;
  isInWorkDelete: boolean = false;
  taskStatus = TaskStatusIdEnum;
  activeCard: string;
  cards = {
    staged: POStatus.Draft,
    inWork: POStatus.InWork,
    wrapUp: POStatus.WrapUp,
    completed: POStatus.Complete,
  };
  isStagedCompleted: boolean = true;
  isInworkCompleted: boolean = false;
  isWrapupCompleted: boolean = false;
  isDisabled: boolean = true;

  isAssign: boolean = false;
  isComplete: boolean = false;
  isFail: boolean = false;
  completionDate: any;
  dateFormat = 'm/d/Y';
  language = 'en';
  completeStatus: boolean = false;
  milestoneStatusEnum = MilestoneStatusEnum;
  actionTaskId = 0;

  constructor(
    public datepipe: DatePipe,
    private loaderService: LoaderService,
    private poTaskService: PoTaskService,
    private userService: UserService,
    private toastr: ToastrService,
    private route: ActivatedRoute,
  ) {
    this.userId = JSON.parse(localStorage.getItem('userId') || '{}');
    this.route.parent?.parent?.params.subscribe((params: any) => {
      if (params.hasOwnProperty('ticketId')) {
        this.contractId = params['contractId'];
        this.ticketId = params['ticketId'];
      }
    });
  }

  ngOnInit(): void {
    this.activeCard = this.cards.staged;
    this.getAllUsers();
  }



  getAllTasks() {
    this.loaderService.show();
    this.poTaskService.getTasks(this.poId).subscribe((res) => {
      this.getAllTask = res.results;
      console.log('this.getAllTask: ', this.getAllTask);
      this.getPoTasks();
    });
  }


  getPoTasks() {
    this.loaderService.show();
    this.poTaskService.getPoTasks(this.poId).subscribe({
      next: (res) => {
        this.loaderService.hide();
        
        this.stagedTasks = this.filterByStatus(res.results.tasks, TicketMilestoneStatus.Staged);
        this.inWorkTasks = this.filterByStatus(res.results.tasks, TicketMilestoneStatus.InWork);
        this.wrapUpTasks = this.filterByStatus(res.results.tasks, TicketMilestoneStatus.WrapUp);
        this.checkStatusOnCompletion(false);
      },
      error: (e) => {
        this.loaderService.hide();
        this.handleError(e);
      },
      complete: () => { },
    });
  }


  onCardSelection(card) {
    this.activeCard = card;
  }

  public OnSelectTask(task: any): void {
    if (task) {
      this.getAllTask.forEach((item) => (item.selected = false));
      task.selected = true;
      this.selectedTask = task;
      this.isAllowToAddTask = true;
    }
  }

  public AddTask(status: number): void {
    this.isAllowToAddTask = false;
    this.defaultValue = '';

    const payload = {
      poId: this.poId,
      poTaskId: 0,
      statusId: status,
      taskId: this.selectedTask.id,
      poMilestones: this.selectedTask.milestones.map((milestone) => {
        return {
          poMilestoneId: 0,
          milestoneId: milestone.id,
        };
      }),
    };
    this.loaderService.show();
    this.poTaskService.saveTask(this.poId, payload).subscribe({
      next: (res) => {
        this.loaderService.hide();

        this.selectedTask.poTaskId = res.results.poTaskId;
        res.results.poMilestones.forEach((response) => {
          this.selectedTask.milestones.forEach((milestone) => {
            if (milestone.id == response.milestoneId) {
              milestone.poMilestoneId = response.poMilestoneId;
              milestone.statusId = response.milestoneStatusId;
              milestone.status = this.getMileStoneStatus(response.milestoneStatusId);
            }
          });
        });
        switch (status) {
          case TicketMilestoneStatus.Staged:
            this.stagedTasks.push({ ...this.selectedTask, statusId: status });

            break;
          case TicketMilestoneStatus.InWork:
            this.inWorkTasks.push({ ...this.selectedTask, statusId: status });
            this.isStagedDelete = true;
            break;
          case TicketMilestoneStatus.WrapUp:
            this.wrapUpTasks.push({ ...this.selectedTask, statusId: status });
            this.isStagedDelete = true;
            this.isInWorkDelete = true;
            break;

          default:
            break;
        }
        this.checkStatusOnCompletion();

      },
      error: (e) => {
        this.loaderService.hide();
        this.handleError(e);
      },
      complete: () => { },
    });
    this.isOpenTaskModal = false
  }

  openTaskListModal(statusId) {
    this.statusId = statusId;
    this.isOpenTaskModal = true;
  }

  onRemoveTaskFromStatus(task: any, statusId) {
    this.statusId = statusId;
    this.deletedTask = task;
    this.isOpenTaskDeleteConfirmationModal = true;
  }

  onRemoveTaskFromStatusConfirm() {
    this.onDelete();
    this.isOpenTaskDeleteConfirmationModal = false
  }

  getMileStoneStatus(statusId) {
    switch (statusId) {
      case 1:
        return 'Active';
      case 2:
        return 'Failed';
      case 3:
        return 'Complete';
      case 4:
        return 'Pending';
      default:
        return '';
    }
  }


  onDelete() {
    const payload = {
      poTaskId: this.deletedTask.poTaskId,
      poMilestoneIds: this.deletedTask.milestones.map((res) => {
        return res.poMilestoneId;
      }),
    };
    this.loaderService.show();
    this.poTaskService
      .deleteTask(this.poId, payload)
      .subscribe({
        next: (res) => {
          this.loaderService.hide();
          this.resetDeletedTaskState();
          switch (this.statusId) {
            case TicketMilestoneStatus.Staged:
              let stagedIndex = this.stagedTasks.findIndex((item) => item.id == this.deletedTask.id);
              if (stagedIndex > -1) {
                this.stagedTasks.splice(stagedIndex, 1);
                this.statusModificationOnDelete(this.stagedTasks, stagedIndex);
              }
              break;
            case TicketMilestoneStatus.InWork:
              let inWorkIndex = this.inWorkTasks.findIndex((item) => item.id == this.deletedTask.id);
              if (inWorkIndex > -1) {
                this.inWorkTasks.splice(inWorkIndex, 1);
                this.statusModificationOnDelete(this.inWorkTasks, inWorkIndex);
              }
              break;
            case TicketMilestoneStatus.WrapUp:
              let index = this.wrapUpTasks.findIndex((item) => item.id == this.deletedTask.id);
              if (index > -1) {
                this.wrapUpTasks.splice(index, 1);
                this.statusModificationOnDelete(this.wrapUpTasks, index);
              }
              break;

            default:
              break;
          }
          this.checkStatusOnCompletion();
        },
        error: (e) => {
          this.loaderService.hide();
          this.handleError(e);
        },
      });

    this.isDeleteOpen = false;
  }

  statusModificationOnDelete(tasks, index) {
    if (tasks.length && tasks[index]?.milestones.length) {
      tasks[index].milestones[0].status = MilestoneStatusEnum.Active;
    }

  }

  resetDeletedTaskState() {
    this.deletedTask.milestones.forEach((milestone, index) => {
      if (index == 0) {
        milestone.status = MilestoneStatusEnum.Active;
        milestone.statusId = MilestoneStatusIdEnum.Active;
        milestone.completedDate = null;
        milestone.completedByName = null;
        milestone.assignToName = null;
        milestone.assignTo = null;
        milestone.failDate = null;
        milestone.failReason = null;
        milestone.failedByName = null;
      } else {
        milestone.status = MilestoneStatusEnum.Pending;
        milestone.statusId = MilestoneStatusIdEnum.Pending;
        milestone.completedDate = null;
        milestone.completedByName = null;
        milestone.assignToName = null;
        milestone.assignTo = null;
        milestone.failDate = null;
        milestone.failReason = null;
        milestone.failedByName = null;
      }
    });
  }

  onAssignSubmit(assignUser: any) {
    const assignedUser = {
      poId: this.poId,
      id: assignUser.potMilestoneId,
      assignTo: assignUser.assignTo,
    };

    const selectedUser = this.users.find((user) => user.id === assignUser.assignTo);
    this.loaderService.show();
    this.poTaskService.saveAssignUser(this.poId, assignedUser).subscribe({
      next: (res) => {
        this.loaderService.hide();
        this.toastr.success('User Assigned Successfully!');

        switch (assignUser.statusId) {
          case TicketMilestoneStatus.Staged:
            this.mapTasksOnUserAssignation(this.stagedTasks, assignUser, selectedUser, res);
            break;
          case TicketMilestoneStatus.InWork:
            this.mapTasksOnUserAssignation(this.inWorkTasks, assignUser, selectedUser, res);
            break;
          case TicketMilestoneStatus.WrapUp:
            this.mapTasksOnUserAssignation(this.wrapUpTasks, assignUser, selectedUser, res);
            break;

          default:
            break;
        }
      },
      error: (err) => {
        this.loaderService.hide();
        this.handleError(err);
      },
    });

  }


  onCompleteSubmit(completeMilestone: any) {
    const completedMilestone = {
      poId: this.poId,
      id: completeMilestone.poMilestoneId,
      completedDate: new Date(completeMilestone.completedDate),
    };

    this.loaderService.show();
    this.poTaskService
      .saveCompleteMilestone(this.poId, completedMilestone)
      .subscribe({
        next: (res) => {
          this.loaderService.hide();
          this.poStatusId = res.results.poStatusId;
          this.toastr.success('Completed Successfully!');

          switch (completeMilestone.statusId) {
            case TicketMilestoneStatus.Staged:
              this.mapTasksOnCompletion(this.stagedTasks, completeMilestone, res);
              break;
            case TicketMilestoneStatus.InWork:
              this.mapTasksOnCompletion(this.inWorkTasks, completeMilestone, res);
              break;
            case TicketMilestoneStatus.WrapUp:
              this.mapTasksOnCompletion(this.wrapUpTasks, completeMilestone, res);
              break;

            default:
              break;
          }
          this.checkStatusOnCompletion();
        },
        error: (err) => {
          this.loaderService.hide();
          this.handleError(err);
        },
      });
  }

  onFailSubmit(failMilestone: any) {
    const failedMilestone = {
      id: failMilestone.poMilestoneId,
      failDate: new Date(failMilestone.failDate),
      failReason: failMilestone.failReason,
    };

    this.loaderService.show();
    this.poTaskService
      .saveFailMilestone(this.poId, failedMilestone)
      .subscribe({
        next: (res) => {
          this.loaderService.hide();
          this.poStatusId = res.results.poStatusId;
          this.toastr.success('Failed Status Updated!');
          switch (failMilestone.statusId) {
            case TicketMilestoneStatus.Staged:
              this.mapTasksOnFail(this.stagedTasks, failMilestone, res);
              break;
            case TicketMilestoneStatus.InWork:
              this.mapTasksOnFail(this.inWorkTasks, failMilestone, res);
              break;
            case TicketMilestoneStatus.WrapUp:
              this.mapTasksOnFail(this.wrapUpTasks, failMilestone, res);
              break;
            default:
              break;
          }
          this.checkStatusOnCompletion();
        },
        error: (err) => {
          this.loaderService.hide();
          this.handleError(err);
        },
      });
  }

  mapTasksOnFail(tasks, failMilestone, res) {
    const index = tasks.findIndex((item) => item.id == failMilestone.taskId);
    tasks = tasks.map((task) => {
      if (task.id === failMilestone.taskId) {
        task.milestones.map((milestone) => {
          if (milestone.id === failMilestone.milestoneId) {
            milestone.status = MilestoneStatusEnum.Failed;
            milestone.statusId = MilestoneStatusIdEnum.Failed;
            milestone.failDate = new Date(res.results.failDate);
            milestone.failReason = res.results.failReason;
            milestone.completedDate = null;
            milestone.failedByName = res.results.failedByName;
            milestone.lastCompletedOrFailedDate = res?.results?.lastCompletedOrFailedDate;
            milestone.assignToName = res?.results?.assignToName;
            milestone.assignTo = res?.results?.assignTo;
          }
        });
        if (task.milestones.length > 1 && failMilestone.milestoneIndex !== task.milestones.length - 1) {
          task.milestones[failMilestone.milestoneIndex + 1].status = MilestoneStatusEnum.Active;
        }
      }

      return task;
    });
    if (this.checkTaskStatus([tasks[index]])) {
      if (tasks && tasks[index + 1]) {
        tasks[index + 1].milestones[0].status = MilestoneStatusEnum.Active;
      }
    }
  }

  mapTasksOnCompletion(tasks, completeMilestone, res) {
    const index = tasks.findIndex((item) => item.id == completeMilestone.taskId);
    tasks = tasks.map((task) => {
      if (task.id === completeMilestone.taskId) {
        task.milestones.map((milestone) => {
          if (milestone.id === completeMilestone.milestoneId) {
            milestone.completedDate = new Date(res.results.completedDate);
            milestone.failDate = null;
            milestone.status = MilestoneStatusEnum.Completed;
            milestone.statusId = MilestoneStatusIdEnum.Completed;
            milestone.completedByName = res?.results?.completedByName;
            milestone.lastCompletedOrFailedDate = res?.results?.lastCompletedOrFailedDate;
            milestone.assignToName = res?.results?.assignToName;
            milestone.assignTo = res?.results?.assignTo;
          }
        });
        if (task.milestones.length > 1 && completeMilestone.milestoneIndex !== task.milestones.length - 1) {
          task.milestones[completeMilestone.milestoneIndex + 1].status = MilestoneStatusEnum.Active;
        }
      }
      return task;
    });
    if (this.checkTaskStatus([tasks[index]])) {
      if (tasks && tasks[index + 1]) {
        tasks[index + 1].milestones[0].status = MilestoneStatusEnum.Active;
      }
    }
  }

  mapTasksOnUserAssignation(tasks, assignUser, selectedUser, res) {
    tasks = tasks.map((task) => {
      if (task.id === assignUser.taskId) {
        task.milestones.map((milestone) => {
          if (milestone.id === assignUser.milestoneId) {
            milestone.assignToName = selectedUser.displayName;
            milestone.assignTo = assignUser.assignTo;
          }
        });
      }
      return task;
    });
  }


  getAllUsers() {
    this.userService
      .getUsers()
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          this.users = res.results.data;
        },
        error: (e) => {
          this.toastr.error('Something went wrong');
        },
        complete: () => { },
      });
  }

  handleError(error: any, message?: string) {
    this.loaderService.hide();
    if (
      error?.error?.statusCode === HttpStatusCode.NotFound ||
      error?.error?.statusCode === HttpStatusCode.Conflict
    ) {
      this.toastr.error(error.error.message, 'Error');
    } else {
      this.toastr.error(message, 'Error');
    }
  }




  filterByStatus(payloadTasks: any, status: TicketMilestoneStatus): any {
    switch (status) {
      case TicketMilestoneStatus.Staged: {
        return payloadTasks.filter(
          (res) => res?.statusId == TicketMilestoneStatus.Staged
        );
      }
      case TicketMilestoneStatus.InWork: {
        return payloadTasks.filter(
          (res) => res?.statusId == TicketMilestoneStatus.InWork
        );
      }
      case TicketMilestoneStatus.WrapUp: {
        return payloadTasks.filter(
          (res) => res?.statusId == TicketMilestoneStatus.WrapUp
        );
      }
    }
  }

  checkTaskStatus(tasks) {
    if (tasks.length == 0) return false;
    let failedMilestoneLength = 0;
    let completedMilestoneLength = 0;
    let totalMilestoneLength = 0;
    tasks.forEach((task) => {
      let completedMilestones = task.milestones.filter((m) => m.statusId === MilestoneStatusIdEnum.Completed);
      let failedMilestones = task.milestones.filter((m) => m.statusId === MilestoneStatusIdEnum.Failed);
      failedMilestoneLength += failedMilestones.length;
      completedMilestoneLength += completedMilestones.length;
      totalMilestoneLength += task.milestones.length;
    });
    if (
      totalMilestoneLength ===
      failedMilestoneLength + completedMilestoneLength
    ) {
      return true;
    } else {
      return false;
    }
  }

  checkStatusOnCompletion(isTaskFetched = true) {
    this.stagedStatus = this.checkTaskStatus(this.stagedTasks);
    this.inWorkStatus = this.checkTaskStatus(this.inWorkTasks);
    this.wrapUpStatus = this.checkTaskStatus(this.wrapUpTasks);

    if (this.inWorkStatus) {
      if (isTaskFetched && this.wrapUpTasks[0]?.milestones[0]?.status == MilestoneStatusEnum.Pending) {
        this.wrapUpTasks[0].milestones[0].status = MilestoneStatusEnum.Active;
        this.wrapUpTasks[0].milestones[0].statusId = MilestoneStatusIdEnum.Active;
      }
      this.isStagedCompleted = true;
      this.isInworkCompleted = true;
      this.isWrapupCompleted = true;
      this.isInWorkDelete = true;
      this.isStagedDelete = true;
      this.isWrapUpDelete = true;
    }
    else if (this.stagedStatus) {
      if (isTaskFetched && this.inWorkTasks[0]?.milestones[0]?.status == MilestoneStatusEnum.Pending) {
        this.inWorkTasks[0].milestones[0].status = MilestoneStatusEnum.Active;
        this.inWorkTasks[0].milestones[0].statusId = MilestoneStatusIdEnum.Active;
      }
      this.isStagedCompleted = true;
      this.isInworkCompleted = true;
      this.isWrapupCompleted = false;
      this.isStagedDelete = true;
    }
    else {
      this.isStagedCompleted = true;
      this.isInworkCompleted = false;
      this.isWrapupCompleted = false;
    }

  }

}
