import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PoMilestonesComponent } from './po-milestones.component';

describe('PoMilestonesComponent', () => {
  let component: PoMilestonesComponent;
  let fixture: ComponentFixture<PoMilestonesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PoMilestonesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PoMilestonesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
