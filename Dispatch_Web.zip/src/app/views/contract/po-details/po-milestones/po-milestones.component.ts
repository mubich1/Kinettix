import { DatePipe } from '@angular/common';
import { HttpStatusCode } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';
import { SavePoTaskAssignUserDto, TaskStatusEnum, TaskStatusIdEnum, MilestoneStatusIdEnum, POStatus } from 'src/app/models/po-milestone/po-milestones';
import { TicketTaskStatus } from 'src/app/models/tickets/tickets';
import { LoaderService } from 'src/app/services/loader/loader.service';
import { PoMilestoneService } from 'src/app/services/po-milestone/po-milestone.service';
import { UserService } from 'src/app/services/user/user.service';

@Component({
  selector: 'app-po-milestones',
  templateUrl: './po-milestones.component.html',
  styleUrls: ['./po-milestones.component.css', './po-milestones.component.scss'],
})

export class PoMilestonesComponent implements OnInit {
  @Input() set poDetails(poDetails: any) {
    if (poDetails) {
      this.poId = poDetails.poId ?? poDetails.id;
      this.getAllMilestones();
    }
  };

  poId: number;
  users: any;
  ngUnsubscribe = new Subject<void>();
  assignUser: SavePoTaskAssignUserDto;
  contractId: number = 0;
  ticketId: number = 0;
  userId: any;
  selectedMilestone: any;
  isAllowToAddMilestone: boolean = false;
  getAllMilestone: any;
  deletedMilestone: any;
  statusId: number;
  stagedMilestones: any[] = [];
  inWorkMilestones: any[] = [];
  wrapUpMilestones: any[] = [];
  poStatusId: number;
  isOpenMilestoneModal = false;
  isOpenMilestoneDeleteConfirmationModal = false;
  stagedStatus: boolean = false;
  inWorkStatus: boolean = false;
  wrapUpStatus: boolean = false;
  isStagedDelete: boolean = false;
  isWrapUpDelete: boolean = false;
  isInWorkDelete: boolean = false;
  milestoneStatus = MilestoneStatusIdEnum;
  activeCard: string;
  cards = {
    staged: POStatus.Draft,
    inWork: POStatus.InWork,
    wrapUp: POStatus.WrapUp,
    completed: POStatus.Complete,
  };
  isStagedCompleted: boolean = true;
  isInworkCompleted: boolean = false;
  isWrapupCompleted: boolean = false;

  selectedMilestonesToBeSaved: any[] = [];
  ngUnsubscribe$: Subject<void> = new Subject<void>();

  constructor(
    public datepipe: DatePipe,
    private loaderService: LoaderService,
    private poMilestoneService: PoMilestoneService,
    private userService: UserService,
    private toastr: ToastrService,
    private route: ActivatedRoute,
  ) {
    this.userId = JSON.parse(localStorage.getItem('userId') || '{}');
    this.route.parent?.parent?.params.subscribe((params: any) => {
      if (params.hasOwnProperty('ticketId')) {
        this.contractId = params['contractId'];
        this.ticketId = params['ticketId'];
      }
    });
  }

  ngOnInit(): void {
    this.activeCard = this.cards.staged;
    this.getAllUsers();
  }

  getAllMilestones() {
    this.loaderService.show();
    this.poMilestoneService.getMilestones(this.poId).subscribe((res) => {
      this.getAllMilestone = res.results;
      this.getPoMilestones();
    });
  }

  getPoMilestones() {
    this.loaderService.show();
    this.poMilestoneService.getPoMilestones(this.poId).subscribe({
      next: (res) => {
        this.loaderService.hide();
        this.stagedMilestones = this.filterByStatus(res.results.milestones, TicketTaskStatus.Staged);
        this.inWorkMilestones = this.filterByStatus(res.results.milestones, TicketTaskStatus.InWork);
        this.wrapUpMilestones = this.filterByStatus(res.results.milestones, TicketTaskStatus.WrapUp);
        this.checkStatusOnCompletion(false);
      },
      error: (e) => {
        this.loaderService.hide();
        this.handleError(e);
      },
      complete: () => { },
    });
  }


  onCardSelection(card) {
    this.activeCard = card;
  }

  public OnSelectMilestone(milestone: any): void {
    if (milestone) {
      this.getAllMilestone.forEach((item) => (item.selected = false));
      milestone.selected = true;
      this.selectedMilestone = milestone;
      this.isAllowToAddMilestone = true;
    }
  }

  public AddMilestone(status: number): void {
    this.isAllowToAddMilestone = false;

    const payload = {
      poId: this.poId,
      poMilestoneId: 0,
      statusId: status,
      milestoneId: this.selectedMilestone.id,
      poTasks: this.selectedMilestone.tasks.map((task) => {
        return {
          poTaskId: 0,
          taskId: task.id
        };
      }),
    };
    this.loaderService.show();
    this.poMilestoneService.saveMilestone(this.poId, payload).subscribe({
      next: (res) => {
        this.loaderService.hide();

        this.selectedMilestone.poMilestoneId = res.results.poMilestoneId;
        res.results.poTasks.forEach((response) => {
          this.selectedMilestone.tasks.forEach((task) => {
            if (task.id == response.taskId) {
              task.poTaskId = response.poTaskId;
              task.statusId = response.taskStatusId;
              task.status = this.getTaskStatus(response.taskStatusId);
            }
          });
        });
        switch (status) {
          case TicketTaskStatus.Staged:
            this.stagedMilestones.push({ ...this.selectedMilestone, statusId: status });

            break;
          case TicketTaskStatus.InWork:
            this.inWorkMilestones.push({ ...this.selectedMilestone, statusId: status });
            this.isStagedDelete = true;
            break;
          case TicketTaskStatus.WrapUp:
            this.wrapUpMilestones.push({ ...this.selectedMilestone, statusId: status });
            this.isStagedDelete = true;
            this.isInWorkDelete = true;
            break;

          default:
            break;
        }
        this.getAllMilestone = this.getAllMilestone.filter(
          (milestone) => milestone.id != this.selectedMilestone.id
        );
        this.checkStatusOnCompletion();

      },
      error: (e) => {
        this.loaderService.hide();
        this.handleError(e);
      },
      complete: () => { },
    });
    this.isOpenMilestoneModal = false
  }

  openMilestoneListModal(statusId) {
    this.statusId = statusId;
    this.isOpenMilestoneModal = true;
  }

  onRemoveMilestoneFromStatus(milestone: any, statusId) {
    this.statusId = statusId;
    this.deletedMilestone = milestone;
    this.isOpenMilestoneDeleteConfirmationModal = true;
  }

  onRemoveMilestoneFromStatusConfirm() {
    this.onDelete();
    this.isOpenMilestoneDeleteConfirmationModal = false
  }

  getTaskStatus(statusId) {
    switch (statusId) {
      case 1:
        return 'Active';
      case 2:
        return 'Failed';
      case 3:
        return 'Complete';
      case 4:
        return 'Pending';
      default:
        return '';
    }
  }


  onDelete() {
    const payload = {
      poMilestoneId: this.deletedMilestone.poMilestoneId,
      poTaskIds: this.deletedMilestone.tasks.map((res) => {
        return res.poTaskId;
      }),
    };
    this.loaderService.show();
    this.poMilestoneService
      .deleteMilestone(this.poId, payload)
      .subscribe({
        next: (res) => {
          this.loaderService.hide();
          this.resetDeletedMilestoneState();
          switch (this.statusId) {
            case TicketTaskStatus.Staged:
              let stagedIndex = this.stagedMilestones.findIndex((item) => item.id == this.deletedMilestone.id);
              if (stagedIndex > -1) {
                this.stagedMilestones.splice(stagedIndex, 1);
                this.statusModificationOnDelete(this.stagedMilestones, stagedIndex);
              }
              break;
            case TicketTaskStatus.InWork:
              let inWorkIndex = this.inWorkMilestones.findIndex((item) => item.id == this.deletedMilestone.id);
              if (inWorkIndex > -1) {
                this.inWorkMilestones.splice(inWorkIndex, 1);
                this.statusModificationOnDelete(this.inWorkMilestones, inWorkIndex);
              }
              break;
            case TicketTaskStatus.WrapUp:
              let index = this.wrapUpMilestones.findIndex((item) => item.id == this.deletedMilestone.id);
              if (index > -1) {
                this.wrapUpMilestones.splice(index, 1);
                this.statusModificationOnDelete(this.wrapUpMilestones, index);
              }
              break;

            default:
              break;
          }
          this.checkStatusOnCompletion();
        },
        error: (e) => {
          this.loaderService.hide();
          this.handleError(e);
        },
      });
  }

  statusModificationOnDelete(milestones, index) {
    if (milestones.length) {
      milestones[index].tasks[0].status = TaskStatusEnum.Active;
    }

  }

  resetDeletedMilestoneState() {
    this.deletedMilestone.tasks.forEach((task, index) => {
      if (index == 0) {
        task.status = TaskStatusEnum.Active;
        task.statusId = TaskStatusIdEnum.Active;
        task.completedDate = null;
        task.completedByName = null;
        task.assignToName = null;
        task.assignTo = null;
        task.failDate = null;
        task.failReason = null;
        task.failedByName = null;
      } else {
        task.status = TaskStatusEnum.Pending;
        task.statusId = TaskStatusIdEnum.Pending;
        task.completedDate = null;
        task.completedByName = null;
        task.assignToName = null;
        task.assignTo = null;
        task.failDate = null;
        task.failReason = null;
        task.failedByName = null;
      }
    });
    this.getAllMilestone.push(this.deletedMilestone);
  }

  onAssignSubmit(assignUser: any) {
    const assignedUser = {
      poId: this.poId,
      id: assignUser.potTaskId,
      assignTo: assignUser.assignTo,
    };

    const selectedUser = this.users.find((user) => user.id === assignUser.assignTo);
    this.loaderService.show();
    this.poMilestoneService.saveAssignUser(this.poId, assignedUser).subscribe({
      next: (res) => {
        this.loaderService.hide();
        this.toastr.success('User Assigned Successfully!');

        switch (assignUser.statusId) {
          case TicketTaskStatus.Staged:
            this.mapMilestonesOnUserAssignation(this.stagedMilestones, assignUser, selectedUser, res);
            break;
          case TicketTaskStatus.InWork:
            this.mapMilestonesOnUserAssignation(this.inWorkMilestones, assignUser, selectedUser, res);
            break;
          case TicketTaskStatus.WrapUp:
            this.mapMilestonesOnUserAssignation(this.wrapUpMilestones, assignUser, selectedUser, res);
            break;

          default:
            break;
        }
      },
      error: (err) => {
        this.loaderService.hide();
        this.handleError(err);
      },
    });

  }


  onCompleteSubmit(completeTask: any) {
    const completedTask = {
      poId: this.poId,
      id: completeTask.poTaskId,
      completedDate: new Date(completeTask.completedDate),
    };

    this.loaderService.show();
    this.poMilestoneService
      .saveCompleteTask(this.poId, completedTask)
      .subscribe({
        next: (res) => {
          this.loaderService.hide();
          this.poStatusId = res.results.poStatusId;
          this.toastr.success('Completed Successfully!');

          switch (completeTask.statusId) {
            case TicketTaskStatus.Staged:
              this.mapMilestoneOnCompletion(this.stagedMilestones, completeTask, res);
              break;
            case TicketTaskStatus.InWork:
              this.mapMilestoneOnCompletion(this.inWorkMilestones, completeTask, res);
              break;
            case TicketTaskStatus.WrapUp:
              this.mapMilestoneOnCompletion(this.wrapUpMilestones, completeTask, res);
              break;

            default:
              break;
          }
          this.checkStatusOnCompletion();
        },
        error: (err) => {
          this.loaderService.hide();
          this.handleError(err);
        },
      });
  }

  onFailSubmit(failTask: any) {
    const failedTask = {
      id: failTask.poTaskId,
      failDate: new Date(failTask.failDate),
      failReason: failTask.failReason,
    };

    this.loaderService.show();
    this.poMilestoneService
      .saveFailTask(this.poId, failedTask)
      .subscribe({
        next: (res) => {
          this.loaderService.hide();
          this.poStatusId = res.results.poStatusId;
          this.toastr.success('Failed Status Updated!');
          switch (failTask.statusId) {
            case TicketTaskStatus.Staged:
              this.mapMilestoneOnFail(this.stagedMilestones, failTask, res);
              break;
            case TicketTaskStatus.InWork:
              this.mapMilestoneOnFail(this.inWorkMilestones, failTask, res);
              break;
            case TicketTaskStatus.WrapUp:
              this.mapMilestoneOnFail(this.wrapUpMilestones, failTask, res);
              break;
            default:
              break;
          }
          this.checkStatusOnCompletion();
        },
        error: (err) => {
          this.loaderService.hide();
          this.handleError(err);
        },
      });
  }

  mapMilestoneOnFail(milestones, failTask, res) {
    const index = milestones.findIndex((item) => item.id == failTask.milestoneId);
    milestones = milestones.map((milestone) => {
      if (milestone.id === failTask.milestoneId) {
        milestone.tasks.map((task) => {
          if (task.id === failTask.taskId) {
            task.status = TaskStatusEnum.Failed;
            task.statusId = TaskStatusIdEnum.Failed;
            task.failDate = new Date(res.results.failDate);
            task.failReason = res.results.failReason;
            task.completedDate = null;
            task.failedByName = res.results.failedByName;
            task.lastCompletedOrFailedDate = res?.results?.lastCompletedOrFailedDate;
            task.assignToName = res?.results?.assignToName;
            task.assignTo = res?.results?.assignTo;
          }
        });
        if (milestone.tasks.length > 1 && failTask.taskIndex !== milestone.tasks.length - 1) {
          milestone.tasks[failTask.taskIndex + 1].status = TaskStatusEnum.Active;
        }
      }

      return milestone;
    });
    if (this.checkMilestoneStatus([milestones[index]])) {
      if (milestones && milestones[index + 1]) {
        milestones[index + 1].tasks[0].status = TaskStatusEnum.Active;
      }
    }
  }

  mapMilestoneOnCompletion(milestones, completeTask, res) {
    const index = milestones.findIndex((item) => item.id == completeTask.milestoneId);
    milestones = milestones.map((milestone) => {
      if (milestone.id === completeTask.milestoneId) {
        milestone.tasks.map((task) => {
          if (task.id === completeTask.taskId) {
            task.completedDate = new Date(res.results.completedDate);
            task.failDate = null;
            task.status = TaskStatusEnum.Completed;
            task.statusId = TaskStatusIdEnum.Completed;
            task.completedByName = res?.results?.completedByName;
            task.lastCompletedOrFailedDate = res?.results?.lastCompletedOrFailedDate;
            task.assignToName = res?.results?.assignToName;
            task.assignTo = res?.results?.assignTo;
          }
        });
        if (milestone.tasks.length > 1 && completeTask.taskIndex !== milestone.tasks.length - 1) {
          milestone.tasks[completeTask.taskIndex + 1].status = TaskStatusEnum.Active;
        }
      }
      return milestone;
    });
    if (this.checkMilestoneStatus([milestones[index]])) {
      if (milestones && milestones[index + 1]) {
        milestones[index + 1].tasks[0].status = TaskStatusEnum.Active;
      }
    }
  }

  mapMilestonesOnUserAssignation(milestones, assignUser, selectedUser, res) {
    milestones = milestones.map((milestone) => {
      if (milestone.id === assignUser.milestoneId) {
        milestone.tasks.map((task) => {
          if (task.id === assignUser.taskId) {
            task.assignToName = selectedUser.displayName;
            task.assignTo = assignUser.assignTo;
          }
        });
      }
      return milestone;
    });
  }


  getAllUsers() {
    this.userService
      .getUsers()
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          this.users = res.results.data;
        },
        error: (e) => {
          this.toastr.error('Something went wrong');
        },
        complete: () => { },
      });
  }

  handleError(error: any, message?: string) {
    this.loaderService.hide();
    if (
      error?.error?.statusCode === HttpStatusCode.NotFound ||
      error?.error?.statusCode === HttpStatusCode.Conflict
    ) {
      this.toastr.error(error.error.message, 'Error');
    } else {
      this.toastr.error(message, 'Error');
    }
  }




  filterByStatus(payloadTasks: any, status: TicketTaskStatus): any {
    switch (status) {
      case TicketTaskStatus.Staged: {
        return payloadTasks.filter(
          (res) => res?.statusId == TicketTaskStatus.Staged
        );
      }
      case TicketTaskStatus.InWork: {
        return payloadTasks.filter(
          (res) => res?.statusId == TicketTaskStatus.InWork
        );
      }
      case TicketTaskStatus.WrapUp: {
        return payloadTasks.filter(
          (res) => res?.statusId == TicketTaskStatus.WrapUp
        );
      }
    }
  }

  checkMilestoneStatus(milestones) {
    if (milestones.length == 0) return false;
    let failedtaskLength = 0;
    let completedTaskLength = 0;
    let totalTaskLength = 0;
    milestones.forEach((milestone) => {
      let completedtasks = milestone.tasks.filter((m) => m.statusId === TaskStatusIdEnum.Completed);
      let failedTasks = milestone.tasks.filter((m) => m.statusId === TaskStatusIdEnum.Failed);
      failedtaskLength += failedTasks.length;
      completedTaskLength += completedtasks.length;
      totalTaskLength += milestone.tasks.length;
    });
    if (totalTaskLength === failedtaskLength + completedTaskLength) {
      return true;
    } else {
      return false;
    }
  }

  checkStatusOnCompletion(isMilestoneFetched = true) {
    this.stagedStatus = this.checkMilestoneStatus(this.stagedMilestones);
    this.inWorkStatus = this.checkMilestoneStatus(this.inWorkMilestones);
    this.wrapUpStatus = this.checkMilestoneStatus(this.wrapUpMilestones);
    if (this.inWorkStatus) {
      if (isMilestoneFetched && this.wrapUpMilestones[0]?.tasks[0]?.status == TaskStatusEnum.Pending) {
        this.wrapUpMilestones[0].tasks[0].status = TaskStatusEnum.Active;
        this.wrapUpMilestones[0].tasks[0].statusId = TaskStatusIdEnum.Active;
      }
      this.isStagedCompleted = true;
      this.isInworkCompleted = true;
      this.isWrapupCompleted = true;
      this.isInWorkDelete = true;
      this.isStagedDelete = true;
      this.isWrapUpDelete = true;
    }
    else if (this.stagedStatus) {
      if (isMilestoneFetched && this.inWorkMilestones[0]?.tasks[0]?.status == TaskStatusEnum.Pending) {
        this.inWorkMilestones[0].tasks[0].status = TaskStatusEnum.Active;
        this.inWorkMilestones[0].tasks[0].statusId = TaskStatusIdEnum.Active;
      }
      this.isStagedCompleted = true;
      this.isInworkCompleted = true;
      this.isWrapupCompleted = false;
      this.isStagedDelete = true;
    }
    else {
      this.isStagedCompleted = true;
      this.isInworkCompleted = false;
      this.isWrapupCompleted = false;
    }

  }


  onCloseMilestoneModal() {
    this.isOpenMilestoneModal = false;
    this.selectedMilestonesToBeSaved = [];
  }

  onToggleMilestoneCheckbox(event: any, milestone: any) {
    if (event.target.checked) {
      this.selectedMilestonesToBeSaved.push(milestone);
    } else {
      this.selectedMilestonesToBeSaved =
        this.selectedMilestonesToBeSaved.filter((m) => m.id != milestone.id);
    }

    console.log(this.selectedMilestonesToBeSaved);
  }

  onToggleSelectAll(event) {
    if (event.target.checked) {
      this.selectedMilestonesToBeSaved = this.getAllMilestone;
    } else {
      this.selectedMilestonesToBeSaved = [];
    }
    console.log(this.selectedMilestonesToBeSaved);
  }

  isChecked(milestone: any) {
    return this.selectedMilestonesToBeSaved.some(
      (selectedMilestone) => selectedMilestone.id === milestone.id
    );
  }

  saveMilestone() {
    this.loaderService.show();
    var milestonesToAdd: any[] = [];
    this.selectedMilestonesToBeSaved.forEach((milestone) => {
      let payload = {
        contractMilestoneId: 0,
        statusId: this.statusId,
        milestoneId: milestone.id,
        poTasks: milestone.tasks.map((task) => {
          return {
            contractTaskId: 0,
            taskId: task.id,
          };
        }),
      };
      milestonesToAdd.push(payload);
    });

    this.poMilestoneService
      .saveMilestone_Multiple(this.poId, milestonesToAdd)
      .pipe(takeUntil(this.ngUnsubscribe$))
      .subscribe({
        next: (res) => {
          if (this.statusId == TicketTaskStatus.Staged) {
            this.stagedMilestones.push(...this.selectedMilestonesToBeSaved);
          }
          if (this.statusId == TicketTaskStatus.InWork) {
            this.inWorkMilestones.push(...this.selectedMilestonesToBeSaved);
            this.isStagedDelete = true;
          }
          if (this.statusId == TicketTaskStatus.WrapUp) {
            this.wrapUpMilestones.push(...this.selectedMilestonesToBeSaved);
            this.isStagedDelete = true;
            this.isInWorkDelete = true;
          }
          this.checkStatusOnCompletion(true);
          this.isOpenMilestoneModal = false;
          this.loaderService.hide();
        },
        error: (err) => {
          this.loaderService.hide();
          this.handleError(err);
        },
        complete: () => {
          this.isOpenMilestoneModal = false;
          this.loaderService.hide();
          this.selectedMilestonesToBeSaved = [];
        },
      });
  }

}
