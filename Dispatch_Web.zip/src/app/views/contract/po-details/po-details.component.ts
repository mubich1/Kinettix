import { HttpStatusCode } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ModalService } from 'carbon-components-angular';
import { ToastrService } from 'ngx-toastr';
import { Observable, Subject, Subscription, takeUntil } from 'rxjs';
import { ContractTicketsActivities, Ticket } from 'src/app/models/tickets/tickets';
import { LoaderService } from 'src/app/services/loader/loader.service';
import { PurchaseOrderService } from 'src/app/services/purchase-order/purchase-order.service';
import { TicketService } from 'src/app/services/ticket/ticket.service';
import { TinyMCEConfiguration } from 'src/app/shared/common/tinyMCEConfiguration';
import { PoPostingPlatformSelectionDialogueComponent } from 'src/app/shared/components/po-posting-platform-selection-dialogue/po-posting-platform-selection-dialogue.component';
import { POScope, ActivityCompetency, PurchaseOrderPlatform, PurchaseOrder, POActivityResource } from '../../../models/purchaseOrder/purchase-order';

@Component({
  selector: 'app-po-details',
  templateUrl: './po-details.component.html',
  styleUrls: ['./po-details.component.css']
})
export class PoDetailsComponent implements OnInit {
  poScope!:POScope;
  activityCompetencies!: ActivityCompetency[];
  poId: number;
  ngUnsubscribe = new Subject<void>();
  subscription$: Subscription = new Subscription();
  tinyMCECApiKey: string = TinyMCEConfiguration.apiKey;
  tinyMCESettings: any = TinyMCEConfiguration.settings;

  poActivities:POActivityResource = {
    contractTicketsActivitiesDto: [],
    POResourceDto: []
  }

  filterName: string = '';
  filterOrderBy: string = '';
  filterSort: string = '';
  pageId: number = 1;
  chooseOpportunityPlatform$: Observable<any> = new Subject<any>();
  showAssignmentTab: boolean = false;

  purchaseOrder: PurchaseOrder;
  poTicket: Ticket;
  postingParameters: string[] = [];

  constructor(
    private toastr: ToastrService,
    private route: ActivatedRoute,
    private loaderService: LoaderService,
    private poService: PurchaseOrderService,
    private ticketService:TicketService,
    private modalService: ModalService,
  ) { }

  ngOnInit(): void {
    this.getRoutingParams();
  }

  ngOnDestroy() {
    this.subscription$.unsubscribe();
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  ngAfterContentInit() {
    this.chooseOpportunityPlatform$.subscribe({
      next: (res) => {
        if (res.confirm) {


        }
      },
    });
  }

  getRoutingParams() {
    this.route.queryParams.subscribe((params: any) => {

      if (params) {
        this.poId = Number(params.poId);
        this.getPurchaseOrder();
        this.getTicketActivities();
        this.getActivityCompetencies();
      }
    });
  }

  getPurchaseOrder(){
    this.poService.getPoById(this.poId)
    .pipe(takeUntil(this.ngUnsubscribe))
    .subscribe({
      next: res => {


        if(res.results != null){


          this.purchaseOrder = res.results;


          if((this.purchaseOrder.vendorId != null) || (this.purchaseOrder.techId != null)){
            this.showAssignmentTab = true;
          }

          this.getTicketByTicketId(this.purchaseOrder.ticketId);
        }

      },
      error: e => {

      },
      complete: () =>{

      }
    });
  }

  onClickCreateOpportunity(){

    //Check Validity
    if(this.isValidForPlatformPosting()){
      this.getPOPlatform();
    }
    else{
      this.postingParameters.forEach(element => {
        this.toastr.error(element);
      });

    }

  }

  isValidForPlatformPosting(): boolean{
    this.postingParameters = [];
    if(this.poActivities != null && this.poActivities.contractTicketsActivitiesDto.length > 0){
      let totalAuthorizedCost = 0;

      this.poActivities.contractTicketsActivitiesDto.forEach(element => {
        totalAuthorizedCost = totalAuthorizedCost + (element.authorizedCost != null? element.authorizedCost: 0);
      });

      if(totalAuthorizedCost > 1){
        if(this.poTicket.clientSiteId != null && this.poTicket.clientSiteId > 0){
          return true;
        }
        else{
          this.postingParameters.push('No Site assigned to Ticket & PO/WO');
        }

      }
      else{
        this.postingParameters.push('PO/WO Total Authorized Payment is not >$1 ');
      }
    }
    else{
      this.postingParameters.push('PO/WO has no assigned Activities');
    }
    return false;
  }


  getPOPlatform(){
    this.poService.getPlatformByPoId(this.poId)
    .pipe(takeUntil(this.ngUnsubscribe))
    .subscribe({
      next: res => {

        let poPlatform: PurchaseOrderPlatform={
          pOId: this.poId,
          platforms: null
        }

        if(res.results != null){
          poPlatform.platforms = res.results.platforms
        }


        this.showPlatformModal(poPlatform);
      },
      error: e => {
        this.toastr.error('Something went wrong while loading Purchase Order Platforms');
      },
      complete: () => {

      }
    });
  }


  showPlatformModal(poPlatforms: PurchaseOrderPlatform){

    const modalInputs = {
      data: poPlatforms,
      obs: this.chooseOpportunityPlatform$,
      confirm: false,
      isClosed: false,

    };
    this.modalService.create({
      component: PoPostingPlatformSelectionDialogueComponent,
      inputs: { data: modalInputs },
    });
  }

  getTicketActivities(){
    this.loaderService.show();
    this.subscription$.add(this.poService.getPOActivitiesByIdAsync(this.poId).subscribe({
      next:(res:any)=>{

        if(res){

          this.poActivities = res.results;
        }
      },
      error:(error)=>{
        this.loaderService.hide();
        this.handleError(error,"An error occurred in getting purchase order scope.")
      }
    }))
  }

  getTicketByTicketId(ticketId: number){
    this.ticketService.getTicketById(ticketId)
    .pipe(takeUntil(this.ngUnsubscribe))
    .subscribe({
      next: res => {
        this.poTicket = res.results;
      }
      ,error: e=> {

      },
      complete: () => {

      }
    });
  }


  getPurchaseOrderScope() {
    this.loaderService.show();
    this.subscription$.add(this.poService.getPoScope(this.poId).subscribe({
      next: (res: any) => {
        this.loaderService.hide();
        if (res){
          this.poScope = res.results;
          this.setSelectedCompetencies();
        }
      },
      error: (error) => {
        this.loaderService.hide();
        this.handleError(error, "An error occurred in getting purchase order scope.");
      },
    }));
  }

  savePurchaseOrderScope(payload) {
    this.loaderService.show();
    this.subscription$.add(this.poService.addPoScope(payload, this.poId).subscribe({
      next: (res: any) => {
        this.toastr.success(' PO scope saved sucessfully', 'Success');
        this.loaderService.hide();
      },
      error: (error) => {
        this.loaderService.hide();
        this.handleError(error, "An error occurred in creating purchase order scope.");
      },
    }));
  }

  getActivityCompetencies() {
    this.loaderService.show();
    this.subscription$.add(this.poService.getActivityCompetencies(this.poTicket.id).subscribe({
      next: (res: any) => {
        this.loaderService.hide();
        if(res){
          this.activityCompetencies = res.results;
          this.getPurchaseOrderScope();

        }
      },
      error: (error) => {
        this.loaderService.hide();
        this.getPurchaseOrderScope();
        this.handleError(error, "An error getting in activity competencies.");
      },
    }));
  }

  handleError(error: any, message?: string) {
    this.loaderService.hide();
    if (error?.error?.statusCode === HttpStatusCode.NotFound || error?.error?.statusCode === HttpStatusCode.Conflict) {
      this.toastr.error(error.error.message, 'Error');
    }
    else {
      this.toastr.error(message, 'Error');
    }
  }

  setSelectedCompetencies() {
    const selectedCompetencies:ActivityCompetency[] = []
    this.activityCompetencies.forEach((item:any) => {
      this.poScope.activityCompetencyIds!.forEach((competencyId:any) =>{
        if(competencyId == item.id)  {
          selectedCompetencies.push(item);
        }
      })
    })
    this.poScope.activityCompetencyIds = selectedCompetencies;
  }
}
