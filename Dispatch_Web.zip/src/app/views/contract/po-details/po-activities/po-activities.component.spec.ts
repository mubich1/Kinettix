import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PoActivitiesComponent } from './po-activities.component';

describe('PoActivitiesComponent', () => {
  let component: PoActivitiesComponent;
  let fixture: ComponentFixture<PoActivitiesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PoActivitiesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PoActivitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
