import { HttpStatusCode } from '@angular/common/http';
import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import {
  ModalService,
  TableItem,
  TableModel,
} from 'carbon-components-angular';
import { ToastrService } from 'ngx-toastr';
import { Observable, Subject } from 'rxjs';
import {
  PoExceptionStatus,
  PoTicketActivityDto,
  SendPOModalData,
  TicketActivityResourceDetail,
} from 'src/app/models/purchaseOrder/purchase-order';
import { EPaymentType } from 'src/app/models/tickets/tickets';
import { LoaderService } from 'src/app/services/loader/loader.service';
import { PurchaseOrderService } from 'src/app/services/purchase-order/purchase-order.service';
import { TicketService } from 'src/app/services/ticket/ticket.service';
import { Permission } from 'src/app/services/utility/permission-constant';
import { UtilityService } from 'src/app/services/utility/utility.service';
import { AngularUtility } from 'src/app/shared/common/angular-utitilty';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';
import { PoDeliveryMediumCofirmationDialogComponent } from 'src/app/shared/components/po-delivery-medium-cofirmation-dialog/po-delivery-medium-cofirmation-dialog.component';


@Component({
  selector: 'app-po-activities',
  templateUrl: './po-activities.component.html',
  styleUrls: ['./po-activities.component.css'],
})
export class PoActivitiesComponent implements OnInit {

  @Input() set poActivitiesData(poActivitiesData: any) {
    if (poActivitiesData) {
      this.poActivities = poActivitiesData;
      this.poActivities.paymentType = this.poActivities.paymentType ? this.poActivities.paymentType : EPaymentType.TimeAndMaterials
      this.isTimeMaterial =
        this.poActivities.paymentType == EPaymentType.TimeAndMaterials
          ? true
          : this.poActivities.paymentType == EPaymentType.FixedPrice
            ? false
            : true;
      this.setActivityInitialValues();
    }
  }
  @Input() poDetails: any;
  @Input() set purchaseOrderId(purchaseOrderId: number) {
    if (purchaseOrderId) {
      this.poId = purchaseOrderId;
    }
  }
  @Input() tinyMCESettings;
  @Input() tinyMCECApiKey: string;
  @Output() onClose = new EventEmitter();
  @Output() emitData = new EventEmitter();

  activityAuthorizedCost: number = 0;
  riskPool: number = 0
  activityTargetCost: number = 0;
  activityBudget: number = 0;
  authRisk: number = 0;
  extendedCost: number;
  activityAuthCost: number;
  exceptionPermission: boolean;
  viewExceptionPermission: boolean;
  budgetCOGS: any;
  allcotedTicketRiskPool: number = 0;
  remainingTicketRiskPool: number = 0
  poId: number;
  isTimeMaterial: boolean = true;
  poActivities: PoTicketActivityDto = new PoTicketActivityDto();
  isAddAllowed: boolean = true;
  isModalOpen = false;
  isApproved: boolean = false;
  isDeclined: boolean = false;
  poSendObs: Observable<any> = new Subject<any>();
  paymentTypes: string[] = ['Time & Materials', 'Fixed Price'];
  activtiyIds: number[] = [];
  resourceIds: any[] = [];
  specialConditions: string = '';
  showActivityCheckbox = true


  constructor(
    private purchaseOrderService: PurchaseOrderService,
    private ticketService: TicketService,
    private toastrService: ToastrService,
    private loaderService: LoaderService,
    private utilityService: UtilityService,
    private modalService: ModalService,
  ) {
    this.checkPermission();
  }

  ticketActivityModel = new TableModel();
  ticketActivityData: TableItem[][] = [];
  carbonUtility = new CarbonUtility();
  angularUtility = new AngularUtility();
  showSpecialConditions: boolean = false;

  ngOnInit(): void {
    this.poActivities.paymentType = EPaymentType.TimeAndMaterials;

  }

  checkPermission() {
    this.viewExceptionPermission = this.utilityService.hasPermission(Permission.ViewActivityApproveException);
  }

  setActivityInitialValues() {
    this.isApproved = this.poActivities.poExceptionStatusId == PoExceptionStatus.Approve ? true : false;
    this.isDeclined = this.poActivities.poExceptionStatusId == PoExceptionStatus.Decline ? true : false;
    this.poActivities.totalTicketRisk = 0.0;
    this.poActivities.unAllocatedCost = 0.0;
    this.budgetCOGS = 0.0;
    this.authRisk = this.poActivities.totalAuthPayment - this.poActivities.totalBudget;
    if (this.authRisk < 0) {
      this.authRisk = 0
    }
    this.poActivities.poTicketActivities.sort((a: any) => a!.ticketActivityId);
    this.poActivities.poTicketActivities.forEach((activity: any) => {
      activity.authorizedCost = 0;
      activity.showActivityCheckbox = true;
      activity.tempBudget = activity.budget;
      activity.actualBudget = activity.budget;
      let isAllResourcesSelected = activity!.ticketActivityResources.every((item) => item.selected == true);
      let isAllResourcesDeselected = activity!.ticketActivityResources.every((item) => item.selected == false);
      if (isAllResourcesSelected || isAllResourcesDeselected) {
        activity.budget = 0;
      }
      activity.ticketRisk = 0;
      activity!.ticketActivityResources.forEach((resource: any) => {
        if (resource.selected) {
          resource.extendedCost = 0;
          resource.extendedCost =
            Number(resource.quantity) * Number(resource.authorizedCost);
          activity.authorizedCost = activity.authorizedCost + resource.extendedCost;
          activity.ticketRisk = Number(activity.ticketRisk) + Number(resource.riskFee);
          this.poActivities.totalTicketRisk += activity.ticketRisk;
          this.poActivities.unAllocatedCost += Number(resource.unAllocatedCost);
          this.budgetCOGS += (Number(activity.budget) + Number(activity.riskPercent))
        }
      });
    });

  }

  onSubmit() {
    const payload = {
      id: this.poId,
      paymentType: this.poActivities.paymentType,
      specialConditions: this.poActivities.specialConditions,
      oosLaborRate: this.poActivities.oosLaborRate,
      totalAuthLabor: this.poActivities.totalAuthLabor,
      totalAuthTravel: this.poActivities.totalAuthTravel,
      totalAuthMaterial: this.poActivities.totalAuthMaterial,
      totalAuthFreight: this.poActivities.totalAuthFreight,
      totalBudget: this.poActivities.totalBudget,
      totalCost: this.poActivities.totalCost,
      totalAuthPayment: this.poActivities.totalAuthPayment,
      poResources: this.getSelectedPoResources(),
      PoExceptionStatusId: this.isApproved ? PoExceptionStatus.Approve : (this.isDeclined ? PoExceptionStatus.Decline : null)
    };

    this.loaderService.show();
    this.purchaseOrderService.updatePOActivityResources(payload).subscribe({
      next: (res) => {
        this.loaderService.hide();
        this.toastrService.success(
          ' PO Activities Resources saved sucessfully',
          'Success'
        );
        this.isApproved ? this.showSendPOWOPopup(this.poDetails) : this.closeModal();
      },
      error: (error) => {
        this.loaderService.hide();
        this.handleError(
          error,
          'An Error occurred in saving Po activitiy resources.'
        );
      },
      complete: () => {
        this.loaderService.hide();
      },
    });
  }

  getSelectedPoResources() {
    let selectedPoResources: any[] = [];
    this.poActivities.poTicketActivities.forEach((item: any) => {
      item.ticketActivityResources.forEach((resource) => {
        if (resource.selected) {
          selectedPoResources.push({
            poResourceId: resource.poResourceId,
            quantity: resource.quantity,
            deleted: false,
            ticketActivityResourceId: resource.ticketActivityResourceId,
            ticketActivityId: resource.ticketActivityId,
            ticketActivityBudget: item.budget,
            ticketActivityAuthorizedCost: item.authorizedCost,
            authorizedCost: resource.authorizedCost,
          });
        }
        if (!resource.selected && resource.poResourceId) {
          selectedPoResources.push({
            poResourceId: resource.poResourceId,
            quantity: resource.quantity,
            deleted: true,
            ticketActivityResourceId: resource.ticketActivityResourceId,
            ticketActivityId: resource.ticketActivityId,
            icketActivityBudget: item.budget,
            ticketActivityAuthorizedCost: item.authorizedCost,
            authorizedCost: resource.authorizedCost,
          });
        }
      });
    });

    return selectedPoResources;
  }

  updatePO(po) {
    this.purchaseOrderService.updatePO(po).subscribe({
      next: (res) => {
        this.toastrService.success('Values saved succesfully.');
      },
      error: (err) => {
        this.toastrService.error(err);
      },
    });
  }

  handleError(error: any, message?: string) {
    this.loaderService.hide();
    if (
      error?.error?.statusCode === HttpStatusCode.NotFound ||
      error?.error?.statusCode === HttpStatusCode.Conflict
    ) {
      this.toastrService.error(error.error.message, 'Error');
    } else {
      this.toastrService.error(message, 'Error');
    }
  }

  onCheckResource(resourceId, activityId) {
    let selctedActivity = this.poActivities.poTicketActivities.filter((item: any) => item.ticketActivityId == activityId);
    let selctedActivityResources = selctedActivity[0].ticketActivityResources?.filter((x) => x.ticketActivityResourceId == resourceId);
    let filteredActivities = this.poActivities.poTicketActivities.filter((item) => item.ticketActivityId !== activityId);
    filteredActivities.forEach((act) => {
      let selectResourceCount = 0;
      let TotalSelectedResourceCount = 0;
      let disabledResourceCount = 0;
      act.ticketActivityResources?.forEach((tickRes: any) => {
        selctedActivityResources?.forEach((z: any) => {
          if (tickRes.resourceId == z.resourceId) {
            tickRes.isEnable = false;
            disabledResourceCount++;
          }
        })
        if (tickRes.isEnable && tickRes.selected) {
          selectResourceCount++;
        }
        TotalSelectedResourceCount++;
      })
      if (disabledResourceCount == TotalSelectedResourceCount) {
        act.showActivityCheckbox = false;
      } else {
        act.showActivityCheckbox = true;
      }

    })
    this.poActivities.poTicketActivities = selctedActivity.concat(filteredActivities).sort((a: any, b: any) => a!.ticketActivityId - b!.ticketActivityId);


  }


  onActivityCheck(activityId) {
    let selctedActivity = this.poActivities.poTicketActivities.filter((item: any) => item.ticketActivityId == activityId);
    let selctedActivityResources = selctedActivity[0].ticketActivityResources;
    let filteredActivities = this.poActivities.poTicketActivities.filter((item) => item.ticketActivityId !== activityId);
    filteredActivities.forEach((act) => {
      let selectResourceCount = 0;
      let TotalSelectedResourceCount = 0;
      let disabledResourceCount = 0;
      act.ticketActivityResources?.forEach((tickRes: any) => {
        selctedActivityResources?.forEach((z: any) => {
          if (tickRes.resourceId == z.resourceId && z.isEnable) {
            tickRes.isEnable = false;
            disabledResourceCount++;
          }
        })
        if (tickRes.isEnable && tickRes.selected) {
          selectResourceCount++;
        }
        TotalSelectedResourceCount++;
      })

      if (selectResourceCount + disabledResourceCount == TotalSelectedResourceCount && selectResourceCount > 0) {
        act.selected = true;
      }
      if (disabledResourceCount == TotalSelectedResourceCount) {
        act.showActivityCheckbox = false;
      }
      else {
        act.showActivityCheckbox = true;
      }
    })
    this.poActivities.poTicketActivities = selctedActivity.concat(filteredActivities).sort((a: any, b: any) => a!.ticketActivityId - b!.ticketActivityId);
  }
  onUncheckResource(resourceId, activityId) {
    let selctedActivity = this.poActivities.poTicketActivities.filter((item: any) => item.ticketActivityId == activityId);
    let selctedActivityResources = selctedActivity[0].ticketActivityResources?.filter((x) => x.ticketActivityResourceId == resourceId);
    let filteredActivities = this.poActivities.poTicketActivities.filter((item) => item.ticketActivityId !== activityId);
    filteredActivities.forEach((act) => {
      let selectResourceCount = 0;
      let TotalSelectedResourceCount = 0;
      let disabledResourceCount = 0;
      act.ticketActivityResources?.forEach((tickRes: any) => {
        selctedActivityResources?.forEach((z: any) => {
          if (tickRes.resourceId == z.resourceId) {
            tickRes.isEnable = true;
          }
        })
        if (tickRes.isEnable && tickRes.selected) {
          selectResourceCount++;
        }
        if (!tickRes.isEnable) {
          disabledResourceCount++;
        }
        TotalSelectedResourceCount++;
      })
      if (disabledResourceCount == TotalSelectedResourceCount) {
        act.showActivityCheckbox = false;
      } else {
        act.showActivityCheckbox = true;
      }
    });
    this.poActivities.poTicketActivities = selctedActivity.concat(filteredActivities).sort((a: any, b: any) => a!.ticketActivityId - b!.ticketActivityId);
  }
  onActivityUnCheck(activityId) {
    let selctedActivity = this.poActivities.poTicketActivities.filter((item: any) => item.ticketActivityId == activityId);
    let selctedActivityResources = selctedActivity[0].ticketActivityResources?.filter((item) => item.isEnable);
    let checkedActivityResources = selctedActivity[0].ticketActivityResources?.filter((item) => item.selected);
    let filteredActivities = this.poActivities.poTicketActivities.filter((item) => item.ticketActivityId !== activityId);
    filteredActivities.forEach((act) => {
      let selectResourceCount = 0;
      let TotalSelectedResourceCount = 0;
      let disabledResourceCount = 0;
      act.ticketActivityResources?.forEach((tickRes: any) => {
        checkedActivityResources?.forEach((y: any) => {
          if (tickRes.resourceId == y.resourceId && !tickRes.isEnable) {
            tickRes.selected = false;
            if (act.selected) {
              act.selected = false;
            }
          }
        });
        selctedActivityResources?.forEach((z: any) => {
          if (tickRes.resourceId == z.resourceId) {
            tickRes.isEnable = true;
          }
        })
        if (tickRes.isEnable && tickRes.selected) {
          selectResourceCount++;
        }
        TotalSelectedResourceCount++
        if (!tickRes.isEnable) {
          disabledResourceCount++;
        }
      });
      if (selectResourceCount + disabledResourceCount == TotalSelectedResourceCount) {
        act.selected = true;
      }
      if (disabledResourceCount == TotalSelectedResourceCount) {
        act.showActivityCheckbox = false
      }
      else {
        act.showActivityCheckbox = true
      }
    })
    this.poActivities.poTicketActivities = selctedActivity.concat(filteredActivities).sort((a: any, b: any) => a!.ticketActivityId - b!.ticketActivityId);
  }

  onSelectActivity(activityId) {
    this.onActivityCheck(activityId);
    this.poActivities.poTicketActivities.forEach((activity: any) => {
      if (activity.ticketActivityId == activityId) {
        activity.budget = 0;
        activity.ticketActivityResources.forEach((resource) => {
          resource.selected = true;
          if (resource.isEnable) {
            resource.extendedCost = 0;
            activity.budget = Math.round(Number(activity.budget) + Number(resource.authorizedCost)).toFixed(2);
            resource.extendedCost =
              Number(resource.quantity) * Number(resource.authorizedCost);
            activity.authorizedCost =
              activity.authorizedCost + resource.extendedCost;
          }
        });
        activity.actualBudget = activity.budget;
      }
      const isanyResourceSelected = activity.ticketActivityResources.some((item) => item.selected);
      if (isanyResourceSelected) {
        activity.selected = true;
      }
      const allResourceUnSelected = activity.ticketActivityResources.every((item) => !item.selected);
      if (allResourceUnSelected) {
        activity.selected = false;
      }
    });
    this.reCalculateSubTotals();
  }

  onDeselectActivity(activityId: number) {
    this.onActivityUnCheck(activityId);
    this.poActivities.poTicketActivities.forEach((activity: any) => {
      if (activity.ticketActivityId == activityId) {
        activity.budget = 0;
        activity.ticketActivityResources.forEach((resource: any) => {
          resource.selected = false;
          if (resource.isEnable) {
            activity.budget = Math.round(Number(activity.budget) - Number(resource.authorizedCost)).toFixed(2);
            resource.extendedCost = Number(resource.quantity) * Number(resource.authorizedCost);
            activity.authorizedCost = activity.authorizedCost - resource.extendedCost;
            if (activity.authorizedCost < 0) {
              activity.authorizedCost = 0;
            }
            if (activity.budget < 0) {
              activity.budget = 0;
            }
          }
        });
      }
      const isanyResourceSelected = activity.ticketActivityResources.some((item) => item.selected);
      if (isanyResourceSelected) {
        activity.selected = isanyResourceSelected;
      }
      const allResourceUnSelected = activity.ticketActivityResources.every((item) => !item.selected);
      if (allResourceUnSelected) {
        activity.selected = false;
      }
    });
    this.isAllResourcesUnchecked(activityId);
    this.reCalculateSubTotals();
  }

  isAllResourcesUnchecked(activityId) {
    this.poActivities.poTicketActivities.forEach((activity: any) => {
      if (activity.ticketActivityId == activityId) {
        let isAllUnchecked = activity.ticketActivityResources.every(
          (item) => item.selected == false
        );
        if (isAllUnchecked) {
          activity.actualBudget = activity.tempBudget;
        }
      }
    });
  }

  onSelectResource(resourceId, activityId) {
    this.onCheckResource(resourceId, activityId);
    this.poActivities.poTicketActivities.forEach((activity: any) => {
      if (activity.ticketActivityId === activityId) {
        let isanyResourceSelected = activity.ticketActivityResources.some((item) => item.selected);
        if (isanyResourceSelected) {
          activity.selected = true;
        }
        activity.ticketActivityResources.forEach((resource) => {
          if (resource.selected && resource.ticketActivityResourceId == resourceId) {
            activity.budget = Math.round(Number(activity.budget) + Number(resource.authorizedCost)).toFixed(2);
            resource.extendedCost = Number(resource.quantity) * Number(resource.authorizedCost);
            activity.authorizedCost = activity.authorizedCost + resource.extendedCost;
          }
        });
        activity.actualBudget = activity.budget;
      }
    });

    this.reCalculateSubTotals();
  }

  onDeselectResource(resourceId, activityId) {
    this.onUncheckResource(resourceId, activityId);
    this.poActivities.poTicketActivities.forEach((activity: any) => {
      if (activity.ticketActivityId == activityId) {
        let isanyResourceSelected = activity.ticketActivityResources.every((item) => !item.selected);
        if (isanyResourceSelected) {
          activity.selected = false;
        }
        activity.authorizedCost = 0;
        activity.budget = 0;
        activity.ticketActivityResources.forEach((resource) => {
          if (resource.selected && resourceId == resource.ticketActivityResourceId) {
            activity.authorizedCost = activity.authorizedCost + resource.extendedCost;
            activity.budget = Math.round(Number(activity.budget) + Number(resource.authorizedCost)).toFixed(2);
            activity.actualBudget = activity.budget;
          }
        });
        let isAllUnchecked = activity.ticketActivityResources.every(
          (item) => item.selected == false
        );
        if (isAllUnchecked) {
          activity.actualBudget = activity.tempBudget;
        }
      }
    });
    this.reCalculateSubTotals();
  }



  onSelectPT(event) {
    if (event.target.value == EPaymentType.TimeAndMaterials) {
      this.isTimeMaterial = true;
    } else {
      this.isTimeMaterial = false;
    }
  }

  stopPropagtion(event) {
    event.stopPropagation();
  }

  qtyTMInput(resourceId: number, activityId: number, event) {
    this.poActivities.poTicketActivities.forEach((activity: any) => {
      if (activity.ticketActivityId == activityId) {
        activity.authorizedCost = 0;
        activity.budget = 0;
        activity.ticketActivityResources.forEach((resource) => {
          if (
            resource.ticketActivityResourceId == resourceId &&
            resource.selected && resource.isEnable
          ) {
            resource.extendedCost = 0;
            resource.quantity = Number(event.target.value);
            resource.authorizedCost = (Number(resource.quantity) * Number(resource.budget)).toFixed(2);
            resource.extendedCost = resource.quantity * resource.authorizedCost;

          }
          if (resource.selected && resource.isEnable) {
            activity.authorizedCost =
              activity.authorizedCost + resource.extendedCost;
            resource.authorizedCost = (Number(resource.quantity) * Number(resource.budget)).toFixed(2);
            activity.budget = Number(activity.budget) + Number(resource.authorizedCost);
            activity.actualBudget = activity.budget;
          }
          else {
            resource.authorizedCost = (Number(resource.quantity) * Number(resource.budget)).toFixed(2);
            resource.extendedCost = resource.quantity * resource.authorizedCost;

          }
        });
      }
    });
    this.reCalculateSubTotals();
  }

  authCostTMInput(resourceId: number, activityId: number, event) {
    this.poActivities.poTicketActivities.forEach((activity: any) => {
      if (activity.ticketActivityId == activityId) {
        activity.authorizedCost = 0;
        activity.ticketActivityResources.forEach((resource) => {
          if (
            resource.ticketActivityResourceId == resourceId &&
            resource.selected
          ) {
            resource.extendedCost = 0;
            resource.authorizedCost = Number(event.target.value);
            resource.extendedCost = resource.quantity * resource.authorizedCost;
          }
          if (resource.selected)
            activity.authorizedCost =
              activity.authorizedCost + resource.extendedCost;
        });
      }
    });
    this.reCalculateSubTotals();
  }

  reCalculateSubTotals() {
    this.poActivities.totalBudget = 0.0;
    this.poActivities.totalCost = 0.0;
    this.poActivities.totalTicketRisk = 0.0;
    this.poActivities.unAllocatedCost = 0.0;
    this.budgetCOGS = 0.0;
    if (this.isTimeMaterial) {
      this.poActivities.totalAuthLabor = 0.0;
      this.poActivities.totalAuthTravel = 0.0;
      this.poActivities.totalAuthMaterial = 0.0;
      this.poActivities.totalAuthFreight = 0.0;
      this.poActivities.totalAuthPayment = 0.0;

      this.poActivities.poTicketActivities.forEach((activity: any) => {
        if (activity.selected) {
          this.poActivities.totalCost += Number(activity.targetCost);
          this.budgetCOGS += (Number(activity.budget) + Number(activity.riskPercent));
          this.poActivities.totalBudget += Number(activity.actualBudget);
        }
        activity.ticketActivityResources.forEach((resource) => {
          if (resource.selected) {
            this.poActivities.totalTicketRisk += Number(resource.riskFee);
            this.poActivities.unAllocatedCost += Number(resource.unAllocatedCost);
            switch (resource.type) {
              case TicketActivityResourceDetail.labor:
                this.poActivities.totalAuthLabor += Number(
                  resource.extendedCost
                );
                break;
              case TicketActivityResourceDetail.Externallabor:
                this.poActivities.totalAuthLabor += Number(
                  resource.extendedCost
                );
                break;
              case TicketActivityResourceDetail.Internallabor:
                this.poActivities.totalAuthLabor += Number(
                  resource.extendedCost
                );
                break;
              case TicketActivityResourceDetail.materials:
                this.poActivities.totalAuthMaterial += Number(
                  resource.extendedCost
                );
                break;
              case TicketActivityResourceDetail.freight:
                this.poActivities.totalAuthFreight += Number(
                  resource.extendedCost
                );
                break;
              case TicketActivityResourceDetail.travel:
                this.poActivities.totalAuthTravel += Number(
                  resource.extendedCost
                );
                break;
            }
          }
        });
      });

      this.setTotalAuthPayment();
    } else {
      this.poActivities.poTicketActivities.forEach((activity: any) => {
        if (activity.selected) {
          this.poActivities.totalCost += Number(activity.targetCost);
          this.budgetCOGS += (activity.budget + activity.riskPercent);
          this.poActivities.totalBudget += Number(activity.budget);
        }
        activity.ticketActivityResources.forEach((resource) => {
          if (resource.selected) {
            this.poActivities.totalTicketRisk += Number(resource.riskFee);
            this.poActivities.unAllocatedCost += Number(resource.unAllocatedCost);
          }
        });
      });
    }

  }
  openExceptionModel() {
    this.isModalOpen = true;
    this.authRisk = Number((this.poActivities.totalAuthPayment - this.poActivities.totalBudget).toFixed(2));
    if (this.authRisk < 0) {
      this.authRisk = 0;
    }
    const COGS = Number(this.poActivities.totalAuthPayment + this.authRisk + this.poActivities.unAllocatedCost);
    this.riskPool = Number((COGS - this.budgetCOGS).toFixed(2));
    this.allcotedTicketRiskPool = Number((this.authRisk - this.poActivities?.totalTicketRisk).toFixed(2));
    this.remainingTicketRiskPool = Number((this.riskPool - (this.authRisk - this.poActivities?.totalTicketRisk)).toFixed(2));

  }

  closeDeleteModel() {
    this.isModalOpen = false;
  }

  closeExceptionModal() {
    this.isModalOpen = false;
  }

  setTotalAuthPayment() {
    this.isApproved = false;
    this.isDeclined = false;
    this.poActivities.totalAuthPayment = 0;
    this.poActivities.totalAuthPayment = this.poActivities.totalAuthLabor + this.poActivities.totalAuthMaterial + this.poActivities.totalAuthFreight + this.poActivities.totalAuthTravel;
  }

  onResourceSelection(resourceId, activityId, isChecked) {
    if (isChecked) {
      this.onSelectResource(resourceId, activityId);
    } else {
      this.onDeselectResource(resourceId, activityId);
    }
  }
  onActivitySelection(activityId, isChecked) {
    if (isChecked) {
      this.onSelectActivity(activityId);
    } else {
      this.onDeselectActivity(activityId);
    }
  }

  closeModal() {
    this.onClose.emit();
  }


  validateInputField(event: any): any {
    if (event.keyCode === 45) {
      return false;
    }
  }
  showSendPOWOPopup(data) {
    const modalInputs: SendPOModalData = {
      header: 'Send PO/WO',
      question: 'How would you like to deliver this PO/WO?',
      confirmationButtoText: 'Download',
      downloadOption: 'PurchaseOrder',
      cancelButtonText: 'Cancel',
      data: data.id,
      obs: this.poSendObs,
      confirm: false,
      isClosed: false,
      recipientEmailList: null,
      ccEmailList: null,
      emailMessage: null,
      selectedOption: '',
      downloadType: '',
      subject: '',
    };
    this.modalService.create({
      component: PoDeliveryMediumCofirmationDialogComponent,
      inputs: { data: modalInputs },
    }).instance.emitData.subscribe((res) => {
      this.emitData.emit(res)
      this.closeModal();
    });
  }


}
