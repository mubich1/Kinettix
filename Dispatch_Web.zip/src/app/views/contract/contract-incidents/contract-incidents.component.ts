import { formatDate } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Table, TableHeaderItem, TableItem, TableModel } from 'carbon-components-angular';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';
import { ContractIncidentService } from 'src/app/services/contract-incident/contract-incident.service';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';
import * as _ from 'lodash';
import { IncidentCategoriesService } from 'src/app/services/incident-categories/incident-categories.service';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/services/user/user.service';
import { UtilityService } from 'src/app/services/utility/utility.service';
import { Permission } from 'src/app/services/utility/permission-constant';
@Component({
  selector: 'app-contract-incident',
  templateUrl: './contract-incidents.component.html',
  styleUrls: ['./contract-incidents.component.css']
})
export class ContractIncidentComponent implements OnInit {
  isLoading: boolean;
  submitted: boolean;
  isAddEdit: boolean = false;
  dateRangeDisabled: boolean = false;
  form: FormGroup;
  isDeleteOpen = false;
  types = ["Issue", "Risk"];
  status = ["Open", "Resolved"];
  priority = ["Low", "Medium", "High", "Critical"];
  clickedRow: number;
  contractIncidentId: any;
  ticketId: number;
  contractIncidents: any = [];
  tableData: TableItem[][] = [];
  @ViewChild('customItemTemplate', { static: true }) customItemTemplate: ElementRef;
  @ViewChild('customViewTemplate', { static: true }) customViewTemplate: ElementRef;

  tableModel = new TableModel();
  carbonUtility = new CarbonUtility();
  showSkeleton: boolean = false;
  tabledata: any;
  ngUnsubscribe = new Subject<void>();
  selectedTableData: any[] = [];
  contractId: any;
  categories: any;
  users: any;

  isAddAllowed: boolean = true;
  isEditAllowed: boolean = true;
  isDeleteAllowed: boolean = true;

  constructor(private formBuilder: FormBuilder, private toastr: ToastrService,
    private contractIncident: ContractIncidentService,
    private iCategoryService: IncidentCategoriesService,
    private userService: UserService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private utilityService: UtilityService) {

    this.activatedRoute.parent?.paramMap.subscribe((params) => {
      this.contractId = +params.get('contractId')!;
    });

    this.tableModel = Table.skeletonModel(5, 5);
    this.getAllUsers();
    this.getCategories();
  }

  ngOnInit(): void {
    this.isAddAllowed = this.utilityService.hasPermission(Permission.AddDeliveryContractIncident);
    this.isEditAllowed = this.utilityService.hasPermission(Permission.EditDeliveryContractIncident);
    this.isDeleteAllowed = this.utilityService.hasPermission(Permission.DeleteDeliveryContractIncident);

    this.form = this.formBuilder.group({
      id: [0],
      type: [null, [Validators.required]],
      status: [null, [Validators.required]],
      title: [null, [Validators.required]],
      description: [null, [Validators.maxLength(500)]],
      priority: [null],
      reportedBy: [null, [Validators.required]],
      reportedDate: [null, [Validators.required]],
      assignedTo: [null, [Validators.required]],
      categoryId: [null, [Validators.required]],
      rootCause: [null, [Validators.maxLength(500)]],
      resolutionDate: [null, []],
      resolution: [null, []],
      contractId: [this.contractId],
      internalOnly: [true],
      modifiedBy: [null],
      deletedBy: [null],
    });
    this.initializeTable();
  }

  selectedStatusType(event) {
    if (event.value === 'Resolved') {
      this.form.get('resolutionDate')?.setValidators([Validators.required]);
      this.form.get('resolutionDate')?.updateValueAndValidity();
      this.form.get('resolution')?.setValidators([Validators.required, Validators.maxLength(500)]);
      this.form.get('resolution')?.updateValueAndValidity();
    }
    else {
      this.form.get('resolutionDate')?.setValidators([Validators.nullValidator]);
      this.form.get('resolutionDate')?.updateValueAndValidity();
      this.form.get('resolution')?.setValidators([Validators.nullValidator]);
      this.form.get('resolution')?.updateValueAndValidity();
      this.form.patchValue({ resolutionDate: null, resolution: null });
    }
  }

  onSubmit() {
    this.isLoading = true;
    this.submitted = true;
    var formstate = this.form.invalid
    if (formstate) {
      this.submitted = false;
      return;
    }
    formstate = true;
    let incident = _.cloneDeep(this.form.value);
    if (!incident.title.replace(/\s/g, '').length) {
      this.toastr.error("Title is required.");
      return;
    }
    if (incident.reportedDate != null) {
      incident.reportedDate = new Date(incident.reportedDate);
    }
    if (incident.resolutionDate != null) {
      incident.resolutionDate = new Date(incident.resolutionDate);
    }
    let request = this.contractIncident.add(this.contractId, incident);
    if (this.f.id.value != 0) {
      request = this.contractIncident.update(this.contractId, incident);
    }
    request.pipe(takeUntil(this.ngUnsubscribe)).subscribe({
      next: (res) => {
        if (this.f.id.value != 0) {
          this.toastr.success("Incident added Successfully");
        } else {
          this.toastr.success("Incident updated Successfully");
        }
        this.isAddEdit = false;
        this.submitted = false;
        this.form.reset();
        this.setDefaultValue();
      },
      error: (e) => {
        this.toastr.error("Something went wrong");
      },
      complete: () => {
        this.getAllIncidents();
      },
    });
  }
  onCancel() {
    this.isAddEdit = false;
    this.form.reset();
    this.setDefaultValue();
  }
  onAdd() {
    this.isAddEdit = true;
  }
  onEdit() {
    setTimeout(() => {
      this.contractIncidentId = this.tableModel.data[this.clickedRow][0].data;
      this.contractIncident.get(this.contractId, this.contractIncidentId)
        .pipe(takeUntil(this.ngUnsubscribe))
        .subscribe({
          next: (res) => {
            this.setupForm(res.results);
            this.isAddEdit = true;
          },
          error: (e) => {
            this.toastr.error("Something went wrong");
          },
          complete: () => { },
        });
    }, 0);
  }
  get f() {
    return this.form.controls;
  }
  setupForm(incident) {
    this.form.get('id')?.setValue(incident.id);
    this.form.get('type')?.setValue(incident.type);
    this.form.get('status')?.setValue(incident.status);
    this.form.get('title')?.setValue(incident.title);
    this.form.get('description')?.setValue(incident.description);
    this.form.get('priority')?.setValue(incident.priority);
    this.form.get('reportedBy')?.setValue(incident.reportedBy);
    this.form.get('reportedDate')?.setValue(this.formatDateFor(incident.reportedDate), { onlyself: true });
    this.form.get('assignedTo')?.setValue(incident.assignedTo);
    this.form.get('categoryId')?.setValue(incident.categoryId);
    this.form.get('rootCause')?.setValue(incident.rootCause);
    this.form.get('resolutionDate')?.setValue(this.formatDateFor(incident.resolutionDate), { onlyself: true });
    this.form.get('resolution')?.setValue(incident.resolution);
    this.form.get('contractId')?.setValue(incident.contractId);
    this.form.get('internalOnly')?.setValue(incident.internalOnly);
    this.form.get('createdBy')?.setValue(incident.createdBy);
    this.form.get('modifiedBy')?.setValue(incident.modifiedBy);
  }

  openDeleteModel(): void {
    this.isDeleteOpen = true;
  }

  closeDeleteModel() {
    this.isDeleteOpen = false;
  }

  onDelete() {
    setTimeout(() => {
      this.contractIncidentId = this.tableModel.data[this.clickedRow][0].data;

      this.contractIncident.delete(this.contractId, this.contractIncidentId)
        .pipe(takeUntil(this.ngUnsubscribe))
        .subscribe({
          next: (res) => {
            if (res.results) {
              this.toastr.success("Contract Incident Deleted Successfully");
              this.isDeleteOpen = false;
            }
          },
          error: (e) => {
            this.toastr.error("Something went wrong");
          },
          complete: () => {
            this.getAllIncidents();
          },
        });
    }, 0);
  }

  onRowClick(event: any) {
    this.clickedRow = event;
    var parentType = this.tableModel.data[this.clickedRow][11].data;
    if (parentType == 1) {
      this.onViewTicket();
    }
  }

  onSearch(event) {
    let searchText = event.target.value;
    if (searchText !== '') {
      let proposal = this.contractIncidents.filter((item) => item.title.toLowerCase().includes(searchText.toLowerCase()) || item.id == searchText);
      this.populateTable(proposal);
    }
    else {
      this.populateTable(this.contractIncidents);
    }
  }

  populateTable(incidents: any) {
    this.tableModel.data = [];
    this.tableData = [];
    this.selectedTableData.forEach((data) => {
      this.tableData.push(data);
    });
    this.selectedTableData.forEach((data) => {
      incidents = incidents.filter((u) => {
        return u.title !== data[1].data;
      });
    });

    this.tableModel.totalDataLength = this.contractIncidents.length;
    if (this.contractIncidents != null && this.contractIncidents.length > 0) {
      for (var el of incidents) {

        this.tableData.push([
          new TableItem({ data: el.id }),
          new TableItem({ data: el.title }),
          new TableItem({ data: el.type }),
          new TableItem({ data: el.status }),
          new TableItem({ data: el.priority }),
          new TableItem({ data: this.users?.find(x => x.id == el.reportedBy)?.displayName }),
          new TableItem({ data: el.reportedDate != null ? formatDate(el.reportedDate, 'yyyy-MM-dd', 'en-US') : "" }),
          new TableItem({ data: this.users?.find(x => x.id == el.assignedTo)?.displayName }),
          new TableItem({ data: this.categories?.find(x => x.id == el.categoryId)?.name }),
          new TableItem({ template: el.parentType == 0 ? this.customItemTemplate : this.customViewTemplate }),
          new TableItem({ data: el.parentId }),
          new TableItem({ data: el.parentType })
        ]);

      };
    }

    this.initializeTable();
    this.showSkeleton = false;
  }
  initializeTable() {

    this.tableModel.data = [];

    let headers = [
      new TableHeaderItem({ data: "Id", visible: false }),
      new TableHeaderItem({ data: "Title" }),
      new TableHeaderItem({ data: "Type" }),
      new TableHeaderItem({ data: "Status" }),
      new TableHeaderItem({ data: "Priority" }),
      new TableHeaderItem({ data: "Reported By" }),
      new TableHeaderItem({ data: "Reported Date" }),
      new TableHeaderItem({ data: "Assigned To" }),
      new TableHeaderItem({ data: "Category" }),
      new TableHeaderItem({ data: "Action", sortable: false }),
      new TableHeaderItem({ data: "ParentId", visible: false }),
      new TableHeaderItem({ data: "ParentType", visible: false }),
    ];

    this.tableModel = this.carbonUtility.initializeTable(
      headers,
      this.tableModel,
      this.tableData
    );

    this.selectPage(1);
  }
  selectPage(page: any) {
    this.tableModel = this.carbonUtility.selectPage(
      page,
      this.tableModel,
      this.tableData
    );
  }

  getAllIncidents() {
    this.contractIncident.getAll(this.contractId).pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          this.contractIncidents = res.results;
          this.populateTable(this.contractIncidents);
        },
        error: (e) => {
          this.toastr.error("Something went wrong");
        },
        complete: () => {
        },
      });
  }

  getCategories() {
    this.iCategoryService.getAllICategories().pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          this.categories = res.results;
        },
        error: (e) => {
          this.toastr.error("Something went wrong");
        },
        complete: () => {

        },
      });
  }

  async getAllUsers() {
    await this.userService.getUsers().pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          this.users = res.results.data;
        },
        error: (e) => {
          this.toastr.error("Something went wrong");
        },
        complete: () => {
          this.getAllIncidents();
        },
      });
  }

  formatDateFor(e: any) {
    if (e == null || e == undefined) {
      return null;
    }
    var d = new Date(e);
    return d.toISOString().substring(0, 10) + d.toISOString().substring(10,);
  }

  setDefaultValue() {
    this.form.get('contractId')?.setValue(this.contractId);
    this.form.get('id')?.setValue(0);
    this.form.get('internalOnly')?.setValue(true);
  }

  onViewTicket() {
    this.ticketId = this.tableModel.data[this.clickedRow][10].data;
    this.router.navigate([`/contracts/${this.contractId}/tickets/${this.ticketId}/ticket-detail/incident`]);
  }

  testfunc(e) {
    e.preventDefault();

  }
}
