import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContractIncidentComponent } from './contract-incidents.component';

describe('ContractIncidentComponent', () => {
  let component: ContractIncidentComponent;
  let fixture: ComponentFixture<ContractIncidentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ContractIncidentComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContractIncidentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
