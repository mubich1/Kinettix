import { DragDropModule } from '@angular/cdk/drag-drop';
import { DatePipe } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ModalService, Table, TableHeaderItem, TableItem, TableModel } from 'carbon-components-angular';
import { ToastrService } from 'ngx-toastr';
import { Observable, Subject, Subscription, takeUntil } from 'rxjs';
import { ContractTicketRequest, GetAllDeliveryContract } from 'src/app/models/deliveryContract/delivery-contract.model';
import { ConfirmationDialog } from 'src/app/models/dialog/confirmation';
import { ClientService } from 'src/app/services/client/client.service';
import { DeliveryContractService } from 'src/app/services/deliveryContract/delivery-contract.service';
import { ProjectActivityResourceService } from 'src/app/services/project-activity-resources/project-activity-resources.service';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';
import { TableFilters } from 'src/app/shared/common/tableFilters';
import { AddTicketComponent } from './add-ticket/add-ticket.component';
import { TicketStatus, ShowTicketStatus } from 'src/app/models/tickets/tickets';
import { LoaderService } from 'src/app/services/loader/loader.service';
@Component({
  selector: 'app-contract-tickets',
  templateUrl: './contract-tickets.component.html',
  styleUrls: ['./contract-tickets.component.css']
})
export class ContractTicketsComponent implements OnInit {

  ticketTableModel = new TableModel();
  ticketsHeaderTable: TableHeaderItem[] = [];
  ticketTableData: TableItem[][] = [];
  carbonUtility = new CarbonUtility();
  isSorted: boolean = false;
  sortIndex: number = 0;
  isAscending: boolean = false;
  tableFilters: TableFilters = new TableFilters();
  ngUnsubscribe = new Subject<void>();
  ticketsList: GetAllDeliveryContract[] = [];
  showDocumentSkeleton: boolean = true;
  isOpenDeleteModal = false;
  currentItem: ContractTicketRequest;
  selectedDeleteTicketId: number = 0;
  contractId: number = 0;
  clientId: number = 0;
  ticketList: any;
  subscription$: Subscription = new Subscription();
  ModalObs: Observable<ConfirmationDialog> =
    new Subject<ConfirmationDialog>();

  @ViewChild('ticketLablesAction', { static: true }) ticketLablesAction: ElementRef;
  @ViewChild('customHeaderAction', { static: true }) customHeaderAction: ElementRef;
  constructor(private modalService: ModalService,
    public datepipe: DatePipe,
    private route: ActivatedRoute,
    private deliveryContractService: DeliveryContractService,
    private clientService: ClientService,
    private loaderService: LoaderService,
    private toastr: ToastrService, private projectActivityService: ProjectActivityResourceService,
    private router: Router) { }

  ngOnInit(): void {
    this.route.parent?.params.subscribe((params: any) => {
      if (params.hasOwnProperty('clientId')) {
        this.clientId = params['clientId'];
        this.contractId = params['contractId'];
        this.clientService.currentClientId = this.clientId;

        this.getTickets();
        this.loadContract(this.contractId);


      }

    });
  }
  ngAfterContentInit(): void {
    this.ModalObs.subscribe((res) => {
      if (res?.confirm) {
        this.getTickets();
      }
    })
  }

  overflowOnClick = (event: any) => {
    event.stopPropagation();
  }

  filterColumns(index: any, checked: boolean) {
    let foundIndex = this.ticketTableModel.header.findIndex(element => element === index);
    this.ticketTableModel.header[foundIndex].visible = checked;
  }
  onSearch(event) {
    this.tableFilters.search = event?.target?.value;
    this.ticketTableModel.currentPage = 1;
    this.tableFilters.page = 1;
    this.getTickets(this.isSorted, this.sortIndex);
  }

  onClearSearch() {
    this.tableFilters.search = '';
    this.getTickets(this.isSorted, this.sortIndex);
  }
  populateDocumentTable(resourcesList: GetAllDeliveryContract[]) {
    if (resourcesList != null && resourcesList.length > 0) {
      resourcesList.forEach((el) => {
        if (el.ticketStatus == TicketStatus.InWork) {
          el.ticketStatus = ShowTicketStatus.InWork;
        }
        if (el.ticketStatus == TicketStatus.WrapUp) {
          el.ticketStatus = ShowTicketStatus.WrapUp;
        }
        this.ticketTableData.push([
          new TableItem({ data: el.id }),
          new TableItem({ data: el.title }),
          new TableItem({ data: el, template: this.customHeaderAction }),
          new TableItem({ data: el.ticketLabel }),
          new TableItem({ data: el.ticketStatus }),
          new TableItem({ data: el.endClientName }),
          new TableItem({ data: el.totalPrice }),
          new TableItem({ data: el.totalAssignCost }),
          new TableItem({ data: el.assignVednor }),
          new TableItem({ data: el.locationName }),
          new TableItem({ data: el.locationAddress }),
          new TableItem({ data: '', template: this.ticketLablesAction }),
          new TableItem({ data: '' }),
        ]);
      });
    }
    const _headers = ['ID', 'Ticket Title', 'Ticket Number', 'Ticket labels',
      'Ticket status', 'End client', 'Total Price', 'Total assigned Cost', 'Assigned Vendor(s)'
      , 'Location Name', 'Location Address', 'Invoice number', 'Client PO'];
    this.ticketTableModel = this.carbonUtility.setTableModel(_headers, this.ticketTableModel, this.ticketTableData, this.ticketTableModel.pageLength, this.ticketTableModel.currentPage, this.ticketTableModel.totalDataLength);
    this.ticketTableModel.header[this.ticketTableModel.header.length - 1].sortable = false;
    this.ticketTableModel.header[0] = new TableHeaderItem({ data: "Id", visible: false });
    this.ticketTableModel.header[11] = new TableHeaderItem({ data: "Invoice number", visible: false });
    this.ticketTableModel.header[12] = new TableHeaderItem({ data: "Client PO", visible: false });

    console.log(this.ticketTableModel.header, ' this.tableModel.header')
    this.ticketList = [...this.ticketTableModel.data];
    this.showDocumentSkeleton = false;
  }
  //** Share ContarctInfo B/w Component Start */
  loadContract(contractId: number) {
    this.projectActivityService.getContractByContractId(contractId)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {

          if (res.results !== null) {
            this.projectActivityService.shareContractInfo(res.results);
          }
        },
        error: (e) => {
          console.log(e);
          this.toastr.error('Something went wrong while loading Client contracts');
        },
        complete: () => { },
      });
  }

  //** Share ContarctInfo B/w Component END */
  getTickets(sort = false, index: number = 0) {
    this.loaderService.show();
    this.deliveryContractService.getTickets(this.tableFilters, this.contractId).subscribe({
      next: (res) => {
        this.loaderService.hide();
        if (res.statusCode == 200) {
          this.ticketTableData = [];
          this.ticketsList = res.results.data;
          this.ticketTableModel.totalDataLength = res.results.total;
          this.populateDocumentTable(this.ticketsList);
        }
      },
      error: (e) => {
        this.loaderService.hide();
        console.log(e);
        this.toastr.error('Something went wrong while loading tickets');
      },
      complete: () => { },
    });
  }
  onSort(index: number) {
    this.loaderService.show();
    this.isAscending = !this.isAscending;
    this.sortIndex = index;
    this.isSorted = true;
    this.tableFilters.sort = this.ticketTableModel.header[index].data;
    this.tableFilters.isAscending = this.isAscending;
    this.getTickets(true, index);
  }
  selectPageDocument(page: any) {
    this.loaderService.show();
    this.ticketTableModel.currentPage = page;
    this.tableFilters.pageSize = this.ticketTableModel.pageLength;
    this.tableFilters.page = page;
    this.showDocumentSkeleton = false;
    this.getTickets(this.isSorted, this.sortIndex);
  }
  closeParentModal() {
    this.isOpenDeleteModal = false;
    this.selectedDeleteTicketId = 0;
  }

  onClickRes(value: ContractTicketRequest) {
    const docId = value.id!;
    if (docId > 0) {
      this.currentItem = value;
    } else {
      //this.onUpload();
    }
  }

  deleteRes(value: ContractTicketRequest) {
    ;
    const doc = value.id!;
    if (doc > 0) {
      this.selectedDeleteTicketId = doc;
      this.openParentModal();
    } else {
      this.selectedDeleteTicketId = 0;
    }
  }

  openParentModal() {
    this.isOpenDeleteModal = true;
  }
  onConfirmationDelete() {
    ;
    this.deliveryContractService
      .deleteTicketById(this.selectedDeleteTicketId)
      .subscribe({
        next: (res) => {
          this.toastr.success('Deleted Successfully');
          this.getTickets();
        },
        error: (e) => {
          console.log(e);
          this.toastr.error('Something went wrong');
        },

        complete: () => this.closeParentModal(),
      });
  }

  openModel() {
    this.modalService.create({
      component: AddTicketComponent,
      inputs: { data: '', clientId: this.clientId, contractId: this.contractId },
    });
  }
  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();

  }
}
