import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TicketLocationsComponent } from './ticket-locations.component';

describe('TicketLocationsComponent', () => {
  let component: TicketLocationsComponent;
  let fixture: ComponentFixture<TicketLocationsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TicketLocationsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TicketLocationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
