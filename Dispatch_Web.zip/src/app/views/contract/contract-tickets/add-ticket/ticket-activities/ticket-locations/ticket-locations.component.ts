import { LocationDialog } from './../../../../../../models/dialog/input-dialog';
import { Component, Injector } from '@angular/core';
import { BaseModal, TableItem } from 'carbon-components-angular';
import { ClientService } from 'src/app/services/client/client.service';
import { ClientSite } from 'src/app/models/client/client-site';
import { map } from 'rxjs';
import { PaginationBuilderLoadRecordsResult, PaginationBuilderOptions, PaginationBuilderRowDefinition } from 'src/app/shared/components/pagination-builder/pagination-builder.component';
import { D1FilterElementText, D1FilterGroup } from 'src/app/shared/components/filter-builder/filter-builder.component';

@Component({
  selector: 'app-ticket-locations',
  templateUrl: './ticket-locations.component.html',
  styleUrls: ['./ticket-locations.component.css']
})
export class TicketLocationsComponent extends BaseModal {

  data: LocationDialog;
  isModalOpen: boolean = true;
  clientSite: ClientSite;
  clientId: number = 0;

  constructor(private injector: Injector, private clientService: ClientService) {
    super();
    this.data = this.injector.get('data');
    this.clientId = this.injector.get('clientId');
  }

  private _mapClientSiteToTableRow(clientSite: ClientSite): PaginationBuilderRowDefinition {
    return {
      columnEntries: [
        new TableItem({
          data: clientSite.name,
        }),
        new TableItem({
          data: clientSite.countryName,
        }),
        new TableItem({
          data: clientSite.state,
        }),
        new TableItem({
          data: clientSite.city,
        }),
      ],
      meta: {
        site: clientSite,
      }
    };
  }

  filterGroups: D1FilterGroup[] = [
    {
      label: 'Search Locations',
      items: [
        new D1FilterElementText('searchText', 'Search...'),
      ],
    },
  ];

  paginationOptions: PaginationBuilderOptions = {
    headers: [
      'Name',
      'Country',
      'State',
      'City',
    ],
    loadItemsCallback: (details) => {
      return this.clientService.getClientSite(details.page, this.clientId, '', details.query?.searchText ?? '', {
        recordsPerPage: details.itemsPerRequest,
      }).pipe(
        map<any, PaginationBuilderLoadRecordsResult>((result) => {
          const results: ClientSite[] = result.results;

          const rows = results.map<PaginationBuilderRowDefinition>((site) => this._mapClientSiteToTableRow(site));

          return {
            listExtentCount: result.totalRecords,
            results: rows,
          };
        }),
      );
    },
    singleSelectCallback: (selection) => {
      this.selectedRow(selection.meta.site);
    },
  };

  selectedRow(site: ClientSite) {
    this.clientSite = site;
    this.data.confirm = true;
    this.isModalOpen = false;
    this.data.data = this.clientSite;
    this.data.obs.next(this.data);
  }

  closeMyModal() {
    this.closeModal();
    this.data.confirm = false;
    this.isModalOpen = false;
    this.data.obs.next(this.data);
  }
}
