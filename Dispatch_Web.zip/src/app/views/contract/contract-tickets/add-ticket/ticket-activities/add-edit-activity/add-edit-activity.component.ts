import { Subject, Subscription, catchError, forkJoin, of } from 'rxjs';
import { NgIf } from '@angular/common';
import { Component, ElementRef, Injector, Input, OnInit, ViewChild, ViewChildren } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BaseModal, TableHeaderItem, TableItem, TableModel } from 'carbon-components-angular';
import { ToastrService } from 'ngx-toastr';
import { ActivityCategory } from 'src/app/models/activity/activity-category';
import { ActivityStatus } from 'src/app/models/activity/activity-status';
import { ActivityType } from 'src/app/models/activity/activity-type';
import { Currency } from 'src/app/models/activity/currency';
import { TicketActivity } from 'src/app/models/deliveryContract/delivery-contract.model';
import { ActivityDialog } from 'src/app/models/dialog/input-dialog';
import { ActivityService } from 'src/app/services/activity/activity.service';
import { ProposalService } from 'src/app/services/proposal/proposal.service';
import { TinyMCEConfiguration } from 'src/app/shared/common/tinyMCEConfiguration';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';
import { Activity } from 'src/app/models/activity/activity';
import * as _ from 'lodash';
import { AngularUtility } from 'src/app/shared/common/angular-utitilty';
import { NgSelectComponent } from '@ng-select/ng-select';
import { LoaderService } from 'src/app/services/loader/loader.service';
import { HttpStatusCode } from '@angular/common/http';
import { TableFilters } from 'src/app/shared/common/tableFilters';
@Component({
  selector: 'app-add-edit-activity',
  templateUrl: './add-edit-activity.component.html',
  styleUrls: ['./add-edit-activity.component.css']
})
export class AddEditActivityComponent extends BaseModal implements OnInit {

  activityTableModel = new TableModel();
  ngUnsubscribe = new Subject<void>();
  activityTableData: TableItem[][] = [];
  carbonUtility = new CarbonUtility();
  locationHeaderTable: TableHeaderItem[] = [];
  showDocumentSkeleton: boolean = true;
  subscription$: Subscription = new Subscription();
  activityForm: FormGroup;
  isEditted: boolean = false;
  tinyMCECApiKey: string = TinyMCEConfiguration.apiKey;
  tinyMCESettings: any = TinyMCEConfiguration.settings;
  activityCategories: ActivityCategory[] = [];
  activityTypes: ActivityType[] = [];
  activityStatuses: ActivityStatus[] = [];
  currencies: Currency[] = [];
  activity: TicketActivity;
  activityList: Activity[];
  quantity: number = 0;
  tableFilter: TableFilters = new TableFilters();
  // Activity Data  Start//
  @Input() paramsData: any;
  angularUtility = new AngularUtility();
  totalLaborCost = 0;
  totalMaterialBudget = 0;
  totalTavelCost = 0;

  // Activity Data ENd
  @ViewChild('customHeaderAction', { static: true }) customHeaderAction: ElementRef;
  @ViewChild('instanceInput', { static: true }) instanceInput: ElementRef;

  data: ActivityDialog;
  isModalOpen: boolean = true;
  isAlreadyContract: boolean = false;
  contractId: number = 0;
  activities: any[] = [];
  selectedActivities: any[] = [];
  finalActivities: any[] = [];

  @ViewChildren('filterDropdown') filterDropdown: NgSelectComponent[];
  filterForm: FormGroup;
  typeFilterList: any = [];
  categoryFilterList: any = [];
  nameFilterList: any = [];
  technicianLevelFilterList: any = [];
  responseIntervalFilterList: any = [];
  regionFilterList: any = [];
  currencyFilterList: any = [];
  totalVariableCostFilterList: any = [];
  isActivitySelected: boolean = false;
  Filter_CurrentSelectedType: any;
  Filter_CurrentSelectedCategory: any;
  Filter_CurrentSelectedTechnicianLevel: any;
  Filter_CurrentSelectedResponseInterval: any;
  Filter_CurrentSelectedName: any;
  Filter_CurrentSelectedRegion: any;
  Filter_CurrentSelectedCurrency: any;
  Filter_CurrentSelectedTotalVariableCost: any;

  constructor(
    protected injector: Injector,
    private formBuilder: FormBuilder,
    private toaster: ToastrService,
    private activityService: ActivityService,
    private proposalService: ProposalService,
    private loaderService: LoaderService
  ) {
    super();
    this.data = this.injector.get('data');
    this.isAlreadyContract = this.injector.get('isalreadyContract');
    this.contractId = this.injector.get('contractId');
    let billable: ActivityType = {
      id: 1,
      type: 'Billable'
    }

    let nonBillable: ActivityType = {
      id: 2,
      type: 'Non-Billable'
    }
    this.activityTypes.push(billable);
    this.activityTypes.push(nonBillable);
  }


  ngOnInit(): void {
    this.totalLaborCost = 0;
    this.totalMaterialBudget = 0;
    this.totalTavelCost = 0;
    this.initilizeFilterForm();

    if (!this.isAlreadyContract) {
      this.createForm();
      this.loadData();
    }
    else {
      this.getActivitiesByProposalId();
    }
  }

  isActivityRowSelected() {
    this.isActivitySelected = this.activityTableModel.rowsSelected.some((item) => item);
    return this.isActivitySelected;
  }

  loadData() {
    const activityRequests = this.executeActivityRequests();
    this.loaderService.show();
    this.subscription$.add(
      forkJoin(activityRequests).subscribe({
        next: (res: any) => {
          this.loaderService.hide();
          this.activityCategories = res?.results;
          this.activityStatuses = res?.results;
          this.currencies = res?.results;
        },
      })
    );
  }

  executeActivityRequests() {
    const activityCategories$ = this.activityService.getActivityCategories().pipe(
      catchError((error) => {
        this.handleError(
          error,
          'Something went wrong while loading categories'
        );
        return of(error);
      })
    );

    const activityStatuses$ = this.activityService.getActivityStatuses().pipe(
      catchError((error) => {
        this.handleError(
          error,
          'Something went wrong while loading statuses'
        );
        return of(error);
      })
    );

    const currencies$ = this.activityService.getCurrencies().pipe(
      catchError((error) => {
        this.handleError(
          error,
          'Something went wrong while loading currencies'
        );
        return of(error);
      })
    );

    const activityRequests = {
      activityCategories: activityCategories$,
      activityStatuses: activityStatuses$,
      currencies: currencies$,
    };
    return activityRequests;
  }

  handleError(error: any, message?: string) {
    if (
      error?.error?.statusCode === HttpStatusCode.NotFound ||
      error?.error?.statusCode === HttpStatusCode.Conflict
    ) {
      this.toaster.error(error?.error?.message, 'Error');
    } else {
      this.toaster.error(message, 'Error');
    }
  }

  onAnyUpdate() {
    this.isEditted = true;
  }
  get f() {
    return this.activityForm.controls;
  }
  createForm() {

    let numRegex = '/^d+(.d{1,2})?$/';
    this.activityForm = this.formBuilder.group({
      id: [null],
      title: new FormControl('', [Validators.required]),
      displayName: new FormControl(''),
      category: new FormControl('', [Validators.required]), //[Validators.required],
      type: new FormControl('', [Validators.required]), //[Validators.required],
      status: new FormControl('', [Validators.required]),
      currencyId: new FormControl('', [Validators.required]),
      quantity: new FormControl('', [Validators.required]),
      assumptions: new FormControl(''), //,Validators.maxLength(100)
      scope: new FormControl(''),
      platformFee: new FormControl('', [Validators.required]),
      financeFee: new FormControl('', [Validators.required]),
      roundingAmount: new FormControl('', [Validators.required]),
      riskPercent: new FormControl('', [Validators.required]),
    });
  }

  getActivitiesByProposalId() {
    this.loaderService.show();
    this.proposalService
      .getProposalActivitiesByProposalId(this.contractId,'ticket',false,this.tableFilter)
      .subscribe({
        next: (res) => {
          this.loaderService.hide();
          if (res.statusCode == 200) {
            this.activityList = res.results
            this.populateDocumentTable(this.activityList);
            this.populateFilterDropdowns(this.activityList);
          }
          else {
            this.toaster.error('Something went wrong');
          }
          // res.results.forEach((element) => {
          //   let activity: TicketActivity = {
          //     id: 0,
          //     name: element.name,
          //     displayName: element.displayName,
          //     categoryId: 2,
          //     billable: element.typeId == 1 ? true : false,
          //     statusId: element.statusId,
          //     currencyId: element.currencyId,
          //     currentDollarValue: null,
          //     quantity: element.quantity,
          //     assumptions: element.assumptions,
          //     scope: element.scope,
          //     platformFeePercent: 0,
          //     financeFeePercent: 0,
          //     roundingAmount: 0,
          //     riskPercent: 0,
          //     versionId: 1,
          //     TicketId: 0,
          //     //parentActivityId: null,
          //     category: null,
          //     status: null,
          //     parentActivityId: null,
          //     resourcesses: element.resourcesses,
          //   };
          //   // let activity = {
          //   //   name: element.name,
          //   //   price: element.currentDollarValue,
          //   // };
          //   // let sow = {
          //   //   name: element.name,
          //   //   scope: element.scope,
          //   // };

          //   //this.activities.push(activity);

          //   // this.scopeOfWork.push(sow);
          // });
        },
        error: (err) => {
          this.loaderService.hide();
          this.handleError(err, 'Something went wrong');
        }
      });
  }

  getValues() {
    let activity: TicketActivity = {
      id: this.isEditted ? this.activity?.id! : null,
      name: this.activityForm.value.title,
      displayName: this.activityForm.value.displayName,
      categoryId: this.activityForm.value.category,
      billable: this.activityForm.value.type == 1 ? true : false,
      statusId: this.activityForm.value.status,
      currencyId: this.activityForm.value.currencyId,
      currentDollarValue: null,
      quantity: this.activityForm.value.quantity,
      assumptions: this.activityForm.value.assumptions,
      scope: this.activityForm.value.scope,
      platformFeePercent: this.activityForm.value.platformFee,
      financeFeePercent: this.activityForm.value.financeFee,
      roundingAmount: this.activityForm.value.roundingAmount,
      riskPercent: this.activityForm.value.riskPercent,
      versionId: 1,
      TicketId: 0,
      //parentActivityId: null,
      category: this.activityForm.value.category,
      status: this.activityForm.value.status,
      parentActivityId: null,
      resourcesses: null,
      totalLaborCost:  0,
      totalMaterialBudget:0,
      totalTavelCost:0,
    };
    return activity;
  }

  closeMyModal() {
    this.closeModal();
    this.data.confirm = false;
    this.isModalOpen = false
    this.data.obs.next(this.data);
  }
  onProjectActivitySave() {
    if (!this.isAlreadyContract) {
      this.closeModal();
      this.data.confirm = true;
      this.isModalOpen = false;
      this.finalActivities.push(this.getValues());
      this.data.data = this.finalActivities;
      this.data.obs.next(this.data);
    }
    else {
      // if (this.selectedActivities.length > 0) {
      //   this.selectedActivities.forEach(element => {
      //     let activityArray = Array(element.quantity).fill(element).flat();
      //     activityArray.map(x=>x.quantity=activityArray.length-(activityArray.length-1));
      //     this.finalActivities.push(...activityArray);
      //   });
      // }

      const validate = this.selectedActivities.every(res => res.quantity > 0);
      if(validate){
        this.closeModal();
        this.data.confirm = true;
        this.isModalOpen = false;
        this.data.data = this.selectedActivities;
        this.data.obs.next(this.data);
      } else {
        this.toaster.error("Quantity should not be empty or zero.");
      }
    }


  }

  changeQuanity(activity, event) {
    this.activityList.forEach((item) => {
      if (item?.id == activity?.id) {
        item.totalLaborCost *= event?.target?.value;
        item.totalTavelCost *= event?.target?.value;
        item.totalMaterialBudget *= event?.target?.value;
      }
    });

    const tempSelectedRow = this.activityTableModel.rowsSelected;
    this.populateDocumentTable(this.activityList);
    this.activityTableModel.rowsSelected = tempSelectedRow;
    this.countGrandTotal();
  }

  onUpdateProjectActivity() {
    // this.activityService.updateActivity(this.getValues()).subscribe((res) => {
    //   if (res.statusCode == 200) {
    //     this.toastr.success('Saved Successfully');
    //     this.routeToParent();

    //   } else {
    //     this.toastr.error('Something went wrong');
    //   }
    // });
  }


  onSubmit() {
    // if (this.isactivitycheck) {
    //   if (this.activity?.id! > 0) {
    //     this.saveRequest(this.getValues());
    //   } else {
    //     this.saveRequest(this.getValues());
    //   }
    // } else {
    //   this.activityService.saveActivity(this.getValues()).subscribe((res) => {
    //     if (res.statusCode == 200) {
    //       this.toastr.success('Saved Successfully');
    //       this.routeToParent();
    //     } else {
    //       this.toastr.error('Something went wrong');
    //     }
    //   });
    // }
  }
  onCancelActivity() {
    this.closeMyModal();
  }



  countGrandTotal() {
    this.totalLaborCost = 0;
    this.totalTavelCost = 0;
    this.totalMaterialBudget = 0;

    this.selectedActivities.forEach(selectedActivity => {
      this.totalLaborCost += selectedActivity.totalLaborCost;
      this.totalTavelCost += selectedActivity.totalTavelCost;
      this.totalMaterialBudget += selectedActivity.totalMaterialBudget;
    });
  }

  handleScrollPosition() {
    var parentContainer = $("#grand-total")?.closest(".bx--modal-content");
    $(".table-border")?.animate({ scrollTop: $("#grand-total")?.scrollTop() }, 1000);
    parentContainer?.animate({ scrollTop: parentContainer?.scrollTop() }, 1000);
    $("#grand-total")?.scrollTop();
  }

  selectedRow(event) {
    this.isActivityRowSelected();
    const index = event?.selectedRowIndex;
    if (index > -1) {
      this.totalLaborCost += this.activityList[index]?.totalLaborCost;
      this.totalTavelCost += this.activityList[index]?.totalTavelCost;
      this.totalMaterialBudget += this.activityList[index]?.totalMaterialBudget;
    }
    const itemPageOffset = ((this.activityTableModel.currentPage - 1) * this.activityTableModel.pageLength) + event.selectedRowIndex;
    const selectedIndex = this.activityTableModel.currentPage > 1 ? itemPageOffset : event.selectedRowIndex;
    let activityData = this.activityList[selectedIndex];
    activityData.activityId = activityData.parentActivityId;
    activityData.parentActivityId = activityData.id;
    activityData['billable'] = true;
    activityData.resources?.map(x => x.id = 0);
    this.selectedActivities.push(activityData);
  }

  deSelectRow(event) {
    this.isActivityRowSelected();
    this.selectedActivities.splice(event.deselectedRowIndex, 1);
    const index = event?.deselectedRowIndex;
    if (index > -1) {
      this.totalLaborCost -= this.activityList[index]?.totalLaborCost;
      this.totalTavelCost -= this.activityList[index]?.totalTavelCost;
      this.totalMaterialBudget -= this.activityList[index]?.totalMaterialBudget;
    }
    this.selectedActivities.splice(event.deselectedRowIndex, 1);

  }

  selectAllRow(event) {
    this.isActivityRowSelected();
    let activityList: any = []
    let selectedItems = event.data;
    selectedItems.forEach(element => {
      let id = element[0]?.data;
      let activityData = this.activityList?.find(s => s.id == id)
      activityData!.activityId = activityData!.parentActivityId;
      activityList.push(activityData)
    });
    this.selectedActivities = activityList;
  }

  deSelectAllRow(activity) {
    this.isActivitySelected = activity?.rowsSelected.every((item) => item);
    if (!this.isActivitySelected) {
      this.selectedActivities = [];
    }
  }

  onSearch(event) {
    let filteredactivityList = this.activityList;
    if (!this.carbonUtility.isEmptyOrSpaces(event)) {
      filteredactivityList = this.activityList.filter((x) => {
        return (
          x.name
            ?.toLocaleLowerCase()
            .includes(event.toLocaleLowerCase())
          || x.name == event

        );
      });
    }
    this.populateDocumentTable(filteredactivityList);
    this.InitializeDocumentLocationTable();
  }

  InitializeDocumentLocationTable() {
    this.activityTableModel.data = [];

    let headers = [

      new TableHeaderItem({ data: 'ID', visible: false }),
      new TableHeaderItem({ data: 'Name' }),
      new TableHeaderItem({ data: 'Type' }),
      new TableHeaderItem({ data: 'Category' }),
      new TableHeaderItem({ data: 'Tech Level' }),
      new TableHeaderItem({ data: 'Response Interval' }),
      new TableHeaderItem({ data: 'Region' }),
      new TableHeaderItem({ data: 'Currency' }),
      new TableHeaderItem({ data: 'Price' }),
      new TableHeaderItem({ data: 'Activity Quantity', isColumnDragging: true }),
      new TableHeaderItem({ data: '# of Instances'}),
      new TableHeaderItem({ data: 'Assumptions' }),
      new TableHeaderItem({ data: 'Total Labor Budget' }),
      new TableHeaderItem({ data: 'Total Travel Budget' }),
      new TableHeaderItem({ data: 'Total Material' }),
    ];
    this.activityTableModel = this.carbonUtility.initializeTable(
      headers,
      this.activityTableModel,
      this.activityTableData
    );

    this.selectPageDocument(1);
  }

  populateDocumentTable(resourecesList: Activity[]) {
    this.activityList = resourecesList;
    this.activityTableData = [];
    this.activityTableModel.totalDataLength = resourecesList.length;
    if (resourecesList != null && resourecesList.length > 0) {
      resourecesList.forEach((el) => {
        el.quantity = el.quantity == 0 ? 1 : el.quantity;
        el.instances = el.instances == 0 || el.instances == undefined || el.instances == null ? 1 : el.instances;
        if (el.resources != null && el.resources.length > 0) {
          el.totalLaborCost = this.angularUtility.getSum(_.filter(el.resources, ['categoryId', 1]), 'totalCost') * el.quantity;
          el.totalMaterialBudget = this.angularUtility.getSum(_.filter(el.resources, ['categoryId', 1008]), 'totalCost') * el.quantity;
          el.totalTavelCost = this.angularUtility.getSum(_.filter(el.resources, ['categoryId', 2]), 'totalCost') * el.quantity;
        }
        const assumptions = document.createElement('div');
        assumptions.innerHTML = el.assumptions?el.assumptions:'';
        const scope = document.createElement('div');
        scope.innerHTML =el.name;
        this.activityTableData.push([
          new TableItem({ data: el.id }),
          new TableItem({ data: el.name }),
          new TableItem({ data: el.parentActivity?.activityTypeName }),
          new TableItem({ data: el.parentActivity?.categoryName }),
          new TableItem({ data: el.parentActivity?.technicianLevelName }),
          new TableItem({ data: el.parentActivity?.responseIntervalName }),
          new TableItem({ data: el.parentActivity?.regionName }),
          new TableItem({ data: el.parentActivity?.currencyName }),
          new TableItem({ data: el.price }),
          new TableItem({ data: el, template: this.customHeaderAction }),
          new TableItem({ data: el, template: this.instanceInput }),
          new TableItem({ data: assumptions.textContent }),
          new TableItem({ data: el.totalLaborCost == undefined ? 0 : el.totalLaborCost }),
          new TableItem({ data: el.totalTavelCost == undefined ? 0 : el.totalTavelCost }),
          new TableItem({ data: el.totalMaterialBudget == undefined ? 0 : el.totalMaterialBudget }),
        ]);
      });
    }
    this.InitializeDocumentLocationTable();
    this.showDocumentSkeleton = false;
    this.handleScrollPosition();
  }

  selectPageDocument(page: any) {
    this.activityTableModel = this.carbonUtility.selectPage(
      page,
      this.activityTableModel,
      this.activityTableData
    );
  }

  stopPropagtion(event) {
    event.stopPropagation();
  }

  changeInputValue(event) {
    if (event.target.value == 0 || event.target.value == '' || event.target.value == null) {
      event.target.value = 1;
      return event.target.value;
    }
  }

  validateInputField(event: any): any {
    if (event.keyCode === 45) {
      return false;
    }
  }

  populateFilterDropdowns(activities: any) {
    var categories = activities.map((s) => s.parentActivity?.categoryName);
    this.categoryFilterList = [];
    categories.forEach((element) => {
      var addedList = this.categoryFilterList.filter((s) => s == element);
      if (addedList.length <= 0) {
        this.categoryFilterList.push(element);
      }
    });

    var types = activities.map((s) => s.parentActivity?.activityTypeName);
    this.typeFilterList = [];
    types.forEach((element) => {
      var addedList = this.typeFilterList.filter((s) => s == element);
      if (addedList.length <= 0) {
        this.typeFilterList.push(element);
      }
    });

    var names = activities.map((s) => s.name);
    this.nameFilterList = [];
    for (let index = 0; index < names.length; index++) {
      const element = names[index];
      var addedList = this.nameFilterList.filter((s) => s == element);
      if (addedList.length <= 0) {
        this.nameFilterList.push(element);
      }
    }

    var reponseIntervals = activities.map(s=>s.parentActivity.responseIntervalName)
    this.responseIntervalFilterList = [];
    reponseIntervals.forEach((element) => {
      var el = (element == null ? '' : element);
      var addedList = this.responseIntervalFilterList.filter((s) => s == el);
      if (addedList.length <= 0) {
        this.responseIntervalFilterList.push(el);
      }
    });

    var techLevels = activities.map(s=>s.parentActivity.technicianLevelName)
    this.technicianLevelFilterList = [];
    techLevels.forEach((element) => {
      var el = (element == null ? '' : element);
      var addedList = this.technicianLevelFilterList.filter((s) => s == el);
      if (addedList.length <= 0) {
        this.technicianLevelFilterList.push(el);
      }
    });

    var regions = activities.map((s) => s.region);
    this.regionFilterList = [];
    for (let index = 0; index < regions.length; index++) {
      const element = regions[index] == null ? '' : regions[index];
      var addedList = this.regionFilterList.filter((s) => s == element);
      if (addedList.length <= 0) {
        this.regionFilterList.push(element);
      }
    }

    var currencies = activities.map((s) => s.currency);
    this.currencyFilterList = [];
    for (let index = 0; index < currencies.length; index++) {
      const element = currencies[index] == null ? '' : currencies[index];
      var addedList = this.currencyFilterList.filter((s) => s == element);
      if (addedList.length <= 0) {
        this.currencyFilterList.push(element);
      }
    }

    var totalvariablecosts = activities.map((s) => s.totalVariableCost);
    this.totalVariableCostFilterList = [];
    for (let index = 0; index < totalvariablecosts.length; index++) {
      const element =
        totalvariablecosts[index] == null
          ? '<blank>'
          : totalvariablecosts[index];
      var addedList = this.totalVariableCostFilterList.filter(
        (s) => s == element
      );
      if (addedList.length <= 0) {
        this.totalVariableCostFilterList.push(element);
      }
    }
  }

  onChangeFilter_Type(event) {
    this.Filter_CurrentSelectedType = event;
    this.filterActivityList();
  }
  onChangeFilter_Category(event) {
    this.Filter_CurrentSelectedCategory = event;
    this.filterActivityList();
  }
  onChangeFilter_Name(event) {
    this.Filter_CurrentSelectedName = event;
    this.filterActivityList();
  }
  onChangeFilter_ResponseInterval(event) {
    this.Filter_CurrentSelectedResponseInterval = event;
    this.filterActivityList();
  }
  onChangeFilter_TechLevel(event) {
    this.Filter_CurrentSelectedTechnicianLevel = event;
    this.filterActivityList();
  }
  onChangeFilter_Region(event) {
    this.Filter_CurrentSelectedRegion = event;
    this.filterActivityList();
  }
  onChangeFilter_Currency(event) {
    this.Filter_CurrentSelectedCurrency = event;
    this.filterActivityList();
  }
  onChangeFilter_TotalVariableCost(event) {
    this.Filter_CurrentSelectedTotalVariableCost = event;
    this.filterActivityList();
  }

  filterActivityList() {
    var newlist: any = [];
    if (this.Filter_CurrentSelectedType != null) {
      newlist = this.activityList.filter(
        (s) => s.parentActivity?.activityTypeName == this.Filter_CurrentSelectedType
      );
      this.populateDocumentTable(newlist);
    }

    if (this.Filter_CurrentSelectedCategory != null) {
      newlist = this.activityList.filter(
        (s) => s.parentActivity?.categoryName == this.Filter_CurrentSelectedCategory
      );
      this.populateDocumentTable(newlist);
    }

    if (this.Filter_CurrentSelectedName != null) {
      newlist = this.activityList.filter(
        (s) => s.name == this.Filter_CurrentSelectedName
      );
      this.populateDocumentTable(newlist);
    }

    if (this.Filter_CurrentSelectedResponseInterval != null) {
      var res = this.activityList.filter(
        (s) => s.parentActivity?.responseIntervalName == this.Filter_CurrentSelectedResponseInterval
      );
      newlist = res;
      this.populateDocumentTable(newlist);
    }

    if (this.Filter_CurrentSelectedTechnicianLevel != null) {
      newlist = this.activityList.filter(
        (s) => s.parentActivity?.technicianLevelName == this.Filter_CurrentSelectedTechnicianLevel
      );
      this.populateDocumentTable(newlist);
    }

    if (this.Filter_CurrentSelectedRegion != null) {
      newlist = this.activityList.filter(
        (s) => s.region == this.Filter_CurrentSelectedRegion
      );
      this.populateDocumentTable(newlist);
    }

    if (this.Filter_CurrentSelectedCurrency != null) {
      newlist = this.activityList.filter(
        (s) => s.currency == this.Filter_CurrentSelectedCurrency
      );
      this.populateDocumentTable(newlist);
    }

    if (this.Filter_CurrentSelectedTotalVariableCost > 0) {
      newlist = this.activityList.filter(
        (s) => s.totalVariableCost == this.Filter_CurrentSelectedTotalVariableCost
      );
      this.populateDocumentTable(newlist);
    }
  }

  initilizeFilterForm() {
    this.filterForm = this.formBuilder.group({
      typeId: [0],
      categoryId: [0],
      name: [null],
      technicianLevel: [null],
      responseInterval: [null],
      region: [null],
      currencyId: [null],
      totalVariableCostId: [null],
    });
  }

  clearFilter() {
    this.filterDropdown.forEach((e) => e.handleClearClick());
    this.filterForm.controls['typeId'].setValue(0);
    this.filterForm.controls['categoryId'].setValue(0);
    this.filterForm.controls['name'].setValue(null);
    this.filterForm.controls['technicianLevel'].setValue(null);
    this.filterForm.controls['responseInterval'].setValue(null);
    this.filterForm.controls['region'].setValue(null);
    this.filterForm.controls['currencyId'].setValue(null);
    this.filterForm.controls['totalVariableCostId'].setValue(0);
    this.Filter_CurrentSelectedType = null;
    this.Filter_CurrentSelectedCategory = null;
    this.Filter_CurrentSelectedName = null;
    this.Filter_CurrentSelectedName = null;
    this.Filter_CurrentSelectedRegion = null;
    this.Filter_CurrentSelectedCurrency = null;
    this.Filter_CurrentSelectedTotalVariableCost = 0;
    this.getActivitiesByProposalId()
  }


}
