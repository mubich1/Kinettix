import { Component, ElementRef, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { ModalService, TableHeaderItem, TableItem, TableModel } from 'carbon-components-angular';
import { Observable, Subject, takeUntil, Subscription, throwIfEmpty } from 'rxjs';
import { TicketActivity } from 'src/app/models/deliveryContract/delivery-contract.model';
import { ConfirmationDialog } from 'src/app/models/dialog/confirmation';
import { ActivityDialog, LocationDialog } from 'src/app/models/dialog/input-dialog';
import { AngularUtility } from 'src/app/shared/common/angular-utitilty';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';
import { ConfirmationDialogComponent } from 'src/app/shared/components/confirmation-dialog/confirmation-dialog.component';
import { AddEditActivityComponent } from './add-edit-activity/add-edit-activity.component';
import * as _ from 'lodash';

@Component({
  selector: 'app-ticket-activities',
  templateUrl: './ticket-activities.component.html',
  styleUrls: ['./ticket-activities.component.css']
})
export class TicketActivitiesComponent implements OnInit, OnDestroy {

  activityTableModel = new TableModel();
  ngUnsubscribe = new Subject<void>();
  activityHeaderTable: TableHeaderItem[] = [];
  activityTableData: TableItem[][] = [];
  carbonUtility = new CarbonUtility();
  currentItem: TicketActivity;
  showDocumentSkeleton: boolean = true;
  isOpenDeleteModal = false;
  selectedDeleteActivityId: number = 0;
  activity: TicketActivity[] = [];
  isAlreadyContract: boolean = false;
  angularUtility = new AngularUtility();
  @Output() GetActivities = new EventEmitter<TicketActivity[]>();
  @ViewChild('customHeaderAction', { static: true }) customHeaderAction: ElementRef;
  @ViewChild('customHeaderToggle', { static: true }) customHeaderToggle: ElementRef;
  statusModalObs: Observable<ActivityDialog> = new Subject<ActivityDialog>();
  activityModalObs: Observable<ConfirmationDialog> = new Subject<ConfirmationDialog>();
  totalLaborCost = 0;
  totalMaterialBudget = 0;
  totalTavelCost = 0;
  @Input() contractId: number = 0;
  constructor(private modalService: ModalService,) { }

  ngOnInit(): void {
    this.populateDocumentTable(this.activity);
  }

  ngAfterContentInit() {
    this.statusModalObs.pipe(takeUntil(this.ngUnsubscribe)).subscribe((value) => {
      if (value.confirm) {
        this.activity.push(...value.data);
        const addId=(arr)=> arr.map((obj, index)=>({...obj,incId: index }));
        this.activity= addId(this.activity)
      }
      this.GetActivities.emit(this.activity);
      this.populateDocumentTable(this.activity);


    });

    // For adding new activities.
    this.activityModalObs.pipe(takeUntil(this.ngUnsubscribe)).subscribe((value) => {
      if (!value.isClosed) {
        if (value.confirm) {
          this.isAlreadyContract = true;
          this.openModel();
        }
      }
    });
  }
  onSearch(event) {
    let filteredactivityList = this.activity;
    if (!this.carbonUtility.isEmptyOrSpaces(event)) {
      filteredactivityList = this.activity.filter((x) => {
        return (
          x.name
            ?.toLocaleLowerCase()
            .includes(event.toLocaleLowerCase())
          || x.riskPercent == event
        );
      });
    }
    this.populateDocumentTable(filteredactivityList);
    this.InitializeDocumentActivityTable();
  }

  InitializeDocumentActivityTable() {
    this.activityTableModel.data = [];

    this.activityHeaderTable = [
      new TableHeaderItem({ data: 'ID', visible: false }),
      new TableHeaderItem({ data: 'Name' }),
      new TableHeaderItem({ data: 'Quantity', isColumnDragging: true }),
      new TableHeaderItem({ data: 'Scope' }),
      new TableHeaderItem({ data: 'Assumptions' }),
      new TableHeaderItem({ data: 'Total Labor Budget' }),
      new TableHeaderItem({ data: 'Total Travel Budget' }),
      new TableHeaderItem({ data: 'Total Material' }),
       new TableHeaderItem({ data: 'Billable' }),
      new TableHeaderItem({ data: 'Action', isColumnDragging: true }),

    ];
    this.activityTableModel = this.carbonUtility.initializeTable(
      this.activityHeaderTable,
      this.activityTableModel,
      this.activityTableData
    );

    this.selectPageDocument(1);
  }
  populateDocumentTable(activityList: TicketActivity[]) {
    this.activityTableData = [];
    this.activityTableModel.totalDataLength = activityList.length;
    if (activityList != null && activityList.length > 0) {
      activityList.forEach((el,index) => {
        if (el.resourcesses != null && el.resourcesses.length > 0) {
          el.totalLaborCost = this.angularUtility.getSum(_.filter(el.resourcesses, ['categoryId', 1]), 'totalCost')*el.quantity;
          el.totalMaterialBudget = this.angularUtility.getSum(_.filter(el.resourcesses, ['categoryId', 4]), 'totalCost')*el.quantity;
          el.totalTavelCost = this.angularUtility.getSum(_.filter(el.resourcesses, ['categoryId', 2]), 'totalCost')*el.quantity;

          this.totalLaborCost += this.angularUtility.getSum(_.filter(el.resourcesses, ['categoryId', 1]), 'totalCost')*el.quantity;
          this.totalMaterialBudget += this.angularUtility.getSum(_.filter(el.resourcesses, ['categoryId', 4]), 'totalCost')*el.quantity;
          this.totalTavelCost += this.angularUtility.getSum(_.filter(el.resourcesses, ['categoryId', 2]), 'totalCost')*el.quantity;
        }
        this.activityTableData.push([
          new TableItem({ data: el.id }),
          new TableItem({ data: el.name }),
          new TableItem({ data: el.quantity }),
          new TableItem({ data: el.scope }),
          new TableItem({ data: el.assumptions }),
          new TableItem({ data: el.totalLaborCost == undefined ? 0 : el.totalLaborCost }),
          new TableItem({ data: el.totalTavelCost == undefined ? 0 : el.totalTavelCost }),
          new TableItem({ data: el.totalMaterialBudget == undefined ? 0 : el.totalMaterialBudget }),
           new TableItem({ data: { data: el, index: index } , template: this.customHeaderToggle }),

          new TableItem({ data: el, template: this.customHeaderAction }),
        ]);
      });
    }
    this.InitializeDocumentActivityTable();
    this.showDocumentSkeleton = false;
  }

  onConfirmationDelete() {
    // ;
    // this.deliveryContractService
    //   .deleteTicketById(this.selectedDeleteTicketId)
    //   .subscribe({
    //     next: (res) => {
    //       this.toastr.success('Deleted Successfully');
    //       this.getTickets();
    //     },
    //     error: (e) => {
    //       console.log(e);
    //       this.toastr.error('Something went wrong');
    //     },

    //     complete: () => this.closeParentModal(),
    //   });
  }

  onClickEdit(value: TicketActivity) {
    const docId = value.id!;
    if (docId > 0) {
      this.currentItem = value;
    } else {
      //this.onUpload();
    }
  }

  deleteRes(value: TicketActivity) {

    let index = this.activity.findIndex(x => x === value);
    this.activity.splice(index, 1);
    this.populateDocumentTable(this.activity);
  }
  openParentModal() {
    this.isOpenDeleteModal = true;
  }


  selectPageDocument(page: any) {
    this.activityTableModel = this.carbonUtility.selectPage(
      page,
      this.activityTableModel,
      this.activityTableData
    );
  }
  closeParentModal() {
    this.isOpenDeleteModal = false;
    this.selectedDeleteActivityId = 0;
  }
  openModel() {
    const modalInputs: ActivityDialog = {
      header: 'Add Activities',
      confirmationButtonText: 'Save',
      cancelButtonText: 'Cancel',
      data: this.activity,
      confirm: false,
      obs: this.statusModalObs,
    };
    this.modalService.create({
      component: AddEditActivityComponent,
      inputs: { data: modalInputs, isalreadyContract: this.isAlreadyContract, contractId: this.contractId },
    });
  }
  onChangeCurrent(data, value: any,index) {
    var state = data.checked;
    value.data.billable=state;
    this.activity[value.data.incId]=value.data;

  }

  openActivityConfirmationModal() {
    const modalInputs: ConfirmationDialog = {
      header: 'Activities',
      question: 'Please Select Activities from Existing Contract ',
      confirmationButtonText: 'Existing',
      cancelButtonText: 'Cancel',
      data: null,
      obs: this.activityModalObs,
      confirm: false,
      isClosed: false,
    };

    this.modalService.create({
      component: ConfirmationDialogComponent,
      inputs: { data: modalInputs },
    });
  }
  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();

  }


}
