import { DatePipe } from '@angular/common';
import { Component, Injector, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BaseModal, ModalService } from 'carbon-components-angular';
import { ToastrService } from 'ngx-toastr';
import { Observable, Subject, takeUntil } from 'rxjs';
import { Client, EndClient } from 'src/app/models/client/client';
import { SelectBox } from 'src/app/models/client/country';
import {
  ContractTicketRequest,
  TicketActivity,
} from 'src/app/models/deliveryContract/delivery-contract.model';
import { LocationDialog } from 'src/app/models/dialog/input-dialog';
import { ClientContractsGetDto } from 'src/app/models/project/project';
import { ClientService } from 'src/app/services/client/client.service';
import { DeliveryContractService } from 'src/app/services/deliveryContract/delivery-contract.service';
import { EmployeeService } from 'src/app/services/employee/employee.service';
import { LoaderService } from 'src/app/services/loader/loader.service';
import { ProjectActivityResourceService } from 'src/app/services/project-activity-resources/project-activity-resources.service';
import { ProposalService } from 'src/app/services/proposal/proposal.service';
import { TicketLocationsComponent } from './ticket-activities/ticket-locations/ticket-locations.component';

@Component({
  selector: 'app-add-ticket',
  templateUrl: './add-ticket.component.html',
  styleUrls: ['./add-ticket.component.css'],
})
export class AddTicketComponent extends BaseModal implements OnInit {
  ticketForm: FormGroup;
  contractId: number = 0;
  clientId: number = 0;
  clients: Client[] = [];
  endClients: EndClient[] = [];
  secondryClientId: number = 0;
  ngUnsubscribe = new Subject<void>();
  ticketActivity: TicketActivity[];
  contractInfo: ClientContractsGetDto;
  locationsModalObs: Observable<LocationDialog> = new Subject<LocationDialog>();

  minDate: Date;
  endClientId: number = 0;
  isClientDisabled: boolean = false;
  isEndClientDisabled: boolean = false;

  isOpenRoundOffConfirmationModal = false;
  currentSelectedArrivalDate: Date;
  currentSelectedArrivalDate_Adjusted: Date;
  currentSelectedActualDate_Adjusted: Date;
  currentSelectedActualDate: Date;

  constructor(
    protected injector: Injector,
    private clientService: ClientService,
    private router: Router,
    private toaster: ToastrService,
    private formBuilder: FormBuilder,
    public datepipe: DatePipe,
    private loaderService: LoaderService,
    private modalService: ModalService,
    private projectActivityService: ProjectActivityResourceService,
    private deliveryContractService: DeliveryContractService
  ) {
    super();
    this.clientId = this.injector.get('clientId');
    this.contractId = this.injector.get('contractId');
  }

  formGroup: FormGroup;

  get invalidRange() {
    return (
      this.formGroup.controls['range'].invalid &&
      this.formGroup.controls['range'].touched
    );
  }

  ngOnInit(): void {
    setInterval(() => {
      this.setMinDate();
    }, 1000);

    this.projectActivityService.getContractServiceInfo().subscribe({
      next: (res) => {
        this.contractInfo = res;
        this.createForm();
        this.getAllClients();
      },
    });
  }

  ngAfterContentInit() {
    this.locationsModalObs.subscribe((value) => {
      if (value.confirm) {
        this.ticketForm.patchValue({
          clientSiteId: value.data.id,
          siteNumber: value.data.siteNumber,
          siteName: value.data.name,
          Country: value.data.countryName,
          address: value.data.address,
          city: value.data.city,
          stateOrProvince: value.data.state,
          postalCode: value.data.postalCode,
          timeZone: value.data.timeZone,
        });
      }
    });
  }
  get f() {
    return this.ticketForm.controls;
  }

  createForm() {
    let numRegex = '/^d+(.d{1,2})?$/';
    this.ticketForm = this.formBuilder.group({
      id: [0],
      name: new FormControl('', [Validators.required]),
      // accountExectiveId: new FormControl(''),
      // projectMangerId: new FormControl(''),
      scheduleArival: new FormControl(),
      actutalEnd: new FormControl(),
      secondaryClient: new FormControl(0),
      endClient: new FormControl(0),
      siteNumber: new FormControl(''),
      siteName: new FormControl(''),
      Country: new FormControl(''),
      clientSiteId: new FormControl(null),
      address: new FormControl(''),
      city: new FormControl(''),
      stateOrProvince: new FormControl(''),
      postalCode: new FormControl(''),
      timeZone: new FormControl(''),
      // preferedMethodOfCommunication: new FormControl('', [Validators.required]),
      actitivties: [],
    });
  }

  changeScheduleArivalDateInput(event) {
    this.ticketForm.get('actutalEnd')?.updateValueAndValidity();
  }
  changeActutalEndDateInput(event) {
    this.ticketForm.get('scheduleArival')?.updateValueAndValidity();
  }
  patchValues() {
    this.ticketForm.patchValue({
      endClientId: this.contractInfo.endClientId!,
      projectManagerId: this.contractInfo.pmoleadId!,
      secondaryClient: this.contractInfo.secondaryClient,
      endClient: this.contractInfo.endClientId,
    });
    if (
      this.contractInfo.endClientId! > 0 &&
      this.contractInfo.endClientId != null
    ) {
      this.isEndClientDisabled = true;
    }
    if (
      this.contractInfo.secondaryClient! > 0 &&
      this.contractInfo.secondaryClient != null
    ) {
      this.isClientDisabled = true;
    }
  }

  getValues() {
    let ticketModel: ContractTicketRequest = {
      id: this.ticketForm.value.id,
      contractId: Number(this.contractId),
      clientId: this.ticketForm.value.secondaryClient ?? this.secondryClientId,
      accountExecutiveId: this.contractInfo.fsoleadId?.toString() ?? '',
      arrivalInstructions: '',
      billingInstructions: '',
      categoryId: this.contractInfo.categoryId!,
      clientSiteId: this.ticketForm.value.clientSiteId,
      coordinatorId: '1',
      deliverableComments: '',
      endClientId: this.ticketForm.value.endClient,
      referenceId: 0,
      referenceType: '',
      title: this.ticketForm.value.name,
      projectManagerId: this.contractInfo.pmoleadId?.toString() ?? '',
      tools: '',
      contractTickets: this.ticketActivity,
      contractTicketSchedule:
        (this.ticketForm.value.scheduleArival &&
          this.ticketForm.value.actutalEnd) !== null
          ? {
              id: 0,
              isDefault: true,
              scheduleArival: this.ticketForm.value.scheduleArival,
              scheduleEnd: this.ticketForm.value.actutalEnd,
              ticketId: 0,
            }
          : null,
    };

    return ticketModel;
  }

  openContractLocationsModal() {
    const modalInputs: LocationDialog = {
      header: 'Add Location',
      confirmationButtonText: 'Save',
      cancelButtonText: 'Cancel',
      data: null,
      confirm: false,
      obs: this.locationsModalObs,
    };

    this.modalService.create({
      component: TicketLocationsComponent,
      inputs: { data: modalInputs, clientId: this.f.endClient.value },
    });
  }
  onSubmit() {
    if (this.currentSelectedArrivalDate != undefined || this.currentSelectedActualDate != undefined) {
        if (this.isOpenRoundOffConfirmationModal != true) {
          var needsToBeRoundedOff_schedulearrival = this.needsToBeRounded(this.currentSelectedArrivalDate);
          var needsToBeRoundedOff_actualArrival = this.needsToBeRounded(this.currentSelectedActualDate);
          if (needsToBeRoundedOff_schedulearrival || needsToBeRoundedOff_actualArrival) {
            this.isOpenRoundOffConfirmationModal = true;
            return;
          } else {
            this.ticketForm.controls['scheduleArival'].setValue(this.currentSelectedArrivalDate);
            this.ticketForm.controls['actutalEnd'].setValue(this.currentSelectedActualDate);
          }
        }
    }

    this.loaderService.show();
    this.deliveryContractService.createTickets(this.getValues()).subscribe({
      next: (res) => {
        this.loaderService.hide();
        if (res !== null) {
          this.routeToParent();
          this.toaster.success('Saved Successfully');
        }
      },
      error: (err) => {
        this.loaderService.hide();
        this.toaster.error(
          err.error?.message != ''
            ? err.error?.message
            : 'Error creating Ticket'
        );
      },
    });

    this.isOpenRoundOffConfirmationModal = false;
  }

  getActivitiesList(event: TicketActivity[]) {
    this.ticketActivity = event;
  }
  ///** Get Clients START  */
  getAllClients() {
    this.clientService.getAllClients().subscribe((res) => {
      if (res.statusCode == 200) {
        this.clients = res.results;
        this.endClients = res.results;
        this.patchValues();
      } else {
        this.toaster.error('Something went wrong while loading clients');
      }
    });
  }
  onSelectSecondryClient() {
    this.secondryClientId = this.ticketForm.value.secondaryClient;
  }
  ///** Get Clients  END  */
  closeSaveModal() {
    this.closeModal();
  }
  routeToParent() {
    let currentUrl = this.router.url;
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigate([currentUrl]);
    });
  }

  setMinDate() {
    const currentDate = new Date(
      new Date().getFullYear(),
      new Date().getMonth(),
      new Date().getDate(),
      new Date().getHours(),
      new Date().getMinutes() + 60,
      new Date().getSeconds()
    );
    this.minDate = new Date(currentDate);
  }

  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  resetTicketFormValue() {
    this.ticketForm.patchValue({
      clientSiteId: 0,
      siteNumber: '',
      siteName: '',
      Country: '',
      address: '',
      city: '',
      stateOrProvince: '',
      postalCode: '',
      timeZone: '',
    });
  }

  onSelectEndClient(event) {
    this.contractInfo.endClientId = event.target.selectedOptions[0].value;
    this.endClientId = event.target.selectedOptions[0].value;
    if (this.ticketForm.value.clientSiteId > 0) {
      this.resetTicketFormValue();
    }
  }

  selectedScheduleArrival(date: any): void {
    console.log('Picked arrival date: ', date);
    this.currentSelectedArrivalDate = date;
  }

  selectedScheduleArrival_Adjusted(date: any): void {
    console.log('Picked arrival date Adjusted: ', date);
    this.currentSelectedArrivalDate_Adjusted = date;
  }

  selectedActualArrival(date: any): void {
    console.log('Picked actual date: ', date);
    this.currentSelectedActualDate = date;
  }

  selectedActualArrival_Adjusted(date: any): void {
    console.log('Picked actual date: ', date);
    this.currentSelectedActualDate_Adjusted = date;
  }

  toggleTimeToUse(timeToUse: String) {
    if (timeToUse == 'Default') {
      this.ticketForm.controls['scheduleArival'].setValue(
        this.currentSelectedArrivalDate
      );
      this.ticketForm.controls['actutalEnd'].setValue(
          this.currentSelectedActualDate
        );
    }
    if (timeToUse == 'Adjusted') {
      this.ticketForm.controls['scheduleArival'].setValue(
        this.currentSelectedArrivalDate_Adjusted
      );
      this.ticketForm.controls['actutalEnd'].setValue(
          this.currentSelectedActualDate_Adjusted
        );
    }
    this.onSubmit();
  }

  getTimeFromDate(dateselected: Date) {
    var date = new Date(dateselected);
    var hours = date.getHours();
    var minutes: any = date.getMinutes();
    var ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0' + minutes : minutes;
    var strTime = hours + ':' + minutes + ' ' + ampm;
    return strTime;
  }

  needsToBeRounded(time) {
    const currentDate = new Date(time);
    const minute = currentDate.getMinutes();
    const minutesToRoundTo = 15;
    const remainder = minute % minutesToRoundTo;
    return remainder !== 0;
  }
}
