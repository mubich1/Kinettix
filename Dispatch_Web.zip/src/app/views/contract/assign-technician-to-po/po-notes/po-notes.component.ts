import { Component, EventEmitter, Injector, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { LoaderService } from 'src/app/services/loader/loader.service';
import { PurchaseOrderService } from 'src/app/services/purchase-order/purchase-order.service';

@Component({
  selector: 'app-po-notes',
  templateUrl: './po-notes.component.html',
  styleUrls: ['./po-notes.component.css']
})
export class PoNotesComponent implements OnInit {
  @Output() emitPoNotes = new EventEmitter();
  @Output() onCloseModal = new EventEmitter();
  @Input() set notesData(notesData:any) {
    if(notesData) {
      this.poNotes = notesData.poNotes;
      this.poId = notesData.poId
    }
  }
  isOpenModal: boolean = true;
  poNotes: any;
  form: FormGroup;
  poId: number;
  subscription$: Subscription = new Subscription();

  constructor(
    private formBuilder: FormBuilder,
    private purchaseOrderService: PurchaseOrderService,
    private loaderService: LoaderService,
    private toastr: ToastrService
  ) {

  }

  ngOnInit(): void {
    this.initializeForm();
  }

  ngOnDestroy() {
    this.subscription$.unsubscribe();
  }

  initializeForm() {
    this.form = this.formBuilder.group({
      notes: [null, [Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/), Validators.required]]
    })
  }

  get registerFormControl() {
    return this.form.controls;
  }

  closeModalPopup() {
    this.onCloseModal.emit();
    this.form.reset();
  }

  onConfirmation(form) {
    this.poNotes.notes = form.value.notes;
    this.emitPoNotes.emit(this.poNotes)
    this.subscription$.add(this.purchaseOrderService.addPONotes(this.poId, this.poNotes).subscribe({
      next: res => {
        this.closeModalPopup()
        this.loaderService.hide();
        if (res) {
          this.toastr.success('Notes added Successfully', 'Success');
        }
      },
      error: error => {
        this.toastr.error('An Error occurred in adding notes', 'Error');
      }
    }));
  }
}
