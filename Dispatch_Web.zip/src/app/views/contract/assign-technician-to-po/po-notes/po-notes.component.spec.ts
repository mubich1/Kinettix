import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PoNotesComponent } from './po-notes.component';

describe('PoNotesComponent', () => {
  let component: PoNotesComponent;
  let fixture: ComponentFixture<PoNotesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PoNotesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PoNotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
