import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild, Renderer2, AfterViewInit, RendererStyleFlags2 } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { TableHeaderItem, TableItem, TableModel } from 'carbon-components-angular';
import * as moment from 'moment';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';
import { LoaderService } from 'src/app/services/loader/loader.service';
import { WorkmarketIntegrationService } from 'src/app/services/workmarket-integration/workmarket-integration.service';
import { AngularUtility } from 'src/app/shared/common/angular-utitilty';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';
import { TinyMCEConfiguration } from 'src/app/shared/common/tinyMCEConfiguration';
import { AssignmentTemplate, AvailableTech, AssignmentJobDetails, TemplateDetails, CreateAssignment, LaborCloud } from '../../../../models/workmarket-integration/workmarket-integration';
import { PriceType, PriceMode } from 'src/app/models/purchaseOrder/purchase-order';
@Component({
  selector: 'app-create-wm-assignment-to-po',
  templateUrl: './create-wm-assignment-to-po.component.html',
  styleUrls: ['./create-wm-assignment-to-po.component.css']
})
export class CreateWmAssignmentToPoComponent implements OnInit, AfterViewInit {
  @Input() set purchaseOrderId(purchaseOrderId: number) {
    if (purchaseOrderId) {
      this.poId = purchaseOrderId;
      this.getJobDetailsForAssignment(purchaseOrderId);
      this.getTechnicians();
      this.getLaborClouds();
    }
  };
  @Input() ticketId:any
  @Output() closeWMModal = new EventEmitter();

  @ViewChild('thebasicdiv') public overviewDiv: ElementRef;
  @ViewChild('locationdiv') public locationDiv: ElementRef;
  @ViewChild('schedulingdiv') public schedulingDiv: ElementRef;
  @ViewChild('pricediv') public priceDiv: ElementRef;
  @ViewChild('templatediv') public templateDiv: ElementRef;
  @ViewChild('negotiationdiv') public negotiationDiv: ElementRef;

  @ViewChild('customTechHeader', { static: true }) customTechHeader: ElementRef;
  @ViewChild('customLaborCLoudHeader', { static: true }) customLaborCLoudHeader: ElementRef;

  behaviour = { behavior: 'smooth', block: 'start', inline: 'start' };

  assignmentWMForm: FormGroup;

  isHourlyPriceType: boolean = true;
  isFlatPriceType: boolean = false;

  minDate: Date;

  IsUseLaborCloudDiv: boolean = false;
  InvitePreviouslyUsedTechDiv: boolean = false;

  showTechModal: boolean = false;
  showCloudLaborModal: boolean = false;

  templateList: AssignmentTemplate[] = [];
  selectedTemplate: number = 0;

  tinyMCECApiKey: string = TinyMCEConfiguration.apiKey;
  tinyMCESettings: any = TinyMCEConfiguration.settings;

  carbonUtility = new CarbonUtility();

  availableTechList: AvailableTech[] = [];
  availableTechToBeAssignedList: AvailableTech[] = [];
  tempAvailableTechList: AvailableTech[] = [];
  assignedTechsName: string[] = [];

  techSearchString: string = '';
  techTableModel = new TableModel();
  techTableData: TableItem[][] = [];
  angularUtility = new AngularUtility();

  laborCloudList: LaborCloud[] = [];
  laborCloudAssignedList: LaborCloud[] = [];
  tempLaborCloudList: LaborCloud[] = [];
  assignedLaborCloudName: string[] = [];

  laborCloudTableModel = new TableModel();
  laborCloudTableData: TableItem[][] = [];

  assignedTechsId: number[] = [];
  assignedLaborCloudsId: string[] = [];

  jobDetailForAssignment!: AssignmentJobDetails;
  templateDetails!: TemplateDetails;
  poId: number;

  ngUnsubscribe = new Subject<void>();

  constructor(
    private formBuilder: FormBuilder,
    private workmarketIntegrationService: WorkmarketIntegrationService,
    private toastr: ToastrService,
    private activatedRoute: ActivatedRoute,
    private loaderService: LoaderService,
    private renderer: Renderer2,
    private elementRef: ElementRef) {
    this.setMinStartDate();
  }

  ngOnInit(): void {
    this.createForm();
    this.getAssignmentTemplates();
  }

  ngAfterViewInit(): void {
    const techModal = (<HTMLElement>this.elementRef.nativeElement).querySelector('#parent-available-tech-modal');
    const laborCloudModal = (<HTMLElement>this.elementRef.nativeElement).querySelector('#parent-labor-cloud-modal');
    this.renderer.setStyle(laborCloudModal?.firstElementChild?.firstElementChild?.firstElementChild, 'width', '100%', RendererStyleFlags2.Important);
    this.renderer.setStyle(techModal?.firstElementChild?.firstElementChild?.firstElementChild, 'width', '100%', RendererStyleFlags2.Important);
  }

  createForm() {
    this.assignmentWMForm = this.formBuilder.group({
      title: ['', [Validators.required, this.angularUtility.noWhitespaceValidator]],
      industryId: ['1000'],
      description: ['', [Validators.required, this.angularUtility.noWhitespaceValidator]],
      arrivalInstructions: [''],
      locationId: [null],
      locationName: [''],
      locationNumber: [''],
      locationAddress: [''],
      locationCity: [''],
      locationState: [''],
      locationCountry: [''],
      locationLong: [''],
      locationLat: [''],
      locationZip: [''],
      scheduleStartDate: ['', [Validators.required]],
      scheduleEndDate: [''],
      priceTypeRadio: [null],
      perHourRate: ['0'],
      hoursAllowed: ['0'],
      flatFee: [''],
      autoInviteTech: new FormControl(true),
      isUsedPreviouslyUsedTech: new FormControl(false),
      IsUseLaborCloudTech: new FormControl(false)
    });
  }

  resetForm() {
    this.assignmentWMForm = this.formBuilder.group({
      title: new FormControl('', [Validators.required, this.angularUtility.noWhitespaceValidator]),
      industryId: new FormControl('1000'),
      description: new FormControl('', [Validators.required, this.angularUtility.noWhitespaceValidator]),
      arrivalInstructions: new FormControl(''),
      locationId: [0],
      locationName: new FormControl(''),
      locationNumber: new FormControl(''),
      locationAddress: new FormControl(''),
      locationCity: new FormControl(''),
      locationState: new FormControl(''),
      locationCountry: new FormControl(''),
      locationLong: new FormControl(''),
      locationLat: new FormControl(''),
      locationZip: new FormControl(''),
      scheduleStartDate: new FormControl('', Validators.required),
      scheduleEndDate: new FormControl(''),
      priceTypeRadio: new FormControl(null),
      perHourRate: new FormControl(''),
      hoursAllowed: new FormControl(''),
      flatFee: new FormControl(''),
      autoInviteTech: new FormControl(true),
      isUsedPreviouslyUsedTech: new FormControl(false),
      IsUseLaborCloudTech: new FormControl(false)
    });
  }

  patchAssignmentDetailsValues() {
    this.assignmentWMForm.patchValue({
      title: this.jobDetailForAssignment.title,
      description: this.jobDetailForAssignment.scope,
      arrivalInstructions: this.jobDetailForAssignment.arrivalInstructions,
      locationName: this.jobDetailForAssignment.siteInfo?.name,
      locationNumber: this.jobDetailForAssignment.siteInfo?.siteNumber,
      locationAddress: this.jobDetailForAssignment.siteInfo?.address,
      locationCity: this.jobDetailForAssignment.siteInfo?.city,
      locationState: this.jobDetailForAssignment.siteInfo?.state,
      locationCountry: this.jobDetailForAssignment.siteInfo?.country,
      locationLong: this.jobDetailForAssignment.siteInfo?.longitude,
      locationLat: this.jobDetailForAssignment.siteInfo?.latitude,
      locationZip: this.jobDetailForAssignment.siteInfo?.postalCode,
      scheduleStartDate: this.jobDetailForAssignment.ticketSchedule?.scheduleArival ?? '',
      perHourRate: Math.round(this.jobDetailForAssignment.pricing.pricingPerHourPrice * 100) / 100,
      hoursAllowed: this.jobDetailForAssignment.pricing.pricingMaxNumberOfHours,
      flatFee: this.jobDetailForAssignment.pricing.pricingFlatPrice ?? 0,
      priceTypeRadio: this.jobDetailForAssignment.pricing.pricingType
    });
    this.assignmentWMForm.get('scheduleStartDate')?.setValidators([Validators.required]);
    this.assignmentWMForm.get('scheduleStartDate')?.updateValueAndValidity();
    if (this.assignmentWMForm.value.flatFee != 0) {
      this.isFlatPriceType = true;
      this.isHourlyPriceType = false;
    }
  }

  overrideAssignmentDetailsFromTemplateValues() {
    let description = this.templateDetails.description;
    let instructions = this.templateDetails.instructions;
    this.assignmentWMForm.patchValue({
      title: this.templateDetails.title,
      description: description !== '' ? description : this.assignmentWMForm.value.description,
      arrivalInstructions: instructions !== '' ? instructions : this.assignmentWMForm.value.instructions
    });

    if (this.templateDetails.location != null) {
      this.assignmentWMForm.patchValue({
        locationId: this.templateDetails.location.id,
        locationName: this.templateDetails.location.name,
        locationNumber: this.templateDetails.location.location_number,
        locationAddress: this.templateDetails.location.address_1,
        locationCity: this.templateDetails.location.city,
        locationState: this.templateDetails.location.state,
        locationCountry: this.templateDetails.location.country,
        locationLong: this.templateDetails.location.longitude,
        locationLat: this.templateDetails.location.latitude,
        locationZip: this.templateDetails.location.zip
      });
    }

    if (this.templateDetails.assignment_window_start_date != null) {
      this.assignmentWMForm.patchValue({
        scheduleStartDate: this.templateDetails.assignment_window_start_date
      });
    }

    if (this.templateDetails.pricing != null) {
      if (this.templateDetails.pricing.type == "PER HOUR") {
        var perHourPrice = this.templateDetails.pricing.per_hour_price;
        var maxNumOfHours = this.templateDetails.pricing.max_number_of_hours;
        perHourPrice = (perHourPrice != null && perHourPrice != undefined && perHourPrice > 0) ? perHourPrice : this.assignmentWMForm.value.perHourRate;
        maxNumOfHours = (maxNumOfHours != null && maxNumOfHours != undefined && maxNumOfHours > 0) ? maxNumOfHours : this.assignmentWMForm.value.hoursAllowed;
        this.assignmentWMForm.patchValue({
          perHourRate: perHourPrice,
          hoursAllowed: maxNumOfHours
        });
      }
    }
    this.overviewDiv.nativeElement.scrollIntoView(this.behaviour);
  }

  onSelectTemplate(event) {
    if (event != undefined && event) {
      let id = parseInt(event, 10);
      if (!isNaN(id) && id > 0) {
        this.resetForm();
        this.loaderService.show();
        this.workmarketIntegrationService.getTemplateDetails(id).subscribe(res => {
          this.loaderService.hide();
          if (res.statusCode == 200) {
            this.templateDetails = res.results;
            this.selectedTemplate = (res.results.template_id != null && !isNaN(parseInt(res.results.template_id, 10))) ? parseInt(res.results.template_id, 10) : 0;
            this.getTechnicians();
            this.getLaborClouds();
            this.overrideAssignmentDetailsFromTemplateValues();
          } else {
            this.toastr.error('Something went wrong while loading the template.');
          }
        });
      }
    }
  }

  setMinStartDate(): void {
    const currentDate = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate(), new Date().getHours(), new Date().getMinutes(), new Date().getSeconds())
    this.minDate = new Date(currentDate);
  }

  changeScheduleStartDateInput(event) {
    this.assignmentWMForm.get('scheduleStartDate')?.setValidators([Validators.required]);
    this.assignmentWMForm.get('scheduleStartDate')?.updateValueAndValidity();
  }

  get f() {
    return this.assignmentWMForm.controls;
  }

  onSubmit(): void {
    if (this.assignmentWMForm.invalid)
      return;
    this.createAssignment();
  }

  createAssignment() {
    let startDate = this.assignmentWMForm.value.scheduleStartDate;
    let endDate = this.assignmentWMForm.value.scheduleEndDate;
    const assignment: CreateAssignment = {
      title: this.assignmentWMForm.value.title,
      description: this.assignmentWMForm.value.description,
      instructions: this.assignmentWMForm.value.arrivalInstructions,
      industry_id: parseInt(this.assignmentWMForm.value.industryId, 10),
      scheduled_start_date: (startDate != null && startDate !== '') ? moment(new Date(this.assignmentWMForm.value.scheduleStartDate as Date)).format("MM/DD/YYYY h:mm a") : null,
      scheduled_end_date: (endDate != null && endDate !== '') ? moment(new Date(this.assignmentWMForm.value.scheduleEndDate as Date)).format("MM/DD/YYYY h:mm a") : null,
      pricing_mode: this.jobDetailForAssignment?.pricing?.pricingMode ?? PriceMode.Spend,
      pricing_type: this.jobDetailForAssignment?.pricing?.pricingType ?? PriceType.PerHour,
      pricing_flat_price: this.assignmentWMForm.value.flatFee,
      pricing_per_hour_price: this.assignmentWMForm.value.perHourRate?.toString() ?? '0',
      pricing_max_number_of_hours: this.assignmentWMForm.value.hoursAllowed?.toString() ?? '0',
      location_id: this.assignmentWMForm.value.locationId ?? '0',
      location_name: this.assignmentWMForm.value.locationName ?? '',
      location_number: this.assignmentWMForm.value.locationNumber ?? '',
      location_address1: this.assignmentWMForm.value.locationAddress ?? '',
      location_city: this.assignmentWMForm.value.locationCity ?? '',
      location_state: this.assignmentWMForm.value.locationState ?? '',
      location_zip: this.assignmentWMForm.value.locationZip ?? '',
      location_country: this.assignmentWMForm.value.locationCountry ?? '',
      location_latitude: this.assignmentWMForm.value.locationLat ?? '',
      location_longitude: this.assignmentWMForm.value.locationLong ?? '',
      auto_invite: this.assignmentWMForm.value.autoInviteTech,
      location_contacts: [],
      techs_id: this.assignedTechsId.toString(),
      laborclouds: this.assignedLaborCloudsId.join(', ')
    }
    let isValid = this.checkValidationUponSubmit();
    if (isValid) {
      this.loaderService.show();
      this.workmarketIntegrationService
        .createAssignment(assignment, this.ticketId)
        .pipe(takeUntil(this.ngUnsubscribe))
        .subscribe({
          next: (res) => {
            this.handleSubmitSuccess();
          },
          error: (err) => {
            this.handleSubmitError(err);
          }
        });
    }
  }

  checkValidationUponSubmit(): boolean {
    let autoInvite = this.assignmentWMForm.value.autoInviteTech;
    let isUseLaborCloud = this.assignmentWMForm.value.IsUseLaborCloudTech;
    let isPreviouslyUsedTech = this.assignmentWMForm.value.isUsedPreviouslyUsedTech;

    let startDate = this.assignmentWMForm.value.scheduleStartDate;
    let endDate = this.assignmentWMForm.value.scheduleEndDate;
    if ((Date.parse(endDate) <= Date.parse(startDate))) {
      this.handleSubmitWarning(4);
      return false;
    }

    if (autoInvite) {
      return true;
    } else if (!autoInvite && !isPreviouslyUsedTech && !isUseLaborCloud) {
      this.handleSubmitWarning(1);
      return false;
    } else if (isUseLaborCloud) {
      let hasLaborCloud = (isUseLaborCloud && this.assignedLaborCloudsId.length > 0) ? true : false;
      if (hasLaborCloud) {
        return true;
      } else {
        this.handleSubmitWarning(2);
        return false;
      }
    } else if (isPreviouslyUsedTech) {
      let hasPreviouslyUsedTech = (isPreviouslyUsedTech && this.assignedTechsId.length > 0) ? true : false;
      if (hasPreviouslyUsedTech) {
        return true;
      } else {
        this.handleSubmitWarning(3)
        return false;
      }
    } else {
      this.handleSubmitWarning(1);
      return false;
    }
  }

  formatToISODate(): string {
    var d = new Date();
    return d.toISOString().substring(0, 10) + d.toISOString().substring(10,);
  }

  handleSubmitError(err: any): void {
    this.loaderService.hide();
    const message = 'Error occurred in creating an assignment.';
    this.toastr.error((err.error.message || message), 'Error');
  }

  handleSubmitWarning(flag: number): void {
    switch (flag) {
      case 1:
        this.toastr.warning('Please select at least one negotiation option.');
        break;
      case 2:
        this.toastr.warning('Please select at least one labor cloud.');
        break;
      case 3:
        this.toastr.warning('Please select at least one previously used tech.');
        break;
      case 4:
        this.toastr.warning('Please select a valid end date.');
        break;
      default:
    }
  }

  handleSubmitSuccess(): void {
    this.loaderService.hide();
    this.toastr.success(`Assignment created successfully.`, 'Success');
    this.closeWMModal.emit(false);
  }

  pageScroll(obj: any) {
    switch (obj) {
      case "Basics":
        this.overviewDiv.nativeElement.scrollIntoView(this.behaviour);
        break;
      case "Location":
        this.locationDiv.nativeElement.scrollIntoView(this.behaviour);
        break;
      case "Scheduling":
        this.schedulingDiv.nativeElement.scrollIntoView(this.behaviour);
        break;
      case "Price":
        this.priceDiv.nativeElement.scrollIntoView(this.behaviour);
        break;
      case "Template":
        this.templateDiv.nativeElement.scrollIntoView(this.behaviour);
        break;
      default:
        this.negotiationDiv.nativeElement.scrollIntoView(this.behaviour);
        break;
    }
  }

  onSelectPriceType(data: any) {
    if (data.value) {
      var radioVal = data.value;
      switch (radioVal) {
        case "per_hour":
          this.isHourlyPriceType = true;
          this.isFlatPriceType = false;
          break;
        case "flat":
          let hourPrice = this.assignmentWMForm.controls['perHourRate'].value;
          let hours = this.assignmentWMForm.controls['hoursAllowed'].value;
          let flatRate = parseFloat(hourPrice) * parseFloat(hours);

          this.isHourlyPriceType = false;
          this.isFlatPriceType = true;
          this.assignmentWMForm.patchValue({ flatFee: !isNaN(flatRate) ? flatRate.toFixed(2) : 0 });
          break;
        default:
          break;
      }
    }
  }

  onCheckedChangeAutoInvite(checked: boolean) {
    if (checked) {
      this.techTableModel.data = [];
      this.InvitePreviouslyUsedTechDiv = false;
      this.IsUseLaborCloudDiv = false;
      this.assignmentWMForm.patchValue({ isUsedPreviouslyUsedTech: false });
      this.assignmentWMForm.patchValue({ IsUseLaborCloudTech: false });
      this.assignedTechsName = [];
      this.assignedTechsId = [];
      this.assignedLaborCloudName = [];
      this.assignedLaborCloudsId = [];
    }
  }

  onCheckedChangePreviouslyUsedTech(checked: boolean) {
    if (checked) {
      this.InvitePreviouslyUsedTechDiv = true;
      this.IsUseLaborCloudDiv = false;
      this.assignmentWMForm.patchValue({ autoInviteTech: false });
      this.assignmentWMForm.patchValue({ IsUseLaborCloudTech: false });
      this.assignedLaborCloudName = [];
      this.assignedLaborCloudsId = [];
    } else {
      this.assignedTechsName = [];
      this.assignedTechsId = [];
      this.InvitePreviouslyUsedTechDiv = false;
    }
  }

  onCheckedChangeLaborCloudTech(checked: boolean) {
    if (checked) {
      this.IsUseLaborCloudDiv = true;
      this.InvitePreviouslyUsedTechDiv = false;
      this.assignmentWMForm.patchValue({ autoInviteTech: false });
      this.assignmentWMForm.patchValue({ isUsedPreviouslyUsedTech: false });
      this.assignedTechsName = [];
      this.assignedTechsId = [];
    } else {
      this.assignedLaborCloudName = [];
      this.assignedLaborCloudsId = [];
      this.IsUseLaborCloudDiv = false;
    }
  }

  getJobDetailsForAssignment(purchaseOrderId: number) {
    console.log('this.ticketId: ', this.ticketId);
    this.loaderService.show();
    this.workmarketIntegrationService.getJobDetailsForAssignment(this.ticketId, purchaseOrderId).subscribe(res => {
      this.loaderService.hide();
      if (res.statusCode == 200) {
        this.jobDetailForAssignment = res.results;
        this.patchAssignmentDetailsValues();
      } else {
        this.toastr.error('Something went wrong while loading the job details.');
      }
    });
  }

  getAssignmentTemplates(): void {
    this.workmarketIntegrationService.getTemplates().subscribe(res => {
      if (res.statusCode == 200) {
        this.templateList = res.results;
      }
    });
  }

  getTechnicians() {
    this.loaderService.show();
    this.workmarketIntegrationService.getTechnicians().subscribe((res) => {
      this.loaderService.hide();
      if (res.statusCode == 200) {
        this.availableTechList = res.results;
        this.availableTechList.forEach(e => {
          return e.selected = false;
        });
        this.populateAvailableTechTable(this.availableTechList);
      } else {
        this.toastr.error('Something went wrong while loading technicians.');
      }
    });
  }

  populateAvailableTechTable(technicians: AvailableTech[]) {
    this.techTableModel.data = [];
    this.techTableData = [];

    this.techTableModel.totalDataLength = technicians.length;
    if (technicians != null && technicians.length > 0) {
      technicians.forEach(e => {
        this.techTableData.push([
          new TableItem({ data: e.resourceId }),
          new TableItem({ data: e, template: this.customTechHeader }),
          new TableItem({ data: e.technicianName }),
        ]);
      });
    }

    this.initializeTechTable();
  }

  initializeTechTable() {
    this.techTableModel.data = [];
    let headers = [
      new TableHeaderItem({ data: 'ID', visible: false }),
      new TableHeaderItem({ data: '', sortable: false }),
      new TableHeaderItem({ data: 'Name', sortable: true }),
    ];
    this.techTableModel = this.carbonUtility.initializeTable(
      headers,
      this.techTableModel,
      this.techTableData
    );
    this.selectTechPage(1);
  }

  selectTechPage(page: any) {
    this.techTableModel = this.carbonUtility.selectPage(page, this.techTableModel, this.techTableData);
  }

  getLaborClouds() {
    this.loaderService.show();
    this.workmarketIntegrationService.getLaborClouds().subscribe((res) => {
      this.loaderService.hide();
      if (res.statusCode == 200) {
        this.laborCloudList = res.results;
        this.laborCloudList.forEach(e => {
          return e.selected = false;
        });
        this.populateLaborCloudTable(this.laborCloudList);
      } else {
        this.toastr.error('Something went wrong while loading technicians.');
      }
    });
  }

  populateLaborCloudTable(laborClouds: LaborCloud[]) {
    this.laborCloudTableModel.data = [];
    this.laborCloudTableData = [];

    this.laborCloudTableModel.totalDataLength = laborClouds.length;
    if (laborClouds != null && laborClouds.length > 0) {
      laborClouds.forEach(e => {
        this.laborCloudTableData.push([
          new TableItem({ data: e.identifier }),
          new TableItem({ data: e, template: this.customLaborCLoudHeader }),
          new TableItem({ data: e.name }),
          new TableItem({ data: e.description }),
          new TableItem({ data: e.members.toString() }),
        ]);
      });
    }
    this.initializeLaborCloudTable();
  }

  initializeLaborCloudTable() {
    this.laborCloudTableModel.data = [];
    let headers = [
      new TableHeaderItem({ data: 'Id', visible: false }),
      new TableHeaderItem({ data: '', sortable: false }),
      new TableHeaderItem({ data: 'Name', sortable: true }),
      new TableHeaderItem({ data: 'Description', sortable: true }),
      new TableHeaderItem({ data: 'Members', sortable: true }),
    ];
    this.laborCloudTableModel = this.carbonUtility.initializeTable(
      headers,
      this.laborCloudTableModel,
      this.laborCloudTableData
    );
    this.selectLaborCloudPage(1);
  }

  selectLaborCloudPage(page: any) {
    this.laborCloudTableModel = this.carbonUtility.selectPage(page, this.laborCloudTableModel, this.laborCloudTableData);
  }

  onToggleLaborCloudCheckBox(event: any, data: LaborCloud) {
    if (event.checked == true) {
      data.selected = true;
      if (this.tempLaborCloudList.length == 0) {
        this.tempLaborCloudList.push(data);
      } else {
        this.tempLaborCloudList.forEach(e => {
          if (e.identifier !== data.identifier)
            this.tempLaborCloudList.push(data);
        });
      }
    } else {
      data.selected = false;
      var newList = this.tempLaborCloudList.filter(e => {
        return e.identifier !== data.identifier;
      });
      this.tempLaborCloudList = newList;
    }
  }

  selectedLaborCloudItems() {
    this.assignedLaborCloudsId = [];
    this.assignedLaborCloudName = [];
    this.laborCloudAssignedList = this.tempLaborCloudList;
    this.laborCloudAssignedList.forEach(e => {
      this.assignedLaborCloudsId.push(e.identifier);
      this.assignedLaborCloudName.push(e.name);
    });
    this.showCloudLaborModal = false;
  }

  showLaborCloudTech() {
    this.showCloudLaborModal = true;
  }

  closeLaborCloudModal() {
    this.showCloudLaborModal = false;
  }

  /* Previously Used Tech */
  showAvailableTech() {
    this.showTechModal = true;
  }

  closeTechModal() {
    this.showTechModal = false;
  }

  selectedTechItems() {
    this.assignedTechsId = [];
    this.assignedTechsName = [];
    this.availableTechToBeAssignedList = this.tempAvailableTechList;
    this.availableTechToBeAssignedList.forEach(e => {
      this.assignedTechsId.push(e.resourceId);
      this.assignedTechsName.push(e.technicianName);
    });
    this.showTechModal = false;
  }

  onToggleTechCheckBox(event: any, data: AvailableTech) {
    if (event.checked == true) {
      data.selected = true;
      if (this.tempAvailableTechList.length == 0) {
        this.tempAvailableTechList.push(data);
      } else {
        this.tempAvailableTechList.forEach(e => {
          if (e.resourceId != data.resourceId)
            this.tempAvailableTechList.push(data);
        });
      }
    } else {
      data.selected = false;
      var newList = this.tempAvailableTechList.filter(e => {
        return e.resourceId != data.resourceId;
      });
      this.tempAvailableTechList = newList;
    }
  }

  closePopupModal() {
    this.closeWMModal.emit(false);
  }
  /* Previously Used Tech */

}
