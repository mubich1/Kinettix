import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateWmAssignmentToPoComponent } from './create-wm-assignment-to-po.component';

describe('CreateWmAssignmentToPoComponent', () => {
  let component: CreateWmAssignmentToPoComponent;
  let fixture: ComponentFixture<CreateWmAssignmentToPoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateWmAssignmentToPoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateWmAssignmentToPoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
