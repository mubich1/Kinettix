import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignTechnicianToPoComponent } from './assign-technician-to-po.component';

describe('AssignTechnicianToPoComponent', () => {
  let component: AssignTechnicianToPoComponent;
  let fixture: ComponentFixture<AssignTechnicianToPoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssignTechnicianToPoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignTechnicianToPoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
