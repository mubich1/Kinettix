import { Component, ElementRef, OnInit, Output, ViewChild, EventEmitter, Input, Injector } from '@angular/core';
import {
  TableModel,
  TableItem,
  ModalService,
  BaseModal,
  TableHeaderItem,
} from 'carbon-components-angular';
import { ToastrService } from 'ngx-toastr';
import { Observable, Subject, Subscription } from 'rxjs';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';
import { LoaderService } from 'src/app/services/loader/loader.service';
import { ConfirmationDialog } from 'src/app/models/dialog/confirmation';
import { HttpStatusCode } from '@angular/common/http';
import {
  AssignTechnician,
  RecommendedTechnician,
  RadiusMiles,
  TechnicianTableFilters,
} from 'src/app/models/assign-technician/assign-technician';
import { PurchaseOrder } from 'src/app/models/purchaseOrder/purchase-order';
import * as moment from 'moment';
import { noUndefined } from '@angular/compiler/src/util';
import { UserPermissions } from 'src/app/shared/common/permission';
import { UtilityService } from 'src/app/services/utility/utility.service';
import { Permission } from 'src/app/services/utility/permission-constant';
import { WorkmarketIntegrationService } from 'src/app/services/workmarket-integration/workmarket-integration.service';
import { AssignmentJobDetails } from 'src/app/models/workmarket-integration/workmarket-integration';
@Component({
  selector: 'app-assign-technician-to-po',
  templateUrl: './assign-technician-to-po.component.html',
  styleUrls: ['./assign-technician-to-po.component.css'],
})
export class AssignTechnicianToPoComponent implements OnInit {
  @Output() closeTechnicianModal = new EventEmitter();
  @Output() onTableDataEmission = new EventEmitter();
  @Output() onDateSelection = new EventEmitter();
  @Output() assignTech = new EventEmitter();
  @Input() set poDetails(poDetails: any) {
    if (poDetails) {
      this.poId = poDetails.poId??poDetails.id;
      this.po = poDetails;
      this.searchTerm = '';
      this.selectedRadius = 50;
    }
  };
  @Input() ticketId: number;
  @Input() set recommendedTechnicians(recommendedTechnicians: any) {
    if (recommendedTechnicians) {
      this.initializeInputValues(recommendedTechnicians);
    }
  }
  @ViewChild('radioButtonTemplate', { static: true })
  radioButtonTemplate: ElementRef;
  @ViewChild('addNotes', { static: true }) addNotes: ElementRef;
  @ViewChild('datePicker', { static: true }) datePicker: ElementRef;
  notesData: {
    poId: number;
    poNotes: {
      vendorId: number | undefined;
      techId: number | undefined;
      notes: string | undefined;
    };
  };
  showPoNotesModal: boolean;
  searchTerm: string = '';
  selectedRadius: number = 50;
  tableModel = new TableModel();
  carbonUtility = new CarbonUtility();
  techniciansList: TableItem[][] = []; // formatted data for table
  tableData: TableItem[][] = []; // formatted temp data for table search
  techTableFilters: TechnicianTableFilters = new TechnicianTableFilters();
  technicians: RecommendedTechnician[] = [];
  po!: PurchaseOrder;
  poId: number;
  techId?: number = 0;
  radiusMiles = RadiusMiles;
  data: any;
  permissions: UserPermissions = new UserPermissions();
  showWMModal: boolean = false;
  jobDetailForAssignment!: AssignmentJobDetails;
  constructor(
    private toastr: ToastrService,
    private loaderService: LoaderService,
    private utilityService: UtilityService,
    private workmarketIntegrationService: WorkmarketIntegrationService,
  ) {
  }

  ngOnInit(): void {
    this.checkUserPermissions();
  }
  initializeTable() {
    if (this.technicians) {
      for (let technician of this.technicians) {
        let rows: any = [];
        rows.push(
          new TableItem({
            data: technician,
            template: this.radioButtonTemplate,
          })
        );
        this.carbonUtility.setTableItem(rows, technician.technicianName);
        this.carbonUtility.setTableItem(rows, technician.vendorName);
        this.carbonUtility.setTableItem(rows, technician.businessPhone);
        this.carbonUtility.setTableItem(rows, technician.weightedScore);
        this.carbonUtility.setTableItem(
          rows,
          moment(new Date(technician.techRecentJobDate as Date)).format(
            'M/DD/YYYY'
          )
        );
        this.carbonUtility.setTableItem(rows, technician.totalJobCount);
        this.carbonUtility.setTableItem(rows, technician.clientJobCount);
        this.carbonUtility.setTableItem(
          rows,
          technician.distance ? `${technician.distance} Miles` : ''
        );
        this.carbonUtility.setTableItem(
          rows,
          technician.nearestJob ? `${technician.nearestJob} Miles` : ''
        );
        this.carbonUtility.setTableItem(rows, technician.rating);
        this.carbonUtility.setTableItem(rows, technician.negotiatedCost);
        this.carbonUtility.setTableItem(rows, technician.poAverage);

        if (this.poId > 0) {
          rows.push(new TableItem({ data: { techId: technician.technicianId, vendorId: technician.vendorId, poLastCallDate: technician.poLastCallDate ? new Date(technician.poLastCallDate) : '' }, template: this.datePicker }));

          rows.push(
            new TableItem({
              data: {
                poNotes: technician.poNotes,
                vendorId: technician.vendorId,
                technicianId: technician.technicianId,
              },
              template: this.addNotes,
            })
          );
        }
        this.tableData.push(rows);
      }
    }
    let _headers: any;
    if (this.poId > 0)
      _headers = [
        '',
        'Technician Name',
        'Vendor Name',
        'Scheduling Phone',
        'Pedro Score',
        'Last Job Date',
        'Total Jobs',
        'Jobs For This Client',
        'Distance',
        'Nearest Job Distance',
        'Rating',
        'Negotiated Cost',
        'Po Average',
        'Last Call Date',
        '',
      ];
    else
      _headers = [
        '',
        'Technician Name',
        'Vendor Name',
        'Scheduling Phone',
        'Pedro Score',
        'Last Job Date',
        'Total Jobs',
        'Jobs For This Client',
        'Distance',
        'Nearest Job Distance',
        'Rating',
        'Negotiated Cost',
        'Po Average',
        '',
      ];

    const headers = _headers;
    this.tableModel = this.carbonUtility.setTableModel(
      headers,
      this.tableModel,
      this.tableData,
      this.tableModel.pageLength,
      this.tableModel.currentPage,
      this.tableModel.totalDataLength
    );
    this.tableModel.header[3] = new TableHeaderItem({
      data: 'Scheduling Phone',
      sortable: false,
    });
    this.techniciansList = [...this.tableModel.data];
  }

  checkUserPermissions() {
    this.permissions.canAdd = this.utilityService.hasPermission(
      Permission.AssignTechnician
    );
  }

  loadTableData() {
    this.onTableDataEmission.emit(this.techTableFilters);
  }

  assignTechnician() {
    const selectedTech = this.getSelectedTech(this.techId);
    if (!selectedTech) {
      this.toastr.error('Technician is required', 'Required');
      return;
    }

    const tech: AssignTechnician = {
      poId: this.poId,
      vendorId: Number(selectedTech.vendorId),
      techId: Number(this.techId),
    };
    this.assignTech.emit({ selectedTech, tech });
  }

  getSelectedTech(techId?: number) {
    if (
      techId &&
      techId > 0 &&
      this.technicians &&
      this.technicians.length > 0
    ) {
      return this.technicians.find((x) => x.technicianId == techId);
    } else {
      return null;
    }
  }

  handleError(error: any, message?: string) {
    this.loaderService.hide();
    if (
      error?.error?.statusCode === HttpStatusCode.NotFound ||
      error?.error?.statusCode === HttpStatusCode.Conflict
    ) {
      this.toastr.error(error.error.message, 'Error');
    } else {
      this.toastr.error(message, 'Error');
    }
  }

  onClearSearch() {
    this.techTableFilters.search = '';
    this.loadTableData();
  }

  onSearch(event: any) {
    this.techTableFilters.search = event?.target?.value;
    this.loadTableData();
  }

  onRadiusSelection(event: any) {
    this.techTableFilters.radius = event?.target?.value;
    if (!this.searchTerm.length) {
      this.techTableFilters.search = '';
    }
    this.loadTableData();
  }

  disabledCharacters() {
    return false;
  }

  onAddNotes(recommendedTechnician: RecommendedTechnician) {
    this.notesData = {
      poId: this.poId,
      poNotes: {
        vendorId: recommendedTechnician.vendorId,
        techId: recommendedTechnician.technicianId,
        notes: recommendedTechnician.poNotes,
      },
    };
    this.showPoNotesModal = true;
  }

  setUpdatedNotes(poNotes) {
    const index = this.technicians.findIndex(
      (technician: RecommendedTechnician) =>
        technician.technicianId === poNotes.techId
    );
    if (index > -1) {
      this.technicians[index].poNotes = poNotes.notes;
      this.tableData = [];
      this.initializeTable();
    }
  }

  onDateChange(date, techId, vendorId) {
    const poCallLog = {
      lastCallDate: date.toLocaleString("en-US"),
      vendorId: vendorId,
      techId: techId,
    };
    this.onDateSelection.emit(poCallLog);
  }

  handleDatePickerPosition() {
    setTimeout(() => {
      document
        .querySelectorAll('.cdk-overlay-pane')[0]
        .classList.add('custom-cdk-pane');
      document
        .querySelectorAll('.owl-dt-container-row.owl-dt-calendar')[0]
        .classList.add('calendar-height');
      document
        .querySelectorAll('.cdk-overlay-transparent-backdrop')[0]
        .classList.add('custom-overlay-transparent-backdrop');
      document
        .querySelectorAll('.cdk-global-scrollblock')[0]
        .classList.add('custum-cdk-global-scrollblock');
    }, 0);
  }

  closeModalPopup(selectedTech?) {
    this.searchTerm = '';
    this.selectedRadius = 50;
    this.closeTechnicianModal.emit(selectedTech);
  }

  closeNotesModal() {
    this.showPoNotesModal = false;
  }

  initializeInputValues(recommendedTechnicians) {
    this.technicians = recommendedTechnicians;
    this.tableData = [];
    this.tableModel.totalDataLength = recommendedTechnicians.length;
    if (this.po && this.po.techId) {
      const selectedTech = this.getSelectedTech(this.po.techId);
      this.techId = selectedTech! && selectedTech!.technicianId ? selectedTech!.technicianId : 0;
    } else {
      this.techId = 0;
    }
    this.initializeTable();
  }

  closeWMModalPopup(data?: boolean) {
    window.location.reload();
    this.showWMModal = data!;
  }

  openWMModalPopup() {
    this.getJobDetailsForAssignment(this.poId);
  }

  getJobDetailsForAssignment(purchaseOrderId: number) {
    this.loaderService.show();
    this.workmarketIntegrationService.getJobDetailsForAssignment(this.ticketId, purchaseOrderId).subscribe(res => {
      this.loaderService.hide();
      if (res.statusCode == 200) {
        this.jobDetailForAssignment = res.results;
        if (this.jobDetailForAssignment.ticketScheduleId == 0) {
          this.toastr.warning('Before creating an opportunity, please add a schedule date to this purchase order.');
          return;
        }
        if (this.jobDetailForAssignment.totalAuthorizedPayment < 1) {
          this.toastr.warning('Authorized cost should be greater than $1');
          return;
        }
        if (!this.jobDetailForAssignment.isPoResurces) {
          this.toastr.warning('Before creating this opportunity, this purchase order must have resources assigned. Please add activities with resources and try again.');
          return;
        }
        if (this.jobDetailForAssignment.clientSiteId == null) {
          this.toastr.warning('A client site is required to create this opportunity.');
          return;
        }
        this.showWMModal = true;
      } else {
        this.toastr.error('Something went wrong while loading the job details.');
      }
    });
  }

}
