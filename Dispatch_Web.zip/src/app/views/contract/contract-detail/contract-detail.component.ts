import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';
import { ProjectActivityResourceService } from 'src/app/services/project-activity-resources/project-activity-resources.service';

@Component({
  selector: 'app-contract-detail',
  templateUrl: './contract-detail.component.html',
  styleUrls: ['./contract-detail.component.css']
})
export class ContractDetailComponent implements OnInit {

  ContractTitle: string="";
ContractID:number=0;
ConHubSpotID: string="";
ConProductType: string="";
ConEntityInvoice: string="";
Platform: string="";
SecondaryClient: string="";
OnsiteEntity: string="";
conAccExecutive: string="";
conAccManager: string="";
pmoLead: string="";
backupPmoLead: string="";
fsoLead: string="";
preVisitTeam: string="";
dayOfTeam: string="";
clientId: any;
contractId:number=0;



ngUnsubscribe = new Subject<void>();
  constructor(private route: ActivatedRoute,private projectActivityService: ProjectActivityResourceService,
    private toastr: ToastrService,public router: Router) {
     }

  ngOnInit(): void {
    this.route.params.subscribe((params: any) => {
      if (params.hasOwnProperty('contractId')) {
        this.contractId = params['contractId'];
        this.loadContract(this.contractId);
      }
    });
  }

  isActiveUrl(url:string):boolean{
   let checkRoute=   this.router.url.endsWith(url);
   return checkRoute;
  }

  loadContract(contractId:number) {
    this.projectActivityService.getContractByContractId(contractId)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          if (res.results !== null) {
            this.projectActivityService.shareContractInfo(res.results);

            this.ContractTitle =res.results.title!;
            this.ContractID = res.results.id!;
            this.ConHubSpotID="64585";
            this.ConProductType="Primary";
            this.ConEntityInvoice="test";
            this.Platform="Kinitix";
            this.SecondaryClient="test";
            this.OnsiteEntity="Cinnova";
            this.conAccExecutive="Mohsin";
            this.conAccManager="Ansab";
            this.pmoLead="nauman";
            this.backupPmoLead="zeeshan";
            this.fsoLead="faisal";
            this.preVisitTeam="usman";
            this.dayOfTeam="test";


          }
        },
        error: (e) => {
          console.log(e);
          this.toastr.error('Something went wrong while loading Client contracts');
        },
        complete: () => { },
      });
  }

  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }
}
