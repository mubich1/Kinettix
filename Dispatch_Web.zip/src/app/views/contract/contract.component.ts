import { Component, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Breadcrumb, BreadcrumbService } from 'src/app/services/breadcrumb.service';

@Component({
  selector: 'app-contract',
  templateUrl: './contract.component.html',
  styleUrls: ['./contract.component.css']
})


export class ContractComponent implements OnInit {
  breadcrumbs$: Observable<Breadcrumb[]>;
  contractId: any;
  breadCrums:any[] = [];

  constructor(private breadcrumbService: BreadcrumbService,private router:Router) {
    this.breadcrumbs$ = this.breadcrumbService.breadcrumbs$;
  }
  ngOnInit(): void {
    this.setBreadcrumbId();
    this.setBreadCrums();
  }

  setBreadcrumbId(){
    const path = this.router.url.split('/');
    this.contractId = Number(path[6]);
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        let path = event.url.split('/');
        this.contractId = Number(path[6]);
        this.setBreadCrums();
      }
    });
  }
  setBreadCrums() {
    this.breadCrums = [
      {alias: 'Dispatch 1',redirectTo: '/client-dashboard'},
      {alias: 'Contracts',redirectTo: '/delivery'},
      {alias: ':contractId',redirectTo: ''},
    ];
    this.breadCrums.forEach(breadCrum => {
      if (breadCrum.alias.includes(":") || breadCrum.redirectTo.includes(":")) {
        breadCrum.alias = this.replaceText(breadCrum.alias);
        breadCrum.redirectTo = this.replaceText(breadCrum.redirectTo);
      }
    });
  }

  replaceText(text: string) {
    return text
      .replace(":contractId", `${this.contractId}`)
  }
}
