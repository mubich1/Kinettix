import { HttpStatusCode } from '@angular/common/http';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil, tap } from 'rxjs';
import {
  ContractTasksStatusIdEnum,
  ContractMilestoneStatus,
} from 'src/app/models/contract/contract';
import { TaskStatusEnum } from 'src/app/models/po-milestone/po-milestones';
import { ContractMilestoneManagerService } from 'src/app/services/contract-milestone-manager/contract-milestone-manager.service';
import { LoaderService } from 'src/app/services/loader/loader.service';
import { UserService } from 'src/app/services/user/user.service';
import { ContractService } from 'src/app/services/contract/contract.service';

@Component({
  selector: 'app-contract-milestone-manager',
  templateUrl: './contract-milestone-manager.component.html',
  styleUrls: ['./contract-milestone-manager.component.css'],
})
export class ContractMilestoneManagerComponent implements OnInit, OnDestroy {
  stagedMilestones: any[] = [];
  inWorkMilestones: any[] = [];
  wrapUpMilestones: any[] = [];
  users: any[] = [];
  statusId: number;
  isOpenMilestoneModal = false;
  isOpenMilestoneDeleteConfirmationModal = false;
  currentSelectedContractMilestone: any;
  contractId: number;
  currentUserId: string;
  ngUnsubscribe = new Subject<void>();
  activeCard: any;
  cards = {
    staged: 'Draft',
    inWork: 'InWork',
    wrapUp: 'WrapUp',
    completed: 'Complete',
  };
  isStagedCompleted: boolean = true;
  isInworkCompleted: boolean = false;
  isWrapupCompleted: boolean = false;
  isStagedDelete: boolean = false;
  isWrapUpDelete: boolean = false;
  isInWorkDelete: boolean = false;
  stagedStatus: boolean = false;
  inWorkStatus: boolean = false;
  wrapUpStatus: boolean = false;
  getAllMilestones: any[] = [];
  selectedMilestone: any;
  isAllowToAddMilestone: boolean = false;
  poStatusId: any;
  contractMilestoneStatus = ContractMilestoneStatus;
  selectedMilestonesToBeSaved: any[] = [];
  ngUnsubscribe$: Subject<void> = new Subject<void>();
  constructor(
    private contractMilestoneManagerService: ContractMilestoneManagerService,
    private activatedRoute: ActivatedRoute,
    private toastr: ToastrService,
    private loaderService: LoaderService,
    private userService: UserService
  ) {}

  ngOnInit(): void {
    this.getRoutingParams();
    this.activeCard = this.cards.staged;
    this.getAllMilestone();
    this.getAllUsers();
  }

  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  getRoutingParams() {
    this.activatedRoute.parent?.params.subscribe((params) => {
      if (params.hasOwnProperty('contractId')) {
        this.contractId = params['contractId'];
      }
    });
    this.getCurrentUserId();
  }

  onCardSelection(card) {
    this.activeCard = card;
  }

  getCurrentUserId() {
    const getUserFromLocalStorage = () => {
      try {
        return JSON.parse(localStorage.getItem('userId') || '');
      } catch (error) {
        return null;
      }
    };
    this.currentUserId = getUserFromLocalStorage();
  }

  public OnSelectTask(milestone: any): void {
    if (milestone) {
      this.getAllMilestones.forEach((item) => (item.selected = false));
      milestone.selected = true;
      this.selectedMilestone = milestone;
      this.isAllowToAddMilestone = true;
    }
  }

  public AddMilestone(status: number): void {
    this.isAllowToAddMilestone = false;

    const payload = {
      contractMilestoneId: 0,
      statusId: status,
      milestoneId: this.selectedMilestone.id,
      contractTasks: this.selectedMilestone.tasks.map((task) => {
        return {
          contractTaskId: 0,
          taskId: task.id,
        };
      }),
    };
    this.loaderService.show();
    this.contractMilestoneManagerService
      .createContractMilestone(this.contractId, payload)
      .subscribe({
        next: (res) => {
          this.isOpenMilestoneModal = false;
          this.loaderService.hide();
          this.selectedMilestone.contractMilestoneId =
            res.results.contractMilestoneId;
          res.results.contractTasks.forEach((response) => {
            this.selectedMilestone.tasks.forEach((task) => {
              if (task.id == response.taskId) {
                task.contractTaskId = response.contractTaskId;
                task.statusId = response.taskStatusId;
                task.status = this.getTaskStatus(response.taskStatusId);
              }
            });
          });

          switch (status) {
            case ContractMilestoneStatus.Staged:
              this.stagedMilestones.push({
                ...this.selectedMilestone,
                statusId: status,
              });

              break;
            case ContractMilestoneStatus.InWork:
              this.inWorkMilestones.push({
                ...this.selectedMilestone,
                statusId: status,
              });
              this.isStagedDelete = true;
              break;
            case ContractMilestoneStatus.WrapUp:
              this.wrapUpMilestones.push({
                ...this.selectedMilestone,
                statusId: status,
              });
              this.isStagedDelete = true;
              this.isInWorkDelete = true;
              break;

            default:
              break;
          }
          this.getAllMilestones = this.getAllMilestones.filter(
            (milestone) => milestone.id != this.selectedMilestone.id
          );
          this.checkStatusOnCompletion(true);
        },

        error: (e) => {
          this.loaderService.hide();
          this.handleError(e);
        },
        complete: () => {},
      });
    this.isOpenMilestoneModal = false;
  }

  openMilestoneListModal(statusId) {
    this.statusId = statusId;
    this.isOpenMilestoneModal = true;
  }

  onRemoveMilestoneFromStatus(contractMilestone: any, statusId) {
    this.statusId = statusId;
    this.currentSelectedContractMilestone = contractMilestone;
    this.isOpenMilestoneDeleteConfirmationModal = true;
  }

  onRemoveMilestoneFromStatusConfirm() {
    this.onDelete();
  }

  getTaskStatus(statusId) {
    switch (statusId) {
      case 1:
        return 'Active';
      case 2:
        return 'Failed';
      case 3:
        return 'Complete';
      case 4:
        return 'Pending';
      default:
        return '';
    }
  }
  resetDeletedTaskState() {
    this.currentSelectedContractMilestone.tasks.forEach((task, index) => {
      if (index == 0) {
        task.status = TaskStatusEnum.Active;
        task.statusId = ContractTasksStatusIdEnum.Active;
        task.completedDate = null;
        task.completedByName = null;
        task.assignToName = null;
        task.assignTo = null;
      } else {
        task.status = TaskStatusEnum.Pending;
        task.statusId = ContractTasksStatusIdEnum.Pending;
        task.completedDate = null;
        task.completedByName = null;
        task.assignToName = null;
        task.assignTo = null;
      }
    });

    this.getAllMilestones.push(this.currentSelectedContractMilestone);
  }

  onDelete() {
    const payload = {
      contractMilestoneId:
        this.currentSelectedContractMilestone.contractMilestoneId,
      contractTaskIds: this.currentSelectedContractMilestone.tasks.map(
        (res) => {
          return res.contractTaskId;
        }
      ),
    };
    this.loaderService.show();
    this.contractMilestoneManagerService
      .deleteContractMilestone(this.contractId, payload)
      .subscribe({
        next: (res) => {
          this.loaderService.hide();
          this.resetDeletedTaskState();
          switch (this.statusId) {
            case ContractMilestoneStatus.Staged:
              let stagedIndex = this.stagedMilestones.findIndex(
                (item) => item.id == this.currentSelectedContractMilestone.id
              );
              if (stagedIndex > -1) {
                this.stagedMilestones.splice(stagedIndex, 1);
                this.statusModificationOnDelete(
                  this.stagedMilestones,
                  stagedIndex
                );
              }
              break;
            case ContractMilestoneStatus.InWork:
              let inWorkIndex = this.inWorkMilestones.findIndex(
                (item) => item.id == this.currentSelectedContractMilestone.id
              );
              if (inWorkIndex > -1) {
                this.inWorkMilestones.splice(inWorkIndex, 1);
                this.statusModificationOnDelete(
                  this.inWorkMilestones,
                  inWorkIndex
                );
              }
              break;
            case ContractMilestoneStatus.WrapUp:
              let index = this.wrapUpMilestones.findIndex(
                (item) => item.id == this.currentSelectedContractMilestone.id
              );
              if (index > -1) {
                this.wrapUpMilestones.splice(index, 1);
                this.statusModificationOnDelete(this.wrapUpMilestones, index);
              }
              break;

            default:
              break;
          }
          this.checkStatusOnCompletion();
        },
        error: (e) => {
          this.loaderService.hide();
          this.handleError(e);
        },
      });
    this.isOpenMilestoneDeleteConfirmationModal = false;
  }

  statusModificationOnDelete(milestones, index) {
    if (milestones.length) {
      milestones[index].tasks[0].status = TaskStatusEnum.Active;
    }
  }

  getAllUsers() {
    this.userService
      .getUsers()
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          this.users = res.results.data;
        },
        error: (e) => {
          this.handleError(e);
        },
        complete: () => {},
      });
  }

  getAllMilestone() {
    this.loaderService.show();
    this.contractMilestoneManagerService
      .getContractMilestone(this.contractId)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe((res) => {
        this.loaderService.hide();
        this.getAllMilestones = res.results;
        this.getContractMilestones();
      });
  }

  getContractMilestones() {
    this.loaderService.show();
    this.contractMilestoneManagerService
      .getSavedContractMilestones(this.contractId)
      .subscribe({
        next: (res) => {
          this.loaderService.hide();
          res.results.milestones.map((milestone) => {
            this.getAllMilestones = this.getAllMilestones.filter(
              (t) => t.id !== milestone?.id
            );
          });
          this.stagedMilestones = this.filterByStatus(
            res.results.milestones,
            ContractMilestoneStatus.Staged
          );
          this.inWorkMilestones = this.filterByStatus(
            res.results.milestones,
            ContractMilestoneStatus.InWork
          );
          this.wrapUpMilestones = this.filterByStatus(
            res.results.milestones,
            ContractMilestoneStatus.WrapUp
          );
          this.checkStatusOnCompletion(false);
        },
        error: (e) => {
          this.loaderService.hide();
          this.handleError(e);
        },
        complete: () => {},
      });
  }

  filterByStatus(payloadTasks: any, status: ContractMilestoneStatus): any {
    switch (status) {
      case ContractMilestoneStatus.Staged: {
        return payloadTasks.filter(
          (res) => res?.statusId == ContractMilestoneStatus.Staged
        );
      }
      case ContractMilestoneStatus.InWork: {
        return payloadTasks.filter(
          (res) => res?.statusId == ContractMilestoneStatus.InWork
        );
      }
      case ContractMilestoneStatus.WrapUp: {
        return payloadTasks.filter(
          (res) => res?.statusId == ContractMilestoneStatus.WrapUp
        );
      }
    }
  }

  handleError(error: any, message?: string) {
    this.loaderService.hide();
    if (
      error?.error?.statusCode === HttpStatusCode.NotFound ||
      error?.error?.statusCode === HttpStatusCode.Conflict
    ) {
      this.toastr.error(error.error.message, 'Error');
    } else {
      this.toastr.error(message, 'Error');
    }
  }

  checkStatusOnCompletion(isMilestoneFetched = true) {
    this.stagedStatus = this.checkMilestoneStatus(this.stagedMilestones);
    this.inWorkStatus = this.checkMilestoneStatus(this.inWorkMilestones);
    this.wrapUpStatus = this.checkMilestoneStatus(this.wrapUpMilestones);
    if (this.inWorkStatus) {
      if (
        isMilestoneFetched &&
        this.wrapUpMilestones[0]?.tasks[0]?.status == TaskStatusEnum.Pending
      ) {
        this.wrapUpMilestones[0].tasks[0].status = TaskStatusEnum.Active;
        this.wrapUpMilestones[0].tasks[0].statusId =
          ContractTasksStatusIdEnum.Active;
      }
      this.isStagedCompleted = true;
      this.isInworkCompleted = true;
      this.isWrapupCompleted = true;
      this.isInWorkDelete = true;
      this.isStagedDelete = true;
      this.isWrapUpDelete = true;
    } else if (this.stagedStatus) {
      if (
        isMilestoneFetched &&
        this.inWorkMilestones[0]?.tasks[0]?.status == TaskStatusEnum.Pending
      ) {
        this.inWorkMilestones[0].tasks[0].status = TaskStatusEnum.Active;
        this.inWorkMilestones[0].tasks[0].statusId =
          ContractTasksStatusIdEnum.Active;
      }
      this.isStagedCompleted = true;
      this.isInworkCompleted = true;
      this.isWrapupCompleted = false;
      this.isStagedDelete = true;
    } else {
      this.isStagedCompleted = true;
      this.isInworkCompleted = false;
      this.isWrapupCompleted = false;
    }
  }

  checkMilestoneStatus(milestones) {
    if (milestones.length == 0) return false;
    let failedTaskLength = 0;
    let completedTaskLength = 0;
    let totalTaskLength = 0;
    milestones.forEach((milestone) => {
      let completedTasks = milestone.tasks.filter(
        (m) => m.statusId === ContractTasksStatusIdEnum.Completed
      );
      let failedTasks = milestone.tasks.filter(
        (m) => m.statusId === ContractTasksStatusIdEnum.Failed
      );
      failedTaskLength += failedTasks.length;
      completedTaskLength += completedTasks.length;
      totalTaskLength += milestone.tasks.length;
    });
    if (totalTaskLength === failedTaskLength + completedTaskLength) {
      return true;
    } else {
      return false;
    }
  }

  onAssignSubmit(assignUser: any) {
    const assignedUser = {
      id: assignUser.contractTaskId,
      assignTo: assignUser.assignTo,
    };

    const selectedUser = this.users.find(
      (user) => user.id === assignUser.assignTo
    );
    this.loaderService.show();
    this.contractMilestoneManagerService
      .saveAssignUser(this.contractId, assignedUser)
      .subscribe({
        next: (res) => {
          this.loaderService.hide();
          this.toastr.success('User Assigned Successfully!');
          switch (assignUser.statusId) {
            case ContractMilestoneStatus.Staged:
              this.mapMilestonesOnUserAssignation(
                this.stagedMilestones,
                assignUser,
                selectedUser
              );
              break;
            case ContractMilestoneStatus.InWork:
              this.mapMilestonesOnUserAssignation(
                this.inWorkMilestones,
                assignUser,
                selectedUser
              );
              break;
            case ContractMilestoneStatus.WrapUp:
              this.mapMilestonesOnUserAssignation(
                this.wrapUpMilestones,
                assignUser,
                selectedUser
              );
              break;
            default:
              break;
          }
        },
        error: (err) => {
          this.loaderService.hide();
          this.handleError(err);
        },
      });
  }

  onCompleteSubmit(completeTasks) {
    const completedTask = {
      id: completeTasks.contractTaskId,
      completedDate: completeTasks.completedDate,
    };

    this.loaderService.show();
    this.contractMilestoneManagerService
      .saveCompleteMilestoneTask(this.contractId, completedTask)
      .subscribe({
        next: (res) => {
          this.loaderService.hide();
          this.poStatusId = res.results.poStatusId;
          this.toastr.success('Completed Successfully!');
          switch (completeTasks.statusId) {
            case ContractMilestoneStatus.Staged:
              this.mapMilestonesOnCompletion(
                this.stagedMilestones,
                completeTasks,
                res
              );
              break;
            case ContractMilestoneStatus.InWork:
              this.mapMilestonesOnCompletion(
                this.inWorkMilestones,
                completeTasks,
                res
              );
              break;
            case ContractMilestoneStatus.WrapUp:
              this.mapMilestonesOnCompletion(
                this.wrapUpMilestones,
                completeTasks,
                res
              );
              break;
            default:
              break;
          }
          this.checkStatusOnCompletion();
        },
        error: (err) => {
          this.loaderService.hide();
          this.handleError(err);
        },
      });
  }

  onFailSubmit(failTask: any) {
    const failedTask = {
      id: failTask.contractTaskId,
      failDate: new Date(failTask.failDate),
      failReason: failTask.failReason,
    };

    this.loaderService.show();
    this.contractMilestoneManagerService
      .saveFailMilestoneTask(this.contractId, failedTask)
      .subscribe({
        next: (res) => {
          this.loaderService.hide();
          this.toastr.success('Failed Status Updated!');
          switch (failTask.statusId) {
            case ContractMilestoneStatus.Staged:
              this.mapMilestonesOnFail(this.stagedMilestones, failTask, res);
              break;
            case ContractMilestoneStatus.InWork:
              this.mapMilestonesOnFail(this.inWorkMilestones, failTask, res);
              break;
            case ContractMilestoneStatus.WrapUp:
              this.mapMilestonesOnFail(this.wrapUpMilestones, failTask, res);
              break;
            default:
              break;
          }
          this.checkStatusOnCompletion();
        },
        error: (err) => {
          this.loaderService.hide();
          this.handleError(err);
        },
      });
  }

  mapMilestonesOnUserAssignation(milestones, assignUser, selectedUser) {
    milestones = milestones.map((milestone) => {
      if (milestone.id === assignUser.milestoneId) {
        milestone.tasks.map((task) => {
          if (task.id === assignUser.taskId) {
            task.assignToName = selectedUser.displayName;
            task.assignTo = assignUser.assignTo;
          }
        });
      }
      return milestone;
    });
  }

  mapMilestonesOnCompletion(milestones, completeTask, res) {
    const index = milestones.findIndex(
      (item) => item.id == completeTask.milestoneId
    );
    milestones = milestones.map((milestone) => {
      if (milestone.id === completeTask.milestoneId) {
        milestone.tasks.map((task) => {
          if (task.id === completeTask.taskId) {
            task.completedDate = new Date(res.results.completedDate);
            task.failDate = null;
            task.status = TaskStatusEnum.Completed;
            task.statusId = ContractTasksStatusIdEnum.Completed;
            task.completedByName = res?.results?.completedByName;
            task.lastCompletedOrFailedDate =
              res?.results?.lastCompletedOrFailedDate;
            task.assignToName = res?.results?.assignToName;
            task.assignTo = res?.results?.assignTo;
          }
        });
        if (
          milestone.tasks.length > 1 &&
          completeTask.taskIndex !== milestone.tasks.length - 1
        ) {
          milestone.tasks[completeTask.taskIndex + 1].status =
            TaskStatusEnum.Active;
        }
      }
      return milestone;
    });
    if (this.checkMilestoneStatus([milestones[index]])) {
      if (milestones && milestones[index + 1]) {
        milestones[index + 1].tasks[0].status = TaskStatusEnum.Active;
      }
    }
  }

  mapMilestonesOnFail(milestones, failTask, res) {
    const index = milestones.findIndex(
      (item) => item.id == failTask.milestoneId
    );
    milestones = milestones.map((milestone) => {
      if (milestone.id === failTask.milestoneId) {
        milestone.tasks.map((task) => {
          if (task.id === failTask.taskId) {
            task.status = TaskStatusEnum.Failed;
            task.statusId = ContractTasksStatusIdEnum.Failed;
            task.failDate = new Date(res.results.failDate);
            task.failReason = res.results.failReason;
            task.completedDate = null;
            task.failedByName = res.results.failedByName;
            task.lastCompletedOrFailedDate =
              res?.results?.lastCompletedOrFailedDate;
            task.assignToName = res?.results?.assignToName;
            task.assignTo = res?.results?.assignTo;
          }
        });
        if (
          milestone.tasks.length > 1 &&
          failTask.taskIndex !== milestone.tasks.length - 1
        ) {
          milestone.tasks[failTask.taskIndex + 1].status =
            TaskStatusEnum.Active;
        }
      }

      return milestone;
    });

    if (this.checkMilestoneStatus([milestones[index]])) {
      if (milestones && milestones[index + 1]) {
        milestones[index + 1].tasks[0].status = TaskStatusEnum.Active;
      }
    }
  }

  onCloseMilestoneModal() {
    this.isOpenMilestoneModal = false;
    this.selectedMilestonesToBeSaved = [];
  }

  onToggleMilestoneCheckbox(event: any, milestone: any) {
    if (event.target.checked) {
      this.selectedMilestonesToBeSaved.push(milestone);
    } else {
      this.selectedMilestonesToBeSaved =
        this.selectedMilestonesToBeSaved.filter((m) => m.id != milestone.id);
    }

    console.log(this.selectedMilestonesToBeSaved);
  }

  onToggleSelectAll(event) {
    if (event.target.checked) {
      this.selectedMilestonesToBeSaved = this.getAllMilestones;
    } else {
      this.selectedMilestonesToBeSaved = [];
    }
    console.log(this.selectedMilestonesToBeSaved);
  }

  isChecked(milestone: any) {
    return this.selectedMilestonesToBeSaved.some(
      (selectedMilestone) => selectedMilestone.id === milestone.id
    );
  }

  saveMilestone() {
    this.loaderService.show();
    var milestonesToAdd: any[] = [];
    this.selectedMilestonesToBeSaved.forEach((milestone) => {
      let payload = {
        contractMilestoneId: 0,
        statusId: this.statusId,
        milestoneId: milestone.id,
        contractTasks: milestone.tasks.map((task) => {
          return {
            contractTaskId: 0,
            taskId: task.id,
          };
        }),
      };
      milestonesToAdd.push(payload);
    });

    this.contractMilestoneManagerService
      .createMultipleContractMilestone(this.contractId, milestonesToAdd)
      .pipe(takeUntil(this.ngUnsubscribe$))
      .subscribe({
        next: (res) => {
          if (this.statusId == ContractMilestoneStatus.Staged) {
            this.stagedMilestones.push(...this.selectedMilestonesToBeSaved);
          }
          if (this.statusId == ContractMilestoneStatus.InWork) {
            this.inWorkMilestones.push(...this.selectedMilestonesToBeSaved);
            this.isStagedDelete = true;
          }
          if (this.statusId == ContractMilestoneStatus.WrapUp) {
            this.wrapUpMilestones.push(...this.selectedMilestonesToBeSaved);
            this.isStagedDelete = true;
            this.isInWorkDelete = true;
          }
          this.checkStatusOnCompletion(true);
          this.isOpenMilestoneModal = false;
          this.loaderService.hide();
        },
        error: (err) => {
          this.loaderService.hide();
          this.handleError(err);
        },
        complete: () => {
          this.isOpenMilestoneModal = false;
          this.loaderService.hide();
          this.selectedMilestonesToBeSaved = [];
        },
      });
  }
}
