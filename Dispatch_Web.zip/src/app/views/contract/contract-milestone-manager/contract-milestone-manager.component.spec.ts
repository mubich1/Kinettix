import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContractMilestoneManagerComponent } from './contract-milestone-manager.component';

describe('ContractMilestoneManagerComponent', () => {
  let component: ContractMilestoneManagerComponent;
  let fixture: ComponentFixture<ContractMilestoneManagerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContractMilestoneManagerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContractMilestoneManagerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
