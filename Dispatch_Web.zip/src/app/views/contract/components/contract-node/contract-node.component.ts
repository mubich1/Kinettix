import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngxs/store';
import { ClientContractsGetDto } from 'src/app/models/project/project';
import { ProjectActivityResourceService } from 'src/app/services/project-activity-resources/project-activity-resources.service';
import { TruncatedClient } from 'src/app/state/contracts/contracts-state.model';
import { LoadContractsForClient } from 'src/app/state/contracts/contracts.state';
import { LoadingState } from 'src/app/state/loading-state.enum';

@Component({
  selector: 'app-contract-node',
  templateUrl: './contract-node.component.html',
  styleUrls: ['./contract-node.component.css']
})
export class ContractNodeComponent implements OnInit {

  constructor(private store: Store, private projectActivityResourceService: ProjectActivityResourceService, private router: Router) { }

  @Input() client: TruncatedClient;

  isShowingClosedContracts: boolean;

  // Define at a component level for template usage
  loadingStates = LoadingState;

  ngOnInit(): void {
    this.isShowingClosedContracts = this.client.contractsState.value.showClosedContracts;
  }

  loadContractsForClient(): void {
    this.store.dispatch(new LoadContractsForClient(this.client));
  }

  viewContractDetails(contract: ClientContractsGetDto){
    this.projectActivityResourceService.shareContractInfo(contract);

    this.router.navigate(['delivery/contract-detail/client/', contract.clientId, 'contract', contract.id]);
  }

  reloadContractsWithOptions() {
    this.store.dispatch(new LoadContractsForClient(this.client, true, this.isShowingClosedContracts));
  }

}
