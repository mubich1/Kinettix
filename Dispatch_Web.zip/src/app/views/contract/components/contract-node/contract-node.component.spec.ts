import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContractNodeComponent } from './contract-node.component';

describe('ContractNodeComponent', () => {
  let component: ContractNodeComponent;
  let fixture: ComponentFixture<ContractNodeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContractNodeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContractNodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
