import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContractSidebarComponent } from './contract-sidebar.component';

describe('ContractSidebarComponent', () => {
  let component: ContractSidebarComponent;
  let fixture: ComponentFixture<ContractSidebarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContractSidebarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContractSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
