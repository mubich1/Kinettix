import { AfterViewInit, Component, ElementRef, OnDestroy, OnInit, QueryList, ViewChildren } from '@angular/core';
import { Select, Store } from '@ngxs/store';
import { debounceTime, distinctUntilChanged, Observable, Subject, takeUntil } from 'rxjs';
import { Permission } from 'src/app/services/utility/permission-constant';
import { UtilityService } from 'src/app/services/utility/utility.service';
import { ContractsStateModel } from 'src/app/state/contracts/contracts-state.model';
import { ClientSearch, ContractsState, LoadAdditionalClients, LoadContractsAction } from 'src/app/state/contracts/contracts.state';
import { LoadingState } from 'src/app/state/loading-state.enum';
import { ContractNodeComponent } from '../contract-node/contract-node.component';

@Component({
  selector: 'app-contract-sidebar',
  templateUrl: './contract-sidebar.component.html',
  styleUrls: ['./contract-sidebar.component.css']
})
export class ContractSidebarComponent implements OnInit, OnDestroy, AfterViewInit {

  constructor(private store: Store,private utilityService:UtilityService) { }

  @ViewChildren(ContractNodeComponent) clientNodes: QueryList<ContractNodeComponent>;

  input$ = new Subject<string>();

  componentDestroyed$ = new Subject<void>();

  clientSearchQuery: string | null;

  @Select(ContractsState) contracts$: Observable<ContractsStateModel>;

  intersectionObserver: IntersectionObserver;

  // Define at a component level for template usage
  loadingStates = LoadingState;

  isViewDeliveryContractsAllowed:boolean = true

  ngOnInit(): void {
    this.isViewDeliveryContractsAllowed = this.utilityService.hasPermission(Permission.ViewDeliveryContract);
    
    this.store.dispatch(new LoadContractsAction());

    this.input$.pipe(
      debounceTime(300),
      distinctUntilChanged(),
      takeUntil(this.componentDestroyed$),
    ).subscribe((value) => {
      this.store.dispatch(new ClientSearch(value));
    });

    this.clientSearchQuery = this.store.selectSnapshot<string | null>((state) => state.contractsState.searchQuery);

    this.intersectionObserver = new IntersectionObserver((event) => {
      if(event[0].isIntersecting) {
        this.store.dispatch(new LoadAdditionalClients());
      }
    });
  }

  ngAfterViewInit(): void {
    if(this.clientNodes.length > 0) {
      this.applyIntersectionObserver();
    }

    this.clientNodes.changes.subscribe(() => {
      this.applyIntersectionObserver();
    });
  }


  applyIntersectionObserver(): void {
    this.intersectionObserver.disconnect();

    const entries = document.querySelectorAll('app-contract-node');
    this.intersectionObserver.observe(entries.item(entries.length - 1));
  }

  ngOnDestroy(): void {
    this.componentDestroyed$.next();
    this.componentDestroyed$.complete();

    this.intersectionObserver.disconnect();
  }

  onSearchInput(event: any): void {
    this.input$.next(event.target.value);
  }

}
