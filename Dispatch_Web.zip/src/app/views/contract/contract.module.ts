import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContractComponent } from './contract.component';
import { RouterModule, Routes } from '@angular/router';
import { CoreModule } from 'src/app/core/core.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { CarbonModule } from 'src/app/carbon.module';
import { PaginationModule, TableModule, TagModule, NumberModule } from 'carbon-components-angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EditorModule } from '@tinymce/tinymce-angular';
import { NotesModule } from '../shared/notes.module';
import { BreadcrumbModule } from 'carbon-components-angular';
import { NgpImagePickerModule } from 'ngp-image-picker';
import { ContractDetailComponent } from './contract-detail/contract-detail.component';
import { ContractTicketsComponent } from './contract-tickets/contract-tickets.component';
import { ContractOverviewComponent } from './contract-overview/contract-overview.component';
import { AddTicketComponent } from './contract-tickets/add-ticket/add-ticket.component';
import { CheckmarkFilledModule, CloseFilledModule, CloseOutlineModule, EditModule, TrashCanModule, ViewModule } from '@carbon/icons-angular';
import { NgSelectModule } from '@ng-select/ng-select';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { TicketActivitiesComponent } from './contract-tickets/add-ticket/ticket-activities/ticket-activities.component';
import { AddEditActivityComponent } from './contract-tickets/add-ticket/ticket-activities/add-edit-activity/add-edit-activity.component';
import { TicketLocationsComponent } from './contract-tickets/add-ticket/ticket-activities/ticket-locations/ticket-locations.component';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from '@danielmoncada/angular-datetime-picker';
import { ContractDocumentsComponent } from './contract-documents/contract-documents.component';
import { PoLogsComponent } from 'src/app/views/contract/po-logs/po-logs.component';
import { ContractActivitiesComponent } from './contract-activities/contract-activities.component';
import { ActivitiesModule } from '../activities/activities.module';
import { PoDetailsComponent } from './po-details/po-details.component';
import { ContractIncidentComponent } from './contract-incidents/contract-incidents.component';
import { ContractFinancialsComponent } from './contract-financials/contract-financials/contract-financials.component';
import { ContractSidebarComponent } from './components/contract-sidebar/contract-sidebar.component';
import { ContractNodeComponent } from './components/contract-node/contract-node.component';
import { AuthGuard } from 'src/app/core/AuthGuard/auth.guard';
import { Permission } from 'src/app/services/utility/permission-constant';
import { ContractMilestoneManagerComponent } from './contract-milestone-manager/contract-milestone-manager.component';
import { PaginationBuilderModule } from 'src/app/shared/components/pagination-builder/pagination-builder.module';

const routes: Routes = [
  {
    path: '',
    component: ContractComponent, data: { breadcrumb: 'Contracts' },
    children: [
      { path: '', redirectTo: 'contract-detail', pathMatch: 'full' },
      { path: 'po/po-logs', component: PoLogsComponent },
      { path: 'po-details', component: PoDetailsComponent },
      {
        path: 'contract-detail/client/:clientId/contract/:contractId', component: ContractDetailComponent,  data: { breadcrumb: 'Contract-Detail' },
        children: [
          { path: '',canActivate:[AuthGuard],data:{permission:Permission.ViewDeliveryContract}, redirectTo: 'overview' , pathMatch: 'full' },
          { path: 'tickets', component: ContractTicketsComponent ,canActivate:[AuthGuard], data: { breadcrumb: 'Tickets',permission:Permission.ViewDeliveryContractTicket }, pathMatch: 'full' },
          { path: 'overview', component: ContractOverviewComponent,canActivate:[AuthGuard],  data: { breadcrumb: 'Overview',permission:Permission.ViewDeliveryContract }, pathMatch: 'full' },
          { path: 'activities', component: ContractActivitiesComponent,canActivate:[AuthGuard], data: { breadcrumb: 'Activities',permission:Permission.ViewDeliveryContractActivity }, pathMatch: 'full' },
          { path: 'contract-milestone-manager', component: ContractMilestoneManagerComponent,canActivate:[AuthGuard], data: { breadcrumb: 'Task Manager',permission:Permission.ViewDeliveryContractActivity }, pathMatch: 'full' },
          { path: 'documents', component: ContractDocumentsComponent,canActivate:[AuthGuard], data: { breadcrumb: 'Documents',permission:Permission.ViewDeliveryContractDocument }, pathMatch: 'full' },
          { path: 'incidents', component: ContractIncidentComponent,canActivate:[AuthGuard], data: { breadcrumb: 'Incidents',permission:Permission.ViewDeliveryContractIncident }, pathMatch: 'full' },
          { path: 'financials', component: ContractFinancialsComponent,canActivate:[AuthGuard], data: { breadcrumb: 'Financials',permission:Permission.ViewDeliveryContractFinancial }, pathMatch: 'full' },
          ]
      },
    ],
  }
];

// /delivery/contract-detail/client/1979/contract/1/tickets/1
@NgModule({
  declarations: [
    ContractComponent,
    ContractDetailComponent,
    ContractTicketsComponent,
    ContractOverviewComponent,
    AddTicketComponent,
    TicketActivitiesComponent,
    AddEditActivityComponent,
    TicketLocationsComponent,
    ContractDocumentsComponent,
    PoLogsComponent,
    // PoNotesLogsComponent,
    // PoCallLogsComponent,
    ContractActivitiesComponent,
    PoDetailsComponent,
    ContractIncidentComponent,
    ContractFinancialsComponent,
    ContractSidebarComponent,
    ContractNodeComponent,
    ContractMilestoneManagerComponent,
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    CoreModule,
    CarbonModule,
    TableModule,
    PaginationModule,
    FormsModule,
    EditorModule,
    ReactiveFormsModule,
    CheckmarkFilledModule,
    CloseFilledModule,
    CloseOutlineModule,
    BreadcrumbModule,
    NotesModule,
    TrashCanModule,
    NgSelectModule,
    NgpImagePickerModule,
    NotesModule,
    DragDropModule,
    OwlDateTimeModule,
    OwlNativeDateTimeModule,
    ActivitiesModule,
    SharedModule,
    EditModule,
    ViewModule,
    TagModule,
    NumberModule,
    PaginationBuilderModule,
  ],
  exports: [RouterModule],
})
export class ContractModule { }
