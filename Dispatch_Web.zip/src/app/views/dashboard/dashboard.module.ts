import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard.component';
import { CoreModule } from 'src/app/core/core.module';
import { RouterModule, Routes } from '@angular/router';
import {BreadcrumbModule } from 'carbon-components-angular';
import { CarbonModule } from 'src/app/carbon.module';

const routes: Routes = [
  { path: '', component: DashboardComponent }
];

@NgModule({
  declarations: [DashboardComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    CoreModule,
    CarbonModule,
    BreadcrumbModule
  ],
  exports:[ RouterModule ]
})
export class DashboardModule { }
