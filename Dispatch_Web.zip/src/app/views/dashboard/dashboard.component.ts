import { Component, OnInit } from '@angular/core';
import { Contract } from 'src/app/models/proposals/proposal';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

    // Deals
    dealsInfo = {
      totalDeals: 0,
      atRisk: 0,
      paused: 0,
      inWork: 0,
      closedLost: 0,
      closedWOn: 0,
    };
  
    loadingDeals: boolean = true;
    // End Deals
  
    // Clients
    clientsInfo = {
      active: 0,
    };
    loadingClients: boolean = true;
    // End Clients
  
    // Proposal
  
    proposalInfo = {
      build: 0,
      sent: 0,
      rejected: 0
    };
  
    loadingProposal: boolean = true;
  
    proposalList: Contract[] = [];
    // End Proposal
  constructor() { }

  ngOnInit(): void {
  }

}
