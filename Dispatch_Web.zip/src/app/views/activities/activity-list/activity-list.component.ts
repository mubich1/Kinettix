import { CurrencyPipe } from '@angular/common';
import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {
  ModalService,
  Table,
  TableHeaderItem,
  TableItem,
  TableModel,
} from 'carbon-components-angular';
import { ToastrService } from 'ngx-toastr';
import { Observable, Subject, Subscription } from 'rxjs';
import { Activity } from 'src/app/models/activity/activity';
import { ActivityResource } from 'src/app/models/activity/activity-resource';
import { ConfirmationDialog } from 'src/app/models/dialog/confirmation';
import { InputDialog } from 'src/app/models/dialog/input-dialog';
import { Permission } from 'src/app/services/utility/permission-constant';
import { UtilityService } from 'src/app/services/utility/utility.service';
import { AngularUtility } from 'src/app/shared/common/angular-utitilty';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';
import { ConfirmationDialogComponent } from 'src/app/shared/components/confirmation-dialog/confirmation-dialog.component';
import { InputDialogComponent } from 'src/app/shared/components/input-dialog/input-dialog.component';
import { AddActivityResourceComponent } from 'src/app/shared/components/project-activity-resources/add-activity-resource/add-activity-resource.component';
import { ActivityResourcesComponent } from '../../settings/activity/activity-resources/activity-resources.component';
import { LoaderService } from 'src/app/services/loader/loader.service';
import { ActivityResourceRequest } from 'src/app/models/resources/resource';
import { ResourceService } from 'src/app/services/Settings/resource.service';
import { TableFilters } from 'src/app/shared/common/tableFilters';

@Component({
  selector: 'app-activity-list',
  templateUrl: './activity-list.component.html',
  styleUrls: ['./activity-list.component.css'],
})
export class ActivityListComponent implements OnInit {
  @Input() paramsData: any;
  @ViewChild('resourceTableTemplate', { static: true })
  resourceTableTemplate: ElementRef;
  @ViewChild('activityActionTemplate', { static: true })
  activityActionTemplate: ElementRef;
  @ViewChild('resourceActionTemplate', { static: true })
  resourceActionTemplate: ElementRef;
  @ViewChild('grandTotalTemplate', { static: true })
  grandTotalTemplate: ElementRef;
  @Input() activityId: number = 0;
  @Input() fromActivity: boolean = false;
  @Input() fromProposal: boolean = false;
  searchString: string = '';
  subscription$: Subscription = new Subscription();
  copyActivityModalObs: Observable<InputDialog> = new Subject<InputDialog>();
  activityModalObs: Observable<ConfirmationDialog> =
    new Subject<ConfirmationDialog>();
  deleteActivityModalObs: Observable<ConfirmationDialog> =
    new Subject<ConfirmationDialog>();
  deleteResourceModalObs: Observable<ConfirmationDialog> =
    new Subject<ConfirmationDialog>();
  addResourceModalObs: Observable<ConfirmationDialog> =
    new Subject<ConfirmationDialog>();

  showSkeleton: boolean = true;
  showStripe: boolean = true;
  @Output() GetActivityResoruceId = new EventEmitter<number>();
  @Output() EditActivity: EventEmitter<number> = new EventEmitter();

  @Output() onAddNewActivity: EventEmitter<any> = new EventEmitter();
  @Output() onAddExistingActivity: EventEmitter<any> = new EventEmitter();
  @Output() onDeleteActivity: EventEmitter<Activity> = new EventEmitter();

  @Output() onCopyActivity: EventEmitter<Activity> = new EventEmitter();
  @Output() onDeleteActivityResource: EventEmitter<any> = new EventEmitter();
  @Output() onAddResource: EventEmitter<any> = new EventEmitter();
  @Output() activityTableFilter: EventEmitter<any> = new EventEmitter();
  @Input() set activityList(activityList: any) {
    if(activityList) {
      this.activitiesLists = activityList.results;
      this.totalActivityLength = activityList.total;
      this.populateActivityTable( this.activitiesLists)
    }

  };

  activityModel = new TableModel();
  activityData: TableItem[][] = [];
  carbonUtility = new CarbonUtility();
  angularUtility = new AngularUtility();
  editActivityClicked: boolean = false;
  editActivityId = 0;
  router: Router;
  dealId: number;
  proposalId: number;
  activitiesLists: Activity[] = []

  GrandquantitySum = 0;
  GrandCostSum = 0;
  GrandPriceSum = 0;

  isResourceExist: boolean = false;

  allowViewActivity: boolean = true;
  allowAddActivitiy: boolean = true;
  allowEditActivity: boolean = true;
  allowDeleteActivity: boolean = true;

  allowViewActivityResource: boolean = true;
  allowAddActivityResource: boolean = true;
  allowDeleteActivityResource: boolean = true;
  allowEditActivityResource: boolean = true;
  tableFilters: TableFilters = new TableFilters();
  index: any;
  sort: boolean;
  isAscending: boolean = false;
  totalActivityLength: number = 0;
  constructor(
    private modalService: ModalService,
    private currencyPipe: CurrencyPipe,
    router: Router,
    private toastr: ToastrService,
    private activatedRoute: ActivatedRoute,
    private utilityService: UtilityService,
    private resourceService: ResourceService,
    private loaderService: LoaderService
  ) {
    this.router = router;
  }

  ngOnInit(): void {
    this.allowAddActivitiy = this.utilityService.hasPermission(Permission.AddContractActivity);
    this.allowEditActivity = this.utilityService.hasPermission(Permission.EditContractActivity) || this.utilityService.hasPermission(Permission.EditManageCatalogs);
    this.allowDeleteActivity = this.utilityService.hasPermission(Permission.DeleteContractActivity);

    this.allowViewActivityResource = this.utilityService.hasPermission(Permission.ViewContractActivityResource);
    this.allowAddActivityResource = this.utilityService.hasPermission(Permission.AddContractActivityResource);
    this.allowEditActivityResource = this.utilityService.hasPermission(Permission.EditContractActivityResource) || this.utilityService.hasPermission(Permission.EditManageCatalogs);
    this.allowDeleteActivityResource = this.utilityService.hasPermission(Permission.DeleteContractActivityResource);

    this.activityList;

    this.activatedRoute.parent?.paramMap.subscribe((params) => {
      this.dealId = +params.get('id')!;
    });

    this.activatedRoute.paramMap.subscribe((params) => {
      this.proposalId = +params.get('proposalId')!;
    });
    this.activityModel = Table.skeletonModel(5, 5);

    this.subscription$.add(
      this.deleteResourceModalObs.subscribe((res) => {
        if (res?.confirm) {
          this.deleteActivityResource(res?.data?.id);
        }
      })
    );
  }

 
  onSearch(event) {
    this.tableFilters.search = event.target.value;
    this.tableFilters.page = 1;
    this.activityTableFilter.emit(this.tableFilters);
  }

  // Bug #5670: This issue exists due to there being two distict add activity buttons. Since
  // there are different cases for each, we can move the conditional logic from the template to the
  // component.
  handleAddActivityButtonClicked() {
    // Logic that existed previously in the template.
    const shouldOpenActivityDialog = this.fromActivity ? false : this.fromProposal ? this.activitiesLists.length > 0 ? (!this.paramsData.stage) : true : true;
    if (shouldOpenActivityDialog) {
      // Logic that previously existed in "onAddActivity()"
      this.openActivityConfirmationModal();
    } else {
      // Logic that previously existed in "onGlobalActivity()". Since this
      // execution path had the least number of conditions, it will be the fallback
      // from the first.
      this.onAddResource.emit();
    }
  }

  ngAfterContentInit(): void {
    // For adding new activities.
    this.activityModalObs.subscribe((value) => {
      if (!value.isClosed) {
        if (value.confirm) {
          this.onAddNewActivity.emit();
          // When new activity is selected.
        } else {
          // When existing activity is selected.
          this.onAddExistingActivity.emit();
        }
      }
    });

    this.copyActivityModalObs.subscribe((value) => {
      if (value.confirm) {
        this.onClearSearch();
        if (value.value === value.data.name) {
          this.toastr.error('Please Change Name of Activity to Copy');
        } else {
          let dataToCopy = value.data == null ? '' : value.data;
          dataToCopy.name = value.value;

          this.editActivityId = dataToCopy.id;
          this.editActivityClicked = true;
          this.onCopyActivity.emit(dataToCopy);
        }
      }
      if (!value.confirm) {
        // this.onCancelActivity();
      }
    });

    this.deleteActivityModalObs.subscribe((value) => {
      if (value.confirm) {
        this.onClearSearch();
        this.onDeleteActivity.emit(value.data);
      }
    });

    this.deleteResourceModalObs.subscribe((value) => {
      if (value.confirm) {
        this.onDeleteActivityResource.emit(value.data);
      }
    });

    this.addResourceModalObs.subscribe((value) => {
      this.onAddResource.emit();
    });
  }

  initializeActivityTable() {
    this.activityModel.header = [];
    this.activityModel.data = [];

    let headers = [
      new TableHeaderItem({ data: 'ACTIVITY TITLE' }),
      new TableHeaderItem({ data: 'TOTAL VARIABLE COST' }),
      new TableHeaderItem({ data: 'TOTAL PRICE' }),
      new TableHeaderItem({ data: 'Type' }),
      new TableHeaderItem({ data: 'Category' }),
      new TableHeaderItem({ data: 'Tech Level' }),
      new TableHeaderItem({ data: 'Response Interval' }),
      new TableHeaderItem({ data: 'Region' }),
      new TableHeaderItem({ data: 'Currency' }),
      new TableHeaderItem({ data: 'STATUS' }),
      new TableHeaderItem({ data: 'QTY', visible: !this.fromActivity }),
      new TableHeaderItem({ data: 'COST', visible: !this.fromActivity }),
      new TableHeaderItem({ data: 'PRICE', visible: !this.fromActivity }),
      new TableHeaderItem({ data: 'ACTION', sortable: false, visible: this.utilityService.hasPermission(Permission.EditContractActivity) }),
    ];

    this.activityModel = this.carbonUtility.initializeTable(
      headers,
      this.activityModel,
      this.activityData
    );

    this.showSkeleton = false;
  }

  selectPage(page: any ) {
      this.activityModel.currentPage = page;
      this.tableFilters.pageSize = this.activityModel.pageLength;
      this.tableFilters.page = page;
      this.activityTableFilter.emit(this.tableFilters);
  }

  onSort(index){
    this.isAscending = !this.isAscending;
    this.index = index;
    this.sort = true;
    this.tableFilters.isAscending = this.isAscending;
    this.tableFilters.sort = this.activityModel.header[index].data;
    this.activityTableFilter.emit(this.tableFilters);
  }

  onClearSearch() {
    this.tableFilters.search = '';
    this.activityTableFilter.emit(this.tableFilters)
  }

  selectResourcePage(
    page: any,
    resourceModel: TableModel,
    resourceData: TableItem[][]
  ) {
    resourceModel = this.carbonUtility.selectPage(
      page,
      resourceModel,
      resourceData
    );
  }

  populateActivityTable(activitiesLists: Activity[]) {

    this.activityModel.data = [];
    this.activityData = [];
    this.activityModel.totalDataLength = this.totalActivityLength;
    if (activitiesLists != null && activitiesLists.length > 0) {
      this.GrandquantitySum = 0;
      this.GrandCostSum = 0;
      this.GrandPriceSum = 0;

      activitiesLists.forEach((el: any) => {
        this.GrandquantitySum += el.quantity;

        let resourceModel = new TableModel();
        let resourceData: TableItem[][] = [];

        this.populateResourceTable(
          el.resources,
          resourceModel,
          resourceData
        );

        let totalcost = 0;
        let totalPrice = 0;

        if (el.resources != null && el.resources.length > 0) {
          this.isResourceExist = true;
          totalcost =
            this.angularUtility.getSum(el.resources, 'totalCost') *
            el.quantity;
          totalPrice =
            this.angularUtility.getSum(el.resources, 'price') * el.quantity;

          this.GrandCostSum += totalcost;
          this.GrandPriceSum += totalPrice;

          this.allowViewActivityResource ?
            this.activityData.push([
              new TableItem({
                data: el?.displayName,
                expandedData: [
                  [
                    new TableItem({
                      data: resourceModel,
                      colSpan: 12,
                      template: this.resourceTableTemplate,
                    }),
                  ],
                ],
                expandAsTable: true,
              }),
              new TableItem({ data: el?.totalVariableCost }),
              new TableItem({ data: el?.totalPrice }),
              new TableItem({ data: el?.type?.type }),
              new TableItem({ data: el?.category }),
              new TableItem({ data: el?.technicianLevel }),
              new TableItem({ data: el?.responseInterval == null ? '' : el?.responseInterval }),
              new TableItem({ data: el?.region == null ? '' : el.region }),
              new TableItem({ data: el?.currency }),

              new TableItem({ data: el?.status != null ? el?.status.name : '' }),
              new TableItem({ data: el?.quantity }),
              new TableItem({
                data: this.currencyPipe.transform(totalcost, 'USD'),
              }),
              new TableItem({
                data: this.currencyPipe.transform(totalPrice, 'USD'),
              }),
              new TableItem({ data: el, template: this.activityActionTemplate }),
            ])
            :
            this.activityData.push([
              new TableItem({ data: el.displayName }),
              new TableItem({ data: el.totalPrice }),
              new TableItem({ data: el.type.type }),
              new TableItem({ data: el.category.name }),
              new TableItem({ data: el.technicianLevel }),
              new TableItem({ data: el.responseInterval == null ? '' : el.responseInterval.name }),
              new TableItem({ data: el.region == null ? '' : el.region }),
              new TableItem({ data: el.currency }),

              new TableItem({ data: el.status != null ? el.status.name : '' }),
              new TableItem({ data: el.quantity }),
              new TableItem({
                data: this.currencyPipe.transform(totalcost, 'USD'),
              }),
              new TableItem({
                data: this.currencyPipe.transform(totalPrice, 'USD'),
              }),
              new TableItem({ data: el, template: this.activityActionTemplate }),
            ]);
        }
        else {
          let resourceModel = new TableModel();
          let resourceData: TableItem[][] = [];

          this.populateResourceTable(
            el.activityResources,
            resourceModel,
            resourceData
          );
          this.activityData.push([
            new TableItem({
              data: el.displayName,
              expandedData: [
                [
                  new TableItem({
                    data: resourceModel,
                    colSpan: 12,
                    template: this.resourceTableTemplate,
                  }),
                ],
              ],
              expandAsTable: true,
            }),
            new TableItem({ data: el.totalVariableCost }),
            new TableItem({ data: el.totalPrice }),

            new TableItem({ data: el.type.type }),
              new TableItem({ data: el.category.name }),
              new TableItem({ data: el.technicianLevel }),
              new TableItem({ data: el.responseInterval == null ? '' : el.responseInterval.name }),
              new TableItem({ data: el.region == null ? '' : el.region }),
              new TableItem({ data: el.currency }),

            new TableItem({ data: el.status != null ? el.status.name : '' }),
            new TableItem({ data: el.quantity }),
            new TableItem({
              data: this.currencyPipe.transform(el.price * el.quantity, 'USD'),
            }),
            new TableItem({
              data: this.currencyPipe.transform(el.price, 'USD'),
            }),
            new TableItem({ data: el, template: this.activityActionTemplate }),
          ]);
        }
      });
      this.totalActivityLength
    }
    this.initializeActivityTable()
    if (this.sort) {
      this.activityModel.header[this.index].descending = !this.isAscending;
      this.activityModel.sort(this.index);
    }
  }

  initializeResourceTable(
    resourceModel: TableModel,
    resourceData: TableItem[][]
  ) {
    resourceModel.header = [];
    resourceModel.data = [];

    let headers = [
      new TableHeaderItem({ data: 'TITLE' }),
      new TableHeaderItem({ data: 'NAME' }),
      new TableHeaderItem({ data: 'CATEGORY' }),
      new TableHeaderItem({ data: 'QUANTITY' }),
      new TableHeaderItem({ data: 'TOTAL COST' }),
      new TableHeaderItem({ data: 'PRICE' }),
      new TableHeaderItem({ data: 'ACTION', sortable: false, visible: this.utilityService.hasPermission(Permission.EditContract) }),
    ];

    resourceModel = this.carbonUtility.initializeTable(
      headers,
      resourceModel,
      resourceData
    );

    this.selectResourcePage(1, resourceModel, resourceData);
  }

  populateResourceTable(
    resources: ActivityResource[] | null,
    resourceModel: TableModel,
    resourceData: TableItem[][]
  ) {
    resourceModel.data = [];
    resourceData = [];
    resourceModel.totalDataLength = 0;

    if (resources != null && resources.length > 0) {
      resourceModel.totalDataLength = resources.length;
      resources.forEach((element: any) => {
        resourceData.push([
          new TableItem({ data: element.resourceDisplayTitle ?? '' }),
          new TableItem({ data: element.resourceName ?? '' }),
          new TableItem({
            data: element.categoryName != null ? element.categoryName : '',
          }),
          new TableItem({ data: element.quantity }),
          new TableItem({
            data: this.currencyPipe.transform(element.totalCost, 'USD'),
          }),
          new TableItem({
            data: this.currencyPipe.transform(element.price, 'USD'),
          }),
          new TableItem({
            data: element,
            template: this.resourceActionTemplate,
          }),
        ]);
      });
    }

    this.initializeResourceTable(resourceModel, resourceData);
  }

  openActivityConfirmationModal() {
    const modalInputs: ConfirmationDialog = {
      header: 'Activities',
      question: 'Do you want to add an exisiting activity or a new activity?',
      confirmationButtonText: 'New',
      cancelButtonText: 'Existing',
      data: null,
      obs: this.activityModalObs,
      confirm: false,
      isClosed: false,
    };

    this.modalService.create({
      component: ConfirmationDialogComponent,
      inputs: { data: modalInputs },
    });
  }

  onClickEditActivity(data) {
    this.editActivityId = data.id;

    this.loaderService.show();
    if (this.fromActivity == true) {
      this.editActivityClicked = true;
      this.EditActivity.emit(data);
    }
    else {
      this.editActivityClicked = false;
      this.EditActivity.emit(data.id);
    }
  }

  CopyActivity(data) {
    const modalInputs: InputDialog = {
      header: 'Copy Activity',
      label: 'Activity Name',
      value: data.name,
      confirmationButtonText: 'Save',
      cancelButtonText: 'Cancel',
      data: data,
      confirm: false,
      obs: this.copyActivityModalObs,
    };

    this.modalService.create({
      component: InputDialogComponent,
      inputs: { data: modalInputs },
    });

    // this.editActivityId = data.id;
    // this.editActivityClicked = true;
    // this.onCopyActivity.emit(data);
  }

  onClickDeleteActivity(data) {
    const modalInputs: ConfirmationDialog = {
      header: 'Delete Activity',
      question: 'Are you sure you want to delete this activity?',
      confirmationButtonText: 'Yes',
      cancelButtonText: 'No',
      data: data,
      obs: this.deleteActivityModalObs,
      confirm: false,
      isClosed: false,
    };

    this.modalService.create({
      component: ConfirmationDialogComponent,
      inputs: { data: modalInputs },
    });
  }

  onClickEditResource(data) {
    let activityResourceData: ActivityResourceRequest[] = [];
    activityResourceData.push(data);
    this.modalService.create({
      component: ActivityResourcesComponent,
      inputs: { data: activityResourceData, activityId: data.activityId, resourceEdit: true, addContractActivityResource: false },
    });
  }

  deleteActivityResource(id: number) {
    this.resourceService.deleteActivityResourceById(id).subscribe({
      next: (res) => {
        this.activitiesLists.forEach((item: any) => {
          const index = item?.activityResources?.findIndex((x) => x.id == id);
          if (index > -1) {
            item?.activityResources?.splice(index, 1);
            this.populateActivityTable(this.activitiesLists);
            this.initializeActivityTable();
            this.toastr.success("Deleted Successfully");
          }
        });
      },
      error: (err) => {
        this.toastr.error(err);
      },
    });
  }

  onClickDeleteResource(data) {
    const modalInputs: ConfirmationDialog = {
      header: 'Delete Activity Resource',
      question: 'Are you sure you want to delete this resource?',
      confirmationButtonText: 'Yes',
      cancelButtonText: 'No',
      data: data,
      obs: this.deleteResourceModalObs,
      confirm: false,
      isClosed: false,
    };

    this.modalService.create({
      component: ConfirmationDialogComponent,
      inputs: { data: modalInputs },
    });
  }

  addResourceModal(data) {
    this.modalService.create({
      component: AddActivityResourceComponent,

      inputs: { data: { obs: this.addResourceModalObs, activityID: data.id } },
    });
  }

  GetActivityId(data: any) {
    this.GetActivityResoruceId.emit(data);
  }

  addGlobelResourceModal(data) {
    this.modalService.create({
      component: ActivityResourcesComponent,

      inputs: { data: { obs: this.addResourceModalObs, activityID: data.id } },
    });
  }


}
