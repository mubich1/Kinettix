import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CarbonModule } from 'src/app/carbon.module';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddModule, ViewModule, EditModule, TrashCanModule } from '@carbon/icons-angular';
import { EditorModule } from '@tinymce/tinymce-angular';
import { IconModule } from 'carbon-components-angular';
import { CoreModule } from 'src/app/core/core.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { ActivityListComponent } from './activity-list/activity-list.component';
import { AddNewActivityComponent } from './add-new-activity/add-new-activity.component';
import { NgSelectModule } from '@ng-select/ng-select';

const routes: Routes = [
  // { path: '', redirectTo: 'add-activity', pathMatch: 'full' },
  { path: 'add-activity', component: AddNewActivityComponent }, 
];

@NgModule({
  declarations: [
    AddNewActivityComponent,
    ActivityListComponent,
  ],
  imports: [
    CommonModule,
    FormsModule, ReactiveFormsModule,
    RouterModule.forChild(routes),
    CoreModule,
    SharedModule,
    EditorModule,
    CarbonModule,
    IconModule,
    NgSelectModule
  ],

  exports: [RouterModule, ActivityListComponent,AddNewActivityComponent]
})
export class ActivitiesModule { }
