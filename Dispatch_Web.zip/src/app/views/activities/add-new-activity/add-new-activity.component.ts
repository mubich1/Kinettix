import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, SimpleChanges, } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ModalService, TableModel } from 'carbon-components-angular';
import { ToastrService } from 'ngx-toastr';
import { catchError, debounceTime, EMPTY, Observable, Subject, takeUntil } from 'rxjs';
import { MilestoneDTO } from "src/app/models/milestoneDTO/milestoneDTO";
import { Activity } from 'src/app/models/activity/activity';
import { ActivityCategory } from 'src/app/models/activity/activity-category';
import { ActivityResource } from 'src/app/models/activity/activity-resource';
import { ActivityStatus } from 'src/app/models/activity/activity-status';
import { ActivityType, ActivityTypeEnum } from 'src/app/models/activity/activity-type';
import { Currency } from 'src/app/models/activity/currency';
import { ConfirmationDialog } from 'src/app/models/dialog/confirmation';
import { Contract } from 'src/app/models/proposals/proposal';
import { Competency, ResponseInterval } from 'src/app/models/vendor/vendor';
import { ActivityService } from 'src/app/services/activity/activity.service';
import { ClientService } from 'src/app/services/client/client.service';
import { CompetencyService } from 'src/app/services/competency/competency.service';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';
import { TinyMCEConfiguration } from 'src/app/shared/common/tinyMCEConfiguration';
import { AddActivityResourceComponent } from 'src/app/shared/components/project-activity-resources/add-activity-resource/add-activity-resource.component';
import { AngularUtility } from 'src/app/shared/common/angular-utitilty';
import { TableFilters } from 'src/app/shared/common/tableFilters';
import { Region } from 'src/app/models/region/region';
import { TechnicianLevelService } from 'src/app/services/technician-level/technician-level.service';
import { RegionService } from 'src/app/services/region/region.service';
import { ResponseIntervalService } from 'src/app/services/response-interval/response-interval.service';
import { LoaderService } from '../../../services/loader/loader.service';
import { MilestoneService } from 'src/app/services/milestone/milestone.service';

@Component({
  selector: 'app-add-new-activity',
  templateUrl: './add-new-activity.component.html',
  styleUrls: ['./add-new-activity.component.css'],
  providers: [ActivityService, ClientService],
})
export class AddNewActivityComponent implements OnInit, OnDestroy {
  @Output() emitFormValue = new EventEmitter<any>();
  @Output() emitFormValidation = new EventEmitter<any>();
  @Input() isactivitycheck = false;
  @Input() isOpenAddNewActivityModel: boolean;
  @Input() addNewActivity: string;
  @Input() proposalActivity: string;
  selectedActivityStatus: ActivityStatus;
  @Input() set activityId(activityId: number) {
    if (activityId || activityId === 0) {
      this.selectedActivityId = activityId;

      Promise.all([this.getCurrencies(),
      this.getActivityStatuses(),
      this.getCompetencies(),
      this.getMilestones(),
      this.getActivityTypes(),
      this.getActivityCategories(),
      this.getTechnicianLevelList(),
      this.getRegions(),
      this.getResponseIntervals()]).then(() => {

        if (activityId > 0) {
          this.loaderService.hide();
          this.getActivityById();
        }
      });
    }
  };

  addResourceModalObs: Observable<ConfirmationDialog> = new Subject<ConfirmationDialog>();
  activityForm: FormGroup;
  activity: Activity;

  componentDestroyed$ = new Subject<void>();

  @Output() SaveActivity = new EventEmitter<Activity>();
  @Output() GetActivityResoruceId = new EventEmitter<number>();
  activityCategories: ActivityCategory[] = [];
  activityTypes: ActivityType[] = [];
  activityStatuses: ActivityStatus[] = [];
  resources: ActivityResource[] = [];
  competencies: Competency[] = [];
  milestone: MilestoneDTO[] = [];
  isOpenResourceModal = false;
  selectedActivityId: number;
  tableRecords = '';
  resourceModel = new TableModel();
  proposalData: Contract[] = [];
  carbonUtility = new CarbonUtility();
  dealId: number;
  proposalId: number;
  activityIdRoute: number;
  isEditMode: boolean = false;
  isEditted: boolean = false;
  currencies: Currency[];
  savedActivityId: number = 0;
  angularUtility = new AngularUtility();
  tableFilter: TableFilters = new TableFilters();
  regions: Region[];
  technicianLevelform: FormGroup;
  technicianList: any[] = [];
  tinyMCECApiKey: string = TinyMCEConfiguration.apiKey;
  tinyMCESettings: any = TinyMCEConfiguration.settings;
  responseList: ResponseInterval[] = [];
  @Input() getEditActivityobject: Activity;
  isResourceAdded: boolean = false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private toastr: ToastrService,
    private activityService: ActivityService,
    private activatedRoute: ActivatedRoute,
    private modalService: ModalService,
    private milestoneService: MilestoneService,
    private competencyService: CompetencyService,
    private technicianLevelService: TechnicianLevelService,
    private regionService: RegionService,
    private responseIntervalService: ResponseIntervalService,
    private loaderService: LoaderService
  ) {
  }

  ngOnInit(): void {
    // this.activity = this.getEditActivityobject;
    this.loadData();
    this.onChanges();

  }
  onChanges(): void {
    this.activityForm.statusChanges.pipe(
      debounceTime(500)).subscribe(values => {
        this.emitFormValidation.emit(values);
        });
    this.activityForm.valueChanges.pipe(
        debounceTime(500)).subscribe(values => {
          this.addNewActivity || this.proposalActivity ? values.status= this.selectedActivityStatus.id : values.status;
        this.emitFormValue.emit(values);
        });
  }

  loadData() {
    this.activatedRoute.parent?.paramMap.subscribe(params => {
      this.dealId = +params.get('id')!;
    });

    this.activatedRoute.paramMap.subscribe((params) => {
      this.proposalId = +params.get('proposalId')!;
    });
    this.createForm();
  }

  get f() {
    return this.activityForm.controls;
  }

  getResponseIntervals() {
    return new Promise((resolve: any, reject: any) => {
      this.responseIntervalService
        .getAllResponseIntervals().subscribe(
          (res) => {
            if (res.statusCode == 200) {
              this.responseList = res.results;
              resolve();
            } else {
              this.toastr.error('Something went wrong while loading response intervals');
              reject();
            }
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

  getCurrencies() {
    return new Promise((resolve: any, reject: any) => {
      this.activityService.getCurrencies().subscribe(
        (res) => {
          this.currencies = res.results;
          resolve();
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  getActivityStatuses() {
    return new Promise((resolve: any, reject: any) => {
      this.activityService.getActivityStatuses().subscribe(
        (res) => {
          if (res.statusCode == 200) {
            this.activityStatuses = res.results;
            this.activityStatuses.forEach(res => res.name == 'Approved' ? this.selectedActivityStatus = res : null)
            resolve();
          } else {
            this.toastr.error('Something went wrong while loading statuses');
            reject();
          }
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  getActivityTypes() {
    return new Promise((resolve: any, reject: any) => {
      this.activityService.getActivityTypes().subscribe(
        (res) => {
          if (res.statusCode == 200) {
            this.activityTypes = res.results;
            resolve();
          } else {
            this.toastr.error('Something went wrong while loading activity types');
            reject();
          }
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  getCompetencies() {
    return new Promise((resolve: any, reject: any) => {
      this.tableFilter.page = 0;
      this.competencyService.getPagedCompetencies(this.tableFilter).subscribe(
        (res) => {
          if (res.statusCode == 200) {
            this.competencies = res.results.data;
            resolve();
          } else {
            this.toastr.error('Something went wrong while loading competencies');
            reject();
          }
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  getRegions() {
    return new Promise((resolve: any, reject: any) => {
      this.tableFilter.page = 0;
      this.regionService.getPagedRegions(this.tableFilter).subscribe(
        (res) => {
          if (res.statusCode == 200) {
            this.regions = res.results;
            resolve();
          } else {
            this.toastr.error('Something went wrong while loading regions');
            reject();
          }
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  getMilestones() {
    return new Promise((resolve: any, reject: any) => {
      this.milestoneService.GetMilestoneList().subscribe(
        (res) => {
          if (res.statusCode == 200) {
            this.milestone = res.results.result;
            resolve();
          } else {
            this.toastr.error('Something went wrong while loading milestones');
            reject();
          }
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  getActivityCategories() {
    return new Promise((resolve: any, reject: any) => {
      this.activityService.getActivityCategories().pipe(
        takeUntil(this.componentDestroyed$),
        catchError(() => {
          this.toastr.error('Failed to load Activity Categories');
          return EMPTY;
        })
      ).subscribe(
        (res) => {
          this.activityCategories = res.results;
          resolve();
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  getTechnicianLevelList() {
    return new Promise((resolve: any, reject: any) => {
      this.technicianLevelService.getAll().subscribe(
        (res) => {
          this.technicianList = res.results;
          resolve();
        },
        (err) => {
          reject(err);
        }
      );
    });
  }

  getActivityById() {
    this.isEditMode = true;
    if (this.isactivitycheck) {
      let activity: Activity = {
        id: this.getEditActivityobject.id,
        assumptions: this.getEditActivityobject.assumptions,
        typeId: this.getEditActivityobject.typeId,
        currencyId: this.getEditActivityobject.currencyId,
        categoryId: this.getEditActivityobject.categoryId,
        totalVariableCost: 0,
        totalFixedCost: 0,
        budgetMargin: 0,
        cogs: 0,
        grossProfit: 0,
        variableMarginPercent: 0,
        totalBudgetExpenses: 0,
        budgetIncome: 0,
        budgetNetMarginPercent: 0,
        authorizedCost: 0,
        targetCost: 0,
        roundingAmount: 0,
        platformFeePercent: 0,
        riskPercent: 0,
        financeFeePercent: 0,
        displayName: this.getEditActivityobject.displayName,
        name: this.getEditActivityobject.name,
        scope: this.getEditActivityobject.scope,
        statusId: this.getEditActivityobject.statusId,
        currentDollarValue: this.getEditActivityobject.currentDollarValue,
        contractId: 0,
        parentActivityId: null,
        quantity: this.getEditActivityobject.quantity,
        resources: this.getEditActivityobject.resources,
        status: null,
        versionId: 0,
        activityCompetencies: this.getEditActivityobject.activityCompetencies,
        activityMilestones: this.getEditActivityobject.activityMilestones,
        totalLaborCost: 0,
        totalMaterialBudget: 0,
        totalTavelCost: 0,
        isUsed: false,
        budget: 0,
        riskFee: 0,
        price: 0,
        isBillAble: 0,
        isNonBillAble: 0,
        numberofTimeUsed: 0,
        regionId: this.getEditActivityobject.regionId,
        responseIntervalId: this.getEditActivityobject.responseIntervalId,
        technicianLevelId: this.getEditActivityobject.technicianLevelId,
        totalRevenue: 0,
      };

      this.activity = activity;
      this.patchActivityValues();
    } else {
      this.activityService.getActivityById(this.selectedActivityId).subscribe((res) => {
        if (res.statusCode == 200) {
          this.activity = res.results;
          if (this.activity != null && this.activity.id != null) {
            this.savedActivityId = this.activity.id;
          }
          this.patchActivityValues();
        } else {
          this.toastr.error('Something went wrong while loading activity');
        }
      });
    }
    this.isEditMode = true;
  }

  patchActivityValues() {
    this.activityForm.patchValue({
      id: this.activity.id,
      title: this.activity.name,
      displayName: this.activity.displayName,
      category: this.activity.categoryId,
      type: this.activity.typeId,
      status: this.activity.statusId,
      currencyId: this.activity.currencyId,
      quantity: this.activity.quantity,
      assumptions: this.activity.assumptions,
      scope: this.activity.scope,
      milestones: this.activity.activityMilestones,
      competencies: this.activity.activityCompetencies,
      regionId: this.activity.regionId,
      responseIntervalId: this.activity.responseIntervalId,
      technicianLevelId: this.activity.technicianLevelId,
    });
  }

  createForm() {
    this.activityForm = this.formBuilder.group({
      id: [null],
      title: new FormControl('', [Validators.required,]),
      displayName: new FormControl(''),
      type: new FormControl('', [Validators.required]), //[Validators.required],
      status: new FormControl('', this.addNewActivity || this.proposalActivity ? null : [Validators.required]),
      currencyId: new FormControl('', [Validators.required]),
      category: new FormControl('', [Validators.required]),
      quantity: new FormControl('', this.isactivitycheck ? [] : [Validators.required]),
      assumptions: new FormControl(''), //,Validators.maxLength(100)
      scope: new FormControl(''),
      competencies: new FormControl(''),
      milestones: new FormControl(''),
      regionId: new FormControl('', [Validators.required]),
      responseIntervalId: new FormControl('', []),
      technicianLevelId: new FormControl('', []),
    });
  }

  getValues() {
    let activity: Activity = {
      id: this.isEditMode || this.isactivitycheck ? this.activity?.id! : this.savedActivityId,
      name: this.activityForm.value.title,
      displayName: this.activityForm.value.displayName,
      typeId: this.activityForm.value.type,
      statusId: this.addNewActivity || this.proposalActivity? this.selectedActivityStatus.id: this.activityForm.value.status,
      currencyId: this.activityForm.value.currencyId,
      totalVariableCost: 0,
      totalFixedCost: 0,
      categoryId: this.activityForm.value.category,
      budgetMargin: 0,
      cogs: 0,
      grossProfit: 0,
      roundingAmount: 0,
      variableMarginPercent: 0,
      totalBudgetExpenses: 0,
      budgetIncome: 0,
      budgetNetMarginPercent: 0,
      authorizedCost: 0,
      targetCost: 0,
      currentDollarValue: null,
      platformFeePercent: 0,
      riskPercent: 0,
      financeFeePercent: 0,
      quantity: this.activityForm.value.quantity,
      assumptions: this.activityForm.value.assumptions,
      scope: this.activityForm.value.scope,
      versionId: this.proposalId,
      contractId: this.proposalId,
      parentActivityId: null,
      status: null,
      resources: this.resources,
      activityCompetencies: this.activityForm?.value?.competencies ?this.activityForm?.value?.competencies : null,
      activityMilestones: this.activityForm?.value?.milestones ?this.activityForm?.value?.milestones: null,
      totalLaborCost: 0,
      totalMaterialBudget: 0,
      totalTavelCost: 0,
      isUsed: false,
      budget: 0,
      riskFee: 0,
      price: 0,
      isBillAble: 0,
      isNonBillAble: 0,
      numberofTimeUsed: 0,
      regionId: this.activityForm.value.regionId,
      responseIntervalId: this.activityForm.value.responseIntervalId,
      technicianLevelId: this.activityForm.value.technicianLevelId,
      totalRevenue: 0,
    };
    return activity;
  }

  ngAfterContentInit(): void {
    this.addResourceModalObs.subscribe((value) => {
      this.router.navigate([
        `/sales/deal/deal-detail/${this.dealId}/proposal/${this.proposalId}`,
      ]);
    });
  }

  public saveRequest(date: any): void {
    this.SaveActivity.emit(date);
  }

  GetActivityId(data: any) {
    this.GetActivityResoruceId.emit(data);
  }

  isBillable() {
    if (this.activityForm.value.type == 1) {
      return true;
    } else return false;
  }

  onClickAddResource() {
    this.isOpenResourceModal = true;
  }

  onProjectActivitySave() {
    if (!this.isResourceAdded) {
      this.toastr.warning('Kindly Add Resources');
      return;
    }
    if (this.savedActivityId == 0) {
      this.activityService.saveActivity(this.getValues())
        .subscribe({
          next: (res) => {
            if (res.statusCode == 200) {
              this.savedActivityId = res.results;
              this.toastr.success('Saved successfully');
              this.routeToParent();
            }
          },
          error: (err) => {
            if (err.status == 409) {
              this.toastr.error('Activity already exists');
              return;
            }
            else {
              this.toastr.error('Something went wrong');
            }
          }
        });
    }
    else {
      this.activityService.updateActivity(this.getValues())
        .subscribe({
          next: (res) => {
            if (res.statusCode == 200) {
              this.routeToParent();
              this.toastr.success('Saved successfully');
            }
          },
          error: (err) => {
            if (err.status == 409) {
              this.toastr.error('Activity already exists');
              return;
            }
            else {
              this.toastr.error('Something went wrong');
            }
          }
        });
    }
  }

  onUpdateProjectActivity() {
    this.activityService.updateActivity(this.getValues()).subscribe({
      next: (res) => {
        if (res.statusCode == 200) {
          this.routeToParent();
          this.toastr.success('Saved Successfully');

        }
      },
      error: (err) => {
        if (err.status == 409) {
          this.toastr.error('Activity already exists');
          return;
        }
        else {
          this.toastr.error('Something went wrong');
        }
      }
    });
  }


  onSubmit() {
    if (this.isactivitycheck) {
      this.saveRequest(this.getValues());
    } else {
      this.activityService.saveActivity(this.getValues())
        .subscribe({
          next: (res) => {
            if (res.statusCode == 200) {
              this.toastr.success('Saved Successfully');
              this.routeToParent();
            }
          },
          error: (err) => {
            if (err.status == 409) {
              this.toastr.error('Activity already exists');
              return;
            }
            else {
              this.toastr.error('Something went wrong');
            }
          }
        });
    }
  }
  onCancel() {
    this.routeToParent();
  }

  routeToParent() {
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigate(['/sales/deal/deal-detail/' + this.dealId + '/proposal/' + this.proposalId]);
    });
    window.location.reload(); // Refresh to reflect changes (Add/Update) in Agreement.
  }
  onCancelActivity() {
    let currentUrl = this.router.url;
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigate([currentUrl]);
    });
  }
  onAnyUpdate() {
    this.isEditted = true;
  }

  addResourceModal() {
    console.log('this.getValues(): ', this.getValues());
    if (this.savedActivityId == 0) {
      this.activityService.saveActivity(this.getValues()).subscribe(res => {
        if (res.statusCode == 200) {
          this.savedActivityId = res.results;
          this.openResourceModel();
        }
        else {
          this.toastr.error('Something went wrong');
        }
      });
    }
    else {
      // if (this.activity != null && this.activity.id != null) {
      //   this.savedActivityId = this.activity.id;
        this.openResourceModel();
        this.isEditted = true;
      }
    // }
  }

  openResourceModel() {
    this.modalService.create({
      component: AddActivityResourceComponent,

      inputs: { data: { obs: this.addResourceModalObs, activityID: this.savedActivityId } },
    }).instance.modalClose.subscribe(result => {
      this.isResourceAdded = result != null;
    });
  }

  onUpdate() {
    this.activityService.updateActivity(this.getValues())
      .subscribe({
        next: (res) => {
          if (res.statusCode == 200) {
            this.routeToParent();
            this.toastr.success('Saved Successfully');

          }
        },
        error: (err) => {
          if (err.status == 409) {
            this.toastr.error('Activity already exists');
            return;
          }
          else {
            this.toastr.error('Something went wrong');
          }
        }
      });
  }

  ngOnDestroy(): void {
    this.componentDestroyed$.next();
    this.componentDestroyed$.complete();
  }

  isHourlyType(type) {
    var acivityType = this.activityTypes.find(x => x.id == type);
    if (acivityType?.type == ActivityTypeEnum.Hourly) return true;
    else return false;
  }

  activityTypeChnage() {
    if (this.isHourlyType(this.activityForm.get("type")?.value)) {
      this.activityForm.get('technicianLevelId')?.setValidators([Validators.required]);
      this.activityForm.get('responseIntervalId')?.setValidators([Validators.required]);
    } else {
      this.activityForm.get('technicianLevelId')?.setValidators([]);
      this.activityForm.get('responseIntervalId')?.setValidators([]);
      this.activityForm.get('technicianLevelId')?.setValue(null);
      this.activityForm.get('responseIntervalId')?.setValue(null);
    }
    this.activityForm.get('responseIntervalId')?.updateValueAndValidity();
    this.activityForm.get('technicianLevelId')?.updateValueAndValidity();
  }
}
