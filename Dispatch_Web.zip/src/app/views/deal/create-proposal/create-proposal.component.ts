import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Observable, Subject, takeUntil } from 'rxjs';
import { ContractCategory, ContractStatus, ContractType } from 'src/app/models/project/project';
import { Contract, ContractRequest } from 'src/app/models/proposals/proposal';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { ProposalService } from 'src/app/services/proposal/proposal.service';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';
import { TinyMCEConfiguration } from 'src/app/shared/common/tinyMCEConfiguration';

@Component({
  selector: 'app-create-proposal',
  templateUrl: './create-proposal.component.html',
  styleUrls: ['./create-proposal.component.css']
})
export class CreateProposalComponent implements OnInit {

  ngUnsubscribe = new Subject<void>();
  isEdit: boolean = false;

  // Skeletons
  showProposalSkeleton: boolean = true;
  showTypeSkeleton: boolean = true;
  showCategorySkeleton: boolean = true;
  // End Skeletons
  proposalId: number = 0;
  dealId: number = 0;
  proposal: Contract;
  formGroup: FormGroup;
  carbonUtility = new CarbonUtility();

  // Editor Options
  tinyMCECApiKey: string = TinyMCEConfiguration.apiKey;
  tinyMCESettings: any = TinyMCEConfiguration.settings;

  projectTypes: ContractType[] = [];
  projectCategories: ContractCategory[] = [];

  constructor(
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private router: Router,
    private toastr: ToastrService,
    private proposalService: ProposalService
  ) {

  }

  ngOnInit(): void {


    this.activatedRoute.parent?.paramMap.subscribe(params => {

      this.dealId = +params.get('id')!;

    });

    this.activatedRoute.paramMap.subscribe(params => {

      this.proposalId = +params.get('proposalId')!;

      if(this.proposalId > 0){
        this.isEdit = true;
        this.getProposalDetail();
      }
      else{
        this.showProposalSkeleton = false;
      }
    });



    this.intializeForm();

    this.getProjectCategories();
    this.getProjectTypes();
    this.getProjectStatus();
  }

  get f() {
    return this.formGroup.controls;
  }


  getProposalDetail(){
    this.proposalService.getProposalById(this.proposalId)
    .pipe(takeUntil(this.ngUnsubscribe))
    .subscribe({
      next: res => {

        if(res.statusCode == 200){
          this.proposal = res.results;
          this.patchFormValues();
        }
        else{
          this.toastr.error('Something went wrong');
        }
      },
      error: e => {
        console.log(e);
        this.toastr.error('Something went wrong');
        this.showProposalSkeleton = false;

      },
      complete: () => {
        this.showProposalSkeleton = false;
      }
    });


  }

  getProjectTypes(){

    this.proposalService.getProjectTypes()
    .pipe(takeUntil(this.ngUnsubscribe))
    .subscribe({
      next: res => {

        if(res.statusCode == 200){
          this.projectTypes = res.results;
          if(this.projectTypes && this.projectTypes.length > 0 && this.proposalId < 1){
            this.formGroup.patchValue({
              type: this.projectTypes[0].id
            });
          }
        }
        else{
          this.toastr.error('Something went wrong while loading project types');
        }
      },
      error: e => {
        console.log(e);
        this.toastr.error('Something went wrong while loading project types');
        this.showTypeSkeleton = false;

      },
      complete: () => {
        this.showTypeSkeleton = false;
      }
    });

  }

  getProjectCategories(){
    this.proposalService.getProjectCategories()
    .pipe(takeUntil(this.ngUnsubscribe))
    .subscribe({
      next: res => {

        if(res.statusCode == 200){
          this.projectCategories = res.results;
          if(this.projectCategories && this.projectCategories.length > 0 && this.proposalId < 1){
            this.formGroup.patchValue({
              category: this.projectCategories[0].id
            });
          }
        }
        else{
          this.toastr.error('Something went wrong while loading project categories');
        }
      },
      error: e => {
        console.log(e);
        this.toastr.error('Something went wrong while loading project categories');
        this.showCategorySkeleton = false;

      },
      complete: () => {
        this.showCategorySkeleton = false;
      }
    });

  }

  getProjectStatus(){
    this.proposalService.getProjectStatus()
    .pipe(takeUntil(this.ngUnsubscribe))
    .subscribe(
      {
        next: res => {

          if(res.statusCode == 200){
            let statuses = res.results;
            if(statuses && statuses.length > 0 && this.proposalId < 1){
              this.formGroup.patchValue({
                status: statuses.find(x => x.status == 'Proposal')
              });
            }
          }
        },
      }
    );
  }

  intializeForm() {
    this.formGroup = this.formBuilder.group({
      id: [null],
      clientId: [0],
      endClientId: [null],
      sow: [null, Validators.required],
      terms: [null, Validators.required],
      name: [null, Validators.required],
      status: [null],
      dealId: [this.dealId, Validators.required],
      category: [null, Validators.required],
      // type: [null, Validators.required],
      versionId: [0],
      stage: [null],
      version: [1],
      current: [true]
    });
  }

  patchFormValues(){

    let status: ContractStatus = {
      id: this.proposal.status.id,
      status: ''
    };

    this.formGroup.patchValue({
      id: this.proposal.id,
      clientId: this.proposal.clientId,
      endClientId: this.proposal.endClientId,
      sow: this.proposal.sow,
      terms: this.proposal.terms,
      name: this.proposal.title,
      status: status,
      dealId: this.proposal.dealId,
      category: this.proposal.category.id,
      // type: this.proposal.type.id,
      versionId: this.proposal.versionId,
      version: this.proposal.version,
      current: this.proposal.current
    });
  }

  onSubmit(){

    if (!this.formGroup.valid) {
      this.toastr.error("Please fill all required fields.");
    }
    else {

      // const proposalType: ContractType = {
      //   id: this.formGroup.value.category,
      //   type: ''
      // };

      const proposalCategory: ContractCategory = {
        id: this.formGroup.value.category,
        category: ''
      };

      const body: ContractRequest = {
        id: this.formGroup.value.id,
        clientId: 0,
        endClientId: 0,
        terms: this.formGroup.value.terms,
        sow: this.formGroup.value.sow,
        title: this.formGroup.value.name,
        status: this.formGroup.value.status,
        dealId: this.dealId,
        category: proposalCategory,
        // type: proposalType,
        versionId: this.formGroup.value.versionId,
        version: this.formGroup.value.version,
        current: this.formGroup.value.current
      };

      if(this.proposalId > 0){
        this.updateProposal(body);
      }
      else{
        this.createProposal(body);
      }

    }

  }

  updateProposal(proposal: ContractRequest) {

    this.proposalService.updateproposal(proposal).subscribe({
      next: res => {

        if (res.statusCode == 200 && res.results) {
          this.toastr.success("Proposal Updated Successfully.");
          this.router.navigate([`sales/deal/deal-detail/${this.dealId}`]);

        }
        else {
          this.toastr.error("Something went wrong.");
        }
      },
      error: (e: HttpErrorResponse) => {

        console.log(e);
        if(e.error.statusCode == 400 && e.error.message == "Duplicate"){
          this.toastr.error("Duplicate Name. Please choose a different name.");
        }
        else{
          this.toastr.error("Something went wrong.");
        }
      }
    });
  }

  createProposal(proposal: ContractRequest) {
    this.proposalService.saveProposal(proposal).subscribe({
      next: res => {


        if (res.statusCode == 200 && res.results > 0) {
          this.toastr.success("Proposal Created Successfully.");
          this.router.navigate([`sales/deal/deal-detail/${this.dealId}`]);

        }
        else {
          this.toastr.error("Something went wrong.");
        }
      },
      error: (e: HttpErrorResponse) => {

        console.log(e);
        if(e.error.statusCode == 400 && e.error.message == "Duplicate"){
          this.toastr.error("Duplicate Name. Please choose a different name.");
        }
        else{
          this.toastr.error("Something went wrong.");
        }
      }
    });
  }

  onClickCancel(){
    this.router.navigate([`sales/deal/deal-detail/${this.dealId}`]);
  }

  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }
}
