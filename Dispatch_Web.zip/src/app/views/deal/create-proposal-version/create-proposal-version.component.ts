import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { catchError, EMPTY, Observable, Subject, takeUntil, tap } from 'rxjs';
import { DealType } from 'src/app/models/deals/deal';
import {
  ContractCategory,
  ContractStatus,
  ContractType,
} from 'src/app/models/project/project';
import { INewProposalVersion } from 'src/app/models/proposals/new-proposal-version.dto';
import {
  Contract,
  ContractRequest,
  ProposalStageEnum,
} from 'src/app/models/proposals/proposal';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { DealService } from 'src/app/services/deals/deal.service';
import { ProposalService } from 'src/app/services/proposal/proposal.service';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';
import { TinyMCEConfiguration } from 'src/app/shared/common/tinyMCEConfiguration';

@Component({
  selector: 'app-create-proposal-version',
  templateUrl: './create-proposal-version.component.html',
  styleUrls: ['./create-proposal-version.component.css'],
})
export class CreateProposalVersionComponent implements OnInit, OnDestroy {

  versionForm: FormGroup;

  componentDestroyed$ = new Subject<void>();

  dealTypes: DealType[] | null;

  dealId: number;

  submitting: boolean = false;

  contractId: number;

  constructor(private proposalService: ProposalService, private router: Router, private activatedRoute: ActivatedRoute, private dealService: DealService, private toastr: ToastrService) {}

  ngOnInit(): void {
    this.versionForm = new FormGroup({
      name: new FormControl(null, [Validators.required]),
      productType: new FormControl(null, [Validators.required]),
    });

    this.activatedRoute.paramMap.pipe(
      takeUntil(this.componentDestroyed$),
    ).subscribe((params) => {
      this.contractId = +params.get('proposalId')!;
    });

    this.activatedRoute.parent?.paramMap.pipe(
      takeUntil(this.componentDestroyed$),
    ).subscribe((params) => {
      this.dealId = +params.get('id')!;
    });

    this.getDealTypes();
  }

  get name() { return this.versionForm.get('name')! };
  get productType() { return this.versionForm.get('productType')! };

  submitForm(): void {
    const payload: INewProposalVersion = {
      name: this.name.value,
      productTypeId: this.productType.value,
      version: {
        contractId: this.contractId,
      },
    };

    this.submitting = true;

    this.proposalService.saveProposalVersion(payload).pipe(
      takeUntil(this.componentDestroyed$),
      tap((result) => {
        this.handleSuccessfulSaveEvent(result.results);
      }),
      catchError((error) => {
        this.submitting = false;

        if(error.status === 409) {
          this.toastr.info('That name is already in use. Please enter a different name.');

          return EMPTY;
        }

        this.toastr.error('Something went wrong...');

        return EMPTY;
      }),
    ).subscribe();
  }

  getDealTypes(): void {
    this.dealService.getTypes().pipe(
      takeUntil(this.componentDestroyed$),
      tap((result) => {
        this.dealTypes = result.results;
      }),
      catchError(() => {
        this.toastr.error('Something went wrong...');

        return EMPTY;
      }),
    ).subscribe();
  }

  handleSuccessfulSaveEvent(newProposalId: number): void {
    this.proposalService.updateCurrentState(newProposalId).pipe(
      takeUntil(this.componentDestroyed$),
      tap(() => {
        this.submitting = false;

        this.toastr.success('Version successfully created!');

        this.router.navigate([`sales/deal/deal-detail/${this.dealId}/proposal/${newProposalId}`]);
      }),
      catchError(() => {
        this.submitting = false;

        this.toastr.error('Something went wrong...');

        return EMPTY;
      }),
    ).subscribe();
  }

  cancelButtonClicked(): void {
    this.router.navigate([`sales/deal/deal-detail/${this.dealId}/proposal/${this.contractId}`]);
  }

  ngOnDestroy(): void {
    this.componentDestroyed$.next();
    this.componentDestroyed$.complete();
  }

}
