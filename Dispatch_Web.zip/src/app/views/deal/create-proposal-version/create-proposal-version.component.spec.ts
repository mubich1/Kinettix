import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateProposalVersionComponent } from './create-proposal-version.component';

describe('CreateProposalVersionComponent', () => {
  let component: CreateProposalVersionComponent;
  let fixture: ComponentFixture<CreateProposalVersionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateProposalVersionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateProposalVersionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
