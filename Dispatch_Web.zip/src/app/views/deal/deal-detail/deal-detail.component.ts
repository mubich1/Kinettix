import { DatePipe } from '@angular/common';
import { AfterContentInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import {
  AlertModalType,
  CheckboxChange,
  ModalButtonType,
  ModalService,
  TableHeaderItem,
  TableItem,
  TableModel,
} from 'carbon-components-angular';
import { ToastrService } from 'ngx-toastr';
import { Observable, Subject, takeUntil } from 'rxjs';
import { Client } from 'src/app/models/client/client';
import { Deal, DealDocument, DealDocumentsType, DealPriority, DealStatus } from 'src/app/models/deals/deal';
import { ConfirmationDialog } from 'src/app/models/dialog/confirmation';
import { InputDialog } from 'src/app/models/dialog/input-dialog';
import { ClientService } from 'src/app/services/client/client.service';
import { environment } from "src/environments/environment";
import { InputDialogComponent } from 'src/app/shared/components/input-dialog/input-dialog.component';
import { ConfirmationDialogComponent } from '../../../shared/components/confirmation-dialog/confirmation-dialog.component';
import { DealService } from 'src/app/services/deals/deal.service';
import { DealDocumentService } from 'src/app/services/document/deal-document.service';
import { UtilityService } from 'src/app/services/utility/utility.service';
import { Permission } from 'src/app/services/utility/permission-constant';

@Component({
  selector: 'app-deal-detail',
  templateUrl: './deal-detail.component.html',
  styleUrls: ['./deal-detail.component.css'],
})
export class DealDetailComponent implements OnInit, AfterContentInit {
  
  riskModalObs: Observable<ConfirmationDialog> = new Subject<ConfirmationDialog>();
  statusModalObs: Observable<InputDialog> = new Subject<InputDialog>();
  
  hubSpotDealBaseUrl = environment.hubspotDealBaseUrl;


  isOpenDeleteModal = false;
  ngUnsubscribe = new Subject<void>();

  dealId: number = 0;
  dealDetail: Deal;



  dealStatuses: DealStatus[] = [];
  dealStatusesSkeleton: boolean = true;


  dealPriorities: DealPriority[] = [];
  dealPrioritiesSkeleton: boolean = true;

  dealAtRiskValue: boolean;
  dealStatusValue: number = 0;
  dealPriorityValue: number = 0;

  paramDealId: number = 0;
  allowEditDeal:boolean = true;
  isEditDeal: boolean = false;
  
  constructor(
    private activeRoute: ActivatedRoute,
    private dealService: DealService,
    private clientService: ClientService,
    private toastr: ToastrService,
    public datepipe: DatePipe,
    private modalService: ModalService,
    private router: Router,
    private documentService: DealDocumentService,
    private utilityService:UtilityService
  ) { }

  ngOnInit() {
    this.allowEditDeal =this.utilityService.hasPermission(Permission.EditDeal)
    this.getQueryParams();

    
  }

  onSubmit(){
  }

  getQueryParams() {
    this.activeRoute.params.subscribe((params) => {
      
      this.dealService.dealInfo.id = +params['id'];
      this.dealId = this.dealService.dealInfo.id;
      this.getDealById();
    });
  }


  getDealById() {
    this.dealService
      .getDealById(this.dealId)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {

          if (res.statusCode == 200) {
            this.dealDetail = res.results;
            this.dealAtRiskValue = this.dealDetail?.atRisk;

            this.getDealStatuses();
            this.getDealPriorites();

          
    
            if (
              this.dealDetail.clientId != null &&
              this.dealDetail.clientId > 0
            ) {
              this.getClientById(this.dealDetail.clientId);
            }
          } else {
            this.toastr.error('Something went wrong');
          }
        },
        error: (e) => {
          console.log(e);
          this.toastr.error('Something went wrong');
        },
        complete: () => { },
      });
  }

  getClientById(id: number) {

    this.clientService.getClientById(id)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res: Client) => {

          this.dealDetail.client = res;
        },
        error: e => {
          console.log(e);
          this.toastr.error('Something went wrong');
        },
        complete: () => {

        }
      });
  }

  getDealStatuses() {
    this.dealService.getDealStatuses()
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: res => {
          if (res.statusCode == 200) {
            if (res.results && res.results.length > 0) {

              this.dealStatuses = res.results.filter(x => x.id != 4);
              this.dealStatusValue = this.dealDetail.status?.id!;
            }
          }
        },
        error: e => {
          console.log(e);
          this.dealStatusesSkeleton = false;

        },
        complete: () => {
          this.dealStatusesSkeleton = false;
        }
        
      });
  }

  getDealPriorites() {
    this.dealService.getDealPriorities()
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: res => {
          if (res.statusCode == 200) {
            this.dealPriorities = res.results;
            this.dealPriorityValue = this.dealDetail.priority?.id!;
          }
        },
        error: e => {
          console.log(e);
          this.dealPrioritiesSkeleton = false;
        },
        complete: () => {
          this.dealPrioritiesSkeleton = false;

        }
      });
  }


  onClickEditDeal() {
    this.isEditDeal = true;
  }

  onChangeAtRisk(event: CheckboxChange) {
    // this.dealAtRiskValue = !this.dealAtRiskValue;
    console.log(this.dealDetail.atRisk);
    this.openRiskConfirmationModal();
  }

  updateAtRisk(atRisk: boolean) {
    this.dealService.updateDealRisk(this.dealId, atRisk).subscribe({
      next: res => {
        if (res.statusCode == 200 && res.results) {
          this.toastr.success('Risk Updated Successfully');
        }
        else {
          this.toastr.error('Something went wrong');
        }
      },
      error: e => {
        this.toastr.error('Something went wrong');
        console.log(e);

      },
      complete: () => {
      }
    });
  }

  onChangeStatus(event) {

    console.log(this.dealStatusValue);
    this.openChangeStatusModal(+event.value);
  }

  changeDealStatus(status: DealStatus) {
    this.dealService.updateDealStatus(status).subscribe({
      next: res => {
        if (res.statusCode == 200 && res.results) {
          if (this.dealDetail.status) {
            this.dealDetail.status.id = this.dealStatusValue;
          }

          this.toastr.success('Status Updated Successfully');
        }
        else {
          this.toastr.error('Something went wrong');
        }
      },
      error: e => {
        this.toastr.error('Something went wrong');
        console.log(e);

      },
      complete: () => {

      }
    });

  }

  onChangePriority(event) {

    this.changeDealPriority(+event.value)
  }

  changeDealPriority(priorityId: number) {
    this.dealService.updateDealPriority(this.dealId, priorityId).subscribe({
      next: res => {
        if (res.statusCode == 200 && res.results) {
          if (this.dealDetail.priority) {
            this.dealDetail.priority.id = priorityId;
            this.dealPriorityValue = this.dealDetail.priority.id;
          }
          this.toastr.success('Priority Updated Successfully');
        }
        else {
          this.toastr.error('Something went wrong');
        }
      },
      error: e => {
        this.toastr.error('Something went wrong');
        console.log(e);

      },
      complete: () => {

      }
    });
  }


  ngAfterContentInit() {
    this.riskModalObs.subscribe(value => {

      if (value.confirm) {
        this.updateAtRisk(!this.dealDetail.atRisk);
      }
      else {
        this.dealAtRiskValue = !this.dealAtRiskValue;
      }
    });

    this.statusModalObs.subscribe(value => {

      if (value.confirm) {
        const dealStatus: DealStatus = {
          id: value.data,
          dealId: this.dealDetail.id,
          status: '',
          reason: value.value == null ? '' : value.value,
        }
        this.changeDealStatus(dealStatus);
      }
      else {
        this.dealStatusValue = this.dealDetail.status?.id!;
      }
    });

  }

  openRiskConfirmationModal() {

    const modalInputs: ConfirmationDialog = {
      header: 'Change Deal Risk',
      question: 'Are you sure you want to change deal risk?',
      confirmationButtonText: 'Yes',
      cancelButtonText: 'No',
      data: this.dealDetail.atRisk,
      obs: this.riskModalObs,
      confirm: false,
      isClosed: false
    };

    this.modalService.create(
      {
        component: ConfirmationDialogComponent,
        inputs: { data: modalInputs }
      });


  }

  openChangeStatusModal(dealStatusId: number) {

    const modalInputs: InputDialog = {
      header: 'Change Deal Status',
      label: 'Reason',
      value: this.dealDetail.reason,
      confirmationButtonText: 'Save',
      cancelButtonText: 'Cancel',
      data: dealStatusId,
      confirm: false,
      obs: this.statusModalObs
    };

    this.modalService.create(
      {
        component: InputDialogComponent,
        inputs: { data: modalInputs }
      });


  }

  onChangeProposalStatus(event) {

  }

  deleteDocmentByUrl(url: string){
    this.documentService.deleteDocument(url).subscribe({
      next: res => {
        
      },
      error: e => console.log(e),
      complete: () => {

      }
    });
  }

  dealData(event) {
    this.dealDetail.contact.firstName = event.contact.firstName;
    this.dealDetail.contact.lastName = event.contact.lastName;
    this.dealDetail.contact.email = event.contact.email;
    this.dealDetail.contact.businessPhone = event.contact.businessPhone;
  }

  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }
}
