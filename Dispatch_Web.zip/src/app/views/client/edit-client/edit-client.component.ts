import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import {
  ListItem,
  ModalService,
} from 'carbon-components-angular';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Client, EndClient } from 'src/app/models/client/client';
import { ClientService } from 'src/app/services/client/client.service';
import { EMPTY, Observable, Subject, Subscription, catchError, takeUntil, tap } from 'rxjs';
import { ConfirmationDialog } from 'src/app/models/dialog/confirmation';
import { ConfirmationDialogComponent } from 'src/app/shared/components/confirmation-dialog/confirmation-dialog.component';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';
import { countrySelectBox } from 'src/app/models/client/country-select-box';
import { AngularUtility } from 'src/app/shared/common/angular-utitilty';
import { ImagePickerConf } from 'ngp-image-picker';
import { DealDocumentService } from 'src/app/services/document/deal-document.service';
import { UserService } from 'src/app/services/user/user.service';
import { ModuleNameEnum } from 'src/app/shared/enum/module-name-enum';

@Component({
  selector: 'app-edit-client',
  templateUrl: './edit-client.component.html',
  styleUrls: ['./edit-client.component.css'],
  providers: [ClientService],
})
export class EditClientComponent implements OnInit {
  constructor(
    private clientService: ClientService,
    private formBuilder: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private location: Location,
    private modalService: ModalService,
    private toastr: ToastrService,
    private uploadService: DealDocumentService,
    private userService: UserService
  ) { }
  selectedClientId: any;
  selectedClientId1 = null;
  isOpenDeleteModal = false;
  EditData: any;
  showCountrySkeleton: boolean = true;
  angularUtility = new AngularUtility();
  editClientInfo: any;
  isUpdated: boolean = false;
  imgName: string;
  clientForm: FormGroup;
  subscription$: Subscription = new Subscription();
  confirmDialog$: Observable<ConfirmationDialog> = new Subject<ConfirmationDialog>();

  private carbonUtility = new CarbonUtility();
  public parentClientsDropdown: Array<ListItem> = [];
  public relationshipTypesDropdown: ListItem[] = [];

  clientId: number = 0;
  // countryId: any;
  countryDropDownList: Array<ListItem> = [];
  accountExeDropDownList: Array<ListItem> = [];
  projectMngDropDownList: Array<ListItem> = [];
  endClientDropDownList: Array<ListItem> = [];
  countries: countrySelectBox[] = [{ value: 0, text: '' }];
  employees: countrySelectBox[] = [{ value: 0, text: '' }];
  selectedEndClient: Array<ListItem> = [];
  endClientIds: any[] = [];
  config1: ImagePickerConf = {
    language: 'en',
    hideDeleteBtn: true,
    hideDownloadBtn: true,
    hideEditBtn: true,
    width: '200px',
    height: '200px',
  };
  filebase64string: string = '';
  profilePic: string = '';
  isEditImg: boolean = false;
  ngUnsubscribe = new Subject<void>();

  ngOnInit(): void {
    this.route.params.subscribe((params: any) => {
      if (params.hasOwnProperty('clientId')) {
        this.clientId = params['clientId'];
        if (this.clientId > 0) {
          this.getClientDetail(this.clientId);
        } else {
          this.getAllCountries();
          this.getUsers();
          this.GetRelationshipTypes();
        }
      }
    });
    this.subscription$.add(
      this.confirmDialog$.subscribe((res) => {
        if (res?.confirm) {
          this.deleteRecord();
        }
      })
    );
    this.intializeForm();
  }

  intializeForm() {
    this.clientForm = this.formBuilder.group({
      name: [null, [Validators.required, this.angularUtility.noWhitespaceValidator]],
      city: [null, [Validators.required, this.angularUtility.noWhitespaceValidator]],
      address: [null, [Validators.required, this.angularUtility.noWhitespaceValidator]],
      email: new FormControl(null, [Validators.required, Validators.email]),
      phone: [null, [Validators.required, this.angularUtility.noWhitespaceValidator]],
      postal: [null],
      state: [null, [Validators.required, this.angularUtility.noWhitespaceValidator]],
      website: new FormControl(null),
      countryId: new FormControl('', Validators.required),
      accountExecutiveId: new FormControl(null),
      projectManagerId: new FormControl(null),
      parentId: new FormControl(''),
      relationshipTypeId: new FormControl('', Validators.required),
      endClient: new FormControl([], Validators.required)
    });
  }

  getAllCountries() {
    this.clientService.getAllContries().subscribe({
      next: (res) => {
        this.countries = res.results;
        if (this.countries && this.countries.length > 0) {
          this.countryDropDownList = [];
          this.countries.forEach(element => {
            this.countryDropDownList.push({ content: element.text, value: element.value, selected: false })
          });
          if (this.clientId < 1) {
            this.clientForm.patchValue({
              countryId: this.countryDropDownList[0]
            });
            this.countryDropDownList[0].selected = true;
          }
          else {
            let selected = this.countryDropDownList.find(x => x.value == this.editClientInfo.countryId);
            this.clientForm.patchValue({
              countryId: selected
            });
            if (selected != null) {
              selected.selected = true;
            }
          }
        }
      },
      error: e => {
        console.log(e);
        this.showCountrySkeleton = false;
      },
      complete: () => {
        this.showCountrySkeleton = false;
      }
    });
  }
  getUsers() {
    this.userService.getUsers().subscribe({
      next: (res) => {
        this.employees = res.results.data;
        if (this.employees && this.employees.length > 0) {
          this.accountExeDropDownList = [];
          this.employees.forEach((element:any) => {
            this.accountExeDropDownList.push({ content: element.displayName, value: element.id, selected: false })
          });
          this.projectMngDropDownList = [];
          this.employees.forEach((element:any) => {
            this.projectMngDropDownList.push({ content: element.displayName, value: element.id, selected: false })
          });

          if (this.clientId < 1) {
            this.clientForm.patchValue({
              accountExecutiveId: this.accountExeDropDownList[0]
            });
            this.accountExeDropDownList[0].selected = true;
          }
          else {
            let selected = this.accountExeDropDownList.find(x => x.value == this.editClientInfo.accountExecutiveId);
            let selectedp = this.projectMngDropDownList.find(x => x.value == this.editClientInfo.projectManagerId);
            this.clientForm.patchValue({
              accountExecutiveId: selected,
              projectManagerId: selectedp
            });
            if (selected != null) {
              selected.selected = true;
            }
            if (selectedp != null) {
              selectedp.selected = true;
            }
          }
        }
      },
    });
  }
  private GetParentClients(): void {
    this.clientService.getAllClients().subscribe((res) => {
      let clients: Client[] = JSON.parse(
        JSON.stringify(res.results)
      ) as Client[];
      clients = JSON.parse(
        JSON.stringify(clients.filter((c) => c.id != this.clientId))
      );

      this.parentClientsDropdown = this.carbonUtility.getListItems(
        clients,
        'name',
        'id'
      );

      //Assigning clients to endclient multi select dropdown.
      this.endClientDropDownList = this.carbonUtility.getListItems(
        clients,
        'name',
        'id'
      );

      //Removing Current Client from the EndClient list.
      if (this.endClientDropDownList !== undefined) {
        var endClient = this.endClientDropDownList.find(x => x.id == this.clientId);
        if (endClient !== undefined) {
          let index = this.endClientDropDownList.indexOf(endClient);
          this.endClientDropDownList.splice(index, 0);
        }
      }

      //Patching endclients to theh multi select deopdown.
      this.selectedEndClient =  this.endClientDropDownList?.filter(x=>this.endClientIds?.includes(x.id));
      this.selectedEndClient.map(x=>x.selected = true);
      if(this.selectedEndClient){
        this.clientForm.patchValue({
          endClient: this.selectedEndClient
        })
      }

      if (this.clientId < 1) {
        this.clientForm.patchValue({
          parentId: this.parentClientsDropdown[0]
        });
        this.parentClientsDropdown[0].selected = true;
      }
      else {
        let selected = this.parentClientsDropdown.find(x => x.id == this.editClientInfo.parentID);
        this.clientForm.patchValue({
          parentId: selected
        });
        if (selected != null) {
          selected.selected = true;
        }
      }
    });
  }

  getClientDetail(id: number) {
    this.clientService.getClientById(id).subscribe({
      next:(res) => {
        this.editClientInfo = res.results;
        this.setProfilePicUrl(res?.results?.logoUrl);
          this.clientForm.patchValue({
            id: res.results.id,
            name: res.results.name,
            city: res.results.city,
            state: res.results.state,
            isSync: res.results.isSync,
            email: res.results.email,
            phone: res.results.phone,
            address: res.results.address,
            website: res.results.website,
            logoUrl: res.results.logoUrl,
            accountantId: res.results.accountantId,
            postal: res.results.postalCode,
            verticalDefinitionId: res.results.verticalDefinitionId,
            status: res.results.status,
            parentId: res.results.parentID,
          });
          this.endClientIds = res.results?.endClients?.map(
            (t) => t.endClientId
          );
          this.selectedEndClient = this.endClientDropDownList?.filter((x) =>
            this.endClientIds?.includes(x.id)
          );
          this.selectedEndClient.map((x) => (x.selected = true));
          if (this.selectedEndClient) {
            this.clientForm.patchValue({
              endClient: this.selectedEndClient,
            });
          }

          this.getAllCountries();
          this.GetRelationshipTypes();
          this.GetParentClients();
          this.getUsers();
      },
      error: (err) => {
        this.toastr.error('Something went wrong!');
      }
    });
  }



  get f() {
    return this.clientForm.controls;
  }
  onCancel() {
    this.clientForm.reset();
    this.location.back();
  }
  onDelete() {
    const modalInputs: ConfirmationDialog = {
      header: 'Delete client',
      question: 'Are you sure you want to delete this client?',
      confirmationButtonText: 'Yes',
      cancelButtonText: 'No',
      data: this.clientId,
      obs: this.confirmDialog$,
      confirm: false,
      isClosed: false,
    };

    this.modalService.create({
      component: ConfirmationDialogComponent,
      inputs: { data: modalInputs },
    });
  }
  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  deleteRecord() {
    this.clientService.deleteClientById(this.clientId).subscribe({
      next: (res) => {
        this.toastr.success('Deleted Successfully');
        this.clientForm.reset();
        this.router.navigate(["/clients/"]);
        setTimeout(() => {
          window.location.reload();
        }, 0)
      },
      error: (e) => {
        console.log(e);
        this.toastr.error('Something went wrong');
      },

      complete: () => this.closeParentModal(),
    });
  }

  closeParentModal() {
    this.isOpenDeleteModal = false;
  }

  save() {
    if (!this.clientForm.valid) {
      this.toastr.error('Please fill all required fields');
      return;
    } else {
      let endClientList: EndClient[] = [];
      this.clientForm.value.endClient.forEach(x => {
        let endClient: EndClient = {
          endClientId: x.id,
          name: x.content
        }
        endClientList.push(endClient);
      });


      const template: Client = {
        id: this.clientId,
        name: this.clientForm.value.name,
        city: this.clientForm.value.city,
        state: this.clientForm.value.state,
        countryId: this.clientForm.value.countryId.value,
        isSync: true,
        countryName: '',
        email: this.clientForm.value.email,
        phone: this.clientForm.value.phone,
        address: this.clientForm.value.address,
        website: this.clientForm.value.website,
        logoUrl: '',
        accountExecutiveId: this.clientForm.value.accountExecutiveId?.value,
        accountantId: '1',
        projectManagerId: this.clientForm.value.projectManagerId?.value,
        postalCode: this.clientForm.value.postal,
        status: 2,
        hasEndClient: this.clientForm.value.hasEndClient ?? false,
        relationshipTypeID: this.clientForm.value.relationshipTypeId.id,
        parentID: this.clientForm.value.parentId.id,
        endClients: endClientList
      };
      if (this.filebase64string !== '') {
        const uploadData = {
          filebase64string: this.filebase64string,
          moduleName: ModuleNameEnum.Client,
          name: this.imgName,
        }
        this.uploadService.uploadDocument(uploadData)
          .pipe(
            takeUntil(this.ngUnsubscribe),
            tap((result) => {
              // Uploaded successfully, set upload URI to client image URI
              template.logoUrl = result.document.path;

              // Finalize the upload
              this.updateClient(template);
            }),
            // If there is an http error while uploading, handle accordingly
            catchError((_) => {
              this.toastr.error('Something went wrong');

              return EMPTY;
            })
          ).subscribe();
      } else {
        // Since no image has been selected, upload the client without uploading image first
        this.updateClient(template);
      }

    }
  }
  updateClient(data: any) {
    this.clientService.updateClient(data).subscribe({
      next: (res) => {
        this.toastr.success('Update Successfully!');
        this.clientForm.reset();
        this.location.back();
      },
    });
  }
  private GetRelationshipTypes(): void {
    this.clientService.getRelationshipTypes().subscribe(res => {
      const relationshipTypes = res.results;
      this.relationshipTypesDropdown = this.carbonUtility.getListItems(
        relationshipTypes,
        'name',
        'id'
      );
      if (this.clientId < 1) {
        this.clientForm.patchValue({
          relationshipTypeID: this.relationshipTypesDropdown[0]
        });
        this.relationshipTypesDropdown[0].selected = true;
      }
      else {
        let selected = this.relationshipTypesDropdown.find(x => x.id == this.editClientInfo.relationshipTypeID);
        this.clientForm.patchValue({
          relationshipTypeId: selected
        });
        if (selected != null) {
          selected.selected = true;
        }
      }
    });
  }
  onImageChange(event) {
    this.filebase64string = event;
  }

  imageFileName(event){
    this.imgName = event?.srcElement?.files[0]?.name;
  }

  editImg() {
    this.isEditImg = !this.isEditImg;
  }

  setProfilePicUrl(imageUrl: string) {
    this.profilePic = imageUrl;
  }
}
