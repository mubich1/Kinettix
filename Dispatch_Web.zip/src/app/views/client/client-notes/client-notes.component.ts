import { Component, OnInit, ViewChild } from "@angular/core";
import { ThisSideUpComponent } from "@carbon/icons-angular";
import { ToastrService } from "ngx-toastr";
import { Subject, takeUntil } from "rxjs";
import { Notes, NotesRequest } from "src/app/models/common/notes";
import { ClientService } from "src/app/services/client/client.service";
import { TableFilters } from "src/app/shared/common/tableFilters";
import { NotesComponent } from "../../shared/notes/notes.component";

@Component({
  selector: "app-client-notes",
  templateUrl: "./client-notes.component.html",
  styleUrls: ["./client-notes.component.css"],
})
export class ClientNotesComponent implements OnInit {
  @ViewChild("cref") cref: NotesComponent;
  parent = "client";
  selectedDeleteNoteId: number = 0;
  clientId: number = 0;
  noteId: number = 0;
  ngUnsubscribe = new Subject<void>();
  notesList: Notes[] = [];
  template: NotesRequest[] = [];
  tableFilters: TableFilters = new TableFilters();

  getNotes(event: any) {
    this.clientId = event.clientId;
    this.tableFilters = event.tableFilters;
    this.getClientNotes();
  }
  getById(noteId: number) {
    this.noteId = noteId;
    this.getNoteById(noteId);
  }
  saveNote(template) {
    this.template = template;
    this.saveUpdateClient(template);
  }
  deleteNote(selectedDeleteNoteId) {
    this.selectedDeleteNoteId = selectedDeleteNoteId;
    this.deleteSelectedClient();
  }
  constructor(
    private clientService: ClientService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void { }

  getClientNotes() {
    this.clientService
      .getPagedClientNotes(this.tableFilters, this.clientId)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe((res) => {
        this.notesList = res;
        this.cref.populateTable(this.notesList);
      });
  }

  getNoteById(id: any) {
    this.clientService.getClientNoteById(id).pipe(takeUntil(this.ngUnsubscribe)).subscribe((res) => {
      this.cref.updateNote(res.results);
    });
  }

  saveUpdateClient(template) {
    if (template.id != null && template.id > 0) {
      this.clientService
        .updateClientNote(template, this.clientId)
        .pipe(takeUntil(this.ngUnsubscribe))
        .subscribe({
          next: (res) => {
            if (res.statusCode == 200) {
              this.cref.showform = false;
              this.toastr.success("Note is sucessfully updated .");
              this.cref.initializeTable();
              this.getClientNotes();
              this.cref.createNotesForm();
            }
          },
          error: (err) => {
            this.toastr.error((err.error.message || "Something went wrong."), 'Error');
          }
        });

    } else {
      this.clientService
        .createClientNote(template, this.clientId)
        .pipe(takeUntil(this.ngUnsubscribe))
        .subscribe({
          next: (res) => {
            if (res.statusCode == 200) {
              this.cref.showform = false;
              this.toastr.success("Note is sucessfully added.");
              this.cref.initializeTable();
              this.getClientNotes();
              this.cref.createNotesForm();
            }
          },
          error: (err) => {
            this.toastr.error((err.error.message || "Something went wrong."), 'Error');
          }
        });
    }
  }

  deleteSelectedClient() {
    this.clientService
      .deleteClientNote(this.selectedDeleteNoteId)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          this.toastr.success("Deleted Successfully");
          this.getClientNotes();
        },
        error: (e) => {
          console.log(e);
          this.toastr.error("Something went wrong");
        },
        complete: () => this.cref.closeParentModal(),
      });
  }
}
