import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CoreModule } from 'src/app/core/core.module';
import { RouterModule, Routes } from '@angular/router';
import { ClientComponent } from './client.component';
import { CarbonModule } from 'src/app/carbon.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ClientDocumentComponent } from './client-document/client-document.component';
import { ClientDetailComponent } from './client-detail/client-detail.component';
import { PaginationModule, TableModule } from 'carbon-components-angular';
import { EditorModule } from '@tinymce/tinymce-angular';
import { SharedModule } from 'src/app/shared/shared.module';

import { SiteDetailsComponent } from './site-details/site-details.component';
import { AddClientComponent } from './add-client/add-client.component';
import { ClientTicketsComponent } from './client-tickets/client-tickets.component';
import { ClientProjectComponent } from './client-project/client-project.component';
import { ClientPricingComponent } from './client-pricing/client-pricing.component';
import { EditClientComponent } from './edit-client/edit-client.component';
import { ClientNotesComponent } from './client-notes/client-notes.component';
import { NotesModule } from '../shared/notes.module';
import { BreadcrumbModule } from 'carbon-components-angular';
import { NgpImagePickerModule } from 'ngp-image-picker';
import { ClientUsersComponent } from './client-users/client-users.component';
import { ClientUserDetailsComponent } from './client-users/client-user-details/client-user-details.component';
import { ClientUserDocumentComponent } from './client-users/client-user-document/client-user-document.component';
import { ClientUserNotesComponent } from './client-users/client-user-notes/client-user-notes.component';
import { ClientUserTicketsComponent } from './client-users/client-user-tickets/client-user-tickets.component';
import { ClientUserAddComponent } from './client-users/client-user-add/client-user-add.component';
import { ClientUserEditComponent } from './client-users/client-user-edit/client-user-edit.component';
import { Permission } from 'src/app/services/utility/permission-constant';
import { AddModule, CheckboxCheckedModule, CheckmarkFilledModule, CloseFilledModule, CloseModule, CloseOutlineModule,ErrorModule, ViewModule  } from '@carbon/icons-angular';
import { AuthGuard } from 'src/app/core/AuthGuard/auth.guard';
const routes: Routes = [
  {
    path: '',
    component: ClientComponent,
    
    children: [
      { path: '', redirectTo: 'client-details', pathMatch: 'full' },
      {
        path: 'client-details/:clientId', component: ClientDetailComponent,
        
        children: [
          { path: '', redirectTo: 'locations', pathMatch: 'full' },
          { path: 'documents', component: ClientDocumentComponent, pathMatch: 'full' },
          { path: 'notes', component: ClientNotesComponent, pathMatch: 'full' },
          { path: 'locations', component: SiteDetailsComponent, pathMatch: 'full' },
          { path:'tickets', component:ClientTicketsComponent, pathMatch: 'full'}
        ]
      },
      { path: 'add', component: AddClientComponent },
      { path: 'edit/:clientId', component: EditClientComponent },
      { path: 'manage-client', component: ClientDetailComponent },
    ],
    
  },
{
  path: 'client-users/:clientId', component: ClientUsersComponent,canActivate: [AuthGuard], data : {permission:Permission.ViewClientUser},
  children: [
      {
      path: 'details/:clientuserId', component: ClientUserDetailsComponent,
      children: [
        { path: '', redirectTo: 'general', pathMatch: 'full' },
        { path: 'documents', component: ClientUserDocumentComponent, pathMatch: 'full' },
        { path: 'notes', component: ClientUserNotesComponent, pathMatch: 'full' },
        { path: 'general', component: ClientUserEditComponent, pathMatch: 'full' },
        { path: 'contracts', component: ClientUserTicketsComponent, pathMatch: 'full' },
      ]
    },
    { path: 'add', component: ClientUserAddComponent },
    //{ path: 'edit/:clientId', component: EditClientComponent },
    //{ path: 'manage-client', component: ClientDetailComponent },
  ],
  
},

];

@NgModule({
  declarations: [
    ClientComponent,
    ClientNotesComponent,
    ClientDocumentComponent,
    ClientDetailComponent,
    SiteDetailsComponent,
    AddClientComponent,
    ClientTicketsComponent,
    ClientProjectComponent,
    ClientPricingComponent,
    EditClientComponent,
    ClientUsersComponent,
    ClientUserDetailsComponent,
    ClientUserDocumentComponent,
    ClientUserNotesComponent,
    ClientUserTicketsComponent,
    ClientUserAddComponent,
    ClientUserEditComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    CoreModule,
    SharedModule,
    CarbonModule,
    TableModule,
    PaginationModule,
    FormsModule,
    EditorModule,
    FormsModule,
    ReactiveFormsModule,
    NotesModule,
    BreadcrumbModule,
    AddModule, 
    ViewModule,
    CheckboxCheckedModule, 
    CheckmarkFilledModule, 
    CloseFilledModule, CloseModule,
     CloseOutlineModule,
     ErrorModule ,
    NgpImagePickerModule
  ],
})
export class ClientModule { }
