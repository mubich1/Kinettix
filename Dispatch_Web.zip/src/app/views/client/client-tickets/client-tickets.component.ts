import { DatePipe } from '@angular/common';
import { Component, ElementRef, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Table, TableHeaderItem, TableItem, TableModel } from 'carbon-components-angular';
import { ToastrService } from 'ngx-toastr';
import { ClientContract } from 'src/app/models/proposals/proposal';
import { Ticket } from 'src/app/models/tickets/tickets';
import { LoaderService } from 'src/app/services/loader/loader.service';
import { TicketService } from 'src/app/services/ticket/ticket.service';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';

@Component({
  selector: 'app-client-tickets',
  templateUrl: './client-tickets.component.html',
  styleUrls: ['./client-tickets.component.css']
})
export class ClientTicketsComponent implements OnInit {
  @ViewChild('ticketTableTemplate', { static: false }) ticketTableTemplate: ElementRef;
  @ViewChild('headerTemplate',{static:false}) headerTemplate:ElementRef;
  @ViewChild('customHtmlTemplate', { static: true }) customHtmlTemplate: TemplateRef<any>;

  contractList:ClientContract[] = [];
  contractModel = new TableModel();
  contractData: TableItem[][] = [];
  carbonUtility = new CarbonUtility();
  showSkeleton: boolean = true;
  clientID:number = 0;
  isClientTicketPaginated: boolean = false;
  isClientTicketSorted: boolean = false;
  clientTicketFilters: {pageSize:number, page:number, contractId: number, sort: string, isAscending: boolean } = {pageSize: 10, page: 1, contractId: 0, sort: '', isAscending: false }
  isAscending: boolean = false;
  sortIndex: number;
  constructor(private ticketService:TicketService,
              private toasterService:ToastrService,
              private datepipe: DatePipe,
              private loaderService: LoaderService,
              private route: ActivatedRoute) { }

  ngOnInit(): void {
   this.getRoutingParams();
  }

  getRoutingParams() {
    this.route.params.subscribe(el => {
      this.clientID = +el.clientID;
      this.getTicketsById();
    });
  }

  getTicketsById(ticketModel?) {
  this.loaderService.show();
  this.ticketService.getTicketsByClientId(this.clientID, this.clientTicketFilters).subscribe({
    next:(res)=>{
      this.loaderService.hide();
      this.contractData = [];
      this.contractModel.totalDataLength = res.results.length;
      this.contractList = res.results;


      if (this.isClientTicketPaginated || this.isClientTicketSorted) {
        let ticketData: TableItem[][] = [];
        const index = this.contractList.findIndex((item) => item.id === this.clientTicketFilters.contractId);
        if(index > -1) {
        this.populateTicketTable( this.contractList[index].tickets, ticketModel, ticketData, this.contractList[index].totalTickets );
      }
        if (this.isClientTicketSorted) {
          ticketModel.header[this.sortIndex].descending = !this.isAscending;
          ticketModel.sort(this.sortIndex);
        }
    }
      else{
      this.populateContractTable(this.contractList)
      }
    },
    error:(err)=>{
      this.loaderService.hide();
      this.toasterService.error(err);
    }
  })
}

stopPropagtion(event) {
  event.stopPropagation();
}

populateContractTable(contractList) {
  if (contractList && contractList.length) {
    for (let contract of contractList) {
      let ticketModel = new TableModel();
      let ticketData: TableItem[][] = [];
      this.populateTicketTable(contract?.tickets, ticketModel,ticketData, contract?.totalTickets );
      let rows: any = [];
      this.carbonUtility.setTableItem(rows, contract?.title, [[ new TableItem({ data: {ticketModel: ticketModel, id: contract?.id }, colSpan: 12, template: this.ticketTableTemplate, })]] , true);
      this.carbonUtility.setTableItem(rows, contract?.type?.type);
      this.carbonUtility.setTableItem(rows, this.datepipe.transform(contract?.createdDate, 'MM/dd/yyyy'));
      this.contractData.push(rows);
    };
  }
  const headers = ['CONTRACT TITLE', 'CONTRACT TYPE', 'CREATED DATE' ];
  this.contractModel = this.carbonUtility.setTableModel(headers, this.contractModel, this.contractData, this.contractModel.pageLength, this.contractModel.currentPage, this.contractModel.totalDataLength);
  this.showSkeleton = false;
}


  populateTicketTable(ticketList:Ticket[] | null, ticketModel: TableModel, ticketData: TableItem[][], totalTickets: number) {
    ticketModel.data = [];
    ticketData = [];
    ticketModel.totalDataLength = 0;
    if (ticketList && ticketList.length) {
      ticketModel.totalDataLength = totalTickets;
      for (let ticket of ticketList) {
        ticket.createdDate =  this.datepipe.transform(ticket?.createdDate, 'MM/dd/yyyy') as string
        let rows: any = [];
        this.carbonUtility.setTableItem(rows, ticket, undefined, undefined, this.customHtmlTemplate);
        this.carbonUtility.setTableItem(rows, ticket, undefined, undefined, this.customHtmlTemplate);
        this.carbonUtility.setTableItem(rows, ticket, undefined, undefined, this.customHtmlTemplate);
        ticketData.push(rows);
      };
    }
    const headers = [ "TITLE", "TOOLS", "CREATED DATE"];
    ticketModel = this.carbonUtility.setTableModel(headers, ticketModel, ticketData, ticketModel.pageLength, ticketModel.currentPage, ticketModel.totalDataLength, this.headerTemplate);
  }

  selectTicketPage(page: any, data) {
    this.isClientTicketPaginated = true;
    data.ticketModel.currentPage = page;
    this.clientTicketFilters.pageSize = data.ticketModel.pageLength;
    this.clientTicketFilters.page = page;
    this.clientTicketFilters.contractId = data.id;
    this.getTicketsById(data.ticketModel)
  }

  sortTicket(event, data, index) {
    this.sortIndex = index;
    this.isClientTicketSorted = true;
    this.isAscending = !this.isAscending;
    this.clientTicketFilters.sort = event.title;
    this.clientTicketFilters.pageSize = data.ticketModel.pageLength;
    this.clientTicketFilters.isAscending = this.isAscending;
    this.clientTicketFilters.contractId = data.id;
    this.getTicketsById(data.ticketModel);
  }

  selectPage(page: any) {
    this.contractModel = this.carbonUtility.selectPage(
      page,
      this.contractModel,
      this.contractData
    );
  }

  onSearch(value:any){
   let  filteredContractList: ClientContract[] = [];
   this.contractList.forEach(x => {
      if(x.title.toLocaleLowerCase().trim().includes(value.toLocaleLowerCase().trim()) ||
         x.type.type.toLocaleLowerCase().trim().includes(value.toLocaleLowerCase().trim()) ||
         x.createdDate.toString().includes(value.toLocaleLowerCase().trim())){
          filteredContractList.push(x);
        }
    })
    this.populateContractTable(filteredContractList)
  }
}
