import { DatePipe } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { TableHeaderItem, TableItem, TableModel } from 'carbon-components-angular';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';
import { ClientDocument, ClientDocumentRequest, ClientDocumentsType } from 'src/app/models/client/client';
import { AllowdDocTypes } from 'src/app/models/common/common';
import { ClientService } from 'src/app/services/client/client.service';
import { CommonService } from 'src/app/services/common/common.service';
import { DealDocumentService } from 'src/app/services/document/deal-document.service';
import { AngularUtility } from 'src/app/shared/common/angular-utitilty';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';
import { ModuleNameEnum } from 'src/app/shared/enum/module-name-enum';
@Component({
  selector: 'app-client-document',
  templateUrl: './client-document.component.html',
  styleUrls: ['./client-document.component.css'],
})
export class ClientDocumentComponent implements OnInit {

  numRegex = /^\d{0,14}[.,]?\d{0,2}$/;
  showTypeSkeleton: boolean = true;
  docsForm: FormGroup;
  ngUnsubscribe = new Subject<void>();
  documentList: ClientDocument[] = [];
  EditDoc: any;
  documentTableModel = new TableModel();
  documentTableData: TableItem[][] = [];
  showDocumentSkeleton: boolean = true;
  documentType: ClientDocumentsType;
  clientId: number = 0;
  showform: boolean = false;
  files = new Set<any>();
  selectedDeleteDocId: number = 0;
  isOpenDeleteModal = false;
  isOpenAddModal = false;
  isMsa: boolean = false;
  isPoDoc: boolean = false;
  carbonUtility = new CarbonUtility();
  fileTypes: string[] = AllowdDocTypes.extensions;
  documnetTypeList: ClientDocumentsType[];
  @ViewChild('customHeaderDoc', { static: true }) customHeaderDoc: ElementRef;
  @ViewChild('customViewDoc', { static: true }) customViewDoc: ElementRef;
  @ViewChild('customViewDocIsInternal', { static: true }) customViewDocIsInternal: ElementRef;
  @ViewChild('customItemNameDoc', { static: true })
  customItemNameTerm: ElementRef;
  angularUtility = new AngularUtility();
  currentSelectedClientDocument: any;
  currentSelectedClientDocumentId = 0;
  currentSelectedDocTypeName = ''
  constructor(
    public datepipe: DatePipe,
    private clientService: ClientService,
    private documentService: DealDocumentService,
    private commonService: CommonService,
    private route: ActivatedRoute,
    private toastr: ToastrService,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit(): void {
    this.route.parent?.params.subscribe((params: any) => {
      if (params.hasOwnProperty('clientId')) {
        this.clientId = params['clientId'];
        this.docsForm = this.formBuilder.group({
            id : [''],
            name : ['', [Validators.required, Validators.maxLength(250)]],
            description : ['', [Validators.required, Validators.maxLength(500)]],
            docType : [''],
            url : [''],
            created : [''],
            signatureDate : [''],
            expirationDate : [null],
            poNumber : ['', Validators.maxLength(99)],
            poValue : ['', [Validators.pattern(this.numRegex)]],
            isInternal : [true]
        })

        //set default value
        this.setDefaultValues()


        this.InitializeDocumentDealTable();
        this.getClientDoucuments();
        this.getDocumentTypes();
      }
    });
  }

  setDefaultValues(){
    this.docsForm.get('isInternal')?.setValue(true);
  }

  // this is for reset fields.
  intializeForm() {
    this.docsForm = this.formBuilder.group({
      id: [0],
      name: ['', [Validators.required, Validators.maxLength(250)]],
      description: ['', Validators.maxLength(500)],
      docType: [null, Validators.required],
      url: [''],
      created: [null],
      signatureDate: [null],
      expirationDate: [null],
      poNumber: [null, Validators.maxLength(99)],
      poValue: [null, Validators.pattern(this.numRegex)],
      isInternal: [true]
    });
  }

  getClientDoucuments() {
    this.clientService.getClientDocumentsByClientId(this.clientId)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          if (res !== null) {
            this.documentList = res.results;
            this.populateDocumentTable(this.documentList);
          }
        },
        error: (e) => {
          this.toastr.error('Something went wrong while loading Client documents');
        },
        complete: () => { },
      });
  }
  selectedDocumentType(event) {

    if (event.value === 'MSA') {
      this.docsForm.get('signatureDate')?.setValidators([Validators.required]);
      this.docsForm.get('signatureDate')?.updateValueAndValidity();
      this.isMsa = true;
    }
    else {
      this.isMsa = false;
      this.docsForm.get('signatureDate')?.setValidators([Validators.nullValidator]);
      this.docsForm.get('signatureDate')?.updateValueAndValidity();
      this.docsForm.patchValue({ signatureDate: null });
    }

    if (event.value == 'Purchase Order') {
      this.docsForm.get('poNumber')?.setValidators([Validators.required, Validators.maxLength(99)]);
      this.docsForm.get('poValue')?.setValidators([Validators.pattern(this.numRegex)]);
      this.docsForm.get('poNumber')?.updateValueAndValidity();
      this.docsForm.get('poValue')?.updateValueAndValidity();
      this.isPoDoc = true;
    }
    else {
      this.isPoDoc = false;
      this.docsForm.get('poNumber')?.setValidators([Validators.nullValidator]);
      this.docsForm.get('poNumber')?.updateValueAndValidity();
      this.docsForm.patchValue({ poNumber: null, poValue: null, expirationDate: null });
    }

  }
  InitializeDocumentDealTable() {
    this.documentTableModel.data = [];
    let headers = [
      new TableHeaderItem({ data: 'ID', visible: false }),
      new TableHeaderItem({ data: 'NAME' }),
      new TableHeaderItem({ data: 'CREATED' }),
      new TableHeaderItem({ data: 'EXPIRATION' }),
      new TableHeaderItem({ data: 'VIEW' }),
      new TableHeaderItem({ data: 'Internal' }),
      new TableHeaderItem({ data: 'ACTION', sortable: false }),
    ];
    this.documentTableModel = this.carbonUtility.initializeTable(
      headers,
      this.documentTableModel,
      this.documentTableData
    );

    this.selectPageDocument(1);
  }

  populateDocumentTable(docList) {
    this.documentTableData = [];
    this.documentTableModel.totalDataLength = docList.length;
    if (docList != null && docList.length > 0) {
      docList.forEach((el) => {
        this.documentTableData.push([
          new TableItem({ data: el.id }),
          new TableItem({ data: el.name }),
          new TableItem({
            data: this.datepipe.transform(el.createdDate, 'MM/dd/yyyy'),
          }),
          new TableItem({ data: el.expiration == null ? '' : this.datepipe.transform(el.expiration, 'MM/dd/yyyy'), }),
          new TableItem({ data: { url: el?.url }, template: this.customViewDoc }),
          new TableItem({ data: el, template: this.customViewDocIsInternal }),
          new TableItem({ data: el, template: this.customHeaderDoc }),
        ]);
      });
    }
    this.InitializeDocumentDealTable();
    this.showDocumentSkeleton = false;
  }
  onDownload(data) {
    this.commonService.downloadDocument(data.url, data.name)
  }

  onSearch(event) {
    let filteredCompetencyList = this.documentList;
    if (!this.angularUtility.isEmptyOrSpaces(event)) {
      filteredCompetencyList = this.documentList.filter((x) => {
        return x.name?.toLocaleLowerCase().includes(event.toLocaleLowerCase());
      });
    }

    this.populateDocumentTable(filteredCompetencyList);
    this.InitializeDocumentDealTable();
  }
  deleteDoc(value: ClientDocumentRequest) {

    const doc = value.id!;
    if (doc > 0) {
      this.selectedDeleteDocId = doc;
      this.openParentModal();
    } else {
      this.selectedDeleteDocId = 0;
    }
  }
  onConfirmationDelete() {
    this.clientService
      .deleteDocumentById(this.selectedDeleteDocId)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          this.toastr.success('Deleted Successfully');
          this.getClientDoucuments();
        },
        error: (e) => {
          console.log(e);
          this.toastr.error('Something went wrong');
        },
        complete: () => this.closeParentModal(),
      });
  }
  openParentModal() {
    this.isOpenDeleteModal = true;
  }
  closeParentModal() {
    this.isOpenDeleteModal = false;
    this.selectedDeleteDocId = 0;
  }
  closeSaveModal() {
    this.docsForm.reset();
    this.intializeForm();
    this.isOpenAddModal = false;
    this.showform = false;
    this.isMsa = false;
    this.isPoDoc = false;
  }
  onClickRow(value: ClientDocumentRequest) {
    const docId = value.id!;
    this.currentSelectedClientDocumentId = docId
    if (docId > 0) {
      this.showform = true;
      this.isOpenAddModal = true;
      this.updateDocument(docId);
    } else {
      this.onUpload();
    }
  }

  updateDocument(docId) {
    this.clientService.getDocumentByDocumentId(docId)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          if (res.results !== null) {
            this.currentSelectedClientDocument = res.results;

            this.EditDoc = res.results;

            this.docsForm.get('name')?.setValue(this.EditDoc.name)
            this.docsForm.get('description')?.setValue(this.EditDoc.description)
            this.docsForm.get('isInternal')?.setValue(this.EditDoc.isInternal)


            var exist = this.documnetTypeList.filter((s) => s.id == this.EditDoc.documentType)
            if (exist.length > 0) {
              this.currentSelectedDocTypeName = this.getTypeName(this.EditDoc.documentType)
            }
            else {
              this.currentSelectedDocTypeName = ''
            }

            this.docsForm.patchValue({
              docType: this.getTypeName(this.EditDoc.documentType)
            })

            if (this.getTypeName(this.EditDoc.documentType) == 'MSA') {
              this.isMsa = true;
            }
            if (this.getTypeName(this.EditDoc.documentType) == 'Purchase Order') {
              this.isPoDoc = true;
            }

            if (this.EditDoc != null) {
              this.docsForm.patchValue({
                id: docId,
                name: this.EditDoc.name,
                description: this.EditDoc.description,
                url: this.EditDoc.url,
                created: this.EditDoc.created,
                poNumber: this.EditDoc.poNumber,
                poValue: this.EditDoc.poValue,
                isInternal: this.EditDoc.isInternal
              });
              if (this.getTypeName(this.EditDoc.documentType) == 'MSA') {
                this.docsForm.controls['signatureDate'].patchValue(
                  new Date(this.EditDoc.signatureDate)
                );
              }
              if (this.getTypeName(this.EditDoc.documentType) == 'Purchase Order') {
                this.docsForm.controls['expirationDate'].patchValue(
                  this.EditDoc.expiration ? new Date(this.EditDoc.expiration) : null
                );
              }
            }
          }
        },
        error: (e) => {
          console.log(e);
          this.toastr.error('Something went wrong while loading Client documents');
        },
        complete: () => { },
      });
  }

  selectPageDocument(page: any) {
    this.documentTableModel = this.carbonUtility.selectPage(
      page,
      this.documentTableModel,
      this.documentTableData
    );
  }

  getDocumentTypes() {
    this.commonService.getDocumentDefinitionTypes()
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: res => {

          //Todo add condition after config update

          if (res.message == "Success" && res != null) {
            this.documnetTypeList = res.results;
          }
        },
        error: e => {
          this.showTypeSkeleton = false;
          console.log(e);
        },
        complete: () => {
          this.showTypeSkeleton = false;
        }
      });
  }

  createDocument(document) {
    this.documentService.uploadDocument(document)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          const clientDoc: ClientDocumentRequest = {
            id: 0,
            name: document.name,
            url: res.document.path,
            documentType: document.docType,
            description: document.description,
            created: document.created,
            signatureDate: this.isMsa ? new Date(this.docsForm.value.signatureDate) : null,
            poNumber: this.isPoDoc ? document.poNumber : null,
            poValue: this.isPoDoc ? document.poValue : null,
            expiration: this.isPoDoc ? this.docsForm.value.expirationDate ? new Date(this.docsForm.value.expirationDate) : null : null,
            isInternal: document.isInternal
          };

          this.clientService.createDocument(clientDoc, this.clientId)
            .pipe(takeUntil(this.ngUnsubscribe)).subscribe({
              next: (res) => {
                if (res !== null) {
                  this.docsForm.reset();
                  this.showform = false;
                  this.isOpenAddModal = false;
                  this.isMsa = false;
                  this.isPoDoc = false;
                  this.toastr.success('Document is sucessfully added.');
                  this.getClientDoucuments();
                }
              },
              error: (err) => {
                this.toastr.error((err.error.message || "Something went wrong."), 'Error');
              },
              complete: () => { },
            });
        },
      });
  }

  updateDocumentSave(document) {
    if (document.url == "" || document.url === null) {
      document.url = this.currentSelectedClientDocument["url"]
    }


    this.clientService.updateDocument(document, this.clientId)
      .pipe(takeUntil(this.ngUnsubscribe)).subscribe({
        next: (res) => {
          if (res !== null) {
            this.docsForm.reset();
            this.showform = false;
            this.isOpenAddModal = false;
            this.isMsa = false;
            this.isPoDoc = false;
            this.toastr.success('Document is sucessfully updated.');
            this.getClientDoucuments();
          }
        },
        error: (err) => {
          this.toastr.error((err.error.message || "Something went wrong."), 'Error');
        },
        complete: () => { },
      });
  }

  updateDocumentSaveWithFile(document) {
    this.documentService.uploadDocument(document)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          const clientDoc: ClientDocumentRequest = {
            id: this.currentSelectedClientDocumentId,
            name: document.name,
            url: res.document.path,
            documentType: document.docType,
            description: document.description,
            created: document.created,
            signatureDate: this.isMsa ? new Date(this.docsForm.value.signatureDate) : null,
            poNumber: document.poNumber,
            poValue: document.poValue,
            expiration: this.isPoDoc ? this.docsForm.value.expirationDate ? new Date(this.docsForm.value.expirationDate) : null : null,
            isInternal: document.isInternal,
          };
          this.clientService.updateDocument(clientDoc, this.clientId)
            .pipe(takeUntil(this.ngUnsubscribe)).subscribe({
              next: (res) => {
                if (res !== null) {
                  this.showform = false;
                  this.isOpenAddModal = false;
                  this.toastr.success('Document is sucessfully Updated.');
                  this.getClientDoucuments();
                  this.currentSelectedClientDocumentId = 0
                }
              },
              error: (err) => {
                this.toastr.error((err.error.message || "Something went wrong."), 'Error');
              },
              complete: () => { },
            });
        },
      });
  }

  onUpload() {
    var docName = this.docsForm?.value?.name;
    const document = {
      id: this.currentSelectedClientDocumentId,
      name: this.docsForm.value.name,
      description: this.docsForm.value.description,
      url: this.docsForm.value.url,
      documentType: this.getTypeId(),
      created: this.docsForm.value.created,
      signatureDate: this.isMsa ? new Date(this.docsForm.value.signatureDate) : null,
      poNumber: this.docsForm.value.poNumber,
      poValue: this.docsForm.value.poValue,
      isInternal: this.docsForm.value.isInternal,
      moduleName: ModuleNameEnum.Client,
      expiration: this.isPoDoc ? this.docsForm.value.expirationDate ? new Date(this.docsForm.value.expirationDate) : null : null,
    };
    if (docName == "" || docName == undefined || docName == null) {
      this.toastr.error('Document Name field is required');
      return;
    }

    if (this.docsForm.value.docType == "" || this.docsForm.value.docType == null) {
      this.toastr.error("Please select Document Type");
      return;
    }

    var poNumber = this.docsForm.value.poNumber?.trim();
    if (this.isPoDoc == true && this.docsForm.valid && poNumber?.length == 0) {
      this.toastr.error('PO Number fields is required');
      return;
    }

    else {
      if (this.files.size == 0) {
        if (this.currentSelectedClientDocumentId > 0) {
          this.updateDocumentSave(document);
        }
        // else {
        //   this.toastr.error('Please add document.');
        // }
      }
      else {
        this.files.forEach((fileItem) => {

          const extension = fileItem.file.name.split('.').pop().toLowerCase();

          if (!this.fileTypes.some(s => s.includes(extension))) {
            this.toastr.error('Invalid File Extension.');
            return;
          }

          if (fileItem.file.size < 50000000) {
            setTimeout(() => {
              fileItem.state = 'complete';
              fileItem.uploaded = true;
            }, 1500);

            const reader = new FileReader();

            reader.readAsDataURL(fileItem.file);
            reader.onload = () => {
              let base64 = reader.result?.toString();

              if (base64 == 'data:') {
                this.toastr.error("Invalid or empty file.");
                return;
              }

              const document = {
                id: this.docsForm.value.id,
                name: `${this.docsForm.value.name.split('.')[0]}.${extension}`,
                description: this.docsForm.value.description,
                filebase64string: base64 !== undefined ? base64.toString() : null,
                type: this.docsForm.value.docType,
                docType: this.getTypeId(),
                created: this.docsForm.value.created,
                signatureDate: this.isMsa ? new Date(this.docsForm.value.signatureDate) : null,
                poNumber: this.isPoDoc ? this.docsForm.value.poNumber : null,
                poValue: this.isPoDoc ? this.docsForm.value.poValue : null,
                expirationDate: this.isPoDoc ? this.docsForm.value.expirationDate ? new Date(this.docsForm.value.expirationDate) : null : null,
                isInternal: this.docsForm.value.isInternal,
                moduleName: ModuleNameEnum.Client
              };
              if (this.docsForm.value.id !== null && this.docsForm.value.id !== 0) {
                this.updateDocumentSaveWithFile(document);
              }
              else {
                this.createDocument(document);
              }
            };
          }
        });
      }
    }
  }

  getTypeId() {
    var res = this.documnetTypeList.filter((s) => (s).name == this.docsForm.value.docType);
    if (res.length <= 0) {
      return "";
    } else {
      return res[0].id;
    }
  }

  getTypeName(id: number) {
    return this.documnetTypeList.filter(x => x.id == id)[0].name;
  }

  addDocumentModel() {
    this.isOpenAddModal = true;
    this.currentSelectedClientDocumentId = 0;
    this.ShowForm();
  }

  ShowForm() {
    if (!this.showform) {
      this.intializeForm();
    }

    this.showform = !this.showform;
  }

  get f(
  ) {
    return this.docsForm.controls;
  }

  selectPage(page: any) {
    this.documentTableModel.currentPage = page;
    const fullPage: TableItem[][] = [];
    for (
      let i = (page - 1) * this.documentTableModel.pageLength;
      i < page * this.documentTableModel.pageLength &&
      i < this.documentTableModel.totalDataLength;
      i++
    ) {
      fullPage.push(this.documentTableData[0 + i]);
      this.documentTableModel.data = fullPage;
    }
  }

  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }
}
