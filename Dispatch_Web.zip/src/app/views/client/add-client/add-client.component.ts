import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ListItem } from 'carbon-components-angular';
import { ImagePickerConf } from 'ngp-image-picker';
import { ToastrService } from 'ngx-toastr';
import { catchError, EMPTY, Subject, takeUntil, tap } from 'rxjs';
import { Client } from 'src/app/models/client/client';
import { countrySelectBox } from 'src/app/models/client/country-select-box';
import { ClientService } from 'src/app/services/client/client.service';
import { DealDocumentService } from 'src/app/services/document/deal-document.service';
import { UserService } from 'src/app/services/user/user.service';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';
import { ModuleNameEnum } from 'src/app/shared/enum/module-name-enum';

@Component({
  selector: 'app-add-client',
  templateUrl: './add-client.component.html',
  styleUrls: ['./add-client.component.css','../../client/client.component.css'],
})
export class AddClientComponent implements OnInit {
  ngUnsubscribe = new Subject<void>();
  config1: ImagePickerConf = {
    language: 'en',
    hideDeleteBtn:true,
    hideDownloadBtn:true,
    hideEditBtn:true,
    width: '200px',
    height: '200px',
  };
  clientForm: FormGroup;
  client: Client;
  profilePic: string = '';
  name: string="";
  dbaName: string="";
  website:string="";
  phone:string="";
  email:string="";
  address:string="";
  city:string="";
  stae:string="";
  // countryId:number;
  countryName:string="";
  state:string="";
  accountExecutive: any;
  accounant: any;
  accountExecutiveId: number ;
  accountantId: number ;
  contractManager: any;
  projectManagerId: any ;
  country:any;
  hasEndClient: boolean = false;
  employees:  countrySelectBox[] = [{ value: 0, text: '' }];
  postal:string = "";
  clientId: number=0;
  countries: countrySelectBox[] = [{ value: 0, text: '' }];
  countryId: any;
  filebase64string:string='';

  private carbonUtility = new CarbonUtility();
  public parentClientsDropdown: ListItem[] = [];
  public relationshipTypesDropdown: ListItem[] = [];
  public relationshipTypeId: any;
  public parentClientId: any;
  imgName: string;
  constructor(private clientService: ClientService,
              private toastr: ToastrService,
              private uploadService: DealDocumentService,
              private route: ActivatedRoute,
              private router: Router,
              private location: Location,
              private userService: UserService) { }

  ngOnInit(): void {
    this.route.params.subscribe(
      (params: any) => {
        if (params.hasOwnProperty('clientId')) {
          this.clientId = params['clientId'];
        }});
    this.getAllCountries();
    this.getUsers();
    this.GetParentClients();
    this.GetRelationshipTypes();
  }
  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  saveAddClient(){
    this.client.name = this.clientForm.value.name;

  }
  onCancel(){
    this.location.back();
  }
  AddClient(){
    if (!this.name.replace(/\s/g, '').length) {
      this.toastr.error('Please input client name');
      return ;
    }
    const client: Client = {
      id: 0,
      name: this.name,
      city: this.city,
      state: this.state,
      countryId: this.countryId,
      isSync: false,
      email: this.email,
      phone: this.phone,
      address: this.address,

      website: this.website,
      postalCode: this.postal,
      accountantId: '1',
      accountExecutiveId: this.accountExecutive,
      projectManagerId: this.projectManagerId,
      status: 2,
      logoUrl: "",
      countryName: this.countryName,
      hasEndClient: this.hasEndClient,
      parentID: this.parentClientId,
      relationshipTypeID: this.relationshipTypeId,

      endClients: null
    }

    // Only upload image if image has been selected, Bug/5805
    this.toastr.info('Uploading client...');

    if(this.filebase64string !== '') {
      const uploadData = {
        filebase64string: this.filebase64string,
        moduleName: ModuleNameEnum.Client,
        name: this.imgName,
      }

      this.uploadService.uploadDocument(uploadData)
      .pipe(
        takeUntil(this.ngUnsubscribe),
        tap((result) => {
          // Uploaded successfully, set upload URI to client image URI
          client.logoUrl = result.document.path;

          // Finalize the upload
          this.uploadClient(client);
        }),
        // If there is an http error while uploading, handle accordingly
        catchError((_) => {
          this.toastr.error('Something went wrong');

          return EMPTY;
        })
      ).subscribe();
    } else {
      // Since no image has been selected, upload the client without uploading image first
      this.uploadClient(client);
    }


  }

  uploadClient(client: Client) {
    this.clientService.createClient(client).pipe(
      takeUntil(this.ngUnsubscribe),
      tap((result) => {
        if(result !== null) {
          // Result will contain values on success. Show success message
          this.toastr.success('Saved Successfully');

          this.location.back();

          return;
        }

        this.toastr.error('Something went wrong');
      }),
      // Handle any http errors while uploading client
      catchError((_) => {
        this.toastr.error(_.error.message);

        return EMPTY;
      }),
    ).subscribe();
  }

  getAllCountries() {
    this.clientService.getAllContries().subscribe({
      next: (res) => {
        this.countries = res.results;
      },
    });
  }
  getUsers() {
   this.userService.getUsers().subscribe({
      next: (res) => {
        this.employees = res.results.data;
      },
    });
  }
  createClientForm() {
    this.clientForm = new FormGroup({
      clientName: new FormControl('', [Validators.minLength(2), Validators.maxLength(30)]),
      website: new FormControl(''),
      clientPhone: new FormControl('', [Validators.minLength(2), Validators.maxLength(20)]),
      clientEmail: new FormControl('', Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")),
      clientAddress: new FormControl('', [Validators.minLength(2), Validators.maxLength(100)]),
      clientCity: new FormControl('', [Validators.minLength(2), Validators.maxLength(20)]),
      clientState: new FormControl(''),
      clientCountry: new FormControl(''),
      clientPostal: new FormControl('', [Validators.minLength(2), Validators.maxLength(20)]),
      projectManagerId: new FormControl('', [Validators.minLength(2), Validators.maxLength(20)]),
      relationshipTypeId: new FormControl('', Validators.required),
      parentId: new FormControl('')
    });
  }
  onImageChange(event){
    this.filebase64string=event;
  }

  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  private GetParentClients() : void {
    this.clientService.getAllClients().subscribe(res => {
      const clients: Client[] = JSON.parse(JSON.stringify(res.results)) as Client[];
      this.parentClientsDropdown = this.carbonUtility.getListItems(clients, 'name', 'id');
    })
  }

  private GetRelationshipTypes(): void {
    this.clientService.getRelationshipTypes().subscribe(res => {
      const relationshipTypes = res.results;
      this.relationshipTypesDropdown = this.carbonUtility.getListItems(relationshipTypes, 'name', 'id');
    });
  }

  imageFileName(event) {
    this.imgName = event?.srcElement?.files[0]?.name;
  }
}
