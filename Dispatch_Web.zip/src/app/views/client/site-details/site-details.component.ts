import { Component, ElementRef, OnInit, ViewChild, TemplateRef, HostBinding } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {
  PaginationModel,
  TableHeaderItem,
  TableItem,
  TableModel,
} from 'carbon-components-angular';
import { ClientSite } from 'src/app/models/client/client-site';
import { ClientService } from 'src/app/services/client/client.service';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';
import { ToastrService } from 'ngx-toastr';
import { countrySelectBox } from 'src/app/models/client/country-select-box';
import { timeZoneSelectBox } from 'src/app/models/client/timezone-select-box';
import { AngularUtility } from 'src/app/shared/common/angular-utitilty';
import { GeoLocation } from 'src/app/models/common/geo-location.enum';
import { GoogleMapService } from 'src/app/services/google-map/google-map.service';
import { debounceTime, distinctUntilChanged, Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-site-details',
  templateUrl: './site-details.component.html',
  styleUrls: [
    './site-details.component.css',
    '../../client/client.component.css',
  ],
})
export class SiteDetailsComponent implements OnInit {

  @ViewChild('customActiveTemplate', { static: true }) customActiveTemplate: TemplateRef<any>;
  name: string = '';
  siteNumber: string = '';
  address: string = '';
  city: string = '';
  phone: string = '';
  postal: string = '';
  state: string = '';
  zone: string = '';
  hqAddress: boolean = false;
  country: any = '';
  longitude: string = '';
  latitude: string = '';
  angularUtility = new AngularUtility();
  countries: countrySelectBox[] = [{ value: 0, text: '' }];
  timeZoneS: timeZoneSelectBox[] = [{ id: '', standardName: '' }];
  selectedDeleteRateId: number = 0;
  standardName: string = '';
  sitePageId: number = 1;
  clientSites: ClientSite[] = [];
  filteredClientSites: ClientSite[] = [];
  showAddMenu: boolean = false;
  carbonUtility = new CarbonUtility();
  showSkeleton: boolean = false;
  isLocName: Boolean = false;
  isAddress: Boolean = false;
  isCity: Boolean = false;
  isState: Boolean = false;
  isZipCode: Boolean = false;
  tabledata: any = [];
  tableModel = new TableModel();
  clientId: number = 0;
  siteId: number = 0;
  showform: boolean = false;
  totalClientSites: number = 0;
  showEditForm: boolean = false;
  isOpenDeleteModal = false;
  @ViewChild('customHeaderTerm', { static: true }) customHeaderTerm: ElementRef;
  longitudeError: boolean = false;
  latitudeError: boolean = false;
  isValidAddress: boolean = false;
  isValidPhoneNumber: boolean = false;
  ngUnsubscribe = new Subject<void>();
  searchQuery$ = new Subject<string>();
  searchQuery: string | null;
  constructor(
    private clientService: ClientService,
    private route: ActivatedRoute,
    private toastr: ToastrService,
    private googleMapService: GoogleMapService,
  ) {
    this.getTimeZone();
  }

  ngOnInit(): void {
    this.getAllCountries();
    this.route.parent?.params.subscribe((params: any) => {
      if (params.hasOwnProperty('clientId')) {
        this.clientId = params['clientId'];
        this.getCientSites();
        this.initializeTable();
      }
    });

    this.searchQuery$.pipe(
      debounceTime(300),
      distinctUntilChanged(),
      takeUntil(this.ngUnsubscribe),
    ).subscribe((query) => {
      this.searchQuery = query === '' ? null : query;

      this.filteredClientSites = [];
      this.tabledata = [];
      this.showSkeleton = true;
      this.populateTable();

      this.clientService.getClientSite(this.sitePageId, this.clientId, query, query, {
        recordsPerPage: this.tableModel.pageLength
      }).pipe(
        takeUntil(this.ngUnsubscribe),
      ).subscribe({
        next: async (res) => {
          this.clientSites = res.results;
          this.totalClientSites = res.totalRecords;
          this.filteredClientSites = res.results;

          this.populateTable();

          this.showSkeleton = false;

          this.initializeTable();
        },
        error: () => this.toastr.error('Failed to load client locations...'),
      });
    });
  }

  getAllCountries() {
    this.clientService.getAllContries().subscribe({
      next: (res) => {
        this.countries = res.results;
      },
    });
  }
  getTimeZone() {
    this.clientService.getTimeZone(this.clientId).subscribe({
      next: (res) => {
        this.timeZoneS = res.results.sort((a, b) =>
          a.standardName.localeCompare(b.standardName)
        );
      },
    });
  }

  onClickSiteButton() {
    this.showform = !this.showform;
  }

  onClickEditButton(value: ClientSite) {
    const siteId = value.id!;
    if (siteId > 0) {
      this.siteId = siteId;
      this.getClientSiteDetail(this.clientId, this.siteId);
    }
  }

  saveNewSite() {
    if (!this.name.replace(/\s/g, '').length) {
      this.isLocName = true;
      return;
    }
    if (!this.address.replace(/\s/g, '')) {
      this.isAddress = true;
      return;
    }
    if (!this.city.replace(/\s/g, '')) {
      this.isCity = true;
      return;
    }
    if (!this.state.replace(/\s/g, '')) {
      this.isState = true;
      return;
    }

    this.validatePhone();
    if (this.isValidAddress == false || this.isValidPhoneNumber==false) {
      if(this.isValidPhoneNumber==false){
        this.toastr.error('Invalid phone number.');
      }

      this.validateGeoCoordinatesFromAddress();
    }
    else {

      if (this.latitude != '' || this.longitude != '') {

        this.longitudeError = false;
        this.latitudeError = false;

        let lat = Number(this.latitude);

        let long = Number(this.longitude);

        if (lat > GeoLocation.maxLatitude || lat < GeoLocation.minLatitude) {

          this.latitudeError = true;

          return;

        }



        if (long > GeoLocation.maxLongitude || long < GeoLocation.minLongitude) {

          this.longitudeError = true;

          return;

        }



      }

      const clientSite: ClientSite = {

        id: this.siteId == 0 ? 0 : this.siteId,

        name: this.name,

        city: this.city,

        state: this.state,

        address: this.address,

        postalCode: this.postal,

        countryId: this.country,

        siteNumber: this.siteNumber,

        countryName: this.siteId == 0 ? this.country : "",

        phone: this.phone.trim(),

        timeZone: this.zone,
        hqAddress: this.hqAddress,

        latitude: this.latitude.toString(),

        longitude: this.longitude.toString(),

      }

      if (clientSite.id != null && clientSite.id > 0) {

        this.clientService.updateClientSite(clientSite, this.clientId).subscribe({

          next: (res) => {

            this.toastr.success("Client location is sucessfully updated.");

            this.getCientSites();

            this.onClickSiteButton();

            this.resetForm();
            this.hqAddress = false;

            this.siteId = 0;
            this.longitudeError = false;
            this.latitudeError = false;
            this.isLocName = false;
            this.isAddress = false;
            this.isCity = false;
            this.isState = false;
            this.isZipCode = false;
            this.isValidPhoneNumber=false;

          },
          error: (err) => {
            this.toastr.error((err.error.message || "Something went wrong."), 'Error');
          }

        });

      } else {

        this.clientService.createClientSite(clientSite, this.clientId).subscribe({

          next: (res) => {

            this.toastr.success("Client location is sucessfully added.");

            this.getCientSites();

            this.onClickSiteButton();

            this.resetForm();
            this.hqAddress = false;

            this.siteId = 0;
            this.longitudeError = false;
            this.latitudeError = false;
            this.isLocName = false;
            this.isAddress = false;
            this.isCity = false;
            this.isState = false;
            this.isZipCode = false;
            this.isValidPhoneNumber=false;

          },
          error: (err) => {
            this.toastr.error((err.error.message || "Something went wrong."), 'Error');
          }

        });

      }

    }

  }
  getCientSites() {
    this.clientService.getClientSite(this.sitePageId, this.clientId, '', '', {
        recordsPerPage: this.tableModel.pageLength
      }).pipe(
        takeUntil(this.ngUnsubscribe),
      ).subscribe({

        next: async (res) => {

          this.clientSites = res.results;

          this.totalClientSites = res.totalRecords;

          this.filteredClientSites = res.results;

          this.populateTable();

          this.showSkeleton = false;

          this.initializeTable();

        },
        error: () => this.toastr.error('Failed to load client locations...'),
      });

  }
  validateLat(newValue): boolean {
    if (newValue > GeoLocation.maxLatitude || newValue < GeoLocation.minLatitude) {
      this.latitudeError = true;
    } else {
      this.latitudeError = false;
    }
    return this.latitudeError;
  }
  nameWhiteSpace() {
    if (!this.name.replace(/\s/g, '').length) {
      this.isLocName = true;
      if (this.name == "") {
        this.isLocName = false;
      }
    } else {
      this.isLocName = false;
    }
  }
  addressWhiteSpace() {
    if (!this.address.replace(/\s/g, '').length) {
      this.isAddress = true;
      if (this.address == "") {
        this.isAddress = false;
      }
    } else {
      this.isAddress = false;
    }
  }
  cityWhiteSpace() {
    if (!this.city.replace(/\s/g, '').length) {
      this.isCity = true;
      if (this.city == "") {
        this.isCity = false;
      }
    } else {
      this.isCity = false;
    }
  }
  stateWhiteSpace() {
    if (!this.state.replace(/\s/g, '').length) {
      this.isState = true;
      if (this.state == "") {
        this.isState = false;
      }
    } else {
      this.isState = false;
    }
  }
  zipCodeWhiteSpace() {
    if (!this.postal.replace(/\s/g, '').length) {
      this.isZipCode = true;
      if (this.postal == "") {
        this.isZipCode = false;
      }
    } else {
      this.isZipCode = false;
    }
  }
  validateLong(newValue): boolean {
    if (newValue > GeoLocation.maxLongitude || newValue < GeoLocation.minLongitude) {
      this.longitudeError = true;
    } else {
      this.longitudeError = false;
    }
    return this.longitudeError;
  }
  populateTable() {
    this.tabledata = [];

    if (
      this.filteredClientSites != null &&
      this.filteredClientSites.length > 0
    ) {
      this.filteredClientSites.forEach((el) => {
        this.tabledata.push([
          new TableItem({ data: el.id }),
          new TableItem({ data: el.siteNumber }),
          new TableItem({ data: el.name }),
          new TableItem({ data: el.address }),
          new TableItem({ data: el.city }),
          new TableItem({ data: el.state + ', ' + el.countryName }),
          new TableItem({ data: el.postalCode }),
          new TableItem({ data: el.hqAddress, template: this.customActiveTemplate }),
          // new TableItem({ data: el.hqAddress}),
          new TableItem({ data: el, template: this.customHeaderTerm }),
        ]);
      });
    }
  }

  initializeTable() {
    this.tableModel.data = [];
    let headers = [
      new TableHeaderItem({ data: 'Id', visible: false }),
      new TableHeaderItem({ data: 'Location Number' }),
      new TableHeaderItem({ data: 'Location Name' }),
      new TableHeaderItem({ data: 'Address' }),
      new TableHeaderItem({ data: 'City' }),
      new TableHeaderItem({ data: 'State, Country' }),
      new TableHeaderItem({ data: 'Zip/Postal' }),
      new TableHeaderItem({ data: "HQ Address" }),
      new TableHeaderItem({ data: 'ACTION', sortable: false }),
    ];
    this.tableModel = this.carbonUtility.initializeTable(
      headers,
      this.tableModel,
      this.tabledata
    );

    this.tableModel.totalDataLength = this.totalClientSites;
  }
  selectPage(page: any) {
    if(this.filteredClientSites == null) {
      return;
    }

    this.tableModel.currentPage = page;

    const finalPage = Math.ceil(this.totalClientSites / this.tableModel.pageLength);
    const loadedPages = Math.ceil(this.filteredClientSites.length / this.tableModel.pageLength);

    if(loadedPages < finalPage && this.tableModel.currentPage > loadedPages && this.showSkeleton === false) {
      this.showSkeleton = true;

      this.clientService.getClientSite(page, this.clientId, this.searchQuery ?? '', this.searchQuery ?? '', {
        recordsPerPage: this.tableModel.pageLength
      }).pipe(
        takeUntil(this.ngUnsubscribe),
      ).subscribe({
        next: async (res) => {
          this.clientSites = res.results;
          this.totalClientSites = res.totalRecords;
          this.filteredClientSites = [
            ...this.filteredClientSites,
            ...res.results,
          ];

          this.showSkeleton = false;

          this.sliceDataSet();
        },
        error: () => this.toastr.error('Failed to load client locations...'),
      });

      return;
    }

    this.sliceDataSet();
  }

  sliceDataSet(): void {
    const startPos = (this.tableModel.currentPage - 1) * this.tableModel.pageLength;
    let endPos: number;
    if(startPos + this.tableModel.pageLength > this.totalClientSites) {
      endPos = this.totalClientSites;
    } else {
      endPos = startPos + this.tableModel.pageLength;
    }

    this.populateTable();

    const set = (this.tabledata as any[]).slice(startPos, endPos);
    this.tableModel.data = set;
  }

  resetForm() {
    (this.name = ''),
      (this.city = ''),
      (this.state = ''),
      (this.address = ''),
      (this.postal = ''),
      (this.country = ''),
      (this.siteNumber = ''),
      (this.phone = ''),
      (this.zone = ''),
      (this.longitude = '');
    this.latitude = '';
    this.hqAddress

  }

  onCancel() {
    this.showform = !this.showform;
    this.resetForm();
    this.siteId = 0;
    this.longitudeError = false;
    this.latitudeError = false;
    this.isLocName = false;
    this.isAddress = false;
    this.isCity = false;
    this.isState = false;
    this.isZipCode = false;
    this.hqAddress = false;
    this.isValidPhoneNumber=false;
  }

  onDelete(value: ClientSite) {
    const siteId = value.id!;
    if (siteId > 0) {
      this.selectedDeleteRateId = siteId;
      this.openParentModal();
    } else {
      this.selectedDeleteRateId = 0;
    }
  }
  openParentModal() {
    this.isOpenDeleteModal = true;
  }
  closeParentModal() {
    this.isOpenDeleteModal = false;
    this.selectedDeleteRateId = 0;
  }
  deleteRecord() {
    this.clientService
      .deleteClientSiteById(this.selectedDeleteRateId, this.clientId)
      .subscribe({
        next: (res) => {
          this.toastr.success('Deleted Successfully');
          this.getCientSites();
        },
        error: (e) => {
          console.log(e);
          this.toastr.error('Something went wrong');
        },
        complete: () => this.closeParentModal(),
      });
  }

  getClientSiteDetail(clientId: number, siteId: number) {
    this.clientService.getSiteById(clientId, siteId).subscribe((res) => {
      if (res.statusCode == 200 && res.results != null) {
        (this.name = res.results.name),
          (this.city = res.results.city),
          (this.state = res.results.state),
          (this.country = res.results.countryId),
          (this.phone = res.results.phone),
          (this.address = res.results.address),
          (this.siteNumber = res.results.siteNumber),
          (this.zone = res.results.timeZone),
          (this.postal = res.results.postalCode),
          (this.longitude = res.results.longitude),
          (this.latitude = res.results.latitude);
        (this.hqAddress = res.results.hqAddress);
      }
    });
    this.showform = !this.showform;
  }

  onSearch(event) {
   this.searchQuery$.next(event);
  }

  unCheckhqAddress($event) {
    let HQ = $event.checked;
    if (HQ == false) {
      this.clientService.checkClientHQ(this.clientId, this.siteId).subscribe({
        next: (res) => {
        },
        error: (e) => {
          console.log(e);
          this.hqAddress = true;
          this.toastr.error('This action cannot be performed.Please select another site location as your hq address');
        },

      });
    }

  }

  validateGeoCoordinatesFromAddress() {
    let address = this.address;
    if (address.trim().length == 0) {
      return
    }
    this.googleMapService.getGeoCoordinatesFromAddress(address)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          if (res.length > 0) {
            let geoResult = res[0];
            this.latitude = geoResult.Coordinates.lat;
            this.longitude = geoResult.Coordinates.lng;
            this.isValidAddress = true;
            this.patchTimeZone(geoResult);
          }
          else {
            this.toastr.error('Invalid location address');
            this.isValidAddress = false;
            return;
          }
        },
        error: (e) => {
          console.log(e);
          this.toastr.error('Something went wrong while validating location');
          this.isValidAddress = false;
          return;
        },
        complete: () => { },
      });
  }

  patchTimeZone(geoResult) {
    let comps = geoResult.Components;
    const parentIds = comps.map((x) => x.LongName);
    let tempZones: any[] = []
    let zone
    parentIds.forEach((element) => {
      zone = this.timeZoneS.filter((act) => {
        return act.standardName
          ?.toLocaleLowerCase()
          .includes(element.toLocaleLowerCase())
      });
      if (zone != undefined && zone.length > 0) {
        tempZones.push(zone);
      }
    });
    let aa = tempZones[0];
    if (aa[0] != null && aa[0].standardName != null) {
      this.zone = aa[0].standardName;
    }
  }

  validatePhone() {
    var regex = /^(\+?( |-|\.)?\d{1,2}( |-|\.)?)?(\(?\d{3}\)?|\d{3})( |-|\.)?(\d{3}( |-|\.)?\d{4})$/

    if (regex.test(this.phone.trim())) {
        this.isValidPhoneNumber=true;
    } else {
      this.isValidPhoneNumber=false;
      return
    }
  }
}
