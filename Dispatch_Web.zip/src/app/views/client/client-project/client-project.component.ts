import { Component, OnInit } from '@angular/core';
import { TableModel } from 'carbon-components-angular';

@Component({
  selector: 'app-client-project',
  templateUrl: './client-project.component.html',
  styleUrls: ['./client-project.component.css']
})
export class ClientProjectComponent implements OnInit {
  ticketsTableModel = new TableModel();
  showDocumentSkeleton: boolean = true;
  constructor() { }

  ngOnInit(): void {
  }

}
