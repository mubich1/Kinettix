import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-pricing',
  templateUrl: './client-pricing.component.html',
  styleUrls: ['./client-pricing.component.css']
})
export class ClientPricingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
