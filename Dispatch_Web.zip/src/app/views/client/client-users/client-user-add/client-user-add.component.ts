import { Component, OnInit, ViewEncapsulation, EventEmitter, Output } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ClientUserService } from 'src/app/services/clientuser/client-user.service';
import { ToastrService } from 'ngx-toastr';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';
import { ListItem } from 'carbon-components-angular';
import * as _ from 'lodash';
import { UserService } from 'src/app/services/user/user.service';
import { LoaderService } from 'src/app/services/loader/loader.service';
import { ApplicationTypeEnum } from 'src/app/shared/enum/application-type-enum';
import { ApplicationTypes } from 'src/app/services/user/models/user-application-information';
@Component({
  selector: 'app-client-user-add',
  templateUrl: './client-user-add.component.html',
  styleUrls: ['./client-user-add.component.css'],
  encapsulation: ViewEncapsulation.None,

})
export class ClientUserAddComponent implements OnInit {
  carbonUtility = new CarbonUtility();
  form: FormGroup;
  submitted: boolean;
  areDatesValid: boolean;
  dateRangeDisabled: boolean = false;
  format = 'MM/dd/yyyy';
  locale = 'en-US';
  tenants: any = [];
  isLoading = false;
  applicationTypes: ListItem[]
  vendors: any = [];
  clients: any = [];
  endClients: any = [];
  technicians: any = [];
  id: any;
  user: any;
  clientId: any;
  clientUserId: any;
  newuserId: string;
  clientstatus: string;

  @Output() addItem = new EventEmitter<any>();
  constructor(private formBuilder: FormBuilder,
    private router: Router,
    private toaster: ToastrService,
    private userService: UserService,
    private clientUserService: ClientUserService,
    private activatedRoute: ActivatedRoute,
    private loaderService: LoaderService) {
    this.id = this.activatedRoute.snapshot.paramMap.get('id');
    this.clientId = this.activatedRoute.parent?.snapshot.paramMap.get('clientId');
    this.clientUserId = this.activatedRoute.parent?.parent?.snapshot.paramMap.get('clientUserId');
    this.applicationTypes =
      this.carbonUtility.getListItems([{ text: "Client Portal", value: "Client Portal" }], 'text', 'value');
  }

  ngOnInit(): void {
    this.newuserId = Math.random().toString();
    this.clientId = this.activatedRoute.parent != null ? this.activatedRoute.parent.snapshot.paramMap.get('clientId') : 0;

    this.form = this.formBuilder.group({
      id: [null],
      businessPhones: [null, [Validators.pattern(/^-?(0|[0-9]\d*)?$/)]],
      displayName: ['', [Validators.required]],
      givenName: ['', []],
      jobTitle: [null,],
      mail: [null, [Validators.required, Validators.email, Validators.pattern("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$")]],
      mobilePhone: [null, [Validators.required, Validators.pattern(/^-?(0|[0-9]\d*)?$/)]],
      preferredLanguage: [null, []],
      surname: ['', [Validators.required]],
      userPrincipalName: [null, []],
      applicationTypes: ["", [Validators.required]],
      vendorId: [null, []],
      clientId: [null, []],
      techId: [null, []],
      endClientId: [null, []],
      active: [true],
      arap: [false]

    });

    this.getClientParentStatus(this.clientId);
  }
  get f() {
    return this.form.controls;
  }
  saveTemp() {
    let request = _.cloneDeep(this.form.value);
    var item: any = {};
    item.clientId = this.clientId;
    item.user = request
    item.uuid = this.newuserId;
    this.clientUserService.clientUserbroadCast(item)
  }
  onSubmit() {
    debugger
    this.submitted = true;
    if (this.form.invalid) {
      return;
    }
    let request = _.cloneDeep(this.form.value);
    const appicationType = [{
      id: ApplicationTypes.clientPortal,
      name: this.form.value.applicationTypes
    }]
    request.applicationTypes = appicationType;
    request.clientId = this.clientId;
    this.loaderService.show();
    this.userService.saveB2CUser(request).subscribe({
      next: (res) => {
        if (res.results.id) {
          res.results.clientId=this.clientId;

          delete res.results.applicationTypes;
          var appTypes: any[] = [{
            id: ApplicationTypeEnum.Client_Portal,
            name: this.form.value.applicationType,
          }];
          res.results['applicationType'] = appTypes;

          this.userService.SaveApplicationsUsers(res.results).subscribe({
            next: (res) => {
              if (this.clientstatus == 'Prospect') {
                this.clientUserService.checkClientStatus(this.clientId).subscribe({
                  next: (res) => {
                  },
                });
              }
              this.loaderService.hide();
              this.toaster.success("User created successfully");
              this.clientUserService.clientUserbroadCast(null)
              this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
                this.router.navigate(["/clients/client-users/" + this.clientId]).then(() => {
                  //console.log(`After navigation I am on:${this.router.url}`)
                })
              })

            },
            error: (err) => {
              this.loaderService.hide();
              this.toaster.error(err.error?.message != "" ? err.error?.message : "Error creating user")
            },
          });

        }
      },
      error: (err) => {
        this.loaderService.hide();
        this.showDuplicateMessage(err.error?.message)
        // this.toaster.error(err.error?.message!=""?err.error?.message:"Error creating user")
      },
    });

  }
  showDuplicateMessage(errorMessage) {
    var initialErrorMessage = errorMessage;
    var isContainSubstr = initialErrorMessage.includes(
      'Another object with the same value for property userPrincipalName already exists'
    );

    var finalErrorMessage = '';
    if (isContainSubstr) {
      finalErrorMessage = 'This email is being used by another user';
    } else {
      finalErrorMessage = initialErrorMessage;
    }

    this.toaster.error(
      finalErrorMessage != '' ? finalErrorMessage : 'Error creating user'
    );
  }
  onCancel() {
    this.clientUserService.clientUserbroadCast(null)
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigate(["/clients/client-users/" + this.clientId]).then(() => {
        //console.log(`After navigation I am on:${this.router.url}`)
      })
    })
  }
  getClientParentStatus(clientid: number) {
    this.clientUserService.getClientStatus(clientid).subscribe({
      next: (res) => {
        console.log(res.results.statusName)
        this.clientstatus = res.results.statusName;
      },
    });
  }
}

