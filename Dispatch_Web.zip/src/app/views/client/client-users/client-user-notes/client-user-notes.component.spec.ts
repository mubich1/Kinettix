import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientUserNotesComponent } from './client-user-notes.component';

describe('ClientUserNotesComponent', () => {
  let component: ClientUserNotesComponent;
  let fixture: ComponentFixture<ClientUserNotesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClientUserNotesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientUserNotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
