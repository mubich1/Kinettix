import { Component, OnInit, ViewChild } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject, takeUntil } from 'rxjs';
import { Notes, NotesRequest } from 'src/app/models/common/notes';
import { ClientService } from 'src/app/services/client/client.service';
import { NotesComponent } from '../../../shared/notes/notes.component';
import { UsernoteService } from 'src/app/services/usernote/usernote.service';
import { UserNote } from 'src/app/models/usernote/usernote';
import { ClientUserService } from 'src/app/services/clientuser/client-user.service';

@Component({
  selector: 'app-client-user-notes',
  templateUrl: './client-user-notes.component.html',
  styleUrls: ['./client-user-notes.component.css'],
})
export class ClientUserNotesComponent implements OnInit {
  @ViewChild('cref') cref: NotesComponent;
  parent = 'clientuser';
  selectedDeleteNoteId: number = 0;
  clientId: any;
  clientuserId: any;
  noteId: number = 0;

  ngUnsubscribe = new Subject<void>();
  notesList: Notes[] = [];
  template: NotesRequest[] = [];

  currentUserId: any;
  currentClientId: any;
  currentClientUserIdString: any;

  getNotes(clientId: number) {
    this.clientId = this.currentClientId;
    if(clientId > 0){
      this.getClientNotes();
    }
  }
  getById(noteId: number) {
    this.noteId = noteId;
    this.getNoteById(noteId);
  }
  saveNote(template) {
    this.template = template;
    this.saveUpdateClient(template);
  }
  deleteNote(selectedDeleteNoteId) {
    this.selectedDeleteNoteId = selectedDeleteNoteId;
    this.deleteSelectedClient();
  }
  constructor(
    private userNoteService: UsernoteService,
    private clientService: ClientService,
    private clientUserService: ClientUserService,
    private activatedRoute: ActivatedRoute,
    private toastr: ToastrService
  ) {}

  ngOnInit(): void {
    this.clientId =
      this.activatedRoute.parent?.parent != null
        ? this.activatedRoute.parent.parent.snapshot.paramMap.get('clientId')
        : 0;
    this.clientuserId =
      this.activatedRoute.parent != null
        ? this.activatedRoute.parent.snapshot.params['clientuserId']
        : 0;

    this.currentClientId = this.clientId;
    if(this.clientuserId > 0 ) {
      this.getCurrentClientUserIdString();
    }
    
  }

  getClientNotes() {
    this.notesList = [];
    this.userNoteService
      .get()
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          if (res !== null) {
            var allItems = res.results;
            var notesPerUser = allItems.filter(
              (s) => s.userId === this.currentClientUserIdString
            );
            notesPerUser.forEach((data) => {
              this.notesList.push(data);
            });

            var notesList: Notes[] = [];
            notesPerUser.forEach((note) => {
              var noteObj = {
                id: note.id,
                name: note.noteTitle,
                description: note.noteBody,
                clientId: note.clientId,
                createdDate: note.createdDate,
                createdBy: note.createdBy,
                modifiedDate: note.modifiedDate,
              } as Notes;
              notesList.push(noteObj);
            });

            this.cref.populateTable(notesList);
          }
        },
        error: () => {
          this.toastr.error('Something went wrong');
        },
        complete: () => {},
      });
  }
  getNoteById(id: any) {
    var noteToEdit = this.notesList.filter((s) => s.id == id);
    var noteObj = {
      id: noteToEdit[0]['id'],
      name: noteToEdit[0]['noteTitle'],
      description: noteToEdit[0]['noteBody'],
      clientId: noteToEdit[0]['clientId'],
      createdDate: new Date(noteToEdit[0]['createdDate']),
      createdBy: noteToEdit[0]['createdBy'],
      modifiedDate: new Date(String(noteToEdit[0]['modifiedDate'])),
    } as Notes;
    this.cref.updateNote(noteObj);
  }

  saveUpdateClient(template, isDelete = false) {
    var noteObj = new UserNote();
    noteObj.id = template.id;
    noteObj.userId = this.currentClientUserIdString;
    noteObj.clientId = this.currentClientId;
    noteObj.noteTitle = template.name;
    noteObj.noteBody = template.description;
    noteObj.modifiedBy = this.currentUserId;
    noteObj.createdBy = this.currentUserId;

    if (template.id != null && template.id > 0) {
      var noteToUpdate = this.notesList.filter((s) => s.id == template.id);
      noteObj.createdDate = noteToUpdate[0]['createdDate'];
      noteObj.modifiedDate = new Date();
      noteObj.deleted = isDelete;

      this.userNoteService.update(noteObj).subscribe({
        next: (res) => {
          if (res.message == 'Success') {
            this.cref.showform = false;
            this.toastr.success('Note is sucessfully updated .');
            this.cref.initializeTable();
            this.cref.createNotesForm();
            this.getClientNotes();

            if (isDelete === true) {
              this.cref.closeParentModal();
            }
          }
        },
        error: (res) => {},
        complete: () => {},
      });
    } else {
      this.userNoteService.create(noteObj).subscribe({
        next: (res) => {
          if (res.message == 'Success') {
            this.cref.showform = false;
            this.toastr.success('Note is sucessfully added.');
            this.cref.initializeTable();
            this.cref.createNotesForm();
            this.getClientNotes();
          }
        },
        error: (res) => {},
        complete: () => {},
      });
    }
  }

  deleteSelectedClient() {
    var noteToDelete = this.notesList.filter(
      (s) => s.id == this.selectedDeleteNoteId
    );
    var noteObj = {
      id: noteToDelete[0]['id'],
      name: noteToDelete[0]['noteTitle'],
      description: noteToDelete[0]['noteBody'],
      clientId: noteToDelete[0]['clientId'],
      createdDate: new Date(noteToDelete[0]['createdDate']),
      createdBy: noteToDelete[0]['createdBy'],
      modifiedDate: new Date(String(noteToDelete[0]['modifiedDate'])),
    } as Notes;
    this.saveUpdateClient(noteObj, true);
  }

  getCurrentUserId() {
    const getUserFromLocalStorage = () => {
      try {
        return JSON.parse(localStorage.getItem('userId') || '');
      } catch (error) {
        return null;
      }
    };
    this.currentUserId = getUserFromLocalStorage();
  }

  getCurrentClientUserIdString() {
    this.clientUserService
      .getClientUserById(this.currentClientId, this.clientuserId)
      .subscribe({
        next: (res) => {
          var res = res.results;
          var clientUserIdString = res.userId;
          this.currentClientUserIdString = clientUserIdString;
        },
        error: () => {},
        complete: () => {},
      });
  }
}
