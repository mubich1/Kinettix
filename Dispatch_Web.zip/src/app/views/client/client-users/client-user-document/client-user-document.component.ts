import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TableHeaderItem, TableItem, TableModel } from 'carbon-components-angular';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';
import { ClientUserDocument, ClientUserDocumentRequest, ClientDocumentsType } from 'src/app/models/client/client';
import { AllowdDocTypes } from 'src/app/models/common/common';
import { ClientUserService } from 'src/app/services/clientuser/client-user.service';
import { CommonService } from 'src/app/services/common/common.service';
import { DealDocumentService } from 'src/app/services/document/deal-document.service';
import { AngularUtility } from 'src/app/shared/common/angular-utitilty';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';
import { DatePipe } from '@angular/common';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { TableFilters } from 'src/app/shared/common/tableFilters';
import { Subscription } from 'rxjs';
import { LoaderService } from 'src/app/services/loader/loader.service';
import { ModuleNameEnum } from 'src/app/shared/enum/module-name-enum';

@Component({
  selector: 'app-client-user-document',
  templateUrl: './client-user-document.component.html',
  styleUrls: ['./client-user-document.component.css']
})
export class ClientUserDocumentComponent implements OnInit {
  numRegex = /^\d{0,14}[.,]?\d{0,2}$/;
  showTypeSkeleton: boolean = true;
  docsForm: FormGroup;
  ngUnsubscribe = new Subject<void>();
  documentList: ClientUserDocument[] = [];
  documentsList: any[] = [];
  EditDoc: any;
  documentTableModel = new TableModel();
  documentTableData: TableItem[][] = [];
  showDocumentSkeleton: boolean = true;
  documentType: ClientDocumentsType;
  clientUserId: number = 0;
  showform: boolean = false;
  files = new Set<any>();
  selectedDeleteDocId: number = 0;
  isOpenDeleteModal = false;
  isOpenAddModal = false;
  isMsa: boolean = false;
  isPoDoc: boolean = false;
  carbonUtility = new CarbonUtility();
  fileTypes: string[] = AllowdDocTypes.extensions;
  documnetTypeList: ClientDocumentsType[];
  @ViewChild('customHeaderDoc', { static: true }) customHeaderDoc: ElementRef;
  @ViewChild('customHeaderDocIsInternal', { static: true }) customHeaderDocIsInternal: ElementRef;
  @ViewChild('customViewDoc', { static: true }) customViewDoc: ElementRef;
  @ViewChild('customItemNameDoc', { static: true })
  customItemNameTerm: ElementRef;
  angularUtility = new AngularUtility();
  //for pagination
  tableFilters: TableFilters = new TableFilters();
  isAscending: boolean = false;
  isSorted: boolean = false;
  sortIndex: number = 0;
  pageNo: any;
  documents: TableItem[][] = [];
  subscription$: Subscription = new Subscription();
  isInternal: Boolean = true;

  constructor(
    public datepipe: DatePipe,
    private clientUserService: ClientUserService,
    private documentService: DealDocumentService,
    private commonService: CommonService,
    private route: ActivatedRoute,
    private toastr: ToastrService,
    private formBuilder: FormBuilder,
    private loaderService: LoaderService
  ) { }

  ngOnInit(): void {
    this.route.parent?.params.subscribe((params: any) => {
      if (params.hasOwnProperty('clientuserId')) {
        this.clientUserId = params['clientuserId'];
        this.docsForm = new FormGroup({
          id: new FormControl(''),
          name: new FormControl('', [Validators.required, Validators.maxLength(250)]),
          description: new FormControl('', Validators.maxLength(500)),
          docType: new FormControl('', Validators.required),
          url: new FormControl(''),
          created: new FormControl(''),
          signatureDate: new FormControl(''),
          expirationDate: new FormControl(null),
          poNumber: new FormControl('', Validators.maxLength(99)),
          poValue: new FormControl('', [Validators.pattern(this.numRegex)]),
        });
        this.intializeForm();
        this.getDocumentTypes();
        if(this.clientUserId > 0){
        this.populateDocumentTable();
        this.getDocumentTypes();
        }
      }
    });

  }
  intializeForm() {
    this.docsForm = this.formBuilder.group({
      id: [0],
      name: ['', [Validators.required, Validators.maxLength(250)]],
      description: ['', Validators.maxLength(500)],
      docType: [null, Validators.required],
      url: [''],
      created: [null],
      signatureDate: [null],
      expirationDate: [null],
      poNumber: [null, Validators.maxLength(99)],
      poValue: [null, Validators.pattern(this.numRegex)],
    });
  }

  selectedDocumentType(event) {
    if (event.value === 'MSA') {
      this.docsForm.get('signatureDate')?.setValidators([Validators.required]);
      this.docsForm.get('signatureDate')?.updateValueAndValidity();
      this.isMsa = true;
    }
    else {
      this.isMsa = false;
      this.docsForm.get('signatureDate')?.setValidators([Validators.nullValidator]);
      this.docsForm.get('signatureDate')?.updateValueAndValidity();
      this.docsForm.patchValue({ signatureDate: null });
    }

    if (event.value == 'Purchase Order') {
      this.docsForm.get('poNumber')?.setValidators([Validators.required, Validators.maxLength(99)]);
      this.docsForm.get('poValue')?.setValidators([Validators.pattern(this.numRegex)]);
      this.docsForm.get('poNumber')?.updateValueAndValidity();
      this.docsForm.get('poValue')?.updateValueAndValidity();
      this.isPoDoc = true;
    }
    else {
      this.isPoDoc = false;
      this.docsForm.get('poNumber')?.setValidators([Validators.nullValidator]);
      this.docsForm.get('poNumber')?.updateValueAndValidity();
      this.docsForm.patchValue({ poNumber: null, poValue: null, expirationDate: null });
    }

  }

  InitializeDocumentDealTable() {
    if (this.documentList && this.documentList.length) {
      for (let document of this.documentList) {
        let rows: any = [];
        this.carbonUtility.setTableItem(rows, document.id);

        this.carbonUtility.setTableItem(rows, document.name);

        rows.push(new TableItem({ data: this.datepipe.transform(document.createdDate, 'MM/dd/yyyy'), }));

        rows.push(new TableItem({ data: document.expiration == null ? '' : this.datepipe.transform(document.expiration, 'MM/dd/yyyy'), }));
        rows.push(new TableItem({ data: { url: this.clientUserService.getDocumentDownloadUrl(document.id), name: document.name }, template: this.customViewDoc }));
        rows.push(new TableItem({ data: document, template: this.customHeaderDocIsInternal }));
        rows.push(new TableItem({ data: document, template: this.customHeaderDoc }));
        this.documentTableData.push(rows);
      };
    }
    const headers = ["ID", "NAME", "CREATED", "EXPIRATION", "VIEW", 'INTERNAL', "ACTION"];
    this.documentTableModel = this.carbonUtility.setTableModel(headers, this.documentTableModel, this.documentTableData, this.documentTableModel.pageLength, this.documentTableModel.currentPage, this.documentTableModel.totalDataLength);
    this.documentTableModel.header[this.documentTableModel.header.length - 1].sortable = false;
    this.documentTableModel.header[0] = new TableHeaderItem({ data: "ID", visible: false })


    this.documentTableModel.header[this.documentTableModel.header.length - 1].style = { "backgroundColor": "#f4f4f4" };
    this.documents = [...this.documentTableModel.data];
  }

  populateDocumentTable(sort = false, index: number = 0) {
    this.subscription$.add(this.clientUserService.getDocumentsByClientUserId(this.clientUserId, this.tableFilters).subscribe((res) => {
      if (res) {
        this.showDocumentSkeleton = false;
        console.log(res.results)
        this.documentTableData = [];
        this.documentList = res.results.data;
        this.documentTableModel.totalDataLength = res.results.total;
        this.InitializeDocumentDealTable();
        if (sort) {
          this.documentTableModel.header[index].descending = !this.isAscending;
          this.documentTableModel.sort(index);
        }
      }
    },
      (err) => {
        this.showDocumentSkeleton = false;
        this.InitializeDocumentDealTable();
        this.toastr.error('Something went wrong while loading Client documents', 'Error');
      }));
  }
  onSort(index: number) {
    this.isAscending = !this.isAscending;
    this.sortIndex = index;
    this.isSorted = true;
    this.tableFilters.sort = this.documentTableModel.header[index].data;
    this.tableFilters.isAscending = this.isAscending;
    this.populateDocumentTable(true, index);
  }
  onSearch(event: any) {
    this.tableFilters.search = event ? event : '';
    this.documentTableModel.currentPage = 1;
    this.tableFilters.page = 1;
    this.populateDocumentTable(this.isSorted, this.sortIndex);
  }
  onClearSearch() {
    this.tableFilters.search = '';
    this.populateDocumentTable(this.isSorted, this.sortIndex);
  }
  deleteDoc(value: ClientUserDocumentRequest) {

    const doc = value.id!;
    if (doc > 0) {
      this.selectedDeleteDocId = doc;
      this.openParentModal();
    } else {
      this.selectedDeleteDocId = 0;
    }
  }
  onConfirmationDelete() {
    this.clientUserService
      .deleteDocumentById(this.selectedDeleteDocId)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          this.toastr.success('Deleted Successfully');
          this.populateDocumentTable(this.isSorted, this.sortIndex);
        },
        error: (e) => {
          console.log(e);
          this.toastr.error('Something went wrong');
        },
        complete: () => this.closeParentModal(),
      });
  }
  openParentModal() {
    this.isOpenDeleteModal = true;
  }
  closeParentModal() {
    this.isOpenDeleteModal = false;
    this.selectedDeleteDocId = 0;
  }
  closeSaveModal() {
    this.docsForm.reset();
    this.intializeForm();
    this.isOpenAddModal = false;
    this.showform = false;
    this.isMsa = false;
    this.isPoDoc = false;
  }
  onClickRow(value: ClientUserDocumentRequest) {
    const docId = value.id!;
    if (docId > 0) {
      this.showform = true;
      this.isOpenAddModal = true;
      this.updateDocument(docId);
    } else {
      this.onUpload();
    }
  }
  onDownload(data) {
    this.commonService.downloadDocument(data.url, data.name)
  }
  updateDocument(docId) {
    this.clientUserService.getDocumentByDocumentId(docId)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          if (res.results !== null) {
            this.EditDoc = res.results;
            if (this.getTypeName(this.EditDoc.documentType) == 'MSA') {
              this.isMsa = true;
            }
            if (this.getTypeName(this.EditDoc.documentType) == 'Purchase Order') {
              this.isPoDoc = true;
            }

            if (this.EditDoc != null) {
              this.isInternal = this.EditDoc.isInternal
              this.docsForm.patchValue({
                id: this.EditDoc.id,
                name: this.EditDoc.name,
                description: this.EditDoc.description,
                docType: this.getTypeName(this.EditDoc.documentType),
                url: this.EditDoc.url,
                created: this.EditDoc.created,
                poNumber: this.EditDoc.poNumber,
                poValue: this.EditDoc.poValue,
                isInternal: this.isInternal,
              });
              if (this.getTypeName(this.EditDoc.documentType) == 'MSA') {
                this.docsForm.controls['signatureDate'].patchValue(
                  new Date(this.EditDoc.signatureDate)
                );
              }
              if (this.getTypeName(this.EditDoc.documentType) == 'Purchase Order') {
                this.docsForm.controls['expirationDate'].patchValue(
                  this.EditDoc.expiration ? new Date(this.EditDoc.expiration) : null
                );
              }
            }
          }
        },
        error: (e) => {
          console.log(e);
          this.toastr.error('Something went wrong while loading Client documents');
        },
        complete: () => { },
      });
  }
  selectPage(page: any) {
    this.documentTableModel.currentPage = page;
    this.tableFilters.pageSize = this.documentTableModel.pageLength;
    this.tableFilters.page = page;
    this.populateDocumentTable(this.isSorted, this.sortIndex);
  }

  getDocumentTypes() {
    this.commonService.getDocumentDefinitionTypes()
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          if (res.message == "Success" && res != null) {
            this.documnetTypeList = res.results;
          }
        },
        error: e => {
          this.showTypeSkeleton = false;
          console.log(e);
        },
        complete: () => {
          this.showTypeSkeleton = false;
        }
      });
  }

  createDocument(document) {
    this.documentService.uploadDocument(document)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          const clientDoc: ClientUserDocumentRequest = {
            id: 0,
            clientUserId: this.clientUserId,
            name: document.name,
            url: res.document.path,
            documentType: document.docType,
            description: document.description,
            created: document.created,
            signatureDate: this.isMsa ? new Date(this.docsForm.value.signatureDate) : null,
            poNumber: this.isPoDoc ? document.poNumber : null,
            poValue: this.isPoDoc ? document.poValue : null,
            isInternal: this.isInternal,
            expiration: this.isPoDoc ? this.docsForm.value.expirationDate ? new Date(this.docsForm.value.expirationDate) : null : null,
          };

          this.clientUserService.createDocument(clientDoc, this.clientUserId)
            .pipe(takeUntil(this.ngUnsubscribe)).subscribe({
              next: (res) => {
                if (res !== null) {
                  this.docsForm.reset();
                  this.showform = false;
                  this.isOpenAddModal = false;
                  this.isMsa = false;
                  this.isPoDoc = false;
                  this.toastr.success('Document is sucessfully added.');
                  this.populateDocumentTable();
                }
              },
              error: (err) => {
                this.toastr.error((err.error.message || "Something went wrong."), 'Error');
              },
              complete: () => { },
            });
        },
      });
  }

  updateDocumentSave(document) {
    this.clientUserService.updateDocument(document, this.clientUserId)
      .pipe(takeUntil(this.ngUnsubscribe)).subscribe({
        next: (res) => {
          if (res !== null) {
            this.docsForm.reset();
            this.showform = false;
            this.isOpenAddModal = false;
            this.isMsa = false;
            this.isPoDoc = false;
            this.toastr.success('Document is sucessfully updated.');
            this.populateDocumentTable(this.isSorted, this.sortIndex);
          }
        },
        error: (err) => {
          this.toastr.error((err.error.message || "Something went wrong."), 'Error');
        },
        complete: () => { },
      });
  }

  updateDocumentSaveWithFile(document) {
    this.documentService.uploadDocument(document)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          const clientDoc: ClientUserDocumentRequest = {
            id: this.docsForm.value.id,
            clientUserId: this.clientUserId,
            name: document.name,
            url: res.document.path,
            documentType: document.docType,
            description: document.description,
            created: document.created,
            signatureDate: this.isMsa ? new Date(this.docsForm.value.signatureDate) : null,
            poNumber: document.poNumber,
            poValue: document.poValue,
            isInternal: this.isInternal,
            expiration: this.isPoDoc ? this.docsForm.value.expirationDate ? new Date(this.docsForm.value.expirationDate) : null : null,
          };

          this.clientUserService.updateDocument(clientDoc, this.clientUserId)
            .pipe(takeUntil(this.ngUnsubscribe)).subscribe({
              next: (res) => {
                if (res !== null) {
                  this.showform = false;
                  this.isOpenAddModal = false;
                  this.toastr.success('Document is sucessfully Updated.');
                  this.populateDocumentTable(this.isSorted, this.sortIndex);
                }
              },
              error: (err) => {
                this.toastr.error((err.error.message || "Something went wrong."), 'Error');
              },
              complete: () => { },
            });
        },
      });
  }

  onUpload() {
    const document = {
      id: this.docsForm.value.id,
      clientId: this.clientUserId,
      name: this.docsForm.value.name,
      description: this.docsForm.value.description,
      url: this.docsForm.value.url,
      documentType: this.getTypeId(),
      created: this.docsForm.value.created,
      signatureDate: this.isMsa ? new Date(this.docsForm.value.signatureDate) : null,
      poNumber: this.docsForm.value.poNumber,
      poValue: this.docsForm.value.poValue,
      isInternal: this.isInternal,
      moduleName: ModuleNameEnum.ClientUser,
      expiration: this.isPoDoc ? this.docsForm.value.expirationDate ? new Date(this.docsForm.value.expirationDate) : null : null,
    };


    var poNumber = this.docsForm.value.poNumber?.trim();
    if (this.isPoDoc == true && this.docsForm.valid && poNumber?.length == 0) {
      this.toastr.error('PO Number fields is required');
      return;
    }

    var docName = this.docsForm.value.name.trim();
    if (this.docsForm.valid && docName?.length == 0) {
      this.toastr.error('Name is invalid');
    }

    else {
      if (this.files.size == 0) {
        if (this.docsForm.value.id > 0) {
          this.updateDocumentSave(document);
        }
        else {
          this.toastr.error('Please add document.');
        }
      }
      else {
        this.files.forEach((fileItem) => {

          const extension = fileItem.file.name.split('.').pop().toLowerCase();

          if (!this.fileTypes.some(s => s.includes(extension))) {
            this.toastr.error('Invalid File Extension.');
            return;
          }

          if (fileItem.file.size < 50000000) {
            setTimeout(() => {
              fileItem.state = 'complete';
              fileItem.uploaded = true;
            }, 1500);

            const reader = new FileReader();

            reader.readAsDataURL(fileItem.file);
            reader.onload = () => {
              let base64 = reader.result?.toString();

              if (base64 == 'data:') {
                this.toastr.error("Invalid or empty file.");
                return;
              }

              const document = {
                id: this.docsForm.value.id,
                name: `${this.docsForm.value.name.split('.')[0]}.${extension}`,
                description: this.docsForm.value.description,
                filebase64string: base64 !== undefined ? base64.toString() : null,
                type: this.docsForm.value.docType,
                docType: this.getTypeId(),
                created: this.docsForm.value.created,
                signatureDate: this.isMsa ? new Date(this.docsForm.value.signatureDate) : null,
                poNumber: this.isPoDoc ? this.docsForm.value.poNumber : null,
                poValue: this.isPoDoc ? this.docsForm.value.poValue : null,
                isInternal: this.isInternal,
                moduleName: ModuleNameEnum.ClientUser,
                expirationDate: this.isPoDoc ? this.docsForm.value.expirationDate ? new Date(this.docsForm.value.expirationDate) : null : null,
              };
              if (this.docsForm.value.id !== null && this.docsForm.value.id !== 0) {
                this.updateDocumentSaveWithFile(document);
              }
              else {
                this.createDocument(document);
              }
            };
          }
        });
      }
    }
  }

  getTypeId() {
    return this.documnetTypeList.filter(x => x.name == this.docsForm.value.docType)[0].id;
  }

  getTypeName(id: number) {
    return this.documnetTypeList.filter(x => x.id == id)[0].name;
  }

  addDocumentModel() {
    this.isInternal = true;
    this.isOpenAddModal = true;
    this.ShowForm();
  }

  ShowForm() {
    if (!this.showform) {
      this.intializeForm();
    }

    this.showform = !this.showform;
  }

  get f(
  ) {
    return this.docsForm.controls;
  }

  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }
}





