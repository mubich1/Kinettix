import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientUserDocumentComponent } from './client-user-document.component';

describe('ClientUserDocumentComponent', () => {
  let component: ClientUserDocumentComponent;
  let fixture: ComponentFixture<ClientUserDocumentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClientUserDocumentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientUserDocumentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
