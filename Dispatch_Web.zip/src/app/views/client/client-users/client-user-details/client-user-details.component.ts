import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Client } from 'src/app/models/client/client';
import { ClientUserService } from 'src/app/services/clientuser/client-user.service';
import { Subject, takeUntil } from 'rxjs';
import { UtilityService } from 'src/app/services/utility/utility.service';

@Component({
  selector: 'app-client-user-details',
  templateUrl: './client-user-details.component.html',
  styleUrls: ['./client-user-details.component.css']
})
export class ClientUserDetailsComponent  implements OnInit {
  constructor() { 
  }

  ngOnInit(): void {
    
  }

  
}
  
