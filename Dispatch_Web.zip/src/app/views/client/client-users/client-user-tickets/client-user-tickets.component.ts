import { Component, OnInit } from '@angular/core';
import { TableModel,Table } from 'carbon-components-angular';

@Component({
  selector: 'app-client-user-tickets',
  templateUrl: './client-user-tickets.component.html',
  styleUrls: ['./client-user-tickets.component.css']
})
export class ClientUserTicketsComponent implements OnInit {
  ticketsUserTableModel = new TableModel();
  showDocumentSkeleton: boolean = true;
  constructor() { }

  ngOnInit(): void {
    this.ticketsUserTableModel = Table.skeletonModel(1, 1);
    this. showDocumentSkeleton=false;
  }

}
