import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientUserTicketsComponent } from './client-user-tickets.component';

describe('ClientUserTicketsComponent', () => {
  let component: ClientUserTicketsComponent;
  let fixture: ComponentFixture<ClientUserTicketsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClientUserTicketsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientUserTicketsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
