import { Component, OnInit,ViewEncapsulation } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import * as _ from 'lodash';
import { ClientUserService } from 'src/app/services/clientuser/client-user.service';
import { UserService } from 'src/app/services/user/user.service';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';
import { ListItem } from 'carbon-components-angular';
import { LoaderService } from 'src/app/services/loader/loader.service';
import { Subject, takeUntil } from 'rxjs';
import { UtilityService } from 'src/app/services/utility/utility.service';
@Component({
  selector: 'app-client-user-edit',
  templateUrl: './client-user-edit.component.html',
  styleUrls: ['./client-user-edit.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class ClientUserEditComponent implements OnInit {
  ngUnsubscribe = new Subject<void>();
  form: FormGroup;
  passwordResetForm: FormGroup;
  submitted: boolean;
  areDatesValid: boolean;
  dateRangeDisabled: boolean = false;
  format = 'MM/dd/yyyy';
  locale = 'en-US';
  tenants: any = [];
  isLoading = false;
  applicationTypes:ListItem[]
  vendors: any = [];
  clients: any = [];
  endClients: any = [];
  technicians: any = [];
  id: any;
  user: any;
  clientId: any;
  clientUserId: any=0;
  userId: any;
  isOpenDeleteModal = false;
  isOpenResetPasswordModal = false;
  isOpenResetPasswordConfirmationModal = false;
  isShowLoaderModal = false;
  isOpenAddModal = false;
  carbonUtility = new CarbonUtility();
  newPassword = '';
  confirmPassword = '';
  isUpdate: boolean;
  isResetPassword:boolean;
  constructor(private formBuilder: FormBuilder,
    private router: Router,
    private clientUserService: ClientUserService,
    private userService: UserService,
    private activatedRoute: ActivatedRoute,
    private toastr: ToastrService, private loaderService: LoaderService,
    private utility:UtilityService
    ) {
      this.applicationTypes=
      this.carbonUtility.getListItems([{text:"Client Portal",value:"Client Portal"}], 'text', 'value');
      this.isUpdate = this.utility.hasPermission('Edit Client User');
      this.isResetPassword = this.utility.hasPermission('Edit Client User');
  }
  ngOnInit(): void {
    this.clientId = this.activatedRoute.parent?.parent != null ? this.activatedRoute.parent.parent.snapshot.paramMap.get('clientId') : 0;
    this.initializeForm();
    this.passwordResetForm = this.formBuilder.group({
      newPassword: [null, [Validators.required]],
      confirmPassword: [null, [Validators.required]],
    });
    this.activatedRoute.parent?.params.subscribe((params: any) => {
      if (params.hasOwnProperty('clientuserId')) {
        this.clientUserService.clientUserbroadCast({ removeNewItems: true })
        this.clientUserId = params['clientuserId'];
        if (this.clientUserId > 0) {
          this.getUser();
        } else {
          this.initializeForm();
        }

      }
    });
  }
  get f() {
    return this.form.controls;
  }
  get fResetPassword() {
    return this.passwordResetForm.controls;
  }


  initializeForm() {
    this.form = this.formBuilder.group({
      id: [null],
      businessPhones: [null, [Validators.required,Validators.pattern(/^-?(0|[0-9]\d*)?$/)]],
      displayName: [null,  [Validators.required]],
      givenName: [null, []],
      jobTitle: [null],
      mail: [null, [Validators.required,Validators.email,Validators.pattern("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$")]],
      mobilePhone: [null,[Validators.required,Validators.pattern(/^-?(0|[0-9]\d*)?$/)]],
      preferredLanguage: [null, []],
      surname: [null, [Validators.required]],
      userPrincipalName: [null, []],
      applicationType: ["", [Validators.required]],
      vendorId: [null, []],
      clientId: [null, []],
      techId: [null, []],
      endClientId: [null, []],
      active: [true],
      arap:[false],
      userId:["",[Validators.required]]
    });
  }
  onSubmit() {
    this.isLoading = true;
    this.submitted = true;
    if (this.form.invalid) {
      return;
    }
    let request: any={};

    request.user = _.cloneDeep(this.form.value);
    request.id=this.clientUserId
    request.clientId=this.clientId
    request.userid=request.user.id;
    this.loaderService.show();
    this.userService.saveB2CUser(request.user).subscribe({
      next: (res) => {
        if (res.results.id) {
          this.clientUserService.updateClientById(request).subscribe({
            next: (res:any) => {
              this.loaderService.hide();
              if (res.message=="Success") {
                this.toastr.success("Client user updated successfully");
                // this.router.navigate(['clients/client-users/',+this.clientId])
                this.router.navigateByUrl('/',{skipLocationChange:true}).then(()=>{
                  this.router.navigate(["/clients/client-users/"+ this.clientId+"/details/", this.clientUserId]).then(()=>{
                              //console.log(`After navigation I am on:${this.router.url}`)
                            })
                          })

              }
            },
            error: (err) => {
              this.loaderService.hide();
              this.toastr.error(err.error?.message!=""?err.error?.message:"Error creating user")
            },
          });

        }
      },
      error: (err) => {
        this.loaderService.hide();

        this.showDuplicateMessage(err.error?.message)
    },
    });


  }
  showDuplicateMessage(errorMessage){
    var initialErrorMessage = errorMessage;
    var isContainSubstr = initialErrorMessage.includes(
      'A conflicting object with one or more of the specified property values is present in the directory'
    );

    var finalErrorMessage = '';
    if (isContainSubstr) {
      finalErrorMessage = 'This email is being used by another user';
    } else {
      finalErrorMessage = initialErrorMessage;
    }

    this.toastr.error(
      finalErrorMessage != '' ? finalErrorMessage : 'Error creating user'
    );
  }
  onCancel() {
    this.router.navigateByUrl('/',{skipLocationChange:true}).then(()=>{
      this.router.navigate(["/clients/client-users/"+ this.clientId+"/details/", this.clientUserId]).then(()=>{
                  //console.log(`After navigation I am on:${this.router.url}`)
                })
              })
  }
  getUser() {
    this.loaderService.show();
    this.clientUserService.getClientUserById(this.clientId,this.clientUserId).subscribe({
      next: (res) => {
        this.loaderService.hide();
        this.user = res.results;
        this.setupForm(this.user);

      }, error: (err) => {
        this.loaderService.hide();
      }
    });
  }
  setupForm(user) {
    console.log(this.user, "user")
    this.form.get('id')?.setValue(user.user.id);
    this.form.get('businessPhones')?.setValue(user.user.businessPhones);
    this.form.get('displayName')?.setValue(user.user.displayName);
    this.form.get('givenName')?.setValue(user.user.givenName);
    this.form.get('jobTitle')?.setValue(user.user.jobTitle);
    this.form.get('mail')?.setValue(user.user.mail);
    this.form.get('mobilePhone')?.setValue(user.user.mobilePhone);
    this.form.get('preferredLanguage')?.setValue(user.user.preferredLanguage);
    this.form.get('surname')?.setValue(user.user.surname);
    this.form.get('userPrincipalName')?.setValue(user.user.userPrincipalName);
    this.form.get('applicationType')?.setValue("Client Portal");
    this.form.get('arap')?.setValue(user.arap);
    this.form.get('userId')?.setValue(user.userId);

   // this.form.get('vendorId')?.setValue(user.vendorId);
    //this.onVendorchange();
    this.form.get('clientId')?.setValue(this.clientId);
   // this.form.get('techId')?.setValue(user.techId);
    //this.form.get('endClientId')?.setValue(user.endClientId);

  }

  openParentModal() {
    this.isOpenDeleteModal = true;
  }
  closeParentModal() {
    this.isOpenDeleteModal = false;
  }
  onConfirmationDelete() {
    this.loaderService.show();
    this.clientUserService
      .deleteClientUserById(this.clientUserId)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          this.toastr.success('Client user deleted successfully');
          this.loaderService.hide();
          this.router.navigateByUrl('/',{skipLocationChange:true}).then(()=>{
            this.router.navigate(['clients/client-users/',this.clientId]).then(()=>{
              //console.log(`After navigation I am on:${this.router.url}`)
            })
          })

        },
        error: (e) => {
          console.log(e);
          this.toastr.error('Something went wrong');
        },

        complete: () => this.closeParentModal(),
      });
  }

  openResetPasswordModal() {
    this.isOpenResetPasswordModal = true;
  }
  closeResetPasswordModal() {
    this.isOpenResetPasswordModal = false;
  }

  public submitResetPassword(){
    if(this.newPassword !== this.confirmPassword){
        this.toastr.error("Passwords don't match")
        return;
    }
    this.clientUserService.getClientUsersByClientId(this.clientId,0,'','','','','').subscribe({
        next : (res) => {
            if (res.message == 'Success' && res.results[0].userId != null) {
                var obj = {
                    userId : res.results[0].userId,
                    newPassword : this.newPassword,
                    forceChangePasswordNextSignIn : true
                }

                this.isShowLoaderModal = true;
                this.clientUserService.changePasswordClientUser(obj).subscribe({
                    next : (res) =>{
                        if(res.statusCode == 200){
                            this.toastr.success('Password changed successfully')
                            this.isOpenResetPasswordModal = false;
                            this.newPassword = ''
                            this.confirmPassword = ''
                        }
                    },
                    error : (res) => {
                        this.toastr.error('Something went wrong')
                    },
                    complete : () =>{
                        this.isShowLoaderModal = false;
                    }
                })

            }
        },
        error: (res) => {
            console.log(res)
            this.toastr.error("Something went wrong with this Client User's ID")
        }
    })
  }

  public submitResetPasswordv2(){
    this.userId= this.form.value?.userId;
    if(this.userId==null || this.userId==undefined || this.userId=="")
    {
      this.toastr.error("UserId not valid")
      return;
    }
    this.isShowLoaderModal = true;
    this.clientUserService.resetPasswordClientUser(this.userId).subscribe({
      next : (res) =>{
          if(res.statusCode == 200){
              console.log(res)
              this.toastr.success('Password changed successfully')
              this.isOpenResetPasswordConfirmationModal = false;
          }
      },
      error : (res) => {
          this.toastr.error('Something went wrong')
      },
      complete : () =>{
          this.isShowLoaderModal = false;
      }
  })
  }
}