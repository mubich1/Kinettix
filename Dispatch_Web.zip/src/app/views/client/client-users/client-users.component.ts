import { AfterViewInit, Component, ElementRef, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { ClientUserService } from 'src/app/services/clientuser/client-user.service';
import { Client } from 'src/app/models/client/client';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';
import { ToastrService } from 'ngx-toastr';
import { Subject,takeUntil } from 'rxjs';
import { TableModel,Table } from 'carbon-components-angular';
import { Router,ActivatedRoute } from '@angular/router';
import { ClientSite } from 'src/app/models/client/client-site';
import { UtilityService } from 'src/app/services/utility/utility.service';
import { countrySelectBox } from 'src/app/models/client/country-select-box';
import { LoaderService } from 'src/app/services/loader/loader.service';
import { UndefinedComponent } from '@carbon/icons-angular';

@Component({
  selector: 'app-client-users',
  templateUrl: './client-users.component.html',
  styleUrls: ['./client-users.component.css']
})
export class ClientUsersComponent implements OnInit,AfterViewInit {
  @ViewChildren('theLastList',{read:ElementRef})
  theLastList: QueryList<ElementRef>;
  selectedCountry;
  clientId: number = 0;
  clientUserId: number = 0;
  countries: countrySelectBox[] = [{ value: 0, text: '' }];
  data: Client[] = [];
  dataList: any= [];
  clientName: string = "";
  ngUnsubscribe = new Subject<void>();
  showMenu: boolean = true;
  clientCity: string = "";
  clientNames: string = "";
  loadMore: boolean = true;
  noClient = false;
  filterName: string = "";
  filterCountry: string = "";
  filterCity: string = "";
  filterOrderBy: string = "";
  filterSort: string = "";
  pageId: number = 1;
  clientDetail: Client;
  firstClientId: number;
  carbonUtility = new CarbonUtility();
  showSkeleton: boolean = false;
  tabledata: any;
  observer:any;
  message:any;
  isOpenDeleteModal = false;
  tableModel = new TableModel();
  selectedItem: number = 0;
  size: string = "normal";
  isAddClientUser: boolean;
  isDeleteClientUser: boolean;
  orders = [
    { name: "Ascending", value: "asc" },
    { name: "Descending", value: "desc" },
  ];
  sortColumns = [
    { name: "Name", value: "name" },
    { name: "Date Created", value: "created" },
    { name: "Date Updated", value: "modified" },
  ];
  isClientAdd:boolean;
  constructor( private loaderService: LoaderService,private clientUserService: ClientUserService, private router: Router,private utility:UtilityService,
    private route: ActivatedRoute,  private toastr: ToastrService
    ) {
    this.isClientAdd = this.utility.hasPermission('Add Client');
    this.isAddClientUser = this.utility.hasPermission('Add Client User');
    this.isDeleteClientUser = this.utility.hasPermission('Delete Client User');
  }

  //clientsite data
  sitePageId: number = 1;
  clientSites: ClientSite[] = [];
  filterSiteCountry: string = "";
  filterSite: string = "";
  showAddMenu: boolean = true;
  clickEvent(event) {
    this.pageId += 1;
    this.searchClient(event);
  }
  onClickAddClient() {
    this.showAddMenu = !this.showAddMenu;
  }
  getCientSites() {
    this.clientUserService
      .getClientSite(this.sitePageId, 15, this.filterCountry, this.filterSite)
      .subscribe({
        next: (res) => {
          if (res.results.length == 0) {
          }
          this.clientSites = res.results;
        },
      });
  }
  ngAfterViewInit(){
    this.theLastList.changes.subscribe((d) => {
     if(d.last) this.observer.observe(d.last.nativeElement)
    });

  }
  intersectionObserver(){
    let options={
      root:document.querySelector('#scrollPage'),
      rootMargin:'0px',
      threshold:1,
    };

    this.observer = new IntersectionObserver((entries) =>{
      if(entries[0].isIntersecting){
        this.pageId++;
        this.searchClient('loadmore');
        this.observer.unobserve(entries[0].target);
      }
    },options);
  }
  searchClient(event) {
    this.loadMore = true;
    var target = event.target || event.srcElement || event.currentTarget || event;
    var id = target.id || target;
    if (id == "tbSearch" || id == "loadmore") {
      this.clientUserService
        .getClientUsersByClientId(
          this.clientId,
          this.pageId,
          this.clientName,
          this.filterCountry,
          this.filterCity,
          this.filterOrderBy,
          this.filterSort
        )
        .subscribe({
          next: (res) => {
            if (id == "tbSearch" && res.results.length == 0) {
              this.dataList = [];
              this.loadMore = false;
              this.noClient = true;
            } else if (id == "loadmore" && res.results.length == 0) {
              this.loadMore = false;
              this.pageId = 1;
              return;
            }
            if (this.pageId == 1) {
              this.dataList = [];
            }
            this.dataList = this.dataList.concat(res.results);
          },
        });
    } else {
      this.clientUserService
      .getClientUsersByClientId(
        this.clientId,
          this.pageId,
          this.filterName,
          this.filterCountry,
          this.filterCity,
          this.filterOrderBy,
          this.filterSort
        )
        .subscribe({
          next: (res) => {
            this.dataList = res.results;
            this.toggleSearchMenu();
          },
        });
    }
  }
  ngOnInit(): void {
    this.clientUserService.clientUserListner.subscribe(item => this.addItem(item))
    this.tableModel = Table.skeletonModel(1, 1);
    this.route.params.subscribe((params: any) => {
      if (params.hasOwnProperty('clientId')) {
        this.clientId = params['clientId'];
      }
    });
   
        this.DispatchClients();
        this.intersectionObserver();
   // this.getAllCountries();
  }
  DispatchClients() {
    this.loaderService.show();
    this.clientUserService
    .getClientUsersByClientId(
      this.clientId,
        this.pageId,
        this.filterName,
        this.filterCountry,
        this.filterCity,
        this.filterOrderBy,
        this.filterSort
      )
      .subscribe({
        next: (res) => {
          this.data = res.results;
          this.renderTable();
           // this.showMenu= this.dataList.length>0;
           this.loaderService.hide();
           this.loadFirstClient();
        
        },
      });
  }
  toggleSearchMenu() {
    this.showMenu = !this.showMenu;
  }
  loadFirstClient() {
    this.firstClientId = this.dataList.length>0?this.dataList[0].id:null;
    if (this.firstClientId != null) {
      this.loadClient(this.firstClientId);
    }else{
      this.loadClient(0);

    }
  }
  loadClient(clientuserId: number) {
    this.router.navigate(["/clients/client-users/"+ this.clientId+"/details/", clientuserId]);
  }
  selected(event) {}
  renderTable() {
    for (let i = 0; i < this.data.length; i++) {
      console.log(this.data[i])
      this.dataList.push(this.data[i]);
    }
  }
  getAllCountries() {
    this.clientUserService.getAllContries().subscribe({
      next: (res) => {
        this.countries = res.results;
      },
    });
  }

  getDetailOfClient(clientuserId: number) {
   this.router.navigate(["/clients/client-users/"+ this.clientId+"/details/", clientuserId]);
     
  }
  addItem(item: any) {
    if(item!=null){
      if(item.removeNewItems!==undefined && item.removeNewItems==true){
        this.dataList = this.dataList.filter(function( obj ) {
          return  (obj.uuid==undefined);
      });
      }else{
        this.dataList = this.dataList.filter(function( obj ) {
          return  (obj.uuid==undefined || obj.uuid!=item.uuid);
      });
      if(item.user.displayName!='' || item.user.givenName!='' || item.user.surname!='')
      this.dataList.unshift(item);
      }
   
  
 
}
  }
  openParentModal(id) {
    this.isOpenDeleteModal = true;
    this.clientUserId=id;
  }
  closeParentModal() {
    this.isOpenDeleteModal = false;
  }
  onConfirmationDelete() {

this.loaderService.show();
    this.clientUserService
      .deleteClientUserById(this.clientUserId)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: (res) => {
          this.loaderService.hide();
          this.toastr.success('Client user deleted successfully');
          this.dataList=[];
          this.DispatchClients();
        },
        error: (e) => {
          this.loaderService.hide();
          this.toastr.error('Something went wrong');
        },

        complete: () => this.closeParentModal(),
      });
  }
  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

}
