import { AfterViewInit, Component, ElementRef, OnDestroy, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { ClientService } from 'src/app/services/client/client.service';
import { Client } from 'src/app/models/client/client';
import { CarbonUtility } from 'src/app/shared/common/carbon-utility';
import { debounceTime, distinctUntilChanged, Subject, takeUntil } from 'rxjs';
import { TableModel } from 'carbon-components-angular';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { ClientSite } from 'src/app/models/client/client-site';
import { UtilityService } from 'src/app/services/utility/utility.service';
import { countrySelectBox } from 'src/app/models/client/country-select-box';
import { Permission } from 'src/app/services/utility/permission-constant';

@Component({
  selector: "app-client",
  templateUrl: "./client.component.html",
  styleUrls: ["./client.component.css"],
})
export class ClientComponent implements OnInit,AfterViewInit {
  @ViewChildren('theLastList',{read:ElementRef})
  theLastList: QueryList<ElementRef>;
  selectedCountry;
  countries: countrySelectBox[] = [{ value: 0, text: '' }];
  data: Client[] = [];
  dataList: Client[] = [];
  clientName: string = "";
  ngUnsubscribe = new Subject<void>();
  showMenu: boolean = true;
  clientCity: string = "";
  clientNames: string = "";
  loadMore: boolean = true;
  noClient = false;
  filterName: string = "";
  filterCountry: string = "";
  filterCity: string = "";
  filterOrderBy: string = "";
  filterSort: string = "";
  pageId: number = 1;
  clientDetail: Client;
  firstClientId: number;
  carbonUtility = new CarbonUtility();
  showSkeleton: boolean = false;
  tabledata: any;
  observer:any;
  tableModel = new TableModel();
  selectedItem: number = 0;
  size: string = "normal";
  orders = [
    { name: "Ascending", value: "asc" },
    { name: "Descending", value: "desc" },
  ];
  sortColumns = [
    { name: "Client Name", value: "name" },
    { name: "Date Created", value: "created" },
    { name: "Date Updated", value: "modified" },
  ];
  isClientAdd:boolean;
  clientId: number;
  constructor(private clientService: ClientService, private router: Router, private activatedRoute:ActivatedRoute,private utility:UtilityService,) {
    this.isClientAdd = this.utility.hasPermission(Permission.AddClient);
  }

  //clientsite data
  sitePageId: number = 1;
  clientSites: ClientSite[] = [];
  filterSiteCountry: string = "";
  filterSite: string = "";
  showAddMenu: boolean = true;
  breadCrums: any[] = [];
  clickEvent(event) {
    this.pageId += 1;
    this.searchClient(event);
  }
  onClickAddClient() {
    this.showAddMenu = !this.showAddMenu;
  }
  getCientSites() {
    this.clientService
      .getClientSite(this.sitePageId, 15, this.filterCountry, this.filterSite)
      .subscribe({
        next: (res) => {
          if (res.results.length == 0) {
          }
          this.clientSites = res.results;
        },
      });
  }
  ngAfterViewInit(){
    this.theLastList.changes.subscribe((d) => {
     if(d.last) this.observer.observe(d.last.nativeElement)
    });

  }
  intersectionObserver(){
    let options={
      root:document.querySelector('#scrollPage'),
      rootMargin:'0px',
      threshold:1,
    };

    this.observer = new IntersectionObserver((entries) =>{
      if(entries[0].isIntersecting){
        this.pageId++;
        this.searchClient('loadmore');
        this.observer.unobserve(entries[0].target);
      }
    },options);
  }

  searchClientTextChanges$ = new Subject<any>();

  searchClientTextInput(event) {
    this.searchClientTextChanges$.next(event);
  }

  searchClient(event) {
    this.loadMore = true;
    var target = event.target || event.srcElement || event.currentTarget || event;
    var id = target.id || target;
    this.pageId =  id == "tbSearch" ? 1 : this.pageId;
    if (id == "tbSearch" || id == "loadmore") {
      this.clientService
        .getClients({
          pageNumber: this.pageId,
          name: this.clientName,
          country: this.filterCountry,
          city: this.filterCity,
          orderBy: this.filterOrderBy,
          sort: this.filterSort,
          hasContract: false
        })
        .subscribe({
          next: (res) => {
            if (id == "tbSearch" && res.results.length == 0) {
              this.dataList = [];
              this.loadMore = false;
              this.noClient = true;
            } else if (id == "loadmore" && res.results.length == 0) {
              this.loadMore = false;
              this.pageId = 1;
              return;
            }
            if (this.pageId == 1) {
              this.dataList = [];
            }
            this.dataList = this.dataList.concat(res.results);
          },
        });
    } else {
      this.clientService
        .getClients({
          pageNumber: this.pageId,
          name: this.filterName,
          country: this.filterCountry,
          city: this.filterCity,
          orderBy: this.filterOrderBy,
          sort: this.filterSort,
          hasContract: false
        })
        .subscribe({
          next: (res) => {
            this.dataList = res.results;
            this.toggleSearchMenu();
          },
        });
    }
  }
  goToSideBarMenu() {}
  ngOnInit(): void {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        let path = event.url.split('/')
        this.clientId = Number(path[3])
      }
      this.setBreadCrums();
    });
    this.DispatchClients();
    this.intersectionObserver();
    this.getAllCountries();

    this.searchClientTextChanges$.pipe(
      debounceTime(300),
      distinctUntilChanged(),
      takeUntil(this.ngUnsubscribe),
    ).subscribe((event) => {
      this.searchClient(event);
    });
  }

  setBreadCrums() {
    this.breadCrums = [
      {alias: 'Dispatch 1',redirectTo: '/client-dashboard'},
      {alias: 'Clients',redirectTo: '/clients'},
      {alias: ':clientId',redirectTo: ''},
    ];
    this.breadCrums.forEach(breadCrum => {
      if (breadCrum.alias.includes(":") || breadCrum.redirectTo.includes(":")) {
        breadCrum.alias = this.replaceText(breadCrum.alias);
        breadCrum.redirectTo = this.replaceText(breadCrum.redirectTo);
      }
    });
  }

  replaceText(text: string) {
    return text
      .replace(":clientId", `${this.clientId}`)
  }

  DispatchClients() {
    this.clientService
      .getClients({
        pageNumber: this.pageId,
        name: this.filterName,
        country: this.filterCountry,
        city: this.filterCity,
        orderBy: this.filterOrderBy,
        sort: this.filterSort,
        hasContract: false
      })

      .subscribe({
        next: (res) => {
          this.data = res.results;
          this.renderTable();
          if (
            !this.router.url.includes("add") &&
            !this.router.url.includes("edit")
          ) {
            this.loadFirstClient();
            this.getCientSites();
          }
        },
      });
  }
  toggleSearchMenu() {
    this.showMenu = !this.showMenu;
  }
  loadFirstClient() {
    let rawClientId=this.activatedRoute.firstChild?.snapshot.params["clientId"];
    if (isNaN(rawClientId) || rawClientId === undefined) {
      this.firstClientId = this.dataList[0].id;
    }
    else {
      this.firstClientId = Number(rawClientId);
    }
    if (this.firstClientId != null && this.firstClientId != undefined) {
      this.loadClient(this.firstClientId);
    }
  }
  loadClient(clientId: number) {
    this.router.navigate(["/clients/client-details/", clientId]);
  }
  selected(event) {}
  renderTable() {
    for (let i = 0; i < this.data.length; i++) {
      this.dataList.push(this.data[i]);
    }
  }
  getAllCountries() {
    this.clientService.getAllContries().subscribe({
      next: (res) => {
        this.countries = res.results;
      },
    });
  }

  getDetailOfClient(clientId: number) {
    this.router.navigate(["/clients/client-details/", clientId]);
  }
  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }
}
