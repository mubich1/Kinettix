import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Client } from 'src/app/models/client/client';
import { ClientService } from 'src/app/services/client/client.service';
import { Subject, takeUntil } from 'rxjs';
import { UtilityService } from 'src/app/services/utility/utility.service';
import { Permission } from 'src/app/services/utility/permission-constant';

@Component({
  selector: 'app-client-detail',
  templateUrl: './client-detail.component.html',
  styleUrls: ['./client-detail.component.css']
})
export class ClientDetailComponent implements OnInit {
  clientDetail: Client;
  ngUnsubscribe = new Subject<void>();
  clientId: number;
  isClientEdit:boolean;
  isclientuser:boolean;
  public relationshipType: string = '';
  isCurrentUserAllowedToSeeClientUsers : boolean = false;
  constructor(private clientService:ClientService,  private route: ActivatedRoute, private router: Router,private utility:UtilityService) {
    this.isClientEdit = this.utility.hasPermission('Edit Client');
    this.isclientuser = this.utility.hasPermission('View Client User');

  }

  ngOnInit(): void {
    this.isCurrentUserAllowedToSeeClientUsers =
      this.utility.hasPermission(Permission.ViewClientUser);

    this.route.params.subscribe(
      (params: any) => {
        if (params.hasOwnProperty('clientId')) {
          this.clientId = params['clientId'];
          this.loadClient(this.clientId);
        }
      }
    );

  }

  loadClient(clientId:number){
    this.clientService.getClientById(clientId)
    .pipe(takeUntil(this.ngUnsubscribe))
    .subscribe({
      next: res=>{
        this.clientDetail = res.results;
        this.GetRelationshipType();
      }
    })
  }

  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  private GetRelationshipType() : void {
    this.clientService.getRelationshipTypes().subscribe(res => {
      const data = res.results.filter(s => s.id == this.clientDetail.relationshipTypeID)[0]
      if(data !== null && data !== undefined) {
        this.relationshipType = data.name ?? '';
      }
    })
  }

}
