export enum ResourceStatusEnum {
  Pending = 3,
  Cancelled = 4,
  Approved = 5,
  Draft = 2022,
  Retired = 2023,
}
