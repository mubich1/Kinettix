export enum ContractMilestoneStatusEnum {
  Completed = 'Completed',
  Failed = 'Failed',
  Active = 'Active',
  Pending = 'Pending'
}