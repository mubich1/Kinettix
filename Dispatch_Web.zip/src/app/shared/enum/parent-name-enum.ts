export enum ParentNameEnum {
  Vendor = 'vendor',
  Client = 'client',
  ClientUser = 'clientuser',
}
