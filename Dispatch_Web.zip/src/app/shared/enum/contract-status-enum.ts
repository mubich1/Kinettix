export enum ContractStatusEnum {
    Proposal = 1,
    Staged = 2,
    In_Work = 3,
    Wrap_up = 4,
    Complete = 5,
}

export enum ResourceCategoryEnum {
    Labor = "Labor",
    Travel="Travel",
    ProjectManagement="Project Management",
    Materials="Materials",
    Freight="Freight",
    LiftRentals= "Lift Rentals",
    Internallabor = 'Internal Labor',
    Externallabor = 'External Labor',
  }
