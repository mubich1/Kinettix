export enum ModuleNameEnum {
  Client = 0,
  ClientUser = 1,
  Contract = 2,
  Deal = 3,
  PurchaseOrder = 4,
  Technician = 5,
  Ticket = 6,
  Vendor = 7
}
