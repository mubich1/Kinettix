export enum ApplicationTypeEnum {
  Core_Dispatch = 1,
  Vendor_Portal = 2,
  Client_Portal = 3,
}
