import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConfirmationDialogComponent } from './components/confirmation-dialog/confirmation-dialog.component';
import { CarbonModule } from '../carbon.module';
import { InputDialogComponent } from './components/input-dialog/input-dialog.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SkeletonTableComponent } from './skeleton-table/skeleton-table.component';
import { AddActivityResourceComponent } from './components/project-activity-resources/add-activity-resource/add-activity-resource.component';
import { NumberModule, TagModule } from 'carbon-components-angular';
import { LoaderComponent } from './components/loader/loader.component';
import { CompetencyDialogComponent } from './components/competency-dialog/competency-dialog.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { AgreementDeliveryMediumConfirmationDialogueComponent } from './components/agreement-delivery-medium-confirmation/agreement-delivery-medium-confirmation-dialogue/agreement-delivery-medium-confirmation-dialogue.component';
import { ClientAlignmentDialogueComponent } from './components/client-alignment-dialogue/client-alignment-dialogue/client-alignment-dialogue.component';
import { TurnoverProcessDialogueComponent } from './components/turnover-process-dialogue/turnover-process-dialogue/turnover-process-dialogue.component';
import { TagInputModule } from 'ngx-chips';
import { PoPostingPlatformSelectionDialogueComponent } from './components/po-posting-platform-selection-dialogue/po-posting-platform-selection-dialogue.component';
import { PoScopeComponent } from 'src/app/views/contract/po-details/po-scope/po-scope.component';
import { EditorModule } from '@tinymce/tinymce-angular';
import { PoDeliveryMediumCofirmationDialogComponent } from './components/po-delivery-medium-cofirmation-dialog/po-delivery-medium-cofirmation-dialog.component';
import { PermissionTableComponent } from './components/permission-table/permission-table.component';
import { MilestoneTasksComponent } from './components/milestone-tasks/milestone-tasks.component';
import { EditModule, UserModule, WarningModule } from '@carbon/icons-angular';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from '@danielmoncada/angular-datetime-picker';
import { ActivitiesResourceComponent } from './components/activities-resource/activities-resource.component';
import { TicketScheduleInputComponent } from '../views/ticket/ticket-schedule/ticket-schedule-input/ticket-schedule-input.component';
import { UploadAgreementDetailsComponent } from './components/agreement-delivery-medium-confirmation/agreement-delivery-medium-confirmation-dialogue/components/upload-agreement-details/upload-agreement-details.component';

@NgModule({
  declarations: [
    ConfirmationDialogComponent,
    InputDialogComponent,
    SkeletonTableComponent,
    AddActivityResourceComponent,
    PoScopeComponent,
    CompetencyDialogComponent,
    LoaderComponent,
    AgreementDeliveryMediumConfirmationDialogueComponent,
    ClientAlignmentDialogueComponent,
    TurnoverProcessDialogueComponent,
    PoPostingPlatformSelectionDialogueComponent,
    PoDeliveryMediumCofirmationDialogComponent,
    PermissionTableComponent,
    MilestoneTasksComponent,
    ActivitiesResourceComponent,
    TicketScheduleInputComponent,
    UploadAgreementDetailsComponent
  ],

  imports: [
    CommonModule,
    TagInputModule,
    CarbonModule,
    FormsModule,
    ReactiveFormsModule,
    NumberModule,
    NgSelectModule,
    TagModule,
    EditorModule,
    EditModule,
    UserModule,
    OwlDateTimeModule,
    OwlNativeDateTimeModule,
    WarningModule,
  ],
    exports: [SkeletonTableComponent, LoaderComponent, PoScopeComponent, PermissionTableComponent, MilestoneTasksComponent, ActivitiesResourceComponent, TicketScheduleInputComponent]
})
export class SharedModule {}
