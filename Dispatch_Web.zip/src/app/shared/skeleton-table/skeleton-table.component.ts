import { Component, Input, OnInit } from '@angular/core';
import { Table, TableHeaderItem, TableItem, TableModel } from 'carbon-components-angular';
import { CarbonUtility } from '../common/carbon-utility';

@Component({
  selector: 'app-skeleton-table',
  templateUrl: './skeleton-table.component.html',
  styleUrls: ['./skeleton-table.component.css']
})
export class SkeletonTableComponent implements OnInit {


  tableModel = new TableModel();
  showSkeleton: boolean = true;

  constructor() { }

  ngOnInit(): void {
    this.tableModel = Table.skeletonModel(5,5)
    // this.populateTable();
    // this.initializeTable();
  }

}
