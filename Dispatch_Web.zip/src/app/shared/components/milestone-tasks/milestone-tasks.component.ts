import { Component, Input, OnInit, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { TaskStatusEnum } from 'src/app/models/po-milestone/po-milestones';
import { TaskService } from 'src/app/services/tasks/tasks.service';

@Component({
  selector: 'app-milestone-tasks',
  templateUrl: './milestone-tasks.component.html',
  styleUrls: ['./milestone-tasks.component.css']
})
export class MilestoneTasksComponent implements OnInit {
  @Input() milestones: any[] = [];
  @Input() milestoneStatus: string;
  @Input() isLevelCompleted: boolean;
  @Input() users: any[] = [];
  @Output() onAssignUser = new EventEmitter();
  @Output() onCompleteTask = new EventEmitter();
  @Output() onFailTask = new EventEmitter();

  submitted: boolean = false;
  isAssign: boolean = false;
  isComplete: boolean = false;
  isFail: boolean = false;
  assignUser: any;
  failTask: any;
  completeTask: any;
  assignForm: FormGroup;
  completeForm: FormGroup;
  failForm: FormGroup;
  taskStatusEnum = TaskStatusEnum;
  isOpenConfirmationModal: boolean = false;
  isOpenEditTaskModal: boolean = false;
  isCompleteOrFail: boolean = false;
  columnName: string = '';
  selectedTask: any;
  selectedTaskName: any;

  constructor(private formBuilder: FormBuilder,
              private taskService: TaskService,
              private toastr: ToastrService) { }

  ngOnInit(): void {
    this.initilizeForm();
  }

  initilizeForm() {
    this.assignForm = this.formBuilder.group({
      milestoneId: [null, [Validators.required]],
      taskID: [null, [Validators.required]],
      assignTo: [null, [Validators.required]],
    });
    this.completeForm = this.formBuilder.group({
      milestoneId: [null, [Validators.required]],
      taskID: [null, [Validators.required]],
      completedDate: [new Date(), [Validators.required]],
    });
    this.failForm = this.formBuilder.group({
      milestoneId: [null, [Validators.required]],
      taskID: [null, [Validators.required]],
      failDate: [new Date(), [Validators.required]],
      failReason: [null, [Validators.required]],
    });
  }

  get a() {
    return this.assignForm.controls;
  }
  get c() {
    return this.completeForm.controls;
  }
  get f() {
    return this.failForm.controls;
  }

  getContractStatusName(statusId) {
    switch (statusId) {
      case 2:
        return 'Staged';
      case 3:
        return 'In-Work';
      case 4:
        return 'Wrap-up';
      case 5:
        return 'Complete';
      default:
        return '';
    }
  }

  onAssign(milestone, task) {
    this.assignUser = task;
    this.assignUser.milestoneId = milestone.id;
    this.assignUser.statusId = milestone.statusId;
    this.assignUser.taskId = task.id;
    this.assignForm.controls['milestoneId'].setValue(milestone.id);
    this.assignForm.controls['taskID'].setValue(task.id);
    this.assignForm.controls['assignTo'].setValue(task.assignTo);
    this.isAssign = true;
  }

  onAssignSubmit(assignTo) {
    this.submitted = true;
    if (this.assignForm.invalid) {
      return;
    }
    this.assignUser.assignTo = assignTo;
    this.onAssignUser.emit(this.assignUser);
    this.isAssign = false;
  }

  onComplete(milestone, task, index, isComplete = true, completeDate?) {
    const completedDate = completeDate ? completeDate:  this.c.completedDate.value;
    this.completeTask = task;
    this.completeTask.milestoneId = milestone.id;
    this.completeTask.statusId = milestone.statusId;
    this.completeTask.taskIndex = index;
    this.completeTask.taskId = task.id;
    this.completeForm.controls['milestoneId'].setValue(milestone.id);
    this.completeForm.controls['taskID'].setValue(task.id);
    this.completeForm.controls['completedDate'].setValue(completedDate);
    this.isComplete = isComplete;
  }

  onCompleteSubmit() {
    if (this.completeForm.invalid) {
      return;
    }
    this.completeTask.completedDate = new Date(this.c.completedDate.value);
    this.onCompleteTask.emit(this.completeTask);
    this.isComplete = false;
  }

  onFail(milestone, task, index, isFail = true, failDate?) {
    const failedDate = failDate ? failDate:  this.f.failDate.value;
    this.failTask = task;
    this.failTask.milestoneId = milestone.id;
    this.failTask.taskIndex = index;
    this.failTask.statusId = milestone.statusId;
    this.failTask.taskId = task.id;
    this.failForm.controls['milestoneId'].setValue(milestone.id);
    this.failForm.controls['taskID'].setValue(task.id);
    this.failForm.controls['failDate'].setValue(new Date(failedDate));
    this.failForm.controls['failReason'].setValue(this.f.failReason.value);
    this.isFail = isFail;
  }

  onFailSubmit() {
    if (this.failForm.invalid) {
      return;
    }
    this.failTask.failDate = new Date(this.f.failDate.value);
    this.failTask.failReason = this.f.failReason.value;
    this.onFailTask.emit(this.failTask);
    this.isFail = false;

  }

  onCancel() {
    this.isAssign = false;
    this.isComplete = false;
    this.isFail = false;
    this.initilizeForm();
  }

 
  openConfirmationModal(milestone, task, index, isCompleteOrFail) {
    this.isOpenConfirmationModal = true;
    this.isCompleteOrFail = isCompleteOrFail;
    if (isCompleteOrFail) {
      this.columnName = "Completed Date";
      this.onComplete(milestone, task, index, false, task.completedDate)
    } else {
      this.columnName = "Failed Date";
      this.onFail(milestone, task, index, false, task.failDate)
    }

  }

  onConfirmation() {
    this.isOpenConfirmationModal = false;
    if (this.isCompleteOrFail) {
      this.isComplete = true;
    } else {
      this.isFail = true;
    }
  }
}
