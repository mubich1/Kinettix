import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientAlignmentDialogueComponent } from './client-alignment-dialogue.component';

describe('ClientAlignmentDialogueComponent', () => {
  let component: ClientAlignmentDialogueComponent;
  let fixture: ComponentFixture<ClientAlignmentDialogueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClientAlignmentDialogueComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientAlignmentDialogueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
