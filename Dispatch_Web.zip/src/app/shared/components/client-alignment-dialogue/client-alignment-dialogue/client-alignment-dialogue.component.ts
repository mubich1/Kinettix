import { Component, Injector, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { BaseModal, ListItem } from 'carbon-components-angular';
import { ToastrService } from 'ngx-toastr';
import {
  Client,
  UpdateAssociatedClients,
  UpdateAssociatedEntities,
} from 'src/app/models/client/client';
import { DealService } from 'src/app/services/deals/deal.service';
import { ProposalService } from 'src/app/services/proposal/proposal.service';

@Component({
  selector: 'app-client-alignment-dialogue',
  templateUrl: './client-alignment-dialogue.component.html',
  styleUrls: ['./client-alignment-dialogue.component.css'],
})
export class ClientAlignmentDialogueComponent
  extends BaseModal
  implements OnInit
{
  data: any;
  isOpenDeleteModal: boolean = true;
  showClientsDropDown: boolean = false;
  primaryClientList: any[] = [];
  secondaryClientList: any[] = [];
  platformList: any[] = [];
  onsiteEntityList: any[] = [];
  usersList: any = [];
  associatedClientsFormGroup: FormGroup;
  clientAssociationTypes = [
    'Entity to Invoice',
    'Client Contact',
    'Platform',
    'Secondary Client',
    'Onsite Entity',
  ];

  constructor(
    private injector: Injector,
    private proposalService: ProposalService,
    private dealService: DealService,
    private toaster: ToastrService
  ) {
    super();
    this.data = this.injector.get('data');
  }

  patchValues() {
    this.patchContractRelatedEntities();
    this.patchDealRelatedEntities();
  }

  patchDealRelatedEntities() {
    this.dealService.getDealById(+this.data.data.dealID).subscribe({
      next: (res) => {
        this.associatedClientsFormGroup.patchValue({
          user: res.results.contact?.id,
          primaryClient: res.results.client?.id,
        });
      },
    });
  }

  patchContractRelatedEntities() {
    this.proposalService.getProposalById(+this.data.data.contractID).subscribe({
      next: (res) => {
        this.associatedClientsFormGroup.patchValue({
          secondaryClient: res.results.secondaryClient,
          onsiteEntity: res.results.onsiteEntity,
          platform: res.results.platform,
        });
      },
    });
  }

  getAllClients() {
    this.proposalService.getAssociatedClients(+this.data.data.dealID).subscribe({
      next: (res) => {
        this.primaryClientList = res.results.entitiesToInvoice.sort(
          this.dynamicSort('name')
        );
        this.onsiteEntityList = res.results.onsiteEntities.sort(
          this.dynamicSort('name')
        );
        this.secondaryClientList = res.results.secondaryClients.sort(
          this.dynamicSort('name')
        );
        this.usersList = res.results.clientContacts.sort(
          this.dynamicSort('fullName')
        );
        this.platformList = res.results.platforms.sort(
          this.dynamicSort('name')
        );
      },
    });
  }
  dynamicSort(property) {
    var sortOrder = 1;
    return function (a, b) {
      var result =
        a[property] < b[property] ? -1 : a[property] > b[property] ? 1 : 0;
      return result * sortOrder;
    };
  }

  async ngOnInit() {
    await this.initForm();
    this.patchValues();
    this.getAllClients();
  }

  initForm() {
    this.associatedClientsFormGroup = new FormGroup({
      primaryClient: new FormControl(0),
      secondaryClient: new FormControl(0),
      onsiteEntity: new FormControl(0),
      user: new FormControl(0),
      platform: new FormControl(0),
    });
  }

  closeMyModalByCross() {
    this.closeModal();
    this.data.isClosed = true;
    this.data.confirm = false;
    this.data.obs.next(this.data);
  }

  closeMyModal() {
    this.closeModal();
    this.data.isClosed = false;
    this.data.confirm = false;
    this.data.obs.next(this.data);
  }

  async onConfirmation() {
    await this.onSubmit();
    this.closeModal();
    this.data.isClosed = false;
    this.data.confirm = true;
    this.data.obs.next(this.data);
  }

  onSubmit() {
    let entityToInvoice: UpdateAssociatedClients = {
      clientID: +this.associatedClientsFormGroup.value.primaryClient,
      dealID: +this.data.data.dealID,
      contractID: null,
      userID: null,
      associationType: 'Entity to Invoice',
    };

    let clientContacts: UpdateAssociatedClients = {
      clientID: null,
      dealID: +this.data.data.dealID,
      contractID: null,
      userID: +this.associatedClientsFormGroup.value.user,
      associationType: 'Client Contact',
    };

    let platform: UpdateAssociatedClients = {
      clientID: +this.associatedClientsFormGroup.value.platform,
      dealID: null,
      contractID: +this.data.data.contractID,
      userID: null,
      associationType: 'Platform',
    };

    let secondaryClient: UpdateAssociatedClients = {
      clientID: +this.associatedClientsFormGroup.value.secondaryClient,
      dealID: null,
      contractID: +this.data.data.contractID,
      userID: null,
      associationType: 'Secondary Client',
    };

    let onsiteEntity: UpdateAssociatedClients = {
      clientID: +this.associatedClientsFormGroup.value.onsiteEntity,
      dealID: null,
      contractID: +this.data.data.contractID,
      userID: null,
      associationType: 'Onsite Entity',
    };

    let associatedEntities: UpdateAssociatedEntities = {
      entityToInvoice: entityToInvoice,
      clientContacts: clientContacts,
      secondaryClient: secondaryClient,
      platform: platform,
      onsiteEntity: onsiteEntity,
    };

    this.proposalService.updateAssociatedClients(associatedEntities).subscribe({
      next: (res) => {
        this.toaster.success('Entities updated successfully.');
      },
      error: (err) => {
        this.toaster.error('Something went wrong.');
      },
    });
  }
}
