import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivitiesResourceComponent } from './activities-resource.component';

describe('ActivitiesResourceComponent', () => {
  let component: ActivitiesResourceComponent;
  let fixture: ComponentFixture<ActivitiesResourceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ActivitiesResourceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivitiesResourceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
