import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-activities-resource',
  templateUrl: './activities-resource.component.html',
  styleUrls: ['./activities-resource.component.css']
})
export class ActivitiesResourceComponent implements OnInit {
  @Input() data: any;

  showStripe: boolean = true;
  constructor() { }

  ngOnInit(): void {
  }

}
