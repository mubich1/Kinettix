import { AfterContentInit, Component, EventEmitter, Injector, OnInit, Output } from '@angular/core';
import { BaseModal, ModalService } from 'carbon-components-angular';
import { Observable, Subject } from 'rxjs';
import { ConfirmationDialog } from 'src/app/models/dialog/confirmation';

@Component({
  selector: 'app-confirmation-dialog',
  templateUrl: './confirmation-dialog.component.html',
  styleUrls: ['./confirmation-dialog.component.css']
})


export class ConfirmationDialogComponent extends BaseModal  implements OnInit  {
  @Output() confirmation = new EventEmitter();
  data: ConfirmationDialog;
  isOpenDeleteModal: boolean = true;

  constructor(
    protected injector: Injector) {
      super();
    
      this.data = this.injector.get("data");
  }

  ngOnInit(): void {
  }

  closeMyModalByCross(){
    this.closeModal();
    this.data.isClosed= true;
    this.data.confirm = false;
    this.data.obs.next(this.data);
  }

  closeMyModal(){
    this.closeModal();
    this.data.isClosed= false;
    this.data.confirm = false;
    this.data.obs.next(this.data);
  }

  onConfirmation(){
    
    this.closeModal();
    this.data.isClosed= false;
    this.data.confirm = true;
    this.data.obs.next(this.data);
    this.confirmation.emit(this.data);
  }
}
