import { Component, Injector, OnInit } from '@angular/core';
import { BaseModal } from 'carbon-components-angular';
import { ConfirmationDialog } from 'src/app/models/dialog/confirmation';
import { InputDialog } from 'src/app/models/dialog/input-dialog';

@Component({
  selector: 'app-input-dialog',
  templateUrl: './input-dialog.component.html',
  styleUrls: ['./input-dialog.component.css']
})
export class InputDialogComponent extends BaseModal  implements OnInit {

  modalText: string; 
  data: InputDialog;
  isModalOpen: boolean = true;

  isDisabled: boolean = true;

  constructor(protected injector: Injector) {
      super();
      
      this.data = this.injector.get("data");
  }

  ngOnInit(): void {
  }

  closeMyModal(){
    this.closeModal();
    this.data.confirm = false;
    this.data.obs.next(this.data);
  }

  onConfirmation(){
    
    this.closeModal();
    this.data.confirm = true;
    this.data.obs.next(this.data);
  }

  onChange(event){
    
  }
}