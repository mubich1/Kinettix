import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subject, forkJoin, takeUntil, Observable, catchError, EMPTY } from 'rxjs';
import { EmployeeService } from 'src/app/services/employee/employee.service';
import { PermissionService } from 'src/app/services/permissions/permission.service';
import { RoleService } from 'src/app/services/roles/role.service';
import { Permission, PermissionGroup, PermissionScope, PermissionPayload } from 'src/app/models/permission/permission';

@Component({
  selector:    'd1-permission-table',
  templateUrl: './permission-table.component.html',
  styleUrls:  ['./permission-table.component.css']
})
export class PermissionTableComponent implements OnInit, OnDestroy {

  currentUser:      any;
  currentUserId:    string | null;
  permissionGroups: PermissionGroup[] = [];
  ngUnsubscribe$:   Subject<void> = new Subject<void>();

  constructor(
    private activatedRoute:     ActivatedRoute,
    private employeeService:    EmployeeService,
    private permissionService:  PermissionService,
    private toastr:             ToastrService,
    private router:             Router
  ) {
    this.currentUserId = this.activatedRoute.snapshot.paramMap.get('id');
  }

  ngOnInit(): void {
    forkJoin({
      getAllPermissions: this.getAllPermissions(),
      getCurrentUser: this.getCurrentUser(),
    }).pipe(
      takeUntil(this.ngUnsubscribe$),
      catchError(() => {
        this.toastr.error('Something went wrong');
        return EMPTY;
      })
    ).subscribe((result) => {
      this.permissionGroups.push(...result.getAllPermissions.results);
      this.currentUser = result.getCurrentUser.results;

      this.getAllCategories();
      this.initializeUserPermissions();
    });
  }

  getAllPermissions(): Observable<any> {
    return this.permissionService.getAllPermissions();
  }

  getPermissionCategory(permission: Permission): string {
    return permission.name.toLowerCase().replace(permission.scope.toLowerCase(), "").trim();
  }

  getAllCategories(): void {
    this.permissionGroups.forEach(permissionGroup => {
      permissionGroup.categories = [];
      permissionGroup.permissions.forEach(permission => {
        permission.category = this.getPermissionCategory(permission);
        if (!permissionGroup.categories.includes(permission.category))
          permissionGroup.categories.push(permission.category);
      })
      permissionGroup.categories.sort();
    })
    this.permissionGroups.sort((a, b) => a.section.localeCompare(b.section));
  }

  getCurrentUser(): Observable<any> {
    return this.employeeService.getEmployee(this.currentUserId);
  }

  onCheckBoxChange(event, id: number) {
    let isChecked = event.checked;
    this.permissionGroups.forEach(permissionGroup => {
      for (let permission of permissionGroup.permissions) {
        if (permission.id == id) {
          permission.isAdd = isChecked;
        }
      }
      this.verifyGroupCheckBoxStatus(permissionGroup);
    });
  }

  onGroupCheckboxChange(event, permissionGroup: PermissionGroup, group: string) {
    let isChecked = event.checked;
    permissionGroup.permissions.forEach(permission => {
      if (permission.scope.toLowerCase() == group.toLowerCase() || permission.section == group)
        permission.isAdd = isChecked;
    });
    this.verifyGroupCheckBoxStatus(permissionGroup);
  }

  onCancel() {
    this.router.navigate(['users/settings/user-management']);
  }

  onSave(): void {
    let permissionPayloads: PermissionPayload[] = [];

    this.permissionGroups.forEach(permissionGroup => {
      permissionGroup.permissions.forEach(permission => {
        permissionPayloads.push({
          id: permission.id,
          isAdd: permission.isAdd
        })
      })
    });

    this.employeeService.addRemoveEmployeePermission(this.currentUserId, permissionPayloads)
      .pipe(takeUntil(this.ngUnsubscribe$))
      .subscribe({
        next:  _     => this.toastr.success("User Permission Updated Successfully"),
        error: _     => this.toastr.error("Something went wrong"),
        complete: () => { },
      });
  }

  filterPermissions(permissions: Permission[], category: string, scope: string): Permission | undefined {
    return  permissions.find(p => p.scope.toLowerCase() === scope.toLowerCase() && p.category.toLowerCase() === category.toLowerCase());
  }

  initializeUserPermissions(): void {
    const userPermissions = this.currentUser.permissions?.map(userPermission => userPermission.id);
    if (!userPermissions) return;

    this.permissionGroups.forEach(permissionGroup => {
      permissionGroup.permissions.forEach(permission => {
        if (userPermissions.includes(permission.id))
          permission.isAdd = true;
      })
      this.verifyGroupCheckBoxStatus(permissionGroup);
    });
  }

  verifyGroupCheckBoxStatus(permissionGroup: PermissionGroup): void {
    permissionGroup.isAll = permissionGroup.permissions.every(p => p.isAdd);
    permissionGroup.isAllAdd = permissionGroup.permissions.filter(p => p.scope == 'Add').every(p => p.isAdd);
    permissionGroup.isAllView = permissionGroup.permissions.filter(p => p.scope == 'View').every(p => p.isAdd);
    permissionGroup.isAllEdit = permissionGroup.permissions.filter(p => p.scope == 'Edit').every(p => p.isAdd);
    permissionGroup.isAllDelete = permissionGroup.permissions.filter(p => p.scope == 'Delete').every(p => p.isAdd);
  }

  toggleHide(event): void {
    const target = event.target;
    const isCollapsed = target.classList.contains('collapsed');

    if (isCollapsed) {
      target.classList.remove('collapsed');
      target.innerHTML = "-";
    } else {
      target.classList.add('collapsed');
      target.innerHTML = '+';
    }

  }

  ngOnDestroy(): void {
    this.ngUnsubscribe$.next();
    this.ngUnsubscribe$.complete();
  }
}
