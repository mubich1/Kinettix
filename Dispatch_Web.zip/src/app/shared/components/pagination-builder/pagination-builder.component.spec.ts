import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaginationBuilderComponent } from './pagination-builder.component';

describe('PaginationBuilderComponent', () => {
  let component: PaginationBuilderComponent;
  let fixture: ComponentFixture<PaginationBuilderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PaginationBuilderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PaginationBuilderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
