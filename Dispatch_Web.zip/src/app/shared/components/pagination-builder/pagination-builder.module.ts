import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaginationBuilderComponent } from './pagination-builder.component';
import { IconModule, PaginationModule, TableModule } from 'carbon-components-angular';
import { FormsModule } from '@angular/forms';
import { FilterBuilderModule } from '../filter-builder/filter-builder.module';



@NgModule({
  declarations: [
    PaginationBuilderComponent,
  ],
  imports: [
    CommonModule,
    TableModule,
    PaginationModule,
    IconModule,
    FormsModule,
    FilterBuilderModule,
  ],
  exports: [
    PaginationBuilderComponent,
  ]
})
export class PaginationBuilderModule { }
