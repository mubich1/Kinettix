import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { TableHeaderItem, TableItem, TableModel } from 'carbon-components-angular';
import { catchError, EMPTY, Observable, Subject, take, takeUntil } from 'rxjs';
import { D1FilterGroup } from '../filter-builder/filter-builder.component';

@Component({
  selector: 'd1-pagination-builder',
  templateUrl: './pagination-builder.component.html',
  styleUrls: ['./pagination-builder.component.css']
})
export class PaginationBuilderComponent implements OnInit, OnDestroy {

  constructor() { }

  @Input() filterConfiguration: D1FilterGroup[] | null;

  @Input() configuration: PaginationBuilderOptions;

  componentDestroyed$ = new Subject<void>();

  tableModel: TableModel;

  displaySkeleton: boolean = false;

  // Used to track changes to the page count
  previousItemsPerPageCount?: number | null;

  pageRepository?: TablePageEntry[] | null;

  // Tracks failure of any page load
  failedToLoadPage: boolean = false;

  query: any;
  filterState$ = new Subject<any>();

  ngOnInit(): void {
    this.tableModel = new TableModel();

    // Configure headers
    this.tableModel.header = this.configuration.headers.map<TableHeaderItem>((rawHeader) => new TableHeaderItem({data: rawHeader}));

    // Load first page of data
    this._loadPage(1);

    this.filterState$.pipe(
      takeUntil(this.componentDestroyed$),
    ).subscribe((filterState) => this.updateQuery(filterState));
  }

  private updateQuery(query: any): void {
    // Reset current results
    this.pageRepository = null;

    this.query = query;

    this._loadPage(1, query);
  }

  // Parse and slice repository for display
  private _selectPage(page: number): void {
    const pageData = this.pageRepository![page - 1];

    if(pageData.pageItems == null) {
      this.tableModel.data = [];

      return;
    }

    this.tableModel.data = pageData.pageItems!.map((item) => item.columnEntries);
  }

  /// Initialize/reset the list containing all of the potential pages
  private _initializePageRepository(): void {
    const totalPageCount = Math.ceil(this.tableModel.totalDataLength / this.tableModel.pageLength);

    this.pageRepository = [];

    for (let index = 0; index < totalPageCount; index++) {
      // Initialize every potential page with no data
      this.pageRepository.push({});
    }
  }

  private _updatePageData(page: number, data: Partial<TablePageEntry>): void {
    this.pageRepository![page - 1] = {...this.pageRepository![page - 1], ...data};
  }

  /// Get items for current applicable page
  _loadPage(page: number, query?: any): void {
    if(this.previousItemsPerPageCount != null && this.previousItemsPerPageCount !== this.tableModel.pageLength) {
      page = 1;

      this.tableModel.data = [];

      this._initializePageRepository();
    }
    this.previousItemsPerPageCount = this.tableModel.pageLength;

    this.tableModel.currentPage = page;

    const currentPage = this.tableModel.currentPage;
    const pageLength = this.tableModel.pageLength;

    // If request has already been made, select it
    if(this.pageRepository != null && this.pageRepository[currentPage - 1].pageRequest != null && query == null) {
      this._selectPage(currentPage);

      return;
    }

    const request = this.configuration.loadItemsCallback({
      page: currentPage,
      itemsPerRequest: pageLength,
      query: this.query,
    });

    if(this.pageRepository != null) {
      // Prevent unwanted reloads
      this._updatePageData(currentPage, {
        pageRequest: request,
      });
    }

    this.displaySkeleton = true;

    request.pipe(
      take(1),
      catchError(() => {
        this.displaySkeleton = false;

        this.failedToLoadPage = true;

        return EMPTY;
      }),
    ).subscribe((results) => {
      this.displaySkeleton = false;

      this.tableModel.totalDataLength = results.listExtentCount;

      // If repository has not yet been initialized, initialize it
      if(this.pageRepository == null) {
        this._initializePageRepository();
      }

      this._updatePageData(currentPage, {
        pageItems: results.results,
        pageRequest: request,
      });

      this._selectPage(currentPage);
    });
  }

  handleRowSelected(selection: any): void {
    const currentPage = this.tableModel.currentPage;
    const applicablePage = this.pageRepository![currentPage - 1];

    if(this.configuration.singleSelectCallback != null) {
      this.configuration.singleSelectCallback(applicablePage.pageItems![selection.selectedRowIndex]);
    }
  }

  handleFilterUpdated(filter: any): void {
    this.filterState$.next(filter);
  }

  ngOnDestroy(): void {
    this.componentDestroyed$.next();
    this.componentDestroyed$.complete();
  }

}

export interface PaginationBuilderOptions {
  /// Headers to apply to the table
  headers: string[],

  /// Callback to request more items
  loadItemsCallback: (details: PaginationBuilderLoadRecordsRequest) => Observable<PaginationBuilderLoadRecordsResult>,

  /// Callback for single selection mode. Omit if not using this functionality
  singleSelectCallback?: ((selection: PaginationBuilderRowDefinition) => void) | null,
}

export interface PaginationBuilderLoadRecordsRequest {
  page: number,
  query?: any | null,
  itemsPerRequest: number,
}

export interface PaginationBuilderLoadRecordsResult {
  /// Data to display to table
  results: PaginationBuilderRowDefinition[],

  /// Number of possible records
  listExtentCount: number,
}

export interface PaginationBuilderRowDefinition {
  columnEntries: TableItem[],

  // Additional information used to identify this item
  meta?: any | null,
}

interface TablePageEntry {
  /// Used for gathering results for any given page
  pageRequest?: Observable<PaginationBuilderLoadRecordsResult> | null,

  /// Tracks the items for any given page
  pageItems?: PaginationBuilderRowDefinition[] | null,
}
