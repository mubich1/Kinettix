import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddActivityResourceComponent } from './add-activity-resource.component';

describe('AddActivityResourceComponent', () => {
  let component: AddActivityResourceComponent;
  let fixture: ComponentFixture<AddActivityResourceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddActivityResourceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddActivityResourceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
