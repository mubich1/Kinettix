import { Component, EventEmitter, Injector, OnInit, Output } from '@angular/core';
import {
  FormArray,
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import {
  BaseModal,
  NotificationService,
  Table,
  TableHeaderItem,
  TableModel,
  Toast,
} from 'carbon-components-angular';
import { ToastrService } from 'ngx-toastr';
import { Resource } from 'src/app/models/activity/activity-resource';
import { ConfirmationDialog } from 'src/app/models/dialog/confirmation';
import { ActivityResourcesTotalDto, ContractActivityResourceMainDto } from 'src/app/models/resources/resource';
import { ProjectActivityResourceService } from 'src/app/services/project-activity-resources/project-activity-resources.service';
import { ResourceCategoryEnum } from 'src/app/shared/enum/contract-status-enum';
@Component({
  selector: 'app-add-activity-resource',
  templateUrl: './add-activity-resource.component.html',
  styleUrls: ['./add-activity-resource.component.css'],
})
export class AddActivityResourceComponent extends BaseModal implements OnInit {
  data: any;
  @Output() modalClose = new EventEmitter<any>();

  resourceModal: boolean = true;

  resourceData: Resource[] = [];

  public activityResourceForm: FormGroup;
  public projectManagementResourceForm: FormGroup;
  public grandTotalForm: FormGroup;
  model = new TableModel();
  projectManagementResourceModel = new TableModel();
  grandTotalFormTable = new TableModel();

  resourceCategories: any[] = [];
  resources: any = [];


  resourceCategoriesPM: any[] = [];
  resourcesPM: any[] = [];

  categorySkeleton: boolean = true;
  titleSkeleton: boolean = true;

   activityResourceTotal:ActivityResourcesTotalDto={
    id: 0,
    totalVariableCost: 0,
    totalFixedCost: 0,
    budgetMargin: 0,
    cogs: 0,
    grossProfit: 0,
    variableMarginPercent: 0,
    totalBudgetExpenses: 0,
    budgetIncome: 0,
    budgetNetMarginPercent: 0,
    authorizedCost: 0,
    targetCost: 0,
    platformFeePercent: 0,
    riskPercent: 0,
    financeFeePercent: 0,
    roundingAmount: 0
  }
  constructor(
    protected injector: Injector,
    private _fb: FormBuilder,
    private projectActivityResourceService: ProjectActivityResourceService,
    private toaster: ToastrService
  ) {
    super();
    this.data = this.injector.get('data');
  }
  ngOnInit(): void {
    this.projectActivityResourceService
      .getProjectActivityResourcesByActivityId(this.data.activityID)
      .subscribe((res) => {
        let exisitingDataTechType = res.results.filter((ele) => {
          if (ele.categoryName !== ResourceCategoryEnum.ProjectManagement) {
            return ele;
          }
        });

        let existingDataPMType = res.results.filter((ele) => {
          if (ele.categoryName ==  ResourceCategoryEnum.ProjectManagement) {
            return ele;
          }
        });

        this.addExistingData(exisitingDataTechType);
        this.addExistingDataPM(existingDataPMType);
      });
    this.projectActivityResourceService
      .getResourceCategories()
      .subscribe((res) => {
        if (res.results) {
          this.resourceCategories = res.results;
          this.categorySkeleton = false;
        }
      });
    //Tech Type Table
    this.model.header = [
      new TableHeaderItem({ data: 'Category' }),
      new TableHeaderItem({ data: 'Title' }),
      new TableHeaderItem({ data: 'Display Title' }),
      new TableHeaderItem({ data: 'Qty' }),
      new TableHeaderItem({ data: 'Budget' }),
      new TableHeaderItem({ data: 'Extended Budget' }),
      new TableHeaderItem({ data: '% Platform Budget ' }),
      new TableHeaderItem({ data: '% Risk Budget  ' }),
      new TableHeaderItem({ data: '% Finance Budget ' }),
      new TableHeaderItem({ data: 'Total Cost	' }),
      new TableHeaderItem({ data: 'Margin % ' }),
      new TableHeaderItem({ data: 'Margin Amount' }),
      new TableHeaderItem({ data: 'Total Price' }),
      new TableHeaderItem({ data: 'Action', sortable: false }),
    ];
    this.activityResourceForm = this._fb.group({
      Rows: this._fb.array([]),
    });

    //Project Mangement Type
    this.projectManagementResourceModel.header = [
      new TableHeaderItem({ data: 'Category' }),
      new TableHeaderItem({ data: 'Title' }),
      new TableHeaderItem({ data: 'Display Title' }),
      new TableHeaderItem({ data: 'QTY' }),
      new TableHeaderItem({ data: 'Budget' }),
      new TableHeaderItem({ data: 'Extended Budget' }),
      new TableHeaderItem({ data: '% Platform Budget ' }),
      new TableHeaderItem({ data: '% Risk Budget  ' }),
      new TableHeaderItem({ data: '% Finance Budget ' }),
      new TableHeaderItem({ data: 'Total Cost	' }),
      new TableHeaderItem({ data: 'Margin  ' }),
      new TableHeaderItem({ data: 'Margin Amount' }),
      new TableHeaderItem({ data: 'Total Price' }),
      new TableHeaderItem({ data: 'Action', sortable: false }),
    ];
    this.projectManagementResourceForm = this._fb.group({
      Rows: this._fb.array([]),
    });

    //Grand Total Form
    this.grandTotalFormTable.header = [
      new TableHeaderItem({ data: '' }),
      new TableHeaderItem({ data: '' }),
      new TableHeaderItem({ data: '' }),
      new TableHeaderItem({ data: '' }),
      new TableHeaderItem({ data: '' }),
      new TableHeaderItem({ data: '' }),
      new TableHeaderItem({ data: '' }),
      new TableHeaderItem({ data: 'Budget' }),
      new TableHeaderItem({ data: 'Extended Budget' }),
      new TableHeaderItem({ data: '% Platform Budget ' }),
      new TableHeaderItem({ data: '% Risk Budget  ' }),
      new TableHeaderItem({ data: '% Finance Budget ' }),
      new TableHeaderItem({ data: 'Total Cost	' }),
      new TableHeaderItem({ data: '  ' }),
      new TableHeaderItem({ data: 'Margin Amount' }),
      new TableHeaderItem({ data: 'Total Price' }),
      new TableHeaderItem({ data: '' }),
    ];

    this.initGrandTotalForm();
    this.addRow();
    this.addProjectManagementResourceRow();
  }

  //Grand Total
  initGrandTotalForm() {
    this.grandTotalForm = this._fb.group({
      totalUnitCost: [0],
      totalDirectCost: [0],
      totalPlatform: [0],
      totalRisk: [0],
      totalFinance: [0],
      totalCost: [0],
      totalMargin: [0],
      totalPrice: [0],
    });
  }
  onCalculateGrandTotal() {
    let totalUnitCostTechType = 0;
    let totalDirectCostTechType = 0;
    let totalPlatformFeeTechType = 0;
    let totalRiskFeeTechType = 0;
    let totalFinanceFeeTechType = 0;
    let totalCostTechType = 0;
    let totalMarginTechType = 0;
    let totalPriceTechType = 0;
    this.activityResourceForm.value.Rows.forEach((element) => {
      totalUnitCostTechType += element.unitCost;
      totalDirectCostTechType += element.directCost;
      totalPlatformFeeTechType += element.platformFeeInAmount;
      totalRiskFeeTechType += element.riskFeeInAmount;
      totalFinanceFeeTechType += element.financeFeeInAmount;
      totalCostTechType = element.totalCost;
      totalMarginTechType += element.marginInAmount;
      totalPriceTechType = element.price;
    });
    this.projectManagementResourceForm.value.Rows.forEach((element) => {
      totalUnitCostTechType += element.unitCost;
      totalDirectCostTechType += element.directCost;
      totalPlatformFeeTechType += element.platformFeeInAmount;
      totalRiskFeeTechType += element.riskFeeInAmount;
      totalFinanceFeeTechType += element.financeFeeInAmount;
      totalCostTechType += element.totalCost;
      totalMarginTechType += element.marginInAmount;
      totalPriceTechType += element.price;
    });

    const control = this.grandTotalForm as FormGroup;
    control.controls['totalUnitCost'].setValue(totalUnitCostTechType);
    control.controls['totalDirectCost'].setValue(totalDirectCostTechType);
    control.controls['totalCost'].setValue(totalCostTechType);
    control.controls['totalPrice'].setValue(totalPriceTechType);
    control.controls['totalPlatform'].setValue(totalPlatformFeeTechType);
    control.controls['totalRisk'].setValue(totalRiskFeeTechType);
    control.controls['totalFinance'].setValue(totalFinanceFeeTechType);
    control.controls['totalMargin'].setValue(totalMarginTechType);
  }

  //Tech Type Resources Methods
  addExistingData(existingdataList: any[]) {
    let resourcesByCategoryId: any[] = [];
    existingdataList.forEach((ele) => {
      this.projectActivityResourceService
        .getResourcesByCategoryId(ele.categoryName)
        .subscribe((res) => {
          if (res !== null) {
            resourcesByCategoryId = res.results;
            const control = this.activityResourceForm.get('Rows') as FormArray;
            control.push(this.initExistingData(ele, resourcesByCategoryId));
            this.onSelectTitle(control.length - 1);
          } else {
            const control = this.activityResourceForm.get('Rows') as FormArray;
            control.push(this.initExistingData(ele, resourcesByCategoryId));
            this.onSelectTitle(control.length - 1);
          }
        });
    });
  }
  initExistingData(existingdata, resourceData) {
    return this._fb.group({
      id: [existingdata.id],
      categoryId: [existingdata.categoryId, [Validators.required]],
      resourceId: [existingdata.resourceId, [Validators.required]],
      displayTitle: [''],
      materialType: [''],
      quantity: [existingdata.quantity, [Validators.required]],
      unitCost: [existingdata.unitCost, [Validators.required]],
      directCost: [existingdata.directCost],
      platformFeePercent: [existingdata.platformFee, [Validators.required]],
      riskFeePercent: [existingdata.riskFee, [Validators.required]],
      financeFeePercent: [existingdata.financeFee, [Validators.required]],
      totalCost: [existingdata.totalCost],
      marginPercent: [existingdata.marginPercent, [Validators.required]],
      price: [existingdata.price],
      quantityCost: [0],
      marginInAmount: [0, [Validators.required]],
      platformFeeInAmount: [0, [Validators.required]],
      riskFeeInAmount: [0, [Validators.required]],
      financeFeeInAmount: [0, [Validators.required]],
      resources: [resourceData],

      totalQuantity: [0],
      totalUnitCost: [0],
      totalDirectCost: [0],
      totalMarginAmount: [0],
      totalPlatformFee: [0],
      totalRiskFee: [0],
      totalFinanceFee: [0],
      finalTotalCost: [0],
      finalTotalPrice: [0],
    });
  }

  onSelectCategory(index,event) {
    let categoryName=event.target.selectedOptions[0].textContent;
    let controlItem = this.getFormControls.at(index) as FormGroup;
    this.projectActivityResourceService
      .getResourcesByCategoryId(categoryName)
      .subscribe((res) => {
        if (res !== null) {
          controlItem.controls['resources'].setValue(res.results);
          this.titleSkeleton = false;
        }
      });
  }
  onSelectTitle(index) {

    this.titleSkeleton = false;
    let controlItem = this.getFormControls.at(index) as FormGroup;
    let resourceId = controlItem.controls['resourceId'].value;
    let resource = controlItem.controls['resources'].value.filter((x) => {
      if (x.id == resourceId) {
        return x;
      }
    });

    controlItem.controls['displayTitle'].setValue(resource[0].displayName);
    controlItem.controls['unitCost'].setValue(resource[0].cost);
  }

  initRows() {
    return this._fb.group({
      id: [0],
      categoryId: [0, [Validators.required]],
      resourceId: [0, [Validators.required]],
      displayTitle: [''],
      materialType: [''],
      quantity: [0, [Validators.required]],
      unitCost: [0, [Validators.required]],
      directCost: [0],
      platformFeePercent: [0, [Validators.required]],
      riskFeePercent: [0, [Validators.required]],
      financeFeePercent: [0, [Validators.required]],
      totalCost: [0],
      marginPercent: [0, [Validators.required]],
      price: [0],
      quantityCost: [0],
      marginInAmount: [0, [Validators.required]],
      platformFeeInAmount: [0, [Validators.required]],
      riskFeeInAmount: [0, [Validators.required]],
      financeFeeInAmount: [0, [Validators.required]],
      resources: [[]],
      totalQuantity: [0],
      totalUnitCost: [0],
      totalDirectCost: [0],
      totalMarginAmount: [0],
      totalPlatformFee: [0],
      totalRiskFee: [0],
      totalFinanceFee: [0],
      finalTotalCost: [0],
      finalTotalPrice: [0],
    });
  }
  addRow() {
    const control = this.activityResourceForm.get('Rows') as FormArray;
    control.push(this.initRows());
  }
  get getFormControls() {
    const control = this.activityResourceForm.get('Rows') as FormArray;
    return control;
  }

  onQuantityChange(index) {
    let controlItem = this.getFormControls.at(index) as FormGroup;
    let cost = controlItem.controls['unitCost'].value;
    let quantity = controlItem.controls['quantity'].value;
    controlItem.controls['quantityCost'].setValue(cost * quantity);
    let quantityCost = controlItem.controls['quantityCost'].value;
    controlItem.controls['directCost'].setValue(quantityCost);
    this.onPlatformFeeChange(index);
  }
  onPlatformFeeChange(index) {
    let controlItem = this.getFormControls.at(index) as FormGroup;
    let platformFeePercent = +controlItem.controls['platformFeePercent'].value;
    let directCost = +controlItem.controls['directCost'].value;
    if (platformFeePercent !== 0) {
      controlItem.controls['platformFeeInAmount'].setValue(
        (platformFeePercent / 100) * directCost
      );
    } else {
      controlItem.controls['platformFeeInAmount'].setValue(0);
    }
    this.onRiskChange(index);
  }
  onRiskChange(index) {
    let controlItem = this.getFormControls.at(index) as FormGroup;
    let riskFeePercent = +controlItem.controls['riskFeePercent'].value;
    let directCost = +controlItem.controls['directCost'].value;
    let platformFeeAmount = +controlItem.controls['platformFeeInAmount'].value;

    if (riskFeePercent !== 0) {
      controlItem.controls['riskFeeInAmount'].setValue(
        (directCost + platformFeeAmount) * (riskFeePercent / 100)
      );
    } else {
      controlItem.controls['riskFeeInAmount'].setValue(0);
    }
    this.onFinanceFeeChange(index);
  }
  onFinanceFeeChange(index) {
    let controlItem = this.getFormControls.at(index) as FormGroup;
    let financeFeePercent = +controlItem.controls['financeFeePercent'].value;
    let riskFeeAmount = +controlItem.controls['riskFeeInAmount'].value;
    let directCost = +controlItem.controls['directCost'].value;
    let platformFeeAmount = +controlItem.controls['platformFeeInAmount'].value;

    if (financeFeePercent !== 0) {
      controlItem.controls['financeFeeInAmount'].setValue(
        (directCost + platformFeeAmount + riskFeeAmount) *
          (financeFeePercent / 100)
      );
    } else {
      controlItem.controls['financeFeeInAmount'].setValue(0);
    }
    this.calculateTotalCost(index);
  }
  calculateTotalCost(index) {
    let controlItem = this.getFormControls.at(index) as FormGroup;
    let financeFeeAmount = +controlItem.controls['financeFeeInAmount'].value;
    let riskFeeAmount = +controlItem.controls['riskFeeInAmount'].value;
    let directCost = +controlItem.controls['directCost'].value;
    let platformFeeAmount = +controlItem.controls['platformFeeInAmount'].value;
    controlItem.controls['totalCost'].setValue(
      directCost + platformFeeAmount + riskFeeAmount + financeFeeAmount
    );
    this.onMarginChange(index);
  }
  onMarginChange(index) {
    let controlItem = this.getFormControls.at(index) as FormGroup;
    let marginPercent = +controlItem.controls['marginPercent'].value;
    let directCost = +controlItem.controls['directCost'].value;
    let platformFeeAmount = +controlItem.controls['platformFeeInAmount'].value;
    let riskFeeAmount = +controlItem.controls['riskFeeInAmount'].value;

    if (marginPercent !== 0) {
      var sumOfFee = directCost + platformFeeAmount + riskFeeAmount;
      var remainingPercentForFinanceFee = (100 - marginPercent) / 100;
      controlItem.controls['marginInAmount'].setValue(
        sumOfFee / remainingPercentForFinanceFee - sumOfFee
      );
    } else {
      controlItem.controls['marginInAmount'].setValue(0);
    }
    this.calculateTotalPrice(index);
  }
  calculateTotalPrice(index) {
    let controlItem = this.getFormControls.at(index) as FormGroup;
    let totalCost = controlItem.controls['totalCost'].value;
    let marginAmount = controlItem.controls['marginInAmount'].value;
    controlItem.controls['price'].setValue(totalCost + marginAmount);
    this.techTypeSubTotal();
  }
  techTypeSubTotal() {
    let totalQuantity = 0;
    let totalDirectCost = 0;
    let totalUnitCost = 0;
    let totalPlatformFee = 0;
    let totalRiskFee = 0;
    let totalFinanceFee = 0;
    let finalTotalCost = 0;
    let finalTotalPrice = 0;
    let totalMarginAmount = 0;

    this.activityResourceForm.value.Rows.forEach((ele) => {
      totalQuantity += ele.quantity;
      totalDirectCost += ele.directCost;
      totalUnitCost += ele.unitCost;
      totalPlatformFee += ele.platformFeeInAmount;
      totalRiskFee += ele.riskFeeInAmount;
      totalFinanceFee += ele.financeFeeInAmount;
      finalTotalCost += ele.totalCost;
      finalTotalPrice += ele.price;
      totalMarginAmount += ele.marginInAmount;
    });
    for (let i = 0; i < this.getFormControls.length; i++) {
      let controlItem = this.getFormControls.at(i) as FormGroup;
      controlItem.controls['totalQuantity'].setValue(totalQuantity);
      controlItem.controls['totalDirectCost'].setValue(totalDirectCost);
      controlItem.controls['totalUnitCost'].setValue(totalUnitCost);
      controlItem.controls['totalPlatformFee'].setValue(totalPlatformFee);
      controlItem.controls['totalRiskFee'].setValue(totalRiskFee);
      controlItem.controls['totalFinanceFee'].setValue(totalFinanceFee);
      controlItem.controls['finalTotalCost'].setValue(finalTotalCost);
      controlItem.controls['finalTotalPrice'].setValue(finalTotalPrice);
      controlItem.controls['totalMarginAmount'].setValue(totalMarginAmount);
    }
    this.onCalculateGrandTotal();
  }
  removeResource(index) {
    this.getFormControls.removeAt(index);
    this.techTypeSubTotal();
  }

  //Project Management Type Resources Methods
  addExistingDataPM(existingdataList: any[]) {
    let resourcesByCategoryId: any[] = [];
    existingdataList.forEach((ele) => {
      this.projectActivityResourceService
        .getResourcesByCategoryId(ele.categoryName)
        .subscribe((res) => {
          if (res !== null) {
            resourcesByCategoryId = res.results;
            const control = this.projectManagementResourceForm.get(
              'Rows'
            ) as FormArray;
            control.push(this.initExistingDataPM(ele, resourcesByCategoryId));
            this.onSelectTitleForExistingDataPM(control.length - 1);
            this.onPlatformFeeChangePM(control.length - 1);
          } else {
            const control = this.projectManagementResourceForm.get(
              'Rows'
            ) as FormArray;
            control.push(this.initExistingDataPM(ele, resourcesByCategoryId));
            this.onSelectTitleForExistingDataPM(control.length - 1);
            this.onPlatformFeeChangePM(control.length - 1);
          }
        });
    });
  }
  initExistingDataPM(existingdata, resourceData) {

    return this._fb.group({
      id: [existingdata.id],
      resourceId: [existingdata.resourceId, [Validators.required]],
      categoryId: [existingdata.categoryId, [Validators.required]],
      displayTitle: [''],
      unitCost: [existingdata.unitCost, [Validators.required]],
      directCost: [existingdata.directCost],
      platformFeePercent: [existingdata.platformFee, [Validators.required]],
      riskFeePercent: [existingdata.riskFee, [Validators.required]],
      financeFeePercent: [existingdata.financeFee, [Validators.required]],
      totalCost: [existingdata.totalCost],
      marginPercent: [existingdata.marginPercent, [Validators.required]],
      marginInAmount: [0],
      platformFeeInAmount: [0],
      riskFeeInAmount: [0],
      financeFeeInAmount: [0],
      price: [existingdata.price],
      resources: [resourceData],

      totalQuantity: [0],
      totalUnitCost: [0],
      totalDirectCost: [0],
      totalMarginAmount: [0],
      totalPlatformFee: [0],
      totalRiskFee: [0],
      totalFinanceFee: [0],
      finalTotalCost: [0],
      finalTotalPrice: [0],
    });
  }
  initProjectManagementResourceRows() {
    return this._fb.group({
      id: [0],
      resourceId: [0],
      categoryId: [0],
      displayTitle: [''],
      unitCost: [0],
      directCost: [0],
      platformFeePercent: [0],
      riskFeePercent: [0],
      financeFeePercent: [0],
      totalCost: [0],
      marginPercent: [0],
      marginInAmount: [0],
      platformFeeInAmount: [0],
      riskFeeInAmount: [0],
      financeFeeInAmount: [0],
      price: [0],
      resources: [[]],

      totalQuantity: [0],
      totalUnitCost: [0],
      totalDirectCost: [0],
      totalMarginAmount: [0],
      totalPlatformFee: [0],
      totalRiskFee: [0],
      totalFinanceFee: [0],
      finalTotalCost: [0],
      finalTotalPrice: [0],
    });
  }
  addProjectManagementResourceRow() {
    const control = this.projectManagementResourceForm.get('Rows') as FormArray;
    control.push(this.initProjectManagementResourceRows());
    this.projectActivityResourceService
      .getResourcesByCategoryId(ResourceCategoryEnum.ProjectManagement)
      .subscribe((res) => {
        if (res.results) {
          const formControl = this.getProjectManagementResourceControls.at(
            control.length - 1
          ) as FormGroup;
          formControl.controls['resources'].setValue(res.results);
          
        }
      });
  }
  get getProjectManagementResourceControls() {
    const control = this.projectManagementResourceForm.get('Rows') as FormArray;
    return control;
  }
  onSelectTitleForExistingDataPM(index) {
    let controlItem = this.getProjectManagementResourceControls.at(
      index
    ) as FormGroup;
    let resourceId = controlItem.controls['resourceId'].value;
    let resource = controlItem.controls['resources'].value.filter((x) => {
      if (x.id == resourceId) {
        return x;
      }
    });

    controlItem.controls['displayTitle'].setValue(resource[0].displayName);
    let totalTechQuantity = 0;
    this.activityResourceForm.value.Rows.forEach((ele) => {
      totalTechQuantity = totalTechQuantity + +ele.quantity;
    });

    controlItem.controls['directCost'].setValue(resource[0].cost);

    this.projectManagementTypeSubTotal();
  }
  onSelectTitlePM(index) {
    let controlItem = this.getProjectManagementResourceControls.at(
      index
    ) as FormGroup;
    let resourceId = controlItem.controls['resourceId'].value;
    let resource = controlItem.controls['resources'].value.filter((x) => {
      if (x.id == resourceId) {
        return x;
      }
    });

    controlItem.controls['displayTitle'].setValue(resource[0].displayName);
    controlItem.controls['categoryId'].setValue(resource[0].categoryId);
    controlItem.controls['unitCost'].setValue(resource[0].cost);
    let totalTechQuantity = 0;
    this.activityResourceForm.value.Rows.forEach((ele) => {
      totalTechQuantity = totalTechQuantity + +ele.quantity;
    });

    controlItem.controls['directCost'].setValue(resource[0].cost);

    this.projectManagementTypeSubTotal();
  }

  onPlatformFeeChangePM(index) {
    let controlItem = this.getProjectManagementResourceControls.at(
      index
    ) as FormGroup;
    let platformFeePercent = +controlItem.controls['platformFeePercent'].value;
    let directCost = +controlItem.controls['directCost'].value;
    if (platformFeePercent !== 0) {
      controlItem.controls['platformFeeInAmount'].setValue(
        (platformFeePercent / 100) * directCost
      );
    } else {
      controlItem.controls['platformFeeInAmount'].setValue(0);
    }
    this.onRiskChangePM(index);
  }
  onRiskChangePM(index) {
    let controlItem = this.getProjectManagementResourceControls.at(
      index
    ) as FormGroup;
    let riskFeePercent = controlItem.controls['riskFeePercent'].value;
    let directCost = controlItem.controls['directCost'].value;
    let platformFeeAmount = controlItem.controls['platformFeeInAmount'].value;

    if (riskFeePercent !== 0) {
      controlItem.controls['riskFeeInAmount'].setValue(
        (parseInt(directCost) + parseInt(platformFeeAmount)) *
          (parseInt(riskFeePercent) / 100)
      );
    } else {
      controlItem.controls['riskFeeInAmount'].setValue(0);
    }
    this.onFinanceFeeChangePM(index);
  }
  onFinanceFeeChangePM(index) {
    let controlItem = this.getProjectManagementResourceControls.at(
      index
    ) as FormGroup;
    let financeFeePercent = controlItem.controls['financeFeePercent'].value;
    let riskFeeAmount = controlItem.controls['riskFeeInAmount'].value;
    let directCost = controlItem.controls['directCost'].value;
    let platformFeeAmount = controlItem.controls['platformFeeInAmount'].value;

    if (financeFeePercent !== 0) {
      controlItem.controls['financeFeeInAmount'].setValue(
        (parseInt(directCost) +
          parseInt(platformFeeAmount) +
          parseInt(riskFeeAmount)) *
          (parseInt(financeFeePercent) / 100)
      );
    } else {
      controlItem.controls['financeFeeInAmount'].setValue(0);
    }
    this.calculateTotalCostPM(index);
  }
  calculateTotalCostPM(index) {
    let controlItem = this.getProjectManagementResourceControls.at(
      index
    ) as FormGroup;
    let financeFeeAmount = controlItem.controls['financeFeeInAmount'].value;
    let riskFeeAmount = controlItem.controls['riskFeeInAmount'].value;
    let directCost = controlItem.controls['directCost'].value;
    let platformFeeAmount = controlItem.controls['platformFeeInAmount'].value;
    controlItem.controls['totalCost'].setValue(
      parseInt(directCost) +
        parseInt(platformFeeAmount) +
        parseInt(riskFeeAmount) +
        parseInt(financeFeeAmount)
    );
    this.onMarginChangePM(index);
  }
  onMarginChangePM(index) {
    let controlItem = this.getProjectManagementResourceControls.at(
      index
    ) as FormGroup;
    let marginPercent = controlItem.controls['marginPercent'].value;
    let directCost = controlItem.controls['directCost'].value;
    let platformFeeAmount = controlItem.controls['platformFeeInAmount'].value;
    let riskFeeAmount = controlItem.controls['riskFeeInAmount'].value;

    if (marginPercent !== 0) {
      var sumOfFee =
        parseInt(directCost) +
        parseInt(platformFeeAmount) +
        parseInt(riskFeeAmount);
      var remainingPercentForFinanceFee = (100 - parseInt(marginPercent)) / 100;
      controlItem.controls['marginInAmount'].setValue(
        sumOfFee / remainingPercentForFinanceFee - sumOfFee
      );
    } else {
      controlItem.controls['marginInAmount'].setValue(0);
    }
    this.calculateTotalPricePM(index);
  }
  calculateTotalPricePM(index) {
    let controlItem = this.getProjectManagementResourceControls.at(
      index
    ) as FormGroup;
    let totalCost = controlItem.controls['totalCost'].value;
    let marginAmount = controlItem.controls['marginInAmount'].value;
    controlItem.controls['price'].setValue(
      parseInt(totalCost) + parseInt(marginAmount)
    );
    this.projectManagementTypeSubTotal();
  }
  projectManagementTypeSubTotal() {
    let totalDirectCost = 0;
    let totalUnitCost = 0;
    let totalPlatformFee = 0;
    let totalRiskFee = 0;
    let totalFinanceFee = 0;
    let finalTotalCost = 0;
    let finalTotalPrice = 0;
    let totalMarginAmount = 0;

    this.projectManagementResourceForm.value.Rows.forEach((ele) => {
      totalDirectCost += ele.directCost;
      totalUnitCost += ele.unitCost;
      totalPlatformFee += ele.platformFeeInAmount;
      totalRiskFee += ele.riskFeeInAmount;
      totalFinanceFee += ele.financeFeeInAmount;
      finalTotalCost += ele.totalCost;
      finalTotalPrice += ele.price;
      totalMarginAmount += ele.marginInAmount;
    });
    for (let i = 0; i < this.getProjectManagementResourceControls.length; i++) {
      let controlItem = this.getProjectManagementResourceControls.at(
        i
      ) as FormGroup;
      controlItem.controls['totalDirectCost'].setValue(totalDirectCost);
      controlItem.controls['totalUnitCost'].setValue(totalUnitCost);
      controlItem.controls['totalPlatformFee'].setValue(totalPlatformFee);
      controlItem.controls['totalRiskFee'].setValue(totalRiskFee);
      controlItem.controls['totalFinanceFee'].setValue(totalFinanceFee);
      controlItem.controls['finalTotalCost'].setValue(finalTotalCost);
      controlItem.controls['finalTotalPrice'].setValue(finalTotalPrice);
      controlItem.controls['totalMarginAmount'].setValue(totalMarginAmount);
    }
    this.onCalculateGrandTotal();
  }
  removeResourcePM(index) {
    this.getProjectManagementResourceControls.removeAt(index);
    this.projectManagementTypeSubTotal();
  }

  //Save resources to db.
  saveResources(resource: Resource[])
  {
    let updateResourceFlag: boolean = false;
    let newResourceFlag: boolean = false;
    resource.forEach((element) => {
      if (!element.categoryId) {
        this.toaster.error('Select appropriate category.');
        newResourceFlag = true;
      } else if (!element.resourceId) {
        this.toaster.error('Select appropriate title');
        newResourceFlag = true;
      }
    });
    if(newResourceFlag === false){
    this.activityResourceTotal.id = this.data.activityID;
    this.activityResourceForm.value.Rows.forEach((element) => {
      this.activityResourceTotal.totalVariableCost += element.directCost;
      this.activityResourceTotal.authorizedCost += element.unitCost;
      this.activityResourceTotal.riskPercent += element.riskFeeInAmount
      this.activityResourceTotal.financeFeePercent += element.financeFeeInAmount
      this.activityResourceTotal.platformFeePercent += element.platformFeeInAmount
      this.activityResourceTotal.roundingAmount += element.directCost;
    });

    this.projectManagementResourceForm.value.Rows.forEach((element) => {
      this.activityResourceTotal.totalFixedCost += element.directCost;
      this.activityResourceTotal.authorizedCost += element.unitCost;
      this.activityResourceTotal.riskPercent += element.riskFeeInAmount
      this.activityResourceTotal.financeFeePercent += element.financeFeeInAmount
      this.activityResourceTotal.platformFeePercent += element.platformFeeInAmount
      this.activityResourceTotal.roundingAmount += element.directCost;
    });

    this.activityResourceTotal.cogs  = this.activityResourceTotal.totalFixedCost + this.activityResourceTotal.totalVariableCost;
    this.activityResourceTotal.grossProfit = this.activityResourceTotal.cogs;
    this.activityResourceTotal.variableMarginPercent = (this.activityResourceTotal.grossProfit/this.activityResourceTotal.roundingAmount)*100;
    this.activityResourceTotal.totalBudgetExpenses = this.activityResourceTotal.totalFixedCost + this.activityResourceTotal.financeFeePercent
    this.activityResourceTotal.budgetIncome = this.activityResourceTotal.roundingAmount - (this.activityResourceTotal.cogs + this.activityResourceTotal.totalBudgetExpenses)
    this.activityResourceTotal.budgetMargin=(this.activityResourceTotal.budgetIncome/this.activityResourceTotal.roundingAmount)*100;

    let contractActivityResources:ContractActivityResourceMainDto = {
      resource: resource,
      resourceTotal: this.activityResourceTotal
    }

    let existingResources = contractActivityResources.resource.filter((ele) => ele.id !== 0);
    if (existingResources.length == 0) {
      updateResourceFlag = true;
    }

    let newAddedResources = contractActivityResources.resource.filter((ele) => ele.id == 0);
    if (newAddedResources.length == 0) {
      newResourceFlag = true;
    }

    if (newResourceFlag == false)
    {
      contractActivityResources.resource = newAddedResources;
      this.projectActivityResourceService
        .addActivityResource(contractActivityResources)
        .subscribe({
          next:(res)=>
          {
            this.toaster.success('Resources added successfully.');
            this.closeModal();
            this.data.obs.next(this.data);
            this.modalClose.emit(this.data);
          },
          error:(err)=>
          {
            this.toaster.error('Something went wrong.');
          }
        });
    }
    if (updateResourceFlag == false)
    {
      contractActivityResources.resource = existingResources;
      this.projectActivityResourceService
        .updateProjectActivityresources(contractActivityResources)
        .subscribe({
          next:(res)=>
          {
            this.toaster.success('Resources added successfully.');
            this.closeModal();
            this.data.obs.next(this.data);
            this.modalClose.emit(this.data);
          },
          error:(err)=>
          {
            this.toaster.error('Something went wrong.');
          }
        });
    }
  }
  }

  //Modal methods.
  onCloseModal(): void {
    this.closeModal();
    this.data.obs.next(this.data);
    this.modalClose.emit(null);
  }
  onSaveModal(): void {
    this.resourceData = [];
    this.activityResourceForm.value.Rows.forEach((ele) => {
      let newResource: Resource = {
        id: ele.id,
        contractActivityId: this.data.activityID,
        categoryId: ele.categoryId,
        resourceId: ele.resourceId,
        quantity: ele.quantity,
        unitCost: ele.unitCost,
        directCost: ele.directCost,
        marginPercent: ele.marginPercent,
        margin: ele.marginPercent,
        platformFee: ele.platformFeePercent,
        riskFee: ele.riskFeePercent,
        financeFee: ele.financeFeePercent,
        totalCost: ele.totalCost,
        materialType: null,
        price: ele.price,
        rouncedPrice: ele.price,
        createdBy: null,
        modifiedBy: null,
      };
      this.resourceData.push(newResource);
    });

    this.projectManagementResourceForm.value.Rows.forEach((ele) => {
      let newResource: Resource = {
        id: ele.id,
        contractActivityId: this.data.activityID,
        resourceId: ele.resourceId,
        categoryId: ele.categoryId,
        quantity: 1,
        unitCost: ele.unitCost,
        directCost: ele.directCost,
        marginPercent: ele.marginPercent,
        margin: ele.marginPercent,
        platformFee: ele.platformFeePercent,
        riskFee: ele.riskFeePercent,
        financeFee: ele.financeFeePercent,
        totalCost: ele.totalCost,
        materialType: null,
        price: ele.price,
        rouncedPrice: ele.price,
        createdBy: null,
        modifiedBy: null,
      };
      this.resourceData.push(newResource);
    });
    if (this.resourceData.length > 0) {
      this.saveResources(this.resourceData);
    } else {
      this.toaster.error('No data selected.');
    }
  }
  onCancelModal(): void {
    this.closeModal();
    this.data.obs.next(this.data);
    this.modalClose.emit(null);
  }
}
