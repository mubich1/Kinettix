import { Component, Injector, OnInit } from '@angular/core';
import { BaseModal, InlineLoadingState } from 'carbon-components-angular';
import { ToastrService } from 'ngx-toastr';
import { Subject, takeUntil } from 'rxjs';
import { Platform } from 'src/app/models/platform/platform';
import { PurchaseOrderPlatform } from 'src/app/models/purchaseOrder/purchase-order';
import { PlatformService } from 'src/app/services/platform/platform.service';
import { PurchaseOrderService } from 'src/app/services/purchase-order/purchase-order.service';

@Component({
  selector: 'app-po-posting-platform-selection-dialogue',
  templateUrl: './po-posting-platform-selection-dialogue.component.html',
  styleUrls: ['./po-posting-platform-selection-dialogue.component.css']
})
export class PoPostingPlatformSelectionDialogueComponent extends BaseModal implements OnInit {

  modalObj: any;
  kinettixGlobalTechPool: boolean = false;
  workMarket: boolean = false;
  fieldNation: boolean = false;
  loadingState = InlineLoadingState.Inactive;
  isPosting: boolean = false;
  ngUnsubscribe = new Subject<void>();
  platforms: Platform[] = [];
  platformCheckboxList: any = [];

  poPlatform: PurchaseOrderPlatform;

  constructor(
    protected injector: Injector,
    private platfromService: PlatformService,
    private purchaseOrderService: PurchaseOrderService,
    private toastr: ToastrService
  ) {
    super();
    this.modalObj = this.injector.get('data');

  }

  ngOnInit(): void {
    
    this.getPlatforms();
    this.poPlatform = this.modalObj.data;
  }


  setCheckboxValues(platforms: Platform[]) {
    if (platforms != null && platforms.length > 0) {
      this.platformCheckboxList = [];

      platforms.forEach(element => {

        let checkBoxObj = { id: element.id, name: element.name, selected: false };

        if (this.poPlatform.platforms != null && this.poPlatform.platforms.some(x => x.id == element.id)) {
          checkBoxObj.selected = true;
        }
        this.platformCheckboxList.push(checkBoxObj);

      });

    }
  }

  onCheckedChange(platform, event) {

    let index = -1;
    if(this.poPlatform.platforms != null && this.poPlatform.platforms.length > 0){
      index = this.poPlatform.platforms.findIndex(x => x.id == platform.id);
    }

    if (event) {
      if (index < 0) {
        if(this.poPlatform.platforms == null){
          this.poPlatform.platforms = [];
        }
        this.modalObj.data.platforms.push(platform);
      }
    }
    else {
      if (index > -1) {
        this.modalObj.data.platforms.splice(index, 1);
      }
    }

  }

  getPlatforms() {
    this.isPosting = true;
    this.platfromService.getPlatform()
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe({
        next: res => {
          this.setCheckboxValues(res.results);
        },
        error: e => {
          this.toastr.error('Something went wrong while loading platforms');
          this.closeMyModalByCross();
        },
        complete: () => {
          this.isPosting = false;
        }
      });
  }

  savePlatform() {
    this.isPosting = true;
    this.loadingState = InlineLoadingState.Active;
    this.purchaseOrderService.addOrUpdatePlatform(this.poPlatform).subscribe({
      next: res => {
        if(res.results){
          this.toastr.success('Platform Updated successfully');
        }
        
      },
      error: e => {
        
        this.toastr.error('Something went wrong');
        this.isPosting = false;
        this.loadingState = InlineLoadingState.Inactive;
        this.closeMyModalByCross();
      },
      complete: () => {
        this.isPosting = false;
        this.loadingState = InlineLoadingState.Inactive;
        this.closeMyModalByCross();
      }
    });
  }

  closeMyModalByCross() {
    this.closeModal();
    this.modalObj.isClosed = true;
    this.modalObj.confirm = false;
    this.modalObj.obs.next(this.modalObj);
    this.ngOnDestroy();

  }

  closeMyModal() {
    this.closeModal();
    this.modalObj.isClosed = false;
    this.modalObj.confirm = false;
    this.modalObj.obs.next(this.modalObj);
    this.ngOnDestroy();
  }

  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

}
