import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PoPostingPlatformSelectionDialogueComponent } from './po-posting-platform-selection-dialogue.component';

describe('PoPostingPlatformSelectionDialogueComponent', () => {
  let component: PoPostingPlatformSelectionDialogueComponent;
  let fixture: ComponentFixture<PoPostingPlatformSelectionDialogueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PoPostingPlatformSelectionDialogueComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PoPostingPlatformSelectionDialogueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
