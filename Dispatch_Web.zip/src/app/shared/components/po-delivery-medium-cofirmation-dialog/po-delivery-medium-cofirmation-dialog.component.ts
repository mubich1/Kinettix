import { Component, EventEmitter, Injector, Output} from '@angular/core';
import { BaseModal, RadioChange } from 'carbon-components-angular';
import { SendPOModalData, SendPOOptionsEnum,DownloadPOOptionsEnum } from 'src/app/models/purchaseOrder/purchase-order';

@Component({
  selector: 'app-po-delivery-medium-cofirmation-dialog',
  templateUrl: './po-delivery-medium-cofirmation-dialog.component.html',
  styleUrls: ['./po-delivery-medium-cofirmation-dialog.component.css']
})


export class PoDeliveryMediumCofirmationDialogComponent extends BaseModal {

  @Output() emitData = new EventEmitter();
  data: SendPOModalData;
  isOpenDeleteModal: boolean = true;
  showEmailMessage: boolean = false;
  showESignEmail: boolean = false;
  ShowSubject: boolean = false;
  emailMessage: string = "";
  subject: string = "";
  toEmails: any[] = [];
  ccEmails: any[] = [];
  showAttachmentOptions: boolean = false;

  constructor(protected injector: Injector) {
    super();

    this.data = this.injector.get('data');
  }



  onChangeRadioBtn(event: RadioChange){
    if(event.value == SendPOOptionsEnum.Email.toString()){
      this.data.confirmationButtoText = 'Send';
      this.showEmailMessage = true;
      this.ShowSubject=true;
    }
    else if(event.value == SendPOOptionsEnum.Download.toString()){
      this.data.confirmationButtoText = 'Download';
      this.showEmailMessage = false;
      this.ShowSubject=false;
    }
    if(event.value){
      this.data.selectedOption = event.value;
    }
  }
  
  onChangeRadioBtnDownload(event: RadioChange){
    if(event.value == DownloadPOOptionsEnum.PurchaseOrder.toString()){
      this.data.downloadType = event.value;
    }
     if(event.value == DownloadPOOptionsEnum.WorkOrder.toString()){
      this.data.downloadType = event.value;
    }
     else if(event.value == DownloadPOOptionsEnum.Both.toString()){
      this.data.downloadType = event.value;
    }
    if(event.value){
      this.data.downloadType = event.value;
    }
  }

  closeMyModalByCross() {
    this.data.isClosed = true;
    this.data.confirm = false;
    this.data.obs.next(this.data);
    this.closeModal();
  }

  closeMyModal() {
    this.data.isClosed = false;
    this.data.confirm = false;
    this.data.obs.next(this.data);
    this.closeModal();
  }

  onConfirmation() {
    this.data.emailMessage = this.emailMessage;
    this.data.subject = this.subject;
    this.data.recipientEmailList = this.toEmails.length > 0 ? this.toEmails.map(x => x.value) : null;
    this.data.ccEmailList = this.ccEmails.length > 0 ? this.ccEmails.map(x => x.value) : null;
    this.data.isClosed = false;
    this.data.confirm = true;
    this.emitData.emit(this.data)
    this.data.obs.next(this.data);
    this.closeModal();
  }
}
