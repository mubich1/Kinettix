import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PoDeliveryMediumCofirmationDialogComponent } from './po-delivery-medium-cofirmation-dialog.component';

describe('PoDeliveryMediumCofirmationDialogComponent', () => {
  let component: PoDeliveryMediumCofirmationDialogComponent;
  let fixture: ComponentFixture<PoDeliveryMediumCofirmationDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PoDeliveryMediumCofirmationDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PoDeliveryMediumCofirmationDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
