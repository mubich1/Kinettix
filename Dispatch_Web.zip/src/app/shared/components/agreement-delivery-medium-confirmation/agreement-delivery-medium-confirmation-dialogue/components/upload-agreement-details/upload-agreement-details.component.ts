import { Component, ElementRef, EventEmitter, Output, ViewChild } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { EMPTY, catchError } from 'rxjs';
import { DealDocumentService } from 'src/app/services/document/deal-document.service';
import { ModuleNameEnum } from 'src/app/shared/enum/module-name-enum';

@Component({
  selector: 'app-upload-agreement-details',
  templateUrl: './upload-agreement-details.component.html',
  styleUrls: ['./upload-agreement-details.component.css']
})
export class UploadAgreementDetailsComponent {

  constructor(private dealDocument: DealDocumentService, private toastr: ToastrService) { }

  @ViewChild('uploadInput') input: ElementRef;

  @Output() agreementFileUploaded = new EventEmitter<string | null>();

  selectedFile: File | null = null;

  uploading: boolean = false;

  uploadFileClick(): void {
    this.input.nativeElement.click();
  }

  uploadFile(event: any): void {
    // The parent component uses null to determine whether or not the modal's button is disabled. This will
    // mark the button as disabled while the file is uploading when a file is being replaced.
    this.agreementFileUploaded.emit(null);

    this.uploading = true;

    const files: FileList = event.target.files;
    this.selectedFile = files[0];

    const reader = new FileReader();
    reader.readAsDataURL(this.selectedFile);

    reader.onload = () => {
      const base64 = reader.result!.toString();

      const agreementDocument = {
        name: this.selectedFile!.name,

        filebase64string: base64,
        moduleName: ModuleNameEnum.Deal
      };

      this.dealDocument.uploadDocument(agreementDocument).pipe(
        catchError(() => {
          this.uploading = false;

          this.toastr.error('Error uploading agreement');

          return EMPTY;
        }),
      ).subscribe(res => {
        this.uploading = false;

        this.agreementFileUploaded.emit(res.document.path);
      });
    };
  }

}
