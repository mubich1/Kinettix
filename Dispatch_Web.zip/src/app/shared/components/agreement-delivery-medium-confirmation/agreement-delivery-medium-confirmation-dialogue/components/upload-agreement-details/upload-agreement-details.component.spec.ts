import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadAgreementDetailsComponent } from './upload-agreement-details.component';

describe('UploadAgreementDetailsComponent', () => {
  let component: UploadAgreementDetailsComponent;
  let fixture: ComponentFixture<UploadAgreementDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UploadAgreementDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadAgreementDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
