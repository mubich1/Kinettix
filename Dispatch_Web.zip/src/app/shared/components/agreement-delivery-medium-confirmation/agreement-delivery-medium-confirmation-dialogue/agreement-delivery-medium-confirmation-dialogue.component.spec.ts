import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgreementDeliveryMediumConfirmationDialogueComponent } from './agreement-delivery-medium-confirmation-dialogue.component';

describe('AgreementDeliveryMediumConfirmationDialogueComponent', () => {
  let component: AgreementDeliveryMediumConfirmationDialogueComponent;
  let fixture: ComponentFixture<AgreementDeliveryMediumConfirmationDialogueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AgreementDeliveryMediumConfirmationDialogueComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AgreementDeliveryMediumConfirmationDialogueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
