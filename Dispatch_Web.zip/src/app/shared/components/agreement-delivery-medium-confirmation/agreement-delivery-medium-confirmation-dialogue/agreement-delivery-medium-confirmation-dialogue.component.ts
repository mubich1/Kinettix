import { Component, Injector, OnInit } from '@angular/core';
import { BaseModal, RadioChange } from 'carbon-components-angular';
import { AgreementFormatOptionsEnum, SendAgreementOptionsEnum } from 'src/app/models/dialog/send-agreement';
import { ClientService } from 'src/app/services/client/client.service';

@Component({
  selector: 'app-agreement-delivery-medium-confirmation-dialogue',
  templateUrl:
    './agreement-delivery-medium-confirmation-dialogue.component.html',
  styleUrls: [
    './agreement-delivery-medium-confirmation-dialogue.component.css',
  ],
})
export class AgreementDeliveryMediumConfirmationDialogueComponent extends BaseModal implements OnInit {
  data: any;
  isOpenDeleteModal: boolean = true;
  showEmailMessage: boolean = false;
  showESignEmail: boolean = false;
  showUploadAgreementDetails: boolean = false;
  selectedOption: string = SendAgreementOptionsEnum.Download.toString();
  showDownloadOptions: boolean = true;
  showAttachmentOptions: boolean = false;
  downloadFormat: string = AgreementFormatOptionsEnum.PDF.toString();
  attachmentFormat: string = AgreementFormatOptionsEnum.PDF.toString();
  emailMessage: string = "";
  contactsList: any;
  toEmails: any = [];
  ccEmails: any = [];

  // Used for the upload agreement details component. This tracks the URL of the uploaded agreement. Null when loading or no document has been uploaded.
  agreementDocumentPath: string | null = null;

  constructor(protected injector: Injector,
    private clientService: ClientService) {
    super();

    this.data = this.injector.get('data');
  }

  ngOnInit(): void {
    this.getClientContactsDropdown();
  }

  getClientContactsDropdown() {
    this.clientService.getClientContacts().subscribe(res => {
      this.contactsList = res.results;
    })
  }

  customSearchFn(item: string, items: any) {
    return items.fullName.toLocaleString().toLowerCase().startsWith(item.toLocaleString().toLowerCase())
}

  onChangeRadioBtn(event: RadioChange) {
    // Always reset after the option has changed.
    this.agreementDocumentPath = null;

    if (event.value == SendAgreementOptionsEnum.Email.toString()) {
      this.data.confirmationButtonText = 'Send';
      this.showEmailMessage = true;
      this.showESignEmail = false;
      this.showDownloadOptions = false;
      this.showAttachmentOptions = true;


    }
    else if (event.value == SendAgreementOptionsEnum.Download.toString()) {
      this.data.confirmationButtonText = 'Download';
      this.showEmailMessage = false;
      this.showESignEmail = false;
      this.showDownloadOptions = true;
      this.showAttachmentOptions = false;
      this.showUploadAgreementDetails = false;
    }
    else if (event.value == SendAgreementOptionsEnum.ESign.toString()) {
      this.data.confirmationButtonText = 'Send';
      this.showEmailMessage = false;
      this.showESignEmail = true;
      this.showDownloadOptions = false;
      this.showAttachmentOptions = false;
      this.showUploadAgreementDetails = false;
    } else if (event.value == SendAgreementOptionsEnum.UploadAgreement.toString()) {
      this.data.confirmationButtonText = 'Upload';
      this.showEmailMessage = false;
      this.showESignEmail = false;
      this.showDownloadOptions = false;
      this.showAttachmentOptions = false;
      this.showUploadAgreementDetails = true;
    }

    if (event.value) {
      this.selectedOption = event.value;
    }

  }

  onReceivedAgreementDocumentPath(documentUrl: string | null): void {
    this.agreementDocumentPath = documentUrl;
  }

  closeMyModalByCross() {
    this.closeModal();
    this.data.isClosed = true;
    this.data.confirm = false;
    this.data.obs.next(this.data);
  }

  closeMyModal() {
    this.closeModal();
    this.data.isClosed = false;
    this.data.confirm = false;
    this.data.obs.next(this.data);
  }

  onConfirmation() {

    this.data.selectedOption = this.selectedOption;
    this.data.selectedDownloadFormatOption = this.downloadFormat;
    this.data.attachmentFormat = this.attachmentFormat;
    this.data.emailMessage = this.emailMessage;
    this.data.agreementDocumentPath = this.agreementDocumentPath;
    this.data.recipientEmailList = this.toEmails ? this.toEmails : [];
    this.data.ccEmailList = this.ccEmails.length > 0 ? this.ccEmails.map(x => x.value) : [];
    this.closeModal();
    this.data.isClosed = false;
    this.data.confirm = true;
    this.data.obs.next(this.data);
  }
}
