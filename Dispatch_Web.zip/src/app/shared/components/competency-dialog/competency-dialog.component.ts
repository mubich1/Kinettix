import { Component, Injector, OnInit } from '@angular/core';
import { BaseModal } from 'carbon-components-angular';
import {
  InputDialog,
  InputDialogCompenticies,
} from 'src/app/models/dialog/input-dialog';
import { CompetencyViewModel } from 'src/app/models/vendor-technicians/technicians';

@Component({
  selector: 'app-competency-dialog',
  templateUrl: './competency-dialog.component.html',
  styleUrls: ['./competency-dialog.component.css'],
})
export class CompetencyDialogComponent extends BaseModal implements OnInit {
  competencies: CompetencyViewModel[] = [];
  competenciesObject: CompetencyViewModel;
  modalText: string;
  data: InputDialogCompenticies;
  isModalOpen: boolean = true;
  isOpenDateModal = false;
  isDisabled: boolean = true;
  expireDate:Date | null;

  constructor(protected injector: Injector) {
    super();
    this.data = this.injector.get('data');
    this.data.valueArray = this.data.valueArray?.map((x) => x.compentency);
  }

  ngOnInit(): void {}

  closeMyModal() {
    this.closeModal();
    this.data.confirm = false;
    this.data.obs.next(this.data);
  }

  onConfirmation() {
    this.closeModal();
    this.data.confirm = true;
    this.data.obs.next(this.data);
  }

  onItemAdd(event:CompetencyViewModel){
    if(event.isExpireable)
    {
      this.isOpenDateModal=true;
      this.competenciesObject=event;
    }

  }

  onConfirmationSaveDate(){
    this.data.valueArray.find(x=>x.id==this.competenciesObject.id).expireDate= new Date(this.expireDate!);
    this.expireDate= null;
    this.isOpenDateModal = false;
  }

  closeDateModal() {
    this.data.valueArray=this.data.valueArray.filter(obj =>obj.id!==this.competenciesObject.id);
    this.isOpenDateModal = false;
    this.expireDate= null;
  }
}
