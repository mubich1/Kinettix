import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TurnoverProcessDialogueComponent } from './turnover-process-dialogue.component';

describe('TurnoverProcessDialogueComponent', () => {
  let component: TurnoverProcessDialogueComponent;
  let fixture: ComponentFixture<TurnoverProcessDialogueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TurnoverProcessDialogueComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TurnoverProcessDialogueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
