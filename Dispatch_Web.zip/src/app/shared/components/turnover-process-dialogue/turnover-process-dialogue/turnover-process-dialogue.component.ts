import { Component, Injector, OnInit } from '@angular/core';
import { BaseModal } from 'carbon-components-angular';
import { DealService } from 'src/app/services/deals/deal.service';

@Component({
  selector: 'app-turnover-process-dialogue',
  templateUrl: './turnover-process-dialogue.component.html',
  styleUrls: ['./turnover-process-dialogue.component.css']
})
export class TurnoverProcessDialogueComponent extends BaseModal implements OnInit {
  data: any;
  isOpenDeleteModal: boolean = true;

  allowTurnover:boolean = false;
  allowView:boolean = false;
  isAccountExecutiveAssigned:boolean = false;
  isActivityAssigned:boolean = false;
  isInvoicingEntityAssigned:boolean = false;
  isSignedDocumentUploaded:boolean = false;

  constructor(protected injector: Injector,
              private dealService:DealService) {
    super();

    this.data = this.injector.get('data');
   }

  ngOnInit(): void {
    this.getTurnoverProcessRequirements(+this.data.data)
  }

  getTurnoverProcessRequirements(contractID:number){

    this.dealService.getTurnOverRequirementsList(contractID).subscribe({

      next:(res)=>{

        if(res.results.isAccountExecutiveAssigned &&
           res.results.isActivityAssigned &&
           res.results.isInvoicingEntityAssigned &&
           res.results.isSignedDocumentUploaded){
            this.allowTurnover = true; 
          }
          this.allowView = true;
          this.isAccountExecutiveAssigned = res.results.isAccountExecutiveAssigned;
          this.isActivityAssigned = res.results.isActivityAssigned;
          this.isInvoicingEntityAssigned = res.results.isInvoicingEntityAssigned;
          this.isSignedDocumentUploaded = res.results.isSignedDocumentUploaded;
      }
    })
  }

  closeMyModalByCross() {
    this.closeModal();
    this.data.isClosed = true;
    this.data.confirm = false;
    this.data.obs.next(this.data);
  }

  closeMyModal() {
    this.closeModal();
    this.data.isClosed = false;
    this.data.confirm = false;
    this.data.obs.next(this.data);
  }

  onConfirmation() {
    this.closeModal();
    this.data.isClosed = false;
    this.data.confirm = true;
    this.data.obs.next(this.data);
  }
}
