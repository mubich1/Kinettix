import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(carData: any[], searchString: string) {
    if (!carData || !searchString) {
      return carData;
    }
    const carDataWithNestedFilter = carData.map((item) => {
      const newItem = { ...item }; // copy the item to not manipulate the original one
      newItem.subHeading = item.subHeading?.filter((car) =>
        car.name.toLowerCase().includes(searchString.toLowerCase())
      );
      return newItem;
    });
    return carDataWithNestedFilter.filter((item) => {
      const nameIncludes = item.name
        .toLowerCase()
        .includes(searchString.toLowerCase());
      return item.subHeading?.length > 0 || nameIncludes;
    });
  }

}