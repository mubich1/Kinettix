export class TinyMCEConfiguration {
  static apiKey: string = 'rkbcoueifq6g75nrpvyebv0w0eqttonwykk49i641f5md4t7';
  static settings = {
    height: 500,
    min_height: 250,
    menubar: false,
    branding: false,
    plugins: [
      'powerpaste',
      'advlist autolink lists link image charmap print preview anchor',
      'searchreplace visualblocks code fullscreen',
      'insertdatetime media table paste code help wordcount',
    ],
    toolbar:
      'addDynamicFieldBtn | undo redo | formatselect | bold italic backcolor | \
            alignleft aligncenter alignright alignjustify | \
            bullist numlist outdent indent | image link | removeformat',
    setup: function (editor: any) {
      var items = [
        {
          type: 'menuitem',
          text: 'Name',
          onAction: function () {
            editor.insertContent('&nbsp;##Name##');
          },
        },
        {
          type: 'menuitem',
          text: 'Company Name',
          onAction: function () {
            editor.insertContent('&nbsp;##Company_Name##');
          },
        },
        {
          type: 'menuitem',
          text: 'Client Name',
          onAction: function () {
            editor.insertContent('&nbsp;##Client_Name##');
          },
        },
      ];

      editor.ui.registry.addMenuButton('addDynamicFieldBtn', {
        text: 'Add',
        fetch: function (callback: any) {
          callback(items);
        },
      });
    },
  };
}
