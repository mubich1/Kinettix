import { FormControl } from "@angular/forms";

export class AngularUtility {
    public getSum(items, prop): number {
        return items.reduce(function (a, b) {
            return a + b[prop];
        }, 0);
    }

    public isEmptyOrSpaces(str) {
        return str === null || str.match(/^ *$/) !== null;
    }

    // new FormControl(field.fieldValue || '', [Validators.required, this.noWhitespaceValidator])
    // <div *ngIf="yourForm.hasError('whitespace')">Please enter valid data</div>
    
    public noWhitespaceValidator(control: FormControl) {
        const isWhitespace = (control.value || '').trim().length === 0;
        const isValid = !isWhitespace;
        return isValid ? null : { 'whitespace': true };
    }
}
