export class UserPermissions  {
  canAdd = false;
  canEdit = false;
  canDelete = false;
  canView = false;
}
