export class TableFilters {
    sort?: string = "id";
    search?: string = '';
    page?: number = 1;
    pageSize?: number = 10;
    isAscending?: boolean = false;
}