import {
  ListItem, TableHeaderItem, TableItem, TableModel
} from "carbon-components-angular";


export class CarbonUtility {

  public getListItems(data: any, contentName: string, idName: string): ListItem[] {
    let items: ListItem[] = [];
    if (data != null && data.length > 0) {
      data.forEach((el: any) => {
        let item: ListItem = {
          content: el[contentName],
          id: el[idName],
          selected: false
        };
        items.push(item);

      });
    }
    return items;
  }


  public selectPage(page: any, tableModel: TableModel, tableData: any) {
    tableModel.currentPage = page;
    const fullPage: TableItem[][] = [];
    for (
      let i = (page - 1) * tableModel.pageLength;
      i < page * tableModel.pageLength &&
      i < tableModel.totalDataLength;
      i++
    ) {
      fullPage.push(tableData[0 + i]);
      tableModel.data = fullPage;
    }

    return tableModel;
  }

  public initializeTable(headers: TableHeaderItem[], tableModel: TableModel, data: TableItem[][], pageLength: number = 10, currentPage: number = 1): TableModel {
    tableModel.data = [];
    tableModel.header = [];

    headers.forEach(el => {
      tableModel.header.push(el);
    });

    if (data?.length > 0) {
      tableModel.data = data;
    }

    return this.setPaginationInfo(tableModel, data, pageLength, currentPage);
  }

  public setTableModel(headers: any[], tableModel: TableModel, data: TableItem[][], pageLength: number = 10, currentPage: number = 1, totalRecords: number = 10, template?: any): TableModel {
    tableModel.data = data;
    tableModel.header = this.initializeTableHeaders(headers, template);
    return this.setPaginationInfo(tableModel, data, pageLength, currentPage, totalRecords);
  }


  public setTableItem(rows: any[], value: any, expandedData?: any, expandAsTable?: boolean, template?: any): any[] {
    if (!rows) {
      rows = [];
    }
    rows.push(new TableItem({ data: value, expandedData: expandedData ? expandedData : null, expandAsTable: expandAsTable ? expandAsTable : false, template: template }));
    return rows;
  }

  public isEmptyOrSpaces(str) {
    return str === null || str.match(/^ *$/) !== null;
  }

  private initializeTableHeaders(columns: string[], template:any): TableHeaderItem[] {
    let headers: TableHeaderItem[] = [];
    if (columns?.length) {
      columns.forEach(col => {
        headers.push(new TableHeaderItem({ data: col, template: template ? template : null }));
      });
    }
    return headers;
  }

  private setPaginationInfo(tableModel: TableModel, data: TableItem[][], pageLength: number, currentPage: number, totalRecords?:number): TableModel {
    tableModel.pageLength = pageLength;
    tableModel.currentPage = currentPage;
    tableModel.totalDataLength = totalRecords ? totalRecords : data?.length;
    return tableModel;
  }
}