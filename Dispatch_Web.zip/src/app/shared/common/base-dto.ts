export interface BaseDto {
    id?: number;
    createdBy?: string;
    modifiedBy?: string;
    createdDate?: Date;
    modifiedDate?: Date;
    deleted?: boolean;
}