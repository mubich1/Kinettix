
import { Injectable, OnInit } from '@angular/core';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
  HttpParams,
  HttpResponse,
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { TableFilters } from 'src/app/shared/common/tableFilters';

@Injectable({
  providedIn: 'root',
})
export class BuyTicketService implements OnInit {

  constructor(private httpClient: HttpClient) {}

  ngOnInit() {

  }

  getPurchaseOrderByTicketId(id:number,payload: TableFilters): Observable<any> {
    return this.httpClient.get<any>(`${environment.workOrderApiBaseUrl}/ticket/${id}/purchaseorders?sort=${payload.sort}&search=${payload.search}&page=${payload.page}&pageSize=${payload.pageSize}&isAscending=${payload.isAscending}`);
  }
  delete(id:number,ticketid:number,userId=""): Observable<any> {

    return this.httpClient.delete(`${environment.workOrderApiBaseUrl}/ticket/${ticketid}/purchaseorders/${id}?userId=${userId}`);
  }
  updatePurchaseOrder(ticketId: number, purchaserorderid: number,request: any) {

    return this.httpClient.put<any>(`${environment.workOrderApiBaseUrl}/ticket/${ticketId}/purchaseorders/${purchaserorderid}`,request);
  }
  savePurchaseOrder(request: any) {

    return this.httpClient.post<any>(`${environment.workOrderApiBaseUrl}/ticket/purchaseorders`,request);
  }
  getTicketActivitiy(ticketId:number): Observable<any> {
    return this.httpClient.get<any>(
      `${environment.workOrderApiBaseUrl}/tickets/${ticketId}/ticketactivity`
    );
  }
}