import { TestBed } from '@angular/core/testing';

import { ReasonCodeTypesService } from './resaon-code-type.service';

describe('reasonCodeTypesService', () => {
  let service: ReasonCodeTypesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ReasonCodeTypesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
