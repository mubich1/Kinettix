import { TestBed } from '@angular/core/testing';

import { ActivityResourceService } from './activity-resource.service';

describe('ActivityResourceService', () => {
  let service: ActivityResourceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ActivityResourceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
