import { TestBed } from '@angular/core/testing';

import { TicketLabelService } from './ticket-label.service';

describe('TicketLabelService', () => {
  let service: TicketLabelService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TicketLabelService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
