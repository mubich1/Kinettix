import { Injectable, OnInit } from '@angular/core';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
  HttpParams,
  HttpResponse,
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { Team } from '../../models/team/team';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { environment } from 'src/environments/environment';
import { GetTicketLabel, Ticket, TicketLabel, TicketNotes, UpdateTicketSite } from 'src/app/models/tickets/tickets';

@Injectable({
  providedIn: 'root',
})
export class TicketLabelService implements OnInit {

  constructor(private httpClient: HttpClient) {}

  ngOnInit() {

  }
  getTicketLabelsByTicketId(id: number): Observable<ResponsePayloadDTO<GetTicketLabel[]>> {
    return this.httpClient.get<ResponsePayloadDTO<GetTicketLabel[]>>(`${environment.workOrderApiBaseUrl}/tickets/${id}/labels`);
  }

  getTicketLabelById(id:number,labelId:number):Observable<ResponsePayloadDTO<GetTicketLabel>> {
    return this.httpClient.get<ResponsePayloadDTO<GetTicketLabel>>(`${environment.workOrderApiBaseUrl}/tickets/${id}/labels/${labelId}`);
  }
  saveTicketLabel(id:number,template: TicketLabel): Observable<ResponsePayloadDTO<number>> {
    return this.httpClient.post<ResponsePayloadDTO<number>>(`${environment.workOrderApiBaseUrl}/tickets/${id}/labels`, template);
  }

  updateTicketLabel(id:number,template: TicketLabel): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.put<ResponsePayloadDTO<boolean>>(`${environment.workOrderApiBaseUrl}/tickets/${id}/labels`, template);
  }


  deleteTicketLabel(id: number, labelId:number): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.delete<ResponsePayloadDTO<boolean>>(`${environment.workOrderApiBaseUrl}/tickets/${id}/labels/${labelId}`);
  }  
  
}

