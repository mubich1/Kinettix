import { TestBed } from '@angular/core/testing';

import { ContractMilestoneManagerService } from './contract-milestone-manager.service';

describe('ContractMilestoneManagerService', () => {
  let service: ContractMilestoneManagerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ContractMilestoneManagerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
