import { HttpClient, HttpEvent, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ContractMilestone } from 'src/app/models/contract-task/contract-milestone';
import { UserNote } from 'src/app/models/usernote/usernote';
import { environment } from 'src/environments/environment';

@Injectable({
    providedIn: 'root'
})
export class ContractMilestoneManagerService {
    private workorderapi = `${environment.workOrderApiBaseUrl}`;
    constructor(private http: HttpClient) {
    }

    GetTasks(): Observable<any> {
        var res = this.http.get<any>(`${this.workorderapi}/contractTask/milestones`);
        return res;
    }


    getContractMilestone(contractId: number = 0): Observable<any> {
        return this.http.get(`${environment.workOrderApiBaseUrl}/ContractTask/milestones?contractId=${contractId}`);
    }

    deleteContractMilestone(contractId: number, payload: any): Observable<any> {
        return this.http.post(`${environment.workOrderApiBaseUrl}/ContractTask/deleteallcontracttaskandcontractmilestone?contractId=${contractId}`, payload);
    }

    createContractMilestone(contractId: number, payload: any): Observable<any> {
        return this.http.post(`${environment.workOrderApiBaseUrl}/ContractTask/contractmilestone?contractId=${contractId}`, payload);
    }

    createMultipleContractMilestone(contractId: number, payload: any): Observable<any> {
        return this.http.post(`${environment.workOrderApiBaseUrl}/ContractTask/contractmilestone/multiple?contractId=${contractId}`, payload);
    }

    saveAssignUser(contractId: number, payload: any): Observable<any> {
        return this.http.put(`${environment.workOrderApiBaseUrl}/ContractTask/contractassignuser?contractId=${contractId}`, payload);
    }

    getSavedContractMilestones(contractId: number): Observable<any> {
        return this.http.get(`${environment.workOrderApiBaseUrl}/ContractTask/Contractmilestones?contractId=${contractId}`)
    }

    saveCompleteMilestoneTask(contractId: number, payload): Observable<any> {
        return this.http.put(`${environment.workOrderApiBaseUrl}/ContractTask/contractcompletetask?contractId=${contractId}`, payload);

    }
    saveFailMilestoneTask(contractId: number, payload: any): Observable<any> {
        return this.http.put<any>(`${environment.workOrderApiBaseUrl}/ContractTask/failtask?contractId=${contractId}`, payload);
    }

}
