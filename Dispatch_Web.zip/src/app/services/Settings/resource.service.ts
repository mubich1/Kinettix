import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Activity } from 'src/app/models/activity/activity';
import { CustomParams } from 'src/app/models/custom-params/custom-params';
import { ActivitiesResponse, ActivityRequest, ActivityResourceMainDto, ActivityResourceRequest, CategoryResponse, ResourceDocument, ResourceRequest, ResourceResponse, StatusesResponse } from 'src/app/models/resources/resource';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { TableFilters } from 'src/app/shared/common/tableFilters';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ResourceService {

  constructor(private httpClient: HttpClient) { }


  getResources(payload: TableFilters): Observable<any> {
    return this.httpClient.get<any>(`${environment.configurationsApiBaseUrl}/resources?sort=${payload.sort}&search=${payload.search}&page=${payload.page}&pageSize=${payload.pageSize}&isAscending=${payload.isAscending}`);
  }
  createResource(resource: ResourceRequest): Observable<any> {

    return this.httpClient.post<ResponsePayloadDTO<ResourceRequest>>(`${environment.configurationsApiBaseUrl}/resources`, resource);

  }
  isExistResource(resource:ResourceRequest) : Observable<any>{
    return this.httpClient.post<ResponsePayloadDTO<Boolean>>(`${environment.configurationsApiBaseUrl}/resources/isexist`, resource);
  }

  getResourcesStatus() {
    return this.httpClient.get<ResponsePayloadDTO<StatusesResponse[]>>(`${environment.configurationsApiBaseUrl}/resources/statuses`);
  }

  updateResource(Resource: ResourceRequest): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.put<ResponsePayloadDTO<boolean>>(`${environment.configurationsApiBaseUrl}/resources`, Resource);
  }

  deleteResourceById(id: number): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.delete<ResponsePayloadDTO<boolean>>(`${environment.configurationsApiBaseUrl}/resources/${id}`);
  }
  copyResourceByName(resource: ResourceRequest): Observable<ResponsePayloadDTO<any>> {
    return this.httpClient.post<ResponsePayloadDTO<any>>(`${environment.configurationsApiBaseUrl}/resources/copy`, resource);
  }

  getResourceCategory(): Observable<ResponsePayloadDTO<CategoryResponse[]>> {//cc
    return this.httpClient.get<ResponsePayloadDTO<CategoryResponse[]>>(`${environment.configurationsApiBaseUrl}/resource-categories`);
  }

  getResourceByCategoryId(id: string): Observable<ResponsePayloadDTO<ResourceResponse[]>> {
    return this.httpClient.get<ResponsePayloadDTO<ResourceResponse[]>>(`${environment.configurationsApiBaseUrl}/resources/category/${id}`);
  }
  saveActivity(activity: any) {
    return this.httpClient.post<ResponsePayloadDTO<boolean>>(`${environment.configurationsApiBaseUrl}/activities`, activity);
  }

  getActivities(tableFilter:TableFilters): Observable<ResponsePayloadDTO<Activity[]>> {
    return this.httpClient.get<ResponsePayloadDTO<Activity[]>>(`${environment.configurationsApiBaseUrl}/activities?Page=${tableFilter?.page}&PageSize=${tableFilter?.pageSize}&Search=${tableFilter?.search}&Sort=${tableFilter?.sort}&IsAscending=${tableFilter?.isAscending}`);
  }

  deleteActivies(id: number): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.delete<ResponsePayloadDTO<boolean>>(`${environment.configurationsApiBaseUrl}/activities/${id}`);
  }

  saveActiviesResources(resource: ActivityResourceMainDto): Observable<any> {
    return this.httpClient.post<ResponsePayloadDTO<boolean>>(`${environment.projectApiBaseUrl}/contract-activity-resources/activity`, resource);
  }

  updateActiviesResources(resource: ActivityResourceMainDto): Observable<any> {
    return this.httpClient.put<ResponsePayloadDTO<boolean>>(`${environment.projectApiBaseUrl}/contract-activity-resources/activity`, resource);
  }

  updateActivityResource(resource: ActivityResourceMainDto): Observable<any> {
    return this.httpClient.put<ResponsePayloadDTO<boolean>>(`${environment.projectApiBaseUrl}/contract-activity-resources/activityresource`, resource);
  }

  deleteActivityResourceById(id: number): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.delete<ResponsePayloadDTO<boolean>>(`${environment.projectApiBaseUrl}/contract-activity-resources/activityresource/${id}`);
  }

  updateActivitiy(Resource: ActivityRequest): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.put<ResponsePayloadDTO<boolean>>(`${environment.configurationsApiBaseUrl}/activities`, Resource);
  }

  copyActivityByName(activityId: number, activityName: string): Observable<ResponsePayloadDTO<number>> {
    const customParams =
      {
        id: activityId,
        pageNumber: 0,
        name: activityName,
        orderby: '',
        sort: '',
      } as CustomParams;
    const params = new HttpParams().set('customParams', JSON.stringify(customParams));
    return this.httpClient.post<ResponsePayloadDTO<number>>(`${environment.configurationsApiBaseUrl}/activities/copy-activity`, null, { params });
  }

  public AddResourceDocument(document: ResourceDocument) : Observable<ResponsePayloadDTO<ResourceDocument>> {
    return this.httpClient.post<ResponsePayloadDTO<ResourceDocument>>(`${environment.configurationsApiBaseUrl}/resources/documents`, document);
  }

  getResourceDocumentsByResourceId(resourceId: number): Observable<ResponsePayloadDTO<ResourceDocument[]>> {
    return this.httpClient.get<ResponsePayloadDTO<ResourceDocument[]>>(`${environment.configurationsApiBaseUrl}/resources/resourcedocument/${resourceId}`);
  }

  public UpdateResourceDocument(id: number, document: ResourceDocument) : Observable<ResponsePayloadDTO<ResourceDocument>> {
    return this.httpClient.put<ResponsePayloadDTO<ResourceDocument>>(`${environment.configurationsApiBaseUrl}/resources/documents/${id}`, document);
  }

}
