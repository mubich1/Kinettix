import { TestBed } from '@angular/core/testing';

import { ClientIntegrationSourceService } from './client-integration-source.service';

describe('ClientIntegrationSourceService', () => {
  let service: ClientIntegrationSourceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ClientIntegrationSourceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
