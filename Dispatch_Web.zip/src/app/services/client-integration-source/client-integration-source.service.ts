import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ClientIntegrationSource } from 'src/app/models/client-integration-source/client-integration-source';
import { TableFilters } from 'src/app/shared/common/tableFilters';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ClientIntegrationSourceService {

  constructor(private httpClient: HttpClient) { }

  createClientIntegration(obj: ClientIntegrationSource): Observable<any> {
    return this.httpClient.post(`${environment.configurationsApiBaseUrl}/clientintegrationsources`, obj);
  }

  updateClientIntegration(obj: ClientIntegrationSource): Observable<any> {
    return this.httpClient.put(`${environment.configurationsApiBaseUrl}/clientintegrationsources`, obj);
  }

  deleteClientIntegration(id: number | undefined): Observable<any> {
    return this.httpClient.delete(`${environment.configurationsApiBaseUrl}/clientintegrationsources/${id}`)
  }

  getClientIntegrationById(id: number): Observable<any> {
    return this.httpClient.get<any>(`${environment.configurationsApiBaseUrl}/clientintegrationsources/${id}`);
  }

  getPagedClientIntegrations(payload: TableFilters): Observable<any> {
    return this.httpClient.get<any>(`${environment.configurationsApiBaseUrl}/clientintegrationsources?sort=${payload.sort}&search=${payload.search}&page=${payload.page}&pageSize=${payload.pageSize}&isAscending=${payload.isAscending}`);
  }

  getClientIntegrationSource(): Observable<any> {
    return this.httpClient.get<any>(`${environment.clientApiBaseUrl}/Client/AllClientsList`);
  }

  getIntegrationSource(): Observable<any> {
    return this.httpClient.get<any>(`${environment.configurationsApiBaseUrl}/integrationsources-dropdown`);
  }
}
