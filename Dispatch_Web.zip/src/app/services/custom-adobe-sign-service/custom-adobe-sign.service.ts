import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { SendESignRequest } from 'src/app/models/adobe-sign/send-esign-request';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class CustomAdobeSignService {
  constructor(private httpClient: HttpClient) {}

  sendContract(esignRequest: SendESignRequest): Observable<ResponsePayloadDTO<any>> {
    return this.httpClient.post<ResponsePayloadDTO<any>>(
      `${environment.saleApiBaseUrl}/custom-adobe-sign/send-contract`,
      esignRequest
    );
  }
}
