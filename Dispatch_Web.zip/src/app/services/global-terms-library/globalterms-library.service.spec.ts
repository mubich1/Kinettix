import { TestBed } from '@angular/core/testing';
import { GlobaltermsLibraryService } from './globalterms-library.service';


describe('GlobaltermsLibraryService', () => {
  let service: GlobaltermsLibraryService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GlobaltermsLibraryService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
