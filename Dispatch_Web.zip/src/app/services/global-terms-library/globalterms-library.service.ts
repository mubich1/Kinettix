import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { combineLatest, map, Observable } from 'rxjs';
import { ClientService } from '../client/client.service';
import { GlobalTermLibrary, GlobalTermLibraryRequest } from 'src/app/models/global-terms-library/globaltermlibrary-template';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class GlobaltermsLibraryService {

  constructor(
    private httpClient: HttpClient,
    private clientService: ClientService) { }

    getAllGlobalTermsLibrary(): Observable<ResponsePayloadDTO<GlobalTermLibrary[]>> {
      return this.httpClient.get<ResponsePayloadDTO<GlobalTermLibrary[]>>(`${environment.configurationsApiBaseUrl}/terms`);
    }

    getGlobalTermsLibraryById(id: number): Observable<ResponsePayloadDTO<GlobalTermLibrary>> {
      return this.httpClient.get<ResponsePayloadDTO<GlobalTermLibrary>>(`${environment.configurationsApiBaseUrl}/terms/${id}`);

    }

    updateGlobalTermsLibrary(template: GlobalTermLibraryRequest): Observable<ResponsePayloadDTO<boolean>> {
      return this.httpClient.put<ResponsePayloadDTO<boolean>>(`${environment.configurationsApiBaseUrl}/terms`, template);

    }
    saveGlobalTermsLibrary(template: GlobalTermLibraryRequest): Observable<ResponsePayloadDTO<number>> {
      return this.httpClient.post<ResponsePayloadDTO<number>>(`${environment.configurationsApiBaseUrl}/terms`, template);

    }




    deleteGlobalTermsLibrary(id: number): Observable<ResponsePayloadDTO<boolean>> {
      return this.httpClient.delete<ResponsePayloadDTO<boolean>>(`${environment.configurationsApiBaseUrl}/terms/${id}`);
    }
  }

