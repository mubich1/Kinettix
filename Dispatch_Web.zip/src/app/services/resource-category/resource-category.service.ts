import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ResourceCategory } from 'src/app/models/activity/resource-category';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ResourceCategoryService {

  constructor(private httpClient: HttpClient) {}

  ngOnInit() {

  }

  getResourceCategories(): Observable<ResponsePayloadDTO<ResourceCategory[]>> {
    return this.httpClient.get<ResponsePayloadDTO<ResourceCategory[]>>(`${environment.configurationsApiBaseUrl}/resource-categories`);
  }


  getResourceCategory(id : number): Observable<ResponsePayloadDTO<ResourceCategory>> {
    return this.httpClient.get<ResponsePayloadDTO<ResourceCategory>>(`${environment.configurationsApiBaseUrl}/resource-categories/`+id);
  }

  deleteResourceCategory(id: number): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.delete<ResponsePayloadDTO<boolean>>(`${environment.configurationsApiBaseUrl}/resource-categories/`+id);
  }

  updateResourceCategory(resourceCategory: ResourceCategory): Observable<ResponsePayloadDTO<number>> {
    return this.httpClient.put<ResponsePayloadDTO<number>>(`${environment.configurationsApiBaseUrl}/resource-categories`, resourceCategory);

  }

  saveResourceCategory(resourceCategory: ResourceCategory): Observable<ResponsePayloadDTO<number>> {
    return this.httpClient.post<ResponsePayloadDTO<number>>(`${environment.configurationsApiBaseUrl}/resource-categories`, resourceCategory);

  }
}
