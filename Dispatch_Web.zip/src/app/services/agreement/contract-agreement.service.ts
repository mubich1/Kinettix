import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ContractAgreement } from 'src/app/models/contract-agreement/contract-agreement';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class ContractAgreementService {
  constructor(private httpClient: HttpClient) {}

  getAgreementByContractId(
    contractVersionID: number
  ): Observable<ResponsePayloadDTO<ContractAgreement>> {
    return this.httpClient.get<ResponsePayloadDTO<ContractAgreement>>(
      `${environment.saleApiBaseUrl}/contracts/agreement/${contractVersionID}`
    );
  }

  UpdateContractAgreement(
    agreement: ContractAgreement
  ): Observable<ResponsePayloadDTO<string>> {
    return this.httpClient.put<ResponsePayloadDTO<string>>(
      `${environment.saleApiBaseUrl}/contracts/agreement`,
      agreement
    );
  }
}
