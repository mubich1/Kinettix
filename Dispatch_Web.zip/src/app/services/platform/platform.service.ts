import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Platform } from 'src/app/models/platform/platform';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PlatformService {

  constructor(private httpClient: HttpClient) { }

  getPlatform(): Observable<ResponsePayloadDTO<Platform[]>> {
    return this.httpClient.get<ResponsePayloadDTO<Platform[]>>(
      `${environment.configurationsApiBaseUrl}/platforms`
    );
  }
}
