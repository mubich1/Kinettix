import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TableFilters } from 'src/app/shared/common/tableFilters';
import { environment } from 'src/environments/environment';
import { Currency } from '../../models/activity/currency';

@Injectable({
  providedIn: 'root'
})
export class CurrencyService {

  constructor(private httpClient: HttpClient) { }

  createCurrency(obj: Currency): Observable<any> {
    return this.httpClient.post(`${environment.configurationsApiBaseUrl}/currencies`, obj);
  }

  updateCurrency(obj: Currency): Observable<any> {
    return this.httpClient.put(`${environment.configurationsApiBaseUrl}/currencies`, obj);
  }

  deleteCurrency(id: number | undefined): Observable<any> {
    return this.httpClient.delete(`${environment.configurationsApiBaseUrl}/currencies/${id}`);
  }

  getCurrencyById(id: number): Observable<any> {
    return this.httpClient.get<any>(`${environment.configurationsApiBaseUrl}/currencies/${id}`);
  }

  getPagedCurrencies(payload: TableFilters): Observable<any> {
    return this.httpClient.get<any>(`${environment.configurationsApiBaseUrl}/currencies?sort=${payload.sort}&search=${payload.search}&page=${payload.page}&pageSize=${payload.pageSize}&isAscending=${payload.isAscending}`);
  }

  getCurrenciesDropDown(): Observable<any> {
    return this.httpClient.get<any>(`${environment.configurationsApiBaseUrl}/currencydropdownlist`);
  }
}
