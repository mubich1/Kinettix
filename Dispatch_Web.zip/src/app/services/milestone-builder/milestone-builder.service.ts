import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { ResponsePayloadDTO } from "src/app/models/salesAPIResponse";
import { MilestoneBuilder } from "src/app/models/milestone-builder/milestone-builder";
import { environment } from "src/environments/environment";

@Injectable({
    providedIn: 'root'
})
export class MilestoneBuilderService {
    constructor(private httpClient: HttpClient) {
    }

    public GetMilestoneBuilder(milestoneId: number) : Observable<ResponsePayloadDTO<MilestoneBuilder>> {
        return this.httpClient.get<ResponsePayloadDTO<MilestoneBuilder>>(`${environment.configurationsApiBaseUrl}/milestones/${milestoneId}/builders`);
    }

    public AddMilestoneBuilder(taskId: number, model: MilestoneBuilder) : Observable<ResponsePayloadDTO<MilestoneBuilder>> {
        return this.httpClient.post<ResponsePayloadDTO<MilestoneBuilder>>(`${environment.configurationsApiBaseUrl}/milestones/${taskId}/builders`, model);
    }

    public UpdateMilestoneBuilder(taskId: number, model: MilestoneBuilder) : Observable<ResponsePayloadDTO<MilestoneBuilder>> {
        return this.httpClient.put<ResponsePayloadDTO<MilestoneBuilder>>(`${environment.configurationsApiBaseUrl}/milestones/${taskId}/builders`, model);
    }
}