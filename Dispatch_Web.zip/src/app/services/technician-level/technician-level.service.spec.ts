import { TestBed } from '@angular/core/testing';

import { TechnicianLevelService } from './technician-level.service';

describe('TechnicianLevelService', () => {
  let service: TechnicianLevelService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TechnicianLevelService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
