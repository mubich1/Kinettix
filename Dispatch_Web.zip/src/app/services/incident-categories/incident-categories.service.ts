import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { incidentCategories } from 'src/app/models/incident-categories/incident-categories';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class IncidentCategoriesService {

  constructor(
    private httpClient: HttpClient,
  ) { }

  getAllICategories(): Observable<ResponsePayloadDTO<incidentCategories[]>> {
    return this.httpClient.get<ResponsePayloadDTO<incidentCategories[]>>(`${environment.configurationsApiBaseUrl}/incident-categories`);
  }

  getICategoriesById(id: number): Observable<ResponsePayloadDTO<incidentCategories>> {
    return this.httpClient.get<ResponsePayloadDTO<incidentCategories>>(`${environment.configurationsApiBaseUrl}/incident-categories/${id}`);

  }

  saveICategories(template: incidentCategories): Observable<ResponsePayloadDTO<number>> {
    return this.httpClient.post<ResponsePayloadDTO<number>>(`${environment.configurationsApiBaseUrl}/incident-categories`, template);

  }

  updateICategories(template: incidentCategories): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.put<ResponsePayloadDTO<boolean>>(`${environment.configurationsApiBaseUrl}/incident-categories`, template);

  }


  deleteICategories(id: number): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.delete<ResponsePayloadDTO<boolean>>(`${environment.configurationsApiBaseUrl}/incident-categories/${id}`);
  }
}
