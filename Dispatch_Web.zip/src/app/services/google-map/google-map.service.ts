import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { incidentCategories } from 'src/app/models/incident-categories/incident-categories';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class GoogleMapService {
  constructor(
    private httpClient: HttpClient,
  ) { }

  getGeoCoordinatesFromAddress(address:string): Observable<any> {
    return this.httpClient.get<any>(`${environment.utilityApiBaseUrl}/addressdetails/${address}`);
  } 
}
