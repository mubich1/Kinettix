import { Injectable, OnInit } from '@angular/core';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
  HttpParams,
  HttpResponse,
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { Employee, Team } from '../../models/team/team';
import { environment } from 'src/environments/environment';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService implements OnInit {

  constructor(private httpClient: HttpClient) { }

  ngOnInit() {

  }

  getAllEmployees(): Observable<any> {
    return this.httpClient.get<any>(
      `${environment.identityBaseUrl}/identity/employees`
    );
  }
  getEmployee(Id: any): Observable<any> {
    return this.httpClient.get<any>(`${environment.identityBaseUrl}/identity/employees/${Id}`);
  }
  addRemoveEmployeeRole(employeeId: any, roles: any): Observable<any> {
    return this.httpClient.put<any>(`${environment.identityBaseUrl}/identity/employees/${employeeId}/role`, roles)
      .pipe();
  }
  addRemoveEmployeePermission(employeeId: any, hasPermission: any): Observable<any> {
    return this.httpClient.put<any>(`${environment.identityBaseUrl}/identity/employees/${employeeId}/permission`, hasPermission)
      .pipe();
  }
  getEmployeeRoles(roleId: any): Observable<any> {
    return this.httpClient.get<any>(`${environment.identityBaseUrl}/identity/employees/${roleId}/employees`);
  }
  getEmployeeId(name: string): Observable<ResponsePayloadDTO<number>> {
    const params = new HttpParams()
      .set('name', name);
    return this.httpClient.get<ResponsePayloadDTO<number>>(`${environment.clientApiBaseUrl}/Employee/${name}`, { params });
  }
  getEmployeePermissions(userName: any): Observable<any> {

    return this.httpClient.get<any>(`${environment.identityBaseUrl}/identity/employees/${userName}/employeePermission`);
  }
  updateEmployee(employee: any): Observable<any> {
    return this.httpClient.put<any>(`${environment.identityBaseUrl}/identity/employees`, employee)
      .pipe();
  }
}
