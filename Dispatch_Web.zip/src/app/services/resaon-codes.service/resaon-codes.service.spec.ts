import { TestBed } from '@angular/core/testing';

import { ResaonCodeService } from './resaon-codes.service';

describe('resaonCodeService', () => {
  let service: ResaonCodeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ResaonCodeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
