import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { TableFilters } from 'src/app/shared/common/tableFilters';
import { Header } from 'carbon-components-angular';

@Injectable({
  providedIn: 'root'
})
export class ResaonCodeService {
  private readonly urlPath = `${environment.configurationsApiBaseUrl}/reasoncodes`;
  constructor(private httpClient: HttpClient) { }

  create(request: any): Observable<any> {
    return this.httpClient.post(`${this.urlPath}`,
        request);
  }
  update(id:number,request: any): Observable<any> {
    return this.httpClient.put(`${this.urlPath}`,
        request);
  }
  
  getById(id:number): Observable<any> {
    return this.httpClient.get(`${this.urlPath}/${id}`);
  }
  delete(id:number): Observable<any> {
    return this.httpClient.delete(`${this.urlPath}/${id}`);
  }
  getAll(payload: TableFilters, reasonCodeTypeId:any=0): Observable<any> {
    return this.httpClient.get(`${this.urlPath}?reasonCodeTypeId=${reasonCodeTypeId}&sort=${payload.sort}&search=${payload.search}&page=${payload.page}&pageSize=${payload.pageSize}&isAscending=${payload.isAscending}`);
  }

}
