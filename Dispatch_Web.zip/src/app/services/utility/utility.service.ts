import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EmailContent } from 'src/app/models/utility/email-content';
import { environment } from 'src/environments/environment';
import { ApplicationTypes } from '../user/models/user-application-information';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class UtilityService {
  user: any;
  permissions: any;
  constructor(private httpClient: HttpClient, private toastr: ToastrService) {
    this.setUserPermissions();
  }

  applicationAccessEnabled(): boolean {
    const applicationTypes: any[] = this.user?.results?.applicationTypes;

    const res = !applicationTypes?.every((type) => type.id !== ApplicationTypes.core);

    if(res === false || res == null) {
      this.toastr.error('Access Dispatch1 is not enabled on your account. Please contact a system administrator if you believe this is a mistake.');
    }

    return res ?? false;
  }

  hasPermission(permissionName: string) {
    if (this.permissions != null) {
      const permisison = this.permissions.find(t => t.name === permissionName);
      return permisison != null || permisison != undefined;
    }
    return false;
  }
  allPermisisons() {
    return this.permissions;
  }

  sendEmail(emailContent: EmailContent): Observable<any> {
    return this.httpClient.post<any>(`${environment.utilityApiBaseUrl}/sendemail`, emailContent);
  }
  setUserPermissions() {
    this.user = JSON.parse(localStorage.getItem('user_profile') || sessionStorage.getItem('user_profile') || '{}');
    this.permissions = this.user?.permissions;
  }
}
