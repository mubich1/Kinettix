import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { TaskGroup } from "src/app/models/milestone-group/milestone-group";

@Injectable({
    providedIn: 'any'
})
export class TaskGroupSharedService {
    private taskGroupList$ = new BehaviorSubject<TaskGroup[]>([]);
    public taskGroupList = this.taskGroupList$.asObservable();

    private isUserCurrentlyAddingTaskGroup$ = new BehaviorSubject<boolean>(false);
    public isUserCurrentlyAddingTaskGroup = this.isUserCurrentlyAddingTaskGroup$.asObservable();

    public SetTaskGroupList(tasks: TaskGroup[]): void {
        this.taskGroupList$.next(tasks);
    }

    public SetIsUserCurrentlyAddingTaskGroup(isAdding: boolean): void {
        this.isUserCurrentlyAddingTaskGroup$.next(isAdding);
    }
}