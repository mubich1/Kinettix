import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { TaskGroup } from "src/app/models/milestone-group/milestone-group";
import { ResponsePayloadDTO } from "src/app/models/salesAPIResponse";
import { environment } from "src/environments/environment";

@Injectable({
    providedIn: 'root'
})
export class TaskGroupService {
    constructor(private httpClient: HttpClient) {
    }

    public GetTaskGroup(id: number) : Observable<ResponsePayloadDTO<TaskGroup>> {
        return this.httpClient.get<ResponsePayloadDTO<TaskGroup>>(`${environment.configurationsApiBaseUrl}/task-groups/${id}`);
    }

    public GetTaskGroupList(limit: number = 0, offSet: number = 0, searchText: string = '', isActive: boolean | null = null) : Observable<ResponsePayloadDTO<TaskGroup[]>> {
        let params = new HttpParams()
        if(searchText) 
            params = params.append('searchText', searchText)
        if(isActive === true || isActive === false)
            params = params.append('isActive', isActive)
        if(limit > 0 && offSet > 0) { 
            params = params.append('limit', limit.toString())
            params = params.append('offSet', offSet.toString())
        }
        return this.httpClient.get<ResponsePayloadDTO<TaskGroup[]>>(`${environment.configurationsApiBaseUrl}/task-groups`, {params: params});
    }

    public AddTaskGroup(model: TaskGroup) : Observable<ResponsePayloadDTO<TaskGroup>> {
        return this.httpClient.post<ResponsePayloadDTO<TaskGroup>>(`${environment.configurationsApiBaseUrl}/task-groups`, model);
    }

    public UpdateTaskGroup(id: number, model: TaskGroup) : Observable<ResponsePayloadDTO<TaskGroup>> {
        return this.httpClient.put<ResponsePayloadDTO<TaskGroup>>(`${environment.configurationsApiBaseUrl}/task-groups`, model);
    }

    public RemoveTaskGroup(id: number) {
        return this.httpClient.delete(`${environment.configurationsApiBaseUrl}/task-groups/${id}`);
    }
}