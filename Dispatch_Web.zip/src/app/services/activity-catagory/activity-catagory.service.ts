import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { combineLatest, map, Observable } from 'rxjs';
import { activitycatagores, ActivityCatagoryRequest } from 'src/app/models/activity-catagories/activitycatagories';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { environment } from 'src/environments/environment';

@Injectable({
    providedIn: 'root'
  })
  export class ActivityCatagoryService {
    constructor(private httpClient: HttpClient) { }
    getAllActivityCatagories(): Observable<ResponsePayloadDTO<activitycatagores[]>> {
        return this.httpClient.get<ResponsePayloadDTO<activitycatagores[]>>(`${environment.configurationsApiBaseUrl}/activitycatagories`);
      };
    getActivityCatagoryById(activitycatagoryid: number): Observable<ResponsePayloadDTO<activitycatagores[]>> {
        return this.httpClient.get<ResponsePayloadDTO<activitycatagores[]>>(`${environment.configurationsApiBaseUrl}/activitycatagories/${activitycatagoryid}`);
      };
    createActivityCatagory(activityCatagory: ActivityCatagoryRequest): Observable<ResponsePayloadDTO<number>> {
        return this.httpClient.post<ResponsePayloadDTO<number>>(`${environment.configurationsApiBaseUrl}/activitycatagories`, activityCatagory);
      }
    updateActivityCatagory(activityCatagory: ActivityCatagoryRequest): Observable<ResponsePayloadDTO<boolean>> {
        return this.httpClient.put<ResponsePayloadDTO<boolean>>(`${environment.configurationsApiBaseUrl}/activitycatagories`, activityCatagory);
      }
      deleteActivityCatagory(activitycatagoryid: number): Observable<ResponsePayloadDTO<boolean>> {
        return this.httpClient.delete<ResponsePayloadDTO<boolean>>(`${environment.configurationsApiBaseUrl}/activitycatagories/${activitycatagoryid}`);
      }

      
  }