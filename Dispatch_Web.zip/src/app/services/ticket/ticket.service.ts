import { Injectable, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, map, Observable } from 'rxjs';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { environment } from 'src/environments/environment';
import {
  RequestTicketClient,
  RequestTicketTile,
  Ticket,
  TicketFinancialsDto,
  UpdateTicketSite,
} from 'src/app/models/tickets/tickets';
import { TicketActivity } from 'src/app/models/deliveryContract/delivery-contract.model';
import { ContractTicketSchedule } from 'src/app/models/deliveryContract/delivery-contract.model';
import { ClientContract } from 'src/app/models/proposals/proposal';
import { TableFilters } from 'src/app/shared/common/tableFilters';
import { ClientSite } from 'src/app/models/client/client-site';

@Injectable({
  providedIn: 'root',
})
export class TicketService implements OnInit {
  constructor(private httpClient: HttpClient) { }
  emitCurrentStatus = new BehaviorSubject<string>('');
  getCurrentTicketStatus$ = this.emitCurrentStatus.asObservable();
  emitActivityChange = new BehaviorSubject<boolean>(false);
  getActivityChange$ = this.emitActivityChange.asObservable();
  emitSelectedClientSite = new BehaviorSubject<ClientSite>({ id: 0, name: "", city: "", state: "", countryId: 0, siteNumber: "", countryName: "", address: "", postalCode: "", phone: "", timeZone: "", clientId: 0, hqAddress: false, longitude: "", latitude: "" });
  getSelectedClientSite$ = this.emitSelectedClientSite.asObservable();
  ngOnInit() { }

  getTicketsByContractId(
    payload: TableFilters,
    contractId: number
  ): Observable<any> {
    return this.httpClient.get<any>(
      `${environment.workOrderApiBaseUrl}/contract/${contractId}/tickets?sort=${payload.sort}&search=${payload.search}&page=${payload.page}&pageSize=${payload.pageSize}&isAscending=${payload.isAscending}`
    );
  }

  getTicketById(id: number): Observable<ResponsePayloadDTO<Ticket>> {
    return this.httpClient.get<ResponsePayloadDTO<Ticket>>(
      `${environment.workOrderApiBaseUrl}/contract/` + id
    );
  }

  getTicketSite(ticketId: number): Observable<ClientSite | null> {
    return this.httpClient
      .get<any>(`${environment.workOrderApiBaseUrl}/tickets/${ticketId}/site`)
      .pipe(
        map<any, ClientSite | null>((source) => {
          const data = source.results;

          return data;
        })
      );
  }

  AddTicketActivities(activities: TicketActivity[]): Observable<any> {
    return this.httpClient.post<boolean>(
      `${environment.workOrderApiBaseUrl}/Tickets/activities`,
      activities
    );
  }
  getTicketActivitiesByTicketId(
    payload: TableFilters,
    ticketId: number
  ): Observable<any> {
    return this.httpClient.get<any>(
      `${environment.workOrderApiBaseUrl}/Tickets/${ticketId}/activities?sort=${payload.sort}&search=${payload.search}&page=${payload.page}&pageSize=${payload.pageSize}&isAscending=${payload.isAscending}`
    );
  }
  CreateTicketSchedual(
    ticketSchedual: ContractTicketSchedule,
    ticketId: number
  ): Observable<any> {
    const localUserId = localStorage.getItem('b2CUserId');
    ticketSchedual.createdBy = JSON.parse(localUserId || '');

    return this.httpClient.post<ContractTicketSchedule>(
      `${environment.workOrderApiBaseUrl}/tickets/${ticketId}/schedules`,
      ticketSchedual
    );
  }
  GetTicketSchedule(ticketId: number): Observable<ResponsePayloadDTO<ContractTicketSchedule[]>> {
    return this.httpClient.get<ResponsePayloadDTO<ContractTicketSchedule[]>>(
      `${environment.workOrderApiBaseUrl}/tickets/${ticketId}/schedules`
    );
  }

  changeTicketActivityStatus(
    status: boolean,
    ticketActivityId: number
  ): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.put<ResponsePayloadDTO<boolean>>(
      `${environment.workOrderApiBaseUrl}/tickets/${ticketActivityId}/activity-status/${status}`,
      {}
    );
  }
  deleteTicketActivity(
    ticketActivityId: number,
    ticketId: number
  ): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.delete<ResponsePayloadDTO<boolean>>(
      `${environment.workOrderApiBaseUrl}/tickets/${ticketId}/activity-delete/${ticketActivityId}`
    );
  }

  updateTicketSchedual(
    ticketSchedual: ContractTicketSchedule,
    ticketId: number
  ): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.put<ResponsePayloadDTO<boolean>>(
      `${environment.workOrderApiBaseUrl}/tickets/${ticketId}/schedules`,
      ticketSchedual
    );
  }

  getTicketsByClientId(
    clientID: number,
    payload?: any
  ): Observable<ResponsePayloadDTO<ClientContract[]>> {
    if (payload === null || payload == undefined) {
      let clientContractRequest = {
        page: 0,
        pageSize: 0,
        contractId: 0,
        isAscending: false,
        search: "",
        sort: ""
      }
      payload = clientContractRequest;
    }
    return this.httpClient.get<ResponsePayloadDTO<ClientContract[]>>(
      `${environment.workOrderApiBaseUrl}/tickets/client-tickets/${clientID}?Page=${payload?.page}&PageSize=${payload?.pageSize}&ContractId=${payload?.contractId}&Sort=${payload?.sort}&IsAscending=${payload?.isAscending}&Search=${payload?.search}`
    );
  }

  updateTicketSite(
    updateTicketSite: UpdateTicketSite
  ): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.put<ResponsePayloadDTO<boolean>>(
      `${environment.workOrderApiBaseUrl}/Tickets/ticket-site`,
      updateTicketSite
    );
  }

  updateTicketActivities(
    ticketActivities: any,
    poId: number
  ): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.put<ResponsePayloadDTO<boolean>>(
      `${environment.workOrderApiBaseUrl}/Tickets/${poId}/activities`,
      ticketActivities
    );
  }
  getTicketFinancialsById(
    ticketId: number
  ): Observable<ResponsePayloadDTO<TicketFinancialsDto>> {
    return this.httpClient.get<ResponsePayloadDTO<TicketFinancialsDto>>(
      `${environment.workOrderApiBaseUrl}/tickets/${ticketId}/financials`
    );
  }

  getMilestones(): Observable<any> {
    return this.httpClient.get<any>(
      `${environment.workOrderApiBaseUrl}/tasks/milestones`
    );
  }
  saveAssignUser(ticketId: number, assignuser: any): Observable<any> {
    return this.httpClient.put<any>(
      `${environment.workOrderApiBaseUrl}/tickets/${ticketId}/tasks/assignuser`,
      assignuser
    );
  }
  saveCompleteMilestoneTask(
    ticketId: number,
    completeTask: any
  ): Observable<any> {
    return this.httpClient.put<any>(
      `${environment.workOrderApiBaseUrl}/tickets/${ticketId}/tasks/CompleteTask`,
      completeTask
    );
  }
  saveFailMilestoneTask(ticketId: number, failMilestone: any): Observable<any> {
    return this.httpClient.put<any>(
      `${environment.workOrderApiBaseUrl}/tickets/${ticketId}/tasks/failtask`,
      failMilestone
    );
  }

  getTicketMilestone(ticketId: number): Observable<any> {
    return this.httpClient.get<any>(
      `${environment.workOrderApiBaseUrl}/tickets/${ticketId}/tasks/milestones`
    );
  }
  deleteMilestone(ticketId: number, milestoneId: number): Observable<any> {
    return this.httpClient.delete<any>(
      `${environment.workOrderApiBaseUrl}/tickets/${ticketId}/tasks/delete?milestoneId=${milestoneId}`
    );
  }

  saveMilestone(ticketId: number, payload: any): Observable<any> {
    return this.httpClient.post(`${environment.workOrderApiBaseUrl}/tickets/${ticketId}/tasks/ticketmilestone`, payload);
  }

  saveMilestone_Multiple(ticketId: number, payload: any): Observable<any> {
    return this.httpClient.post(`${environment.workOrderApiBaseUrl}/tickets/${ticketId}/tasks/ticketmilestone/multiple`, payload);
  }

  deleteMilestonesWithTask(ticketId: number, payload: any): Observable<any> {
    return this.httpClient.post(`${environment.workOrderApiBaseUrl}/tickets/${ticketId}/tasks/deletealltickettaskandticketmilestone`, payload)
  }
  getUserMilestone(userId: string, payload: any): Observable<any> {
    return this.httpClient.get<any>(`${environment.workOrderApiBaseUrl}/tickets/${userId}/user-tasks?sort=${payload.sort}&search=${payload.search}&page=${payload.page}&pageSize=${payload.pageSize}&isAscending=${payload.isAscending}`)
  }

  getUnassignedMilestone(payload: any): Observable<any> {
    return this.httpClient.get<any>(`${environment.workOrderApiBaseUrl}/tickets/unassignedmilestone?sort=${payload.sort}&search=${payload.search}&page=${payload.page}&pageSize=${payload.pageSize}&isAscending=${payload.isAscending}`)
  }

  editTicketTitle(ticketDetail: RequestTicketTile): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.patch<ResponsePayloadDTO<boolean>>(`${environment.workOrderApiBaseUrl}/tickets/title`, ticketDetail);
  }
  editTicketClient(ticketDetail: RequestTicketClient): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.patch<ResponsePayloadDTO<boolean>>(`${environment.workOrderApiBaseUrl}/tickets/endclient`, ticketDetail);
  }
  updateTicketActivity(payload): Observable<any> {
    return this.httpClient.put<any>(
      `${environment.workOrderApiBaseUrl}/tickets/ticketactivityuplift`,
      payload
    );
  }
}
