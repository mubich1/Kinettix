import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import {
  Deal,
  DealDocument,
  DealDocumentsType,
  DealPriority,
  DealSearch,
  DealStatus,
  DealType,
  SearchDealResponse,
  TurnoverRequirementCheckDto,
} from 'src/app/models/deals/deal';
import { environment } from 'src/environments/environment';
import { DealDocumentRequest } from 'src/app/models/document';
import { Observable, Subject } from 'rxjs';
import { TableFilters } from 'src/app/shared/common/tableFilters';

@Injectable({
  providedIn: 'root',
})
export class DealService {
  constructor(private httpClient: HttpClient) {}
  public dealInfo = {
    id: 0,
  };

  proposalInfo: any = {
    proposalID: 0,
    versionID: 0,
    version: 1,
    isCurrent: true,
    stage: 'Build',
    stageTime: '09/10/22',
    parentProjectId: 0,
  };
  load(data: any) {
    this.sharedObj.next(data);
  }
  public sharedObj = new Subject<any>();
  retrieveMappedObject(): Observable<any> {
    return this.sharedObj.asObservable();
  }

  getDealById(id: number): Observable<ResponsePayloadDTO<Deal>> {
    return this.httpClient.get<ResponsePayloadDTO<Deal>>(
      `${environment.saleApiBaseUrl}/deals/${id}`
    );
  }

  getTypes(): Observable<ResponsePayloadDTO<DealType[]>> {
    return this.httpClient.get<ResponsePayloadDTO<DealType[]>>(
      `${environment.saleApiBaseUrl}/deals/types`
    );
  }

  getSearchDeals(payload: TableFilters): Observable<any> {
    return this.httpClient.get(
      `${environment.saleApiBaseUrl}/deals?sort=${payload.sort}&search=${payload.search}&page=${payload.page}&pageSize=${payload.pageSize}&isAscending=${payload.isAscending}`
    );
  }

  searchDeals(
    body: DealSearch
  ): Observable<ResponsePayloadDTO<SearchDealResponse[]>> {
    return this.httpClient.post<ResponsePayloadDTO<SearchDealResponse[]>>(
      `${environment.saleApiBaseUrl}/deals/search`,
      body
    );
  }

  updateDeal(deal: any): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.put<ResponsePayloadDTO<boolean>>(
      `${environment.saleApiBaseUrl}/deals`,
      deal
    );
  }

  getDealStatuses(): Observable<ResponsePayloadDTO<DealStatus[]>> {
    return this.httpClient.get<ResponsePayloadDTO<DealStatus[]>>(
      `${environment.saleApiBaseUrl}/deals/statuses`
    );
  }

  getDealPriorities(): Observable<ResponsePayloadDTO<DealPriority[]>> {
    return this.httpClient.get<ResponsePayloadDTO<DealPriority[]>>(
      `${environment.saleApiBaseUrl}/deals/priorities`
    );
  }

  updateDealRisk(
    id: number,
    atRisk: boolean
  ): Observable<ResponsePayloadDTO<boolean>> {
    const params = new HttpParams().set('dealId', id).set('atRisk', atRisk);

    return this.httpClient.put<ResponsePayloadDTO<boolean>>(
      `${environment.saleApiBaseUrl}/deals/risk`,
      null,
      { params }
    );
  }

  updateDealPriority(
    id: number,
    priorityId: number
  ): Observable<ResponsePayloadDTO<boolean>> {
    const params = new HttpParams()
      .set('dealId', id)
      .set('priorityId', priorityId);

    return this.httpClient.put<ResponsePayloadDTO<boolean>>(
      `${environment.saleApiBaseUrl}/deals/priority`,
      null,
      { params }
    );
  }

  updateDealStatus(
    dealStatus: DealStatus
  ): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.put<ResponsePayloadDTO<boolean>>(
      `${environment.saleApiBaseUrl}/deals/status`,
      dealStatus
    );
  }

  getDealDocumentsType(): Observable<ResponsePayloadDTO<DealDocumentsType[]>> {
    return this.httpClient.get<ResponsePayloadDTO<DealDocumentsType[]>>(
      `${environment.saleApiBaseUrl}/deals/document-types`
    );
  }

  createDocument(
    document: DealDocumentRequest,
    dealId: number
  ): Observable<ResponsePayloadDTO<number>> {
    return this.httpClient.post<ResponsePayloadDTO<number>>(
      `${environment.saleApiBaseUrl}/deals/${dealId}/documents`,
      document
    );
  }

  getDealDocumentsByDealId(
    dealId: number
  ): Observable<ResponsePayloadDTO<DealDocument[]>> {
    return this.httpClient.get<ResponsePayloadDTO<DealDocument[]>>(
      `${environment.saleApiBaseUrl}/deals/${dealId}/documents`
    );
  }

  deleteAllDealDocument(
    dealId: number
  ): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.delete<ResponsePayloadDTO<boolean>>(
      `${environment.saleApiBaseUrl}/deals/${dealId}/documents`
    );
  }

  getAllDealDocuments(): Observable<ResponsePayloadDTO<DealDocument[]>> {
    return this.httpClient.get<ResponsePayloadDTO<DealDocument[]>>(
      `${environment.saleApiBaseUrl}/deals/documents`
    );
  }
  getDealDocumentByDocumentId(
    dealId: number,
    id: number
  ): Observable<ResponsePayloadDTO<DealDocument>> {
    return this.httpClient.get<ResponsePayloadDTO<DealDocument>>(
      `${environment.saleApiBaseUrl}/deals/${dealId}/documents/${id}`
    );
  }

  getDocumentByDocumentId(
    id: number
  ): Observable<ResponsePayloadDTO<DealDocument>> {
    return this.httpClient.get<ResponsePayloadDTO<DealDocument>>(
      `${environment.saleApiBaseUrl}/deals/documents/${id}`
    );
  }

  deleteDocumentById(id: number): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.delete<ResponsePayloadDTO<boolean>>(
      `${environment.saleApiBaseUrl}/deals/documents/${id}`
    );
  }

  getTurnOverRequirementsList(contractID:number):Observable<ResponsePayloadDTO<TurnoverRequirementCheckDto>>{
    return this.httpClient.get<ResponsePayloadDTO<TurnoverRequirementCheckDto>>(`${environment.saleApiBaseUrl}/deals/turnover-requirements/${contractID}`)
  }

  turnoverProcess(contractID:number):Observable<ResponsePayloadDTO<boolean>>{
    return this.httpClient.put<ResponsePayloadDTO<boolean>>(`${environment.saleApiBaseUrl}/deals/turnover-process/${contractID}`,contractID);
  }
  createDeal(request: any): Observable<any> {
    return this.httpClient.post<any>(
      `${environment.saleApiBaseUrl}/deals`,
      request
    );
  }
}
