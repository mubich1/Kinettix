import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { TicketProblemCodes } from 'src/app/models/vendor/vendor';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TicketProblemCodesService {

  constructor(
    private httpClient: HttpClient,
  ) { }

  getAllTicketProblemCodes(): Observable<ResponsePayloadDTO<TicketProblemCodes[]>> {
    return this.httpClient.get<ResponsePayloadDTO<TicketProblemCodes[]>>(`${environment.configurationsApiBaseUrl}/problem-codes`);
  }

  getTicketProblemCodeById(id: number): Observable<ResponsePayloadDTO<TicketProblemCodes>> {
    return this.httpClient.get<ResponsePayloadDTO<TicketProblemCodes>>(`${environment.configurationsApiBaseUrl}/problem-codes/${id}`);
  }

  saveTicketProblemCode(template: TicketProblemCodes): Observable<ResponsePayloadDTO<number>> {
    return this.httpClient.post<ResponsePayloadDTO<number>>(`${environment.configurationsApiBaseUrl}/problem-codes`, template);
  }

  updateTicketProblemCode(template: TicketProblemCodes): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.put<ResponsePayloadDTO<boolean>>(`${environment.configurationsApiBaseUrl}/problem-codes`, template);
  }

  deleteTicketProblemCode(id: number): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.delete<ResponsePayloadDTO<boolean>>(`${environment.configurationsApiBaseUrl}/problem-codes/${id}`);
  }
}
