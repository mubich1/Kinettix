import { TestBed } from '@angular/core/testing';

import { TicketDocumentsService } from './ticket-documents.service';

describe('TicketDocumentsService', () => {
  let service: TicketDocumentsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TicketDocumentsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
