import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { TicketDocuments } from 'src/app/models/tickets/tickets';
import { TableFilters } from 'src/app/shared/common/tableFilters';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TicketDocumentsService {

  constructor(private httpClient: HttpClient) { }

  ngOnInit() {
  }

  getPagedTicketDocumentsByTicketId(payload: TableFilters, id: number): Observable<any> {
    return this.httpClient.get<any>(`${environment.workOrderApiBaseUrl}/tickets/${id}/documents?sort=${payload.sort}&search=${payload.search}&page=${payload.page}&pageSize=${payload.pageSize}&isAscending=${payload.isAscending}`);
  }
  getTicketDocumentsById(id: number, docId: number): Observable<ResponsePayloadDTO<TicketDocuments>> {
    return this.httpClient.get<ResponsePayloadDTO<TicketDocuments>>(`${environment.workOrderApiBaseUrl}/tickets/${id}/documents/${docId}`);
  }

  saveTicketDocument(id: number, template: TicketDocuments): Observable<ResponsePayloadDTO<number>> {
    return this.httpClient.post<ResponsePayloadDTO<number>>(`${environment.workOrderApiBaseUrl}/tickets/${id}/documents`, template);
  }

  updateTicketDocument(id: number, template: TicketDocuments): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.put<ResponsePayloadDTO<boolean>>(`${environment.workOrderApiBaseUrl}/tickets/${id}/documents`, template);
  }

  deleteTicketDocument(id: number, docId: number): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.delete<ResponsePayloadDTO<boolean>>(`${environment.workOrderApiBaseUrl}/tickets/${id}/documents/${docId}`);
  }
  getDocumentDownloadUrl(id: number): string {
    return `${environment.utilityApiBaseUrl}/document/ticket/${id}`;
  }
}
