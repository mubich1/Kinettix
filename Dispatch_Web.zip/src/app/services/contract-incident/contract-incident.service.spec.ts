import { TestBed } from '@angular/core/testing';

import { ContractIncidentService } from './contract-incident.service';

describe('ContractIncidentService', () => {
  let service: ContractIncidentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ContractIncidentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
