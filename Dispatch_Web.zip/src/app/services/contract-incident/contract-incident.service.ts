import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ContractIncidentService {

  constructor(private httpClient: HttpClient) { }

  get(contractId: any, id: any): Observable<any> {
    return this.httpClient.get<any>(`${environment.projectApiBaseUrl}/contracts/${contractId}/incidents/${id}`);
  }
  getAll(contractId: any): Observable<any> {
    return this.httpClient.get<any>(`${environment.projectApiBaseUrl}/contracts/${contractId}/incidents`);
  }
  update(contractId: any, incident: any): Observable<any> {
    return this.httpClient.put<any>(`${environment.projectApiBaseUrl}/contracts/${contractId}/incidents`, incident);
  }
  add(contractId: any, incident: any): Observable<any> {
    return this.httpClient.post<any>(`${environment.projectApiBaseUrl}/contracts/${contractId}/incidents`, incident);
  }
  delete(contractId: any, id: any): Observable<any> {
    return this.httpClient.delete<any>(`${environment.projectApiBaseUrl}/contracts/${contractId}/incidents/${id}`);
  }
}
