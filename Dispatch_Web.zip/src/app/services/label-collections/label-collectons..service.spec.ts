import { TestBed } from '@angular/core/testing';

import { LabelCollectionsService } from './label-collections.service';

describe('DefinationTypesService', () => {
  let service: LabelCollectionsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LabelCollectionsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
