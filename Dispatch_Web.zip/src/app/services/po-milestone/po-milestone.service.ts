import { Injectable, OnInit } from '@angular/core';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
  HttpParams,
  HttpResponse,
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { TableFilters } from 'src/app/shared/common/tableFilters';
import { SavePoTaskAssignUserDto, SavePoMilestoneCompleteDto, SavePoMilestoneFailDto } from 'src/app/models/po-milestone/po-milestones';

@Injectable({
  providedIn: 'root',
})
export class PoMilestoneService implements OnInit {

  constructor(private httpClient: HttpClient) { }

  ngOnInit() {

  }

  getPurchaseOrderTaskByPoId(poId: number): Observable<any> {
    return this.httpClient.get<any>(`${environment.workOrderApiBaseUrl}/potasks/${poId}/getallpotasks`);
  }
  saveAssignUser(poId: any, payload: SavePoTaskAssignUserDto): Observable<any> {
    return this.httpClient.put<any>(`${environment.workOrderApiBaseUrl}/potasks/${poId}/saveassignuser`, payload);
  }
  saveFailTask(poId: any, payload: any): Observable<any> {
    return this.httpClient.put<any>(`${environment.workOrderApiBaseUrl}/potasks/${poId}/savefailtask`, payload);
  }
  saveCompleteTask(poId: number, payload: any): Observable<any> {
    return this.httpClient.put<any>(`${environment.workOrderApiBaseUrl}/potasks/${poId}/pocompletetask`, payload);
  }

  getMilestones(poId): Observable<any> {
    return this.httpClient.get<any>(`${environment.workOrderApiBaseUrl}/potasks/${poId}/milestones`);
  }
  getPoMilestones(poId: number): Observable<any> {
    return this.httpClient.get<any>(
      `${environment.workOrderApiBaseUrl}/potasks/${poId}/pomilestones`
    );
  }
  deleteMilestone(poId: number, payload): Observable<any> {
    return this.httpClient.post<any>(
      `${environment.workOrderApiBaseUrl}/potasks/${poId}/deleteallpotasksandpomilestone`, payload
    );
  }

  saveMilestone(poId: number, payload: any): Observable<any> {
    return this.httpClient.post(`${environment.workOrderApiBaseUrl}/potasks/${poId}/savepomilestones`, payload);
  }
  saveMilestone_Multiple(poId: number, payload: any): Observable<any> {
    return this.httpClient.post(`${environment.workOrderApiBaseUrl}/potasks/${poId}/savepomilestones/multiple`, payload);
  }
}