import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class CustomfieldsService {
  private readonly urlPath = `${environment.configurationsApiBaseUrl}/customfields`;
  constructor(private httpClient: HttpClient) { }

  create(request: any): Observable<any> {
    return    this.httpClient.post(`${this.urlPath}`,request);
  }
  update(id:number,request: any): Observable<any> {
    return    this.httpClient.put(`${this.urlPath}`,request);
    }
  getAll(id:number): Observable<any> {
    return this.httpClient.get(`${this.urlPath}/all/${id}`);
  }
  getById(id:number): Observable<any> {
    return this.httpClient.get(`${this.urlPath}/${id}`);
  }
  delete(id:number): Observable<any> {
    return this.httpClient.delete(`${this.urlPath}/${id}`);
  }
}
