import { TestBed } from '@angular/core/testing';

import { CustomfieldsService } from './customfieldsservice';

describe('CustomfieldsService', () => {
  let service: CustomfieldsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CustomfieldsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
