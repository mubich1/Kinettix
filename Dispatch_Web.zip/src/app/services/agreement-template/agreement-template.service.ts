import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { combineLatest, forkJoin, map, Observable } from 'rxjs';
import { AgreementTemplate, AgreementTemplateRequest } from 'src/app/models/agreement-template/agreement-template';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { environment } from 'src/environments/environment';
import { ClientService } from '../client/client.service';

@Injectable({
  providedIn: 'root'
})
export class AgreementTemplateService {

  constructor(
    private httpClient: HttpClient,
    private clientService: ClientService) { }

  getAllAgreementTemplates(): Observable<ResponsePayloadDTO<AgreementTemplate[]>> {
    return this.httpClient.get<ResponsePayloadDTO<AgreementTemplate[]>>(`${environment.configurationsApiBaseUrl}/agreement-templates`);
  }

  getAgreementTemplateById(id: number): Observable<ResponsePayloadDTO<AgreementTemplate>> {
    return this.httpClient.get<ResponsePayloadDTO<AgreementTemplate>>(`${environment.configurationsApiBaseUrl}/agreement-templates/${id}`);

  }

  saveAgreementTemplate(template: AgreementTemplateRequest): Observable<ResponsePayloadDTO<number>> {
    return this.httpClient.post<ResponsePayloadDTO<number>>(`${environment.configurationsApiBaseUrl}/agreement-templates`, template);

  }

  updateAgreementTemplate(template: AgreementTemplateRequest): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.put<ResponsePayloadDTO<boolean>>(`${environment.configurationsApiBaseUrl}/agreement-templates`, template);

  }


  deleteAgreementTemplate(id: number): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.delete<ResponsePayloadDTO<boolean>>(`${environment.configurationsApiBaseUrl}/agreement-templates/${id}`);
  }
}
