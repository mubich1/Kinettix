import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { ReviewResponsePayload, TicketAddReview, TicketReview, TicketVendors } from 'src/app/models/tickets/tickets';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TicketReviewService {

  constructor(private httpClient: HttpClient) { }

  add(ticketId: number, review: TicketReview): Observable<ResponsePayloadDTO<TicketAddReview>> {
    return this.httpClient.post<ResponsePayloadDTO<TicketAddReview>>(`${environment.workOrderApiBaseUrl}/tickets/${ticketId}/review/create`, review);
  }

  update(ticketId: number, review: TicketReview): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.put<ResponsePayloadDTO<boolean>>(`${environment.workOrderApiBaseUrl}/tickets/${ticketId}/review/edit`, review);
  }

  getAll(ticketId: number): Observable<ResponsePayloadDTO<ReviewResponsePayload>> {
    return this.httpClient.get<ResponsePayloadDTO<ReviewResponsePayload>>(`${environment.workOrderApiBaseUrl}/tickets/${ticketId}/review/list`);
  }

  get(ticketId: number, reviewId: number): Observable<ResponsePayloadDTO<TicketReview>> {
    return this.httpClient.get<ResponsePayloadDTO<TicketReview>>(`${environment.workOrderApiBaseUrl}/tickets/${ticketId}/review/get?id=${reviewId}`);
  }

  delete(ticketId: number, review: TicketAddReview): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.put<ResponsePayloadDTO<boolean>>(`${environment.workOrderApiBaseUrl}/tickets/${ticketId}/review/delete`, review);
  }

}
