import { TestBed } from '@angular/core/testing';

import { TicketReviewService } from './ticket-review.service';

describe('TicketReviewService', () => {
  let service: TicketReviewService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TicketReviewService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
