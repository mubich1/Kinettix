import { TestBed } from '@angular/core/testing';

import { TicketIncidentService } from './ticket-incident.service';

describe('TicketIncidentService', () => {
  let service: TicketIncidentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TicketIncidentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
