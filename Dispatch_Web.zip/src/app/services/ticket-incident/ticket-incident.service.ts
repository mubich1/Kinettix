import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TicketIncidentService {

  constructor(private httpClient: HttpClient) { }

  get(ticketId: any, id: any): Observable<any> {
    return this.httpClient.get<any>(`${environment.workOrderApiBaseUrl}/tickets/${ticketId}/incidents/${id}`);
  }
  getAll(ticketId: any): Observable<any> {
    return this.httpClient.get<any>(`${environment.workOrderApiBaseUrl}/tickets/${ticketId}/incidents`);
  }
  update(ticketId: any, incident: any): Observable<any> {
    return this.httpClient.put<any>(`${environment.workOrderApiBaseUrl}/tickets/${ticketId}/incidents`, incident);
  }
  add(ticketId: any, incident: any): Observable<any> {
    return this.httpClient.post<any>(`${environment.workOrderApiBaseUrl}/tickets/${ticketId}/incidents`, incident);
  }
  delete(ticketId: any, id: any): Observable<any> {
    return this.httpClient.delete<any>(`${environment.workOrderApiBaseUrl}/tickets/${ticketId}/incidents/${id}`);
  }
}
