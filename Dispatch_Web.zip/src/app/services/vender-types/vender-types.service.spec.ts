import { TestBed } from '@angular/core/testing';

import { VenderTypesService } from './vender-type.service';

describe('DeliverabletypesService', () => {
  let service: VenderTypesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(VenderTypesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
