import { TestBed } from '@angular/core/testing';

import { DocumentDefinitionService } from './documentdefinition.service';

describe('DefinationTypesService', () => {
  let service: DocumentDefinitionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DocumentDefinitionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
