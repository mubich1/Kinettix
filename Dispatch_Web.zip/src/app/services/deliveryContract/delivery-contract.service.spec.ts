import { TestBed } from '@angular/core/testing';

import { DeliveryContractService } from './delivery-contract.service';

describe('DeliveryContractService', () => {
  let service: DeliveryContractService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DeliveryContractService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
