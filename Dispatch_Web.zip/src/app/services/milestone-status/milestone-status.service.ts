import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { ResponsePayloadDTO } from "src/app/models/salesAPIResponse";
import { MilestoneStatus } from "src/app/models/milestone-status/milestone-status";
import { environment } from "src/environments/environment";

@Injectable({
    providedIn: 'root'
})
export class MilestoneStatusService {
    constructor(private httpClient: HttpClient) {
    }
    
    public GetMilestoneStatusList(limit: number = 0, offSet: number = 0, searchText: string = '', isActive: boolean | null = null) : Observable<ResponsePayloadDTO<MilestoneStatus[]>> {
        let params = new HttpParams()
        if(searchText) 
            params = params.append('searchText', searchText)
        if(isActive === true || isActive === false)
            params = params.append('isActive', isActive)
        if(limit > 0 && offSet > 0) { 
            params = params.append('limit', limit.toString())
            params = params.append('offSet', offSet.toString())
        }
        return this.httpClient.get<ResponsePayloadDTO<MilestoneStatus[]>>(`${environment.configurationsApiBaseUrl}/milestone-statuses`, {params: params});
    }

    public GetMilestoneStatus(milestoneStatusId: number) : Observable<ResponsePayloadDTO<MilestoneStatus>> {
        return this.httpClient.get<ResponsePayloadDTO<MilestoneStatus>>(`${environment.configurationsApiBaseUrl}/milestone-statuses/${milestoneStatusId}`);
    }

    public AddMilestoneStatus(model: MilestoneStatus) : Observable<ResponsePayloadDTO<MilestoneStatus>> {
        return this.httpClient.post<ResponsePayloadDTO<MilestoneStatus>>(`${environment.configurationsApiBaseUrl}/milestone-statuses`, model);
    }

    public UpdateMilestoneStatus(milestoneStatusId: number, model: MilestoneStatus) : Observable<ResponsePayloadDTO<MilestoneStatus>> {
        return this.httpClient.put<ResponsePayloadDTO<MilestoneStatus>>(`${environment.configurationsApiBaseUrl}/milestone-statuses`, model);
    }

    public DeleteMilestoneStatus(milestoneStatusId: number) {
        return this.httpClient.delete(`${environment.configurationsApiBaseUrl}/milestone-statuses/${milestoneStatusId}`);
    }

}