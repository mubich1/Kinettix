import { TestBed } from '@angular/core/testing';

import { DeliverableTypesService } from './deliverable-type.service';

describe('deliverabletypesService', () => {
  let service: DeliverableTypesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DeliverableTypesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
