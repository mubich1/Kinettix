import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { contractDocuments } from 'src/app/models/contract-documents/contract-document';
import { ContractDocument } from 'src/app/models/proposals/proposal';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { TableFilters } from 'src/app/shared/common/tableFilters';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ContractDocumentService {

  constructor(
    private httpClient: HttpClient,
  ) { }

  getPagedContractDocumentsByContractId(payload: TableFilters, id: number): Observable<any> {
    return this.httpClient.get<any>(`${environment.projectApiBaseUrl}/ContractDoucments/${id}/documents?sort=${payload.sort}&search=${payload.search}&page=${payload.page}&pageSize=${payload.pageSize}&isAscending=${payload.isAscending}`);
  }

  getDocumentsById(id: number): Observable<ResponsePayloadDTO<contractDocuments>> {
    return this.httpClient.get<ResponsePayloadDTO<contractDocuments>>(`${environment.projectApiBaseUrl}/ContractDoucments/${id}`);
  }
  saveDocument(id: number, template: contractDocuments): Observable<ResponsePayloadDTO<number>> {
    return this.httpClient.post<ResponsePayloadDTO<number>>(`${environment.projectApiBaseUrl}/ContractDoucments/${id}`, template);
  }
  updateDocument(id: number, template: contractDocuments): Observable<ResponsePayloadDTO<boolean>> {
    var res = this.httpClient.put<ResponsePayloadDTO<boolean>>(`${environment.projectApiBaseUrl}/ContractDoucments/${id}`, template);
    return res;
  }
  deleteDocument(id: number): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.delete<ResponsePayloadDTO<boolean>>(`${environment.projectApiBaseUrl}/ContractDoucments/${id}`);
  }
  getDocTypes(): Observable<ResponsePayloadDTO<contractDocuments[]>> {
    return this.httpClient.get<ResponsePayloadDTO<contractDocuments[]>>(`${environment.configurationsApiBaseUrl}/competencies/types`);
  }
  getDocumentDownloadUrl(id: number): string {
    return `${environment.utilityApiBaseUrl}/document/contract/${id}`;
  }
}
