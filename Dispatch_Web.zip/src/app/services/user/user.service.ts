import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { UserAccountInfo } from 'src/app/models/user/user';
import { MsalService } from '@azure/msal-angular';
import { CookieService } from 'ngx-cookie-service';
import { UserApplicationInformation } from './models/user-application-information';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpClient: HttpClient, private msalService: MsalService,
              private cookies:CookieService) { }

  saveLocalUser(obj: UserAccountInfo): Observable<any> {
    return this.httpClient.post(`${environment.identityBaseUrl}/identity/users/SaveLocal`, obj);
  }

  getUserProfile(userId: string): Observable<any> {
    return this.httpClient.get(`${environment.identityBaseUrl}/identity/users/${userId}`)
  }

  getCurrentUserProfile(): Observable<any> {
    return this.httpClient.get(`${environment.identityBaseUrl}/identity/users/Me`)
  }

  getJwtToken() {
    return this.httpClient.get(`${environment.identityBaseUrl}/identity/users/GenerateToken`);
  }

  resetPassword(userId: string): Observable<any> {
    return this.httpClient.get(`${environment.identityBaseUrl}/identity/users/ResetPassword/${userId}`)
  }

  logout() {
    setTimeout(() => {
      this.msalService.logout();
      sessionStorage.clear();
      localStorage.clear();
      this.cookies.deleteAll('/');
    }, 200);
  }
  saveB2CUser(obj: any): Observable<any> {
    return this.httpClient.post(`${environment.identityBaseUrl}/identity/users/SaveB2C`, obj);
  }

  deleteUser(userId: string): Observable<any> {
    return this.httpClient.delete(`${environment.identityBaseUrl}/identity/users/${userId}`)
  }

  SaveApplicationsUsers(obj: any): Observable<any> {
    return this.httpClient.post(`${environment.identityBaseUrl}/identity/users/SaveApplicationsUser`, obj);
  }
  getUsers(): Observable<any> {
    return this.httpClient.get(`${environment.identityBaseUrl}/identity/users`);
  }

  getUserApplicationInformation(userId: string): Observable<UserApplicationInformation> {
    return this.httpClient.get(`${environment.identityBaseUrl}/identity/users/${userId}/application`).pipe(
      map<any, UserApplicationInformation>((value) => {
        return value.results;
      })
    );
  }

  updateUserApplicationInformation(userId: string, information: UserApplicationInformation): Observable<void> {
    return this.httpClient.put<void>(`${environment.identityBaseUrl}/identity/users/${userId}/application`, information);
  }
}
