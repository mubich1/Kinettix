import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class RoleService {
  private readonly urlPath = `${environment.identityBaseUrl}/identity/roles`;
  constructor(private httpClient: HttpClient) { }

  create(request: any): Observable<any> {
    return this.httpClient
      .post<any>(`${this.urlPath}`,
        request).pipe();
  }
  update(roleId: number, request: any): Observable<any> {
    return this.httpClient
      .put<any>(`${this.urlPath}/${roleId}`,
        request).pipe();
  }
  getAllRoles(): Observable<any> {
    return this.httpClient.get<any>(`${this.urlPath}`).pipe();
  }
  getRoleById(roleId: number): Observable<any> {
    return this.httpClient.get<any>(`${this.urlPath}/${roleId}`).pipe();
  }
  deleteRole(roleId: number): Observable<any> {
    return this.httpClient.delete<any>(`${this.urlPath}/${roleId}`).pipe();
  }
  getPermisionsByRoleId(roleId: number): Observable<any> {
    return this.httpClient.get<any>(`${this.urlPath}/${roleId}/permissions`).pipe();
  }
  assignRolePermissions(roleId: number, request: any): Observable<any> {
    return this.httpClient
      .put<any>(`${this.urlPath}/${roleId}/permissions`,
        request).pipe();
  }
  assignRoleToUsers(roleId: number, request: any): Observable<any> {
    return this.httpClient
      .put<any>(`${this.urlPath}/${roleId}/users`, request).pipe();
  }

}
