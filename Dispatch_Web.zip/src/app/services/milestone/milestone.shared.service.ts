import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { MilestoneDTO } from "src/app/models/milestoneDTO/milestoneDTO";

@Injectable({
    providedIn: 'any'
})
export class MilestoneSharedService {
    private workflowList$ = new BehaviorSubject<MilestoneDTO[]>([]);
    public workflowList = this.workflowList$.asObservable();

    private isUserCurrentlyAddingWorkflow$ = new BehaviorSubject<boolean>(false);
    public isUserCurrentlyAddingWorkflow = this.isUserCurrentlyAddingWorkflow$.asObservable();

    private workflowIdToEdit$ = new BehaviorSubject<number>(0);
    public workflowIdToEdit = this.workflowIdToEdit$.asObservable();

    public SetWorkflowList (workflows: MilestoneDTO[]) : void {
        this.workflowList$.next(workflows);
    }

    public SetIsUserCurrentlyAddingWorkflow(isAdding: boolean) : void {
        this.isUserCurrentlyAddingWorkflow$.next(isAdding);
    }
    
    public SetWorkflowIdToEdit(workflowId: number) : void {
        this.workflowIdToEdit$.next(workflowId);
    }
}