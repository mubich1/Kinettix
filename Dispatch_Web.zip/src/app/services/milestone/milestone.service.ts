import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { ResponsePayloadDTO } from "src/app/models/salesAPIResponse";
import { MilestoneDTO } from "src/app/models/milestoneDTO/milestoneDTO";
import { environment } from "src/environments/environment";
import { TableFilters } from 'src/app/shared/common/tableFilters';
import { GetMilestoneOptions } from "src/app/models/taskDTO/taskDTO";

@Injectable({
    providedIn: 'root'
})
export class MilestoneService {
    constructor(private httpClient: HttpClient) { }



    public GetMilestone(id: number): Observable<ResponsePayloadDTO<any>> {
        return this.httpClient.get<ResponsePayloadDTO<any>>(`${environment.configurationsApiBaseUrl}/milestones/${id}`);
    }

    public GetMilestoneList(limit: number = 0, offSet: number = 0, searchText: string = '', isActive: boolean | null = null, options?: GetMilestoneOptions): Observable<ResponsePayloadDTO<any>> {
        let params = new HttpParams()
        if (searchText)
            params = params.append('search', searchText)
        if (isActive === true || isActive === false)
            params = params.append('isActive', isActive)
        if (limit > 0 && offSet > 0) {
            params = params.append('page', limit.toString())
            params = params.append('offSet', offSet.toString())
        }
        if (options?.recordsPerPage != null) {
            params = params.set('pageSize', options!.recordsPerPage);
        }
        return this.httpClient.get<ResponsePayloadDTO<any>>(`${environment.configurationsApiBaseUrl}/milestones`, { params: params });
    }

    public AddMilestone(model: MilestoneDTO): Observable<ResponsePayloadDTO<any>> {
        return this.httpClient.post<ResponsePayloadDTO<any>>(`${environment.configurationsApiBaseUrl}/milestones`, model);
    }

    public UpdateMilestone(model: MilestoneDTO): Observable<ResponsePayloadDTO<any>> {
        return this.httpClient.put<ResponsePayloadDTO<any>>(`${environment.configurationsApiBaseUrl}/milestones`, model);
    }

    public RemoveMilestone(id: number) {
        return this.httpClient.delete(`${environment.configurationsApiBaseUrl}/milestones/${id}`);
    }

    public getDefaultMilestones() {
        return this.httpClient.get<ResponsePayloadDTO<MilestoneDTO[]>>(`${environment.configurationsApiBaseUrl}/milestones/default-milestones`);
    }

    public deleteDefaultMilestone(id: number) {
        return this.httpClient.delete<ResponsePayloadDTO<boolean>>(`${environment.configurationsApiBaseUrl}/milestones/default-milestones/${id}`);
    }
    public getUnassignedMilestone(payload: TableFilters) {
        return this.httpClient.get<any>(`${environment.workOrderApiBaseUrl}/tasks/unassigned-tasks?sort=${payload.sort}&search=${payload.search}&page=${payload.page}&pageSize=${payload.pageSize}&isAscending=${payload.isAscending}`);
    }

    public getMilestoneStatuses() {
        return this.httpClient.get<any>(`${environment.configurationsApiBaseUrl}/milestone/status`);
    }
}