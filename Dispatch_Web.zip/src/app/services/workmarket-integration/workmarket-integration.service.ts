import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { AssignmentTemplate, AvailableTech, AssignmentJobDetails, TemplateDetails, CreateAssignment, LaborCloud } from 'src/app/models/workmarket-integration/workmarket-integration';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class WorkmarketIntegrationService {

  constructor(private httpClient: HttpClient) { }

  getTechnicians(): Observable<ResponsePayloadDTO<AvailableTech[]>> {
    var res = this.httpClient.get<ResponsePayloadDTO<AvailableTech[]>>(
      `${environment.workOrderApiBaseUrl}/WorkMarketIntegration/technicians`
    );
    return res;
  }

  getLaborClouds(): Observable<ResponsePayloadDTO<LaborCloud[]>> {
    var res = this.httpClient.get<ResponsePayloadDTO<LaborCloud[]>>(
      `${environment.workOrderApiBaseUrl}/WorkMarketIntegration/talentpools`
    );
    return res;
  }

  getJobDetailsForAssignment(ticketId: number, poId: number): Observable<ResponsePayloadDTO<AssignmentJobDetails>> {
    var res = this.httpClient.get<ResponsePayloadDTO<AssignmentJobDetails>>(
      `${environment.workOrderApiBaseUrl}/WorkMarketIntegration/${ticketId}/${poId}/jobdetails`
    );
    return res;
  }

  getTemplates(): Observable<ResponsePayloadDTO<AssignmentTemplate[]>> {
    var res = this.httpClient.get<ResponsePayloadDTO<AssignmentTemplate[]>>(`${environment.workOrderApiBaseUrl}/WorkMarketIntegration/templates`);
    return res;
  }

  getTemplateDetails(templateId: number): Observable<ResponsePayloadDTO<TemplateDetails>> {
    var res = this.httpClient.get<ResponsePayloadDTO<TemplateDetails>>(`${environment.workOrderApiBaseUrl}/WorkMarketIntegration/template/${templateId}`);
    return res;
  }

  createAssignment(assignment: CreateAssignment, ticketId: number): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.post<ResponsePayloadDTO<boolean>>(`${environment.workOrderApiBaseUrl}/WorkMarketIntegration/${ticketId}/assignment`, assignment);
  }

}
