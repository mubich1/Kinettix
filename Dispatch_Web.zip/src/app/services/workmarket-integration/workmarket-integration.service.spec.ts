import { TestBed } from '@angular/core/testing';

import { WorkmarketIntegrationService } from './workmarket-integration.service';

describe('WorkmarketIntegrationService', () => {
  let service: WorkmarketIntegrationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WorkmarketIntegrationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
