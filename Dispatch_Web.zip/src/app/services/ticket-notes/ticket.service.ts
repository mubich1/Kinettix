import { Injectable, OnInit } from '@angular/core';
import {
  HttpClient
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { environment } from 'src/environments/environment';
import { Ticket, TicketNotes } from 'src/app/models/tickets/tickets';
import { TableFilters } from 'src/app/shared/common/tableFilters';

@Injectable({
  providedIn: 'root',
})
export class TicketNotesService implements OnInit {

  constructor(private httpClient: HttpClient) { }

  ngOnInit() {

  }

  getTicketById(id: number): Observable<ResponsePayloadDTO<Ticket>> {
    return this.httpClient.get<ResponsePayloadDTO<Ticket>>(`${environment.workOrderApiBaseUrl}/contract/` + id);
  }
  getPagedTicketNotesByTicketId(payload: TableFilters, id: number): Observable<any> {
    return this.httpClient.get<any>(`${environment.workOrderApiBaseUrl}/tickets/${id}/notes?sort=${payload.sort}&search=${payload.search}&page=${payload.page}&pageSize=${payload.pageSize}&isAscending=${payload.isAscending}`);
  }

  getTicketNotesById(id: number, noteId: number): Observable<ResponsePayloadDTO<TicketNotes>> {
    return this.httpClient.get<ResponsePayloadDTO<TicketNotes>>(`${environment.workOrderApiBaseUrl}/tickets/${id}/notes/${noteId}`);
  }
  saveTicketNote(id: number, template: TicketNotes): Observable<ResponsePayloadDTO<number>> {
    return this.httpClient.post<ResponsePayloadDTO<number>>(`${environment.workOrderApiBaseUrl}/tickets/${id}/notes`, template);
  }

  updateTicketNote(id: number, template: TicketNotes): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.put<ResponsePayloadDTO<boolean>>(`${environment.workOrderApiBaseUrl}/tickets/${id}/notes`, template);
  }

  deleteTicketNote(id: number, noteId: number): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.delete<ResponsePayloadDTO<boolean>>(`${environment.workOrderApiBaseUrl}/tickets/${id}/notes/${noteId}`);
  }

}
