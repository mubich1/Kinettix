import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { TableFilters } from 'src/app/shared/common/tableFilters';


@Injectable({
  providedIn: 'root'
})
export class AuditHistoryService {
  private readonly urlPath = `${environment.configurationsApiBaseUrl}/audithistory`;
  constructor(private httpClient: HttpClient) { }

  create(request: any): Observable<any> {
    return this.httpClient
      .post<any>(`${this.urlPath}`,
        request).pipe();
  }
  update(id:number,request: any): Observable<any> {
    return this.httpClient
      .put<any>(`${this.urlPath}/${id}`,
        request).pipe();
  }
  getAll(table:string,payload: TableFilters): Observable<any> {
    return this.httpClient.get<any>(`${this.urlPath}/${table}?sort=${payload.sort}&search=${payload.search}&page=${payload.page}&pageSize=${payload.pageSize}&isAscending=${payload.isAscending}`).pipe();
  }
  getById(id:number): Observable<any> {
    return this.httpClient.get<any>(`${this.urlPath}/${id}`).pipe();
  }
  delete(id:number): Observable<any> {
    return this.httpClient.delete<any>(`${this.urlPath}/${id}`).pipe();
  }
  
}