import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { GetMilestoneOptions, TaskDTO } from "src/app/models/taskDTO/taskDTO";
import { ResponsePayloadDTO } from "src/app/models/salesAPIResponse";
import { environment } from "src/environments/environment";

@Injectable({
    providedIn: 'root'
})
export class TaskService {
    constructor(private httpClient: HttpClient) { }
    public GetTask(id: number): Observable<ResponsePayloadDTO<TaskDTO>> {
        return this.httpClient.get<ResponsePayloadDTO<TaskDTO>>(`${environment.configurationsApiBaseUrl}/tasks/${id}`);
    }

    public GetTaskList(limit: number = 0, offSet: number = 0, searchText: string = '', isActive: boolean | null = null, options?: GetMilestoneOptions): Observable<ResponsePayloadDTO<TaskDTO[]>> {
        let params = new HttpParams()
        if (searchText)
            params = params.append('search', searchText)
        if (isActive === true || isActive === false)
            params = params.append('isActive', isActive)
        if (limit > 0 && offSet > 0) {
            params = params.append('page', limit.toString())
            params = params.append('offSet', offSet.toString())
        }
        if (options?.recordsPerPage != null) {
            params = params.set('pageSize', options!.recordsPerPage);
        }
        return this.httpClient.get<ResponsePayloadDTO<TaskDTO[]>>(`${environment.configurationsApiBaseUrl}/tasks`, { params: params });
    }

    public AddTask(model: TaskDTO): Observable<ResponsePayloadDTO<TaskDTO>> {
        return this.httpClient.post<ResponsePayloadDTO<TaskDTO>>(`${environment.configurationsApiBaseUrl}/tasks`, model);
    }

    public UpdateTask(model: TaskDTO): Observable<ResponsePayloadDTO<TaskDTO>> {
        return this.httpClient.put<ResponsePayloadDTO<TaskDTO>>(`${environment.configurationsApiBaseUrl}/tasks`, model);
    }

    public RemoveTask(id: number) {
        return this.httpClient.delete(`${environment.configurationsApiBaseUrl}/tasks/${id}`);
    }
    public GetTaskByLevelType(level: string): Observable<ResponsePayloadDTO<TaskDTO[]>> {
        return this.httpClient.get<ResponsePayloadDTO<TaskDTO[]>>(`${environment.configurationsApiBaseUrl}/tasks/${level}/GetTasksByLevel`);
    }
}
