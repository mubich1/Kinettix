import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { TaskDTO } from "src/app/models/taskDTO/taskDTO";

@Injectable({
    providedIn: 'any'
})
export class TaskSharedService {
    private milestoneList$ = new BehaviorSubject<TaskDTO[]>([]);
    public milestoneList = this.milestoneList$.asObservable();

    private isUserCurrentlyAddingTask$ = new BehaviorSubject<boolean>(false);
    public isUserCurrentlyAddingTask = this.isUserCurrentlyAddingTask$.asObservable();

    private taskIdToEdit$ = new BehaviorSubject<number>(0);
    public taskIdToEdit = this.taskIdToEdit$.asObservable();

    public SetTaskList (milestones: TaskDTO[]) : void {
        this.milestoneList$.next(milestones);
    }

    public SetIsUserCurrentlyAddingTask(isAdding: boolean) : void {
        this.isUserCurrentlyAddingTask$.next(isAdding);
    }

    public SetMilestoneIdToEdit(id: number) : void {
        this.taskIdToEdit$.next(id);
    }

}