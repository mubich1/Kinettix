import { TestBed } from '@angular/core/testing';

import { TicketDeliverableService } from './ticket-deliverable.service';

describe('TicketDeliverableService', () => {
  let service: TicketDeliverableService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TicketDeliverableService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
