import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TicketDeliverableService {

  constructor(private httpClient: HttpClient) { }


  //DELIVERABLE REQUIREMENTS
  createDeliverableRequirement(requirementObj: any, ticketId: any): Observable<any> {
    return this.httpClient.post<any>(`${environment.workOrderApiBaseUrl}/ticket/${ticketId}/deliverable/createTicketDeliverableRequirements`, requirementObj);
  }
  getAllDeliverableRequirements(ticketId: any, poId: any): Observable<any> {
    return this.httpClient.get<any>(`${environment.workOrderApiBaseUrl}/ticket/${ticketId}/deliverable/${poId}/ticketdeliverablerequirements`);
  }
  getDeliverableRequirementById(ticketId: any, deliverableId: any): Observable<any> {
    return this.httpClient.get<any>(`${environment.workOrderApiBaseUrl}/ticket/${ticketId}/deliverable/${deliverableId}/DeliverableRequirement`);
  }
  updateDeliverableRequirement(doc: any, ticketId: any): Observable<any> {
    return this.httpClient.put<any>(`${environment.workOrderApiBaseUrl}/ticket/${ticketId}/deliverable/deliverableRequirement`, doc);
  }
  deleteDeliverableRequirement(ticketId: any, deliverableId: any): Observable<any> {
    return this.httpClient.delete<any>(`${environment.workOrderApiBaseUrl}/ticket/${ticketId}/deliverable/deliverableRequirement/${deliverableId}`);
  }

  getAll(ticketId: any, poId: any): Observable<any> {
    return this.httpClient.get<any>(`${environment.workOrderApiBaseUrl}/ticket/${ticketId}/deliverable/${poId}/poDeliverable`);
  }
  updateDeliverable(doc: any, ticketId: any): Observable<any> {
    return this.httpClient.put<any>(`${environment.workOrderApiBaseUrl}/ticket/${ticketId}/deliverable`, doc);
  }
  createDeliverable(doc: any, ticketId: any): Observable<any> {
    return this.httpClient.post<any>(`${environment.workOrderApiBaseUrl}/ticket/${ticketId}/deliverable`, doc);
  }
  getById(ticketId: any, deliverableId: any): Observable<any> {
    return this.httpClient.get<any>(`${environment.workOrderApiBaseUrl}/ticket/${ticketId}/deliverable/${deliverableId}/getDeliverable`);
  }
  delete(ticketId: any, deliverableId: any): Observable<any> {
    return this.httpClient.delete<any>(`${environment.workOrderApiBaseUrl}/ticket/${ticketId}/deliverable/${deliverableId}`);
  }
  documentUpload(document: any): Observable<any> {
    const body = {
      filename: document?.name,
      filebase64string: document?.filebase64string,
      doctype: 'Deliverable',
      moduleName: document?.moduleName,
      gliability: document?.generalLiability,
      uliability: document?.umbrellaLiability,
      date: document?.expiration
    }
    return this.httpClient.post<any>(`${environment.utilityApiBaseUrl}/document/upload`, body);
  }
  approveDeliverable(ticketId, deliverableId, poId: number): Observable<any> {
    return this.httpClient.put<any>(`${environment.workOrderApiBaseUrl}/ticket/${ticketId}/deliverable/${deliverableId}/DeliverableRequirement/Approve/${poId}`, null);
  }
  rejectDeliverable(ticketId, deliverableId, rejectReason, poId: number): Observable<any> {
    const model = { deliverableId: deliverableId, rejectedReason: rejectReason, poId: poId };
    return this.httpClient.put<any>(`${environment.workOrderApiBaseUrl}/ticket/${ticketId}/deliverable/DeliverableRequirement/Reject/`, model);
  }
}
