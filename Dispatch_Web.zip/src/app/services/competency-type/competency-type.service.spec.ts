import { TestBed } from '@angular/core/testing';

import { CompetencyTypeService } from './competency-type.service';

describe('CompetencyTypeService', () => {
  let service: CompetencyTypeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CompetencyTypeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
