import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { Competency, CompetencyRequest, CompetencyType } from 'src/app/models/vendor/vendor';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CompetencyTypeService {

  constructor(
    private httpClient: HttpClient,
  ) { }

  getAllTypes(): Observable<ResponsePayloadDTO<CompetencyType[]>> {
    return this.httpClient.get<ResponsePayloadDTO<CompetencyType[]>>(`${environment.configurationsApiBaseUrl}/competency-types`);
  }

  getCompetencyTypeById(id: number): Observable<ResponsePayloadDTO<CompetencyType>> {
    return this.httpClient.get<ResponsePayloadDTO<CompetencyType>>(`${environment.configurationsApiBaseUrl}/competency-types/${id}`);

  }

  saveCompetencyType(template: CompetencyType): Observable<ResponsePayloadDTO<number>> {
    return this.httpClient.post<ResponsePayloadDTO<number>>(`${environment.configurationsApiBaseUrl}/competency-types`, template);

  }

  updateCompetencyType(template: CompetencyType): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.put<ResponsePayloadDTO<boolean>>(`${environment.configurationsApiBaseUrl}/competency-types`, template);

  }


  deleteCompetencyType(id: number): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.delete<ResponsePayloadDTO<boolean>>(`${environment.configurationsApiBaseUrl}/competency-types/${id}`);
  }

}
