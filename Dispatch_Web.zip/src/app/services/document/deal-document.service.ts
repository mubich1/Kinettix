import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class DealDocumentService {

  constructor(private httpClient: HttpClient) { }

  uploadDocument(document: any): Observable<any> {
    const body = {
      filename: document?.name,
      filebase64string: document?.filebase64string,
      doctype: document?.docType?.name,
      moduleName: document?.moduleName,
      gliability: document?.generalLiability,
      uliability: document?.umbrellaLiability,
      date: document?.expiration,
      isInternal: document?.isInternal,
      vendorName: document?.vendorName,
      technicianName: document?.technicianName
    }
    return this.httpClient.post<any>(`${environment.utilityApiBaseUrl}/document/upload`, body);
  }

  uploadDocumentV2(document: any): Observable<any> {
    const body = {
      filename: document.name,
      filebase64string: document.filebase64string,
      doctype: document.type,
      gliability: document.generalLiability,
      uliability:document.umbrellaLiability,
      date:document.expiration
    }
    return this.httpClient.post<any>(`${environment.utilityApiBaseUrl}/document/upload`, body);
  }

  deleteDocument(documentUrl: string): Observable<any> {

    return this.httpClient.post<any>(`${environment.utilityApiBaseUrl}/document/delete-by-url`, documentUrl);
  }

  deleteDocumentById(id: number): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.delete<ResponsePayloadDTO<boolean>>(`${environment.saleApiBaseUrl}/deals/documents/`+id);
  }
}
