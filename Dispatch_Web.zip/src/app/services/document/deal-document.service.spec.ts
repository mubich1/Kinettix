import { TestBed } from '@angular/core/testing';

import { DealDocumentService } from './deal-document.service';

describe('DealDocumentService', () => {
  let service: DealDocumentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DealDocumentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
