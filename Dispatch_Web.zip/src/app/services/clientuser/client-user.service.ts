import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { combineLatest, map, Observable,BehaviorSubject } from 'rxjs';
import {
  AssociatedEntities,
  Client,
  ClientUserDocument,
  ClientUserDocumentRequest,
  ClientRelationshipType,
} from 'src/app/models/client/client';
import { ClientSite } from 'src/app/models/client/client-site';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { environment } from 'src/environments/environment';
import { clientworkorders } from 'src/app/models/client-workorders/clientworkorders';
import { Notes, NotesRequest } from 'src/app/models/common/notes';
import { Subject, takeUntil } from 'rxjs';
import { TableFilters } from 'src/app/shared/common/tableFilters';

@Injectable({
  providedIn: 'root',
})
export class ClientUserService {
  private clientUserSource = new BehaviorSubject(null);
  clientUserListner = this.clientUserSource.asObservable();
  constructor(private httpClient: HttpClient) {}

  public copyDataFromParentToChild = {
    id: 0,
  };
  clientUserbroadCast(item: any) {
    this.clientUserSource.next(item)
  }
  getClientUsersId(clientid:any): Observable<any> {
    return this.httpClient.get<any>(
      `${environment.clientApiBaseUrl}/ClientUser/${clientid}`
    );
  }
  getClientUsersByClientId(
    clientid:number,
    pageNumber: number,
    name: string,
    country: string,
    city: string,
    orderby: string,
    sort: string
  ): Observable<any> {
    const params = new HttpParams()
    .set('clientId', clientid)
      .set('pageNumber', pageNumber)
      .set('name', name?.toString())
      .set('country', country?.toString())
      .set('city', city.toString())
      .set('orderby', orderby?.toString())
      .set('sort', sort?.toString());
    return this.httpClient.get<any>(`${environment.clientApiBaseUrl}/ClientUser`, {
      params,
    });
  }

  getClientUserById(clientId: number,id:number=0): Observable<any> {
    const params = new HttpParams().set('id', id);
    return this.httpClient.get<Client>(
      `${environment.clientApiBaseUrl}/ClientUser/${clientId}`,
      { params }
    );
  }
  getAllContries(): Observable<any> {
    return this.httpClient.get<any>(
      `${environment.configurationsApiBaseUrl}/countrydropdownlist`
    );
  }
  getSiteById(clientId: number, siteId: number): Observable<any> {
    return this.httpClient.get<ClientSite>(
      `${environment.clientApiBaseUrl}/Client/${clientId}/sites/${siteId}`
    );
  }
  updateClientById(client: any): Observable<Client> {
    return this.httpClient.put<Client>(
      `${environment.clientApiBaseUrl}/ClientUser/`,
      client
    );
  }
  updateClient(client: Client): Observable<Client> {
    return this.httpClient.put<Client>(
      `${environment.clientApiBaseUrl}/Client`,
      client
    );
  }
  GetWorkorderByClientId(id: number): Observable<any> {
    return this.httpClient.get<clientworkorders>(
      `${environment.clientApiBaseUrl}/Client/${id}/tickets`
    );
  }

  createDocument(
    document: ClientUserDocumentRequest,
    clientUserId: number
  ): Observable<ResponsePayloadDTO<number>> {
    return this.httpClient.post<ResponsePayloadDTO<number>>(
      `${environment.clientApiBaseUrl}/clientuser/${clientUserId}/userDocuments`,
      document
    );
  }
  updateDocument(
    document: ClientUserDocumentRequest,
    clientUserId: number
  ): Observable<ResponsePayloadDTO<number>> {
    return this.httpClient.put<ResponsePayloadDTO<number>>(
      `${environment.clientApiBaseUrl}/clientuser/${clientUserId}/documents`,
      document
    );
  }

  // getDocumentsByClientUserId(
  //   clientUserId: number
  // ): Observable<ResponsePayloadDTO<ClientUserDocument[]>> {
  //   return this.httpClient.get<ResponsePayloadDTO<ClientUserDocument[]>>(
  //     `${environment.clientApiBaseUrl}/clientuser/${clientUserId}/documents`
  //   );
  // }

  getDocumentByDocumentId(
    documentId: number
  ): Observable<ResponsePayloadDTO<ClientUserDocument>> {
    return this.httpClient.get<ResponsePayloadDTO<ClientUserDocument>>(
      `${environment.clientApiBaseUrl}/clientuser/documents/${documentId}`
    );
  }

  getDocumentDetailsById(id: number): Observable<ResponsePayloadDTO<ClientUserDocument>> {
    return this.httpClient.get<ResponsePayloadDTO<ClientUserDocument>>(`${environment.clientApiBaseUrl}/clients/documents/${id}/details`);
  }

  deleteDocumentById(clientUserId: number): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.delete<ResponsePayloadDTO<boolean>>(
      `${environment.clientApiBaseUrl}/clientuser/documents/${clientUserId}`
    );
  }
  deleteDocumentByUserId(documentId: number): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.delete<ResponsePayloadDTO<boolean>>(
      `${environment.clientApiBaseUrl}/clientuser/${documentId}/documents`
    );
  }

  deleteClientUserById(id: number): Observable<ResponsePayloadDTO<boolean>> {
    console.warn(`deleteClientByID triggered with ${id}`);
    return this.httpClient.delete<ResponsePayloadDTO<boolean>>(
      `${environment.clientApiBaseUrl}/ClientUser?userid=${id}`
    );
  }

  createClient(client: Client): Observable<any> {
    return this.httpClient.post<Client>(
      `${environment.clientApiBaseUrl}/Client`,
      client
    );
  }
  getClientSite(
    pageNumber: number,
    clientId: number,
    country: string,
    filter: string
  ): Observable<any> {
    const params = new HttpParams()
      .set('pageNumber', pageNumber)
      .set('country', country?.toString())
      .set('filter', filter?.toString());
    return this.httpClient.get<ClientSite>(
      `${environment.clientApiBaseUrl}/Client/${clientId}/sites`,
      { params }
    );
  }
  createClientSite(clientSite: ClientSite, clientId: number): Observable<any> {
    return this.httpClient.post<ClientSite>(
      `${environment.clientApiBaseUrl}/Client/${clientId}/sites`,
      clientSite
    );
  }
  updateClientSite(clientSite: ClientSite): Observable<ClientSite> {
    return this.httpClient.put<ClientSite>(
      `${environment.clientApiBaseUrl}/Client/{clientId}/sites`,
      clientSite
    );
  }

  getAllClientNotes(clientId: number): Observable<ResponsePayloadDTO<Notes[]>> {
    return this.httpClient.get<ResponsePayloadDTO<Notes[]>>(
      `${environment.clientApiBaseUrl}/clients/${clientId}/notes`
    );
  }
  getClientNoteById(noteId: number): Observable<ResponsePayloadDTO<Notes>> {
    return this.httpClient.get<ResponsePayloadDTO<Notes>>(
      `${environment.clientApiBaseUrl}/clients/notes/${noteId}`
    );
  }

  createClientNote(
    clientNote: NotesRequest,
    clientId: number
  ): Observable<ResponsePayloadDTO<number>> {
    return this.httpClient.post<ResponsePayloadDTO<number>>(
      `${environment.clientApiBaseUrl}/clients/${clientId}/notes`,
      clientNote
    );
  }
  updateClientNote(
    clientNote: NotesRequest,
    clientId: number
  ): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.put<ResponsePayloadDTO<boolean>>(
      `${environment.clientApiBaseUrl}/clients/${clientId}/notes`,
      clientNote
    );
  }
  deleteClientNote(noteId: number): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.delete<ResponsePayloadDTO<boolean>>(
      `${environment.clientApiBaseUrl}/clients/notes/${noteId}`
    );
  }

  getAllNotesWithClientName(clientId: number): Observable<Notes[]> {
    let note$ = this.getAllClientNotes(clientId).pipe(
      map((res) => res.results)
    );
    let clients$ = this.getClientUserById(clientId);

    return combineLatest([note$, clients$]).pipe(
      map(([note, clients]) =>
        note.map(
          (a) =>
            ({
              id: a.id,
              clientId: a.clientId,
              clientName: clients?.results?.name,
              name: a.name,
              description: a.description,
              createdDate: a.createdDate,
            } as Notes)
        )
      )
    );
  }
  getAllDeactivatedClients(): Observable<any> {
    return this.httpClient.get<any>(
      `${environment.clientApiBaseUrl}/Client/deactivated`
    );
  }
  activateClient(clientId: number): Observable<any> {
    return this.httpClient.patch<any>(
      `${environment.clientApiBaseUrl}/Client/${clientId}/activate`,
      null
    );
  }

  getAllClientList(): Observable<any> {
    return this.httpClient.get<any>(
      `${environment.clientApiBaseUrl}/Client/AllClientsList`
    );
  }
  getAllEndClientsList(id:any): Observable<any> {
    return this.httpClient.get<any>(`${environment.clientApiBaseUrl}/Client/${id}/AllEndClientsList`);
  }

  getRelationshipTypes(): Observable<
    ResponsePayloadDTO<ClientRelationshipType[]>
  > {
    return this.httpClient.get<ResponsePayloadDTO<ClientRelationshipType[]>>(
      `${environment.clientApiBaseUrl}/client/relationship-types`
    );
  }

  getDocumentDownloadUrl(id: number): string {
    return `${environment.utilityApiBaseUrl}/document/clientUser/${id}`;
  }
  checkClientStatus(clientId:number): Observable<any> {
    return this.httpClient.get<any>(
      `${environment.clientApiBaseUrl}/ClientUser/${clientId}/clientStatus`
    );
  }
  getClientStatus(clientId:number): Observable<any> {
    return this.httpClient.get<any>(
      `${environment.clientApiBaseUrl}/ClientUser/${clientId}/GetClientStatus`
    );
  }

  changePasswordClientUser(resetPasswordObj: any): Observable<any> {
    return this.httpClient.put<any>(
      `${environment.identityBaseUrl}/identity/users/ChangePassword`,
      resetPasswordObj
    );
  }

  resetPasswordClientUser(userid: String): Observable<any> {
    return this.httpClient.get<any>(`${environment.identityBaseUrl}/identity/users/resetpassword/${userid}`);
  }
  
  getDocumentsByClientUserId(
    clientUserId: number,payload:TableFilters
  ): Observable<any> {
    return this.httpClient.get(
      `${environment.clientApiBaseUrl}/clientuser/${clientUserId}/documents?sort=${payload.sort}&search=${payload.search}&page=${payload.page}&pageSize=${payload.pageSize}&isAscending=${payload.isAscending}`
    );
  }
}
