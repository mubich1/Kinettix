import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { TableFilters } from 'src/app/shared/common/tableFilters';

@Injectable({
  providedIn: 'root'
})
export class CustomfieldSetsService {
  private readonly urlPath = `${environment.configurationsApiBaseUrl}/customfieldsets`;
  constructor(private httpClient: HttpClient) { }

  create(request: any): Observable<any> {
   return this.httpClient.post(`${this.urlPath}`,
        request);
  }
  update(request: any): Observable<any> {
  return  this.httpClient.put(`${this.urlPath}`,
        request)
  }
  getAll(payload: TableFilters): Observable<any> {
    return this.httpClient.get(`${this.urlPath}?sort=${payload.sort}&search=${payload.search}&page=${payload.page}&pageSize=${payload.pageSize}&isAscending=${payload.isAscending}`);
  }
  getById(id:number): Observable<any> {
    return this.httpClient.get(`${this.urlPath}/${id}`);
  }
  delete(id:number): Observable<any> {
    return this.httpClient.delete(`${this.urlPath}/${id}`);
  }
}
