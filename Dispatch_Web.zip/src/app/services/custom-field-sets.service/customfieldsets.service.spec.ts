import { TestBed } from '@angular/core/testing';

import { CustomfieldSetsService } from './customfieldsets.service';

describe('CustomfieldsService', () => {
  let service: CustomfieldSetsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CustomfieldSetsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
