import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
    providedIn: 'root'
})
export class CommonService {

    constructor(private httpClient: HttpClient) { }

    getDocumentDefinitionTypes(): Observable<any> {
        return this.httpClient.get<any>(`${environment.configurationsApiBaseUrl}/document-definitions`);
    }

    getPaymentTerms(): Observable<any> {
        return this.httpClient.get<any>(`${environment.configurationsApiBaseUrl}/common/paymentTerms`);
    }

    getPaymentTypes(): Observable<any> {
        return this.httpClient.get<any>(`${environment.configurationsApiBaseUrl}/common/paymentTypes`);
    }

    getPowerBIReportConfig(reportId: string, workSpaceId:any): Observable<any> {
        return this.httpClient.get<any>(`${environment.utilityApiBaseUrl}/report/${workSpaceId}/${reportId}`);
    }
    downloadDocument(url,FileName)
    {
        const jwtToken = JSON.parse(localStorage.getItem('jwtToken') as any);
        var documentname = FileName
        if (documentname.indexOf(".") > 0){
          documentname = documentname.substring(0,documentname.lastIndexOf("."))
        }
        var req = new XMLHttpRequest();
        req.open("GET", url, true);
        req.setRequestHeader("Authorization","Bearer "+jwtToken);
        req.setRequestHeader("Ocp-Apim-Subscription-Key",environment.apimSubscriptionKey);
      req.responseType = "blob";
        req.onload = function (event) {
            var blob = req.response;
            var link=document.createElement('a');
            link.href=window.URL.createObjectURL(blob);
            link.download= documentname;
            link.click();
        };
        req.send();
    }
}
