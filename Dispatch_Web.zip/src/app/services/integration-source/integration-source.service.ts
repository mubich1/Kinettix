import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { IntegrationSource } from "src/app/models/integration-source/integration-source";
import { ResponsePayloadDTO } from "src/app/models/salesAPIResponse";
import { TableFilters } from "src/app/shared/common/tableFilters";
import { environment } from "src/environments/environment";

@Injectable({
    providedIn: 'root'
})
export class IntegrationSourceService {
    constructor(private httpClient: HttpClient) {
    }

    public GetIntegrationSource(id: number) : Observable<ResponsePayloadDTO<IntegrationSource>> {
        return this.httpClient.get<ResponsePayloadDTO<IntegrationSource>>(`${environment.configurationsApiBaseUrl}/integrationsources/${id}`);
    }

    public GetIntegrationSourceList(payload: TableFilters) : Observable<any> {
        return this.httpClient.get<any>(`${environment.configurationsApiBaseUrl}/integrationsources?sort=${payload.sort}&search=${payload.search}&page=${payload.page}&pageSize=${payload.pageSize}&isAscending=${payload.isAscending}`);
    }

    public AddIntegrationSource(model: IntegrationSource) : Observable<ResponsePayloadDTO<IntegrationSource>> {
        return this.httpClient.post<ResponsePayloadDTO<IntegrationSource>>(`${environment.configurationsApiBaseUrl}/integrationsources`, model);
    }

    public UpdateIntegrationSource( model: IntegrationSource) : Observable<ResponsePayloadDTO<IntegrationSource>> {
        return this.httpClient.put<ResponsePayloadDTO<IntegrationSource>>(`${environment.configurationsApiBaseUrl}/integrationsources`, model);
    }

    public RemoveIntegrationSource(id: number) {
        return this.httpClient.delete(`${environment.configurationsApiBaseUrl}/integrationsources/${id}`);
    }
}