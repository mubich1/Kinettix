import { TestBed } from '@angular/core/testing';

import { VendorTechniciansService } from './vendor-technicians.service';

describe('VendorTechniciansService', () => {
  let service: VendorTechniciansService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(VendorTechniciansService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
