import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, shareReplay, Subject, tap } from 'rxjs';
import { environment } from 'src/environments/environment';
import { CompetencyViewModel, TechContract, TechDocumentRequest, TechnicianDTO, TechnicianTypeViewModel } from 'src/app/models/vendor-technicians/technicians';
import { Filters } from 'src/app/models/common/common';
import { NotesRequest } from 'src/app/models/common/notes';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { TableFilters } from 'src/app/shared/common/tableFilters';

@Injectable({
  providedIn: 'root'
})
export class VendorTechniciansService {
  data$: Observable<CompetencyViewModel[]>;
  private tech: Subject<TechnicianDTO> = new BehaviorSubject<TechnicianDTO>({});
  constructor(private httpClient: HttpClient) { }


  getAllTechnicians(vendorId: number,): Observable<any> {
    const params = new HttpParams()
      .set('pageNumber', 0)
      .set('name', "")
      .set('orderby', "")
      .set('sort', "")
      ;

    return this.httpClient.get<any>(`${environment.vendorApiBaseUrl}/vendor/${vendorId}/technician/getall`, { params });
  }
  getAllFilterTechnicians(vendorId: number, pageNumber: number, name: string, orderby: string, sort: string): Observable<any> {
    const filters =
      {
        pageNumber: pageNumber,
        name: name?.toString(),
        orderby: orderby?.toString(),
        sort: sort?.toString(),
      } as Filters;
    const params = new HttpParams()
      .set('filters', JSON.stringify(filters));
    return this.httpClient.get<any>(`${environment.vendorApiBaseUrl}/vendor/${vendorId}/technician/getall`, { params });
  }
  getTechType() {
    return this.httpClient.get<TechnicianTypeViewModel[]>(`${environment.vendorApiBaseUrl}/vendor/techniciantypes`);
  }

  getCompetencies(type: string) {
    this.data$ = this.httpClient.get(`${environment.vendorApiBaseUrl}/vendor/competencies/${type}`).pipe(
      tap(console.log),
      shareReplay(1),
      tap(() => console.log('after sharing'))
    );
    return this.data$;
  }

  getVendorFieldServiceInfo() {
    return this.tech.asObservable();
  }
  addVendorFieldServiceInfo(data: TechnicianDTO) {
    this.tech.next(data);
  }
  saveTech(model: TechnicianDTO, vendorId: number) {

    return this.httpClient.post<TechnicianDTO>(`${environment.vendorApiBaseUrl}/vendor/${vendorId}/technician/create`, model);
  }

  updateTech(model: TechnicianDTO, vendorId: number) {

    return this.httpClient.put<TechnicianDTO>(`${environment.vendorApiBaseUrl}/vendor/${vendorId}/technician/tech-update`, model);
  }

  skillsupdateTech(model: TechnicianDTO, vendorId: number) {

    return this.httpClient.put<TechnicianDTO>(`${environment.vendorApiBaseUrl}/vendor/${vendorId}/technician/skills-update`, model);
  }

  deleteTechById(id: number, vendorId: number): Observable<boolean> {
    return this.httpClient.delete<boolean>(`${environment.vendorApiBaseUrl}/vendor/${vendorId}/technician/delete/${id}`);
  }
  getTechById(vendorId: number, techId: number) {
    return this.httpClient.get<TechnicianDTO>(`${environment.vendorApiBaseUrl}/vendor/${vendorId}/technician-detail/${techId}`);
  }
  getAllContries(): Observable<any> {
    return this.httpClient.get<any>(`${environment.configurationsApiBaseUrl}/countrydropdownlist`);

  }

  createDocument(document: TechDocumentRequest, techId: number): Observable<number> {

    return this.httpClient.post<number>(`${environment.vendorApiBaseUrl}/vendor/${techId}/technician/documents`, document);
  }

  updateDocument(document: TechDocumentRequest, techId: number): Observable<number> {

    return this.httpClient.put<number>(`${environment.vendorApiBaseUrl}/vendor/${techId}/technician/documents`, document);
  }
  getTechDocumentsByTechId(techId: number): Observable<TechDocumentRequest[]> {
    return this.httpClient.get<TechDocumentRequest[]>(`${environment.vendorApiBaseUrl}/vendor/technician/${techId}/documentslist`);
  }

  getDocumentByDocumentId(id: number): Observable<TechDocumentRequest> {
    return this.httpClient.get<TechDocumentRequest>(`${environment.vendorApiBaseUrl}/vendor/technician/documents/${id}`);
  }

  deleteDocumentById(id: number): Observable<boolean> {
    return this.httpClient.delete<boolean>(`${environment.vendorApiBaseUrl}/vendor/technician/documents/${id}`);
  }

  getPagedTechNotes(payload: TableFilters, techId: number): Observable<any> {
    return this.httpClient.get<any>(`${environment.vendorApiBaseUrl}/vendor/technician/${techId}/notes?sort=${payload.sort}&search=${payload.search}&page=${payload.page}&pageSize=${payload.pageSize}&isAscending=${payload.isAscending}`);
  }

  getTechnicianNoteById(noteId: number, techId: number): Observable<any> {
    return this.httpClient.get<any>(`${environment.vendorApiBaseUrl}/vendor/technician/${techId}/notes/${noteId}`);
  }

  updateTechnicianNote(techNote: NotesRequest, techId: number): Observable<boolean> {
    return this.httpClient.put<boolean>(`${environment.vendorApiBaseUrl}/vendor/technician/${techId}/notes`, techNote);
  }
  createTechnicianNote(techNote: NotesRequest, techId: number): Observable<number> {
    return this.httpClient.post<number>(`${environment.vendorApiBaseUrl}/vendor/technician/${techId}/notes`, techNote);
  }

  deleteTechnicianNote(noteId: number, techId: number): Observable<boolean> {
    return this.httpClient.delete<boolean>(`${environment.vendorApiBaseUrl}/vendor/technician/${techId}/notes/${noteId}`);
  }
  deleteVendorNote(noteId: number): Observable<boolean> {
    return this.httpClient.delete<boolean>(`${environment.vendorApiBaseUrl}/vendor/notes/${noteId}`);
  }

  // Tech Note operational Method End

  getAllContractsAndTicketsByTechId(techId: number): Observable<ResponsePayloadDTO<TechContract[]>> {
    return this.httpClient.get<ResponsePayloadDTO<TechContract[]>>(`${environment.workOrderApiBaseUrl}/tickets/tech-tickets/${techId}`);
  }
  getDocumentDownloadUrl(id: number): string {
    return `${environment.utilityApiBaseUrl}/document/tech/${id}`;
  }
}
