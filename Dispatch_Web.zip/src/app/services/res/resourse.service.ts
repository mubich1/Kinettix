import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ResourseService {

  constructor(private httpClient: HttpClient) {}

  ngOnInit() {

  }

  getResources(): Observable<ResponsePayloadDTO<any[]>> {
    return this.httpClient.get<ResponsePayloadDTO<any[]>>(`${environment.saleApiBaseUrl}/Resources`);
  }


  getResourceById(id : number): Observable<ResponsePayloadDTO<any>> {
    return this.httpClient.get<ResponsePayloadDTO<any>>(`${environment.saleApiBaseUrl}/Resources/`+id);
  }

  deleteResource(id: number): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.delete<ResponsePayloadDTO<boolean>>(`${environment.saleApiBaseUrl}/Resources/`+id);
  }

  updateResource(resource: any): Observable<ResponsePayloadDTO<number>> {
    return this.httpClient.put<ResponsePayloadDTO<number>>(`${environment.saleApiBaseUrl}/Resources`, resource);

  }

  saveResource(resource: any): Observable<ResponsePayloadDTO<number>> {
    return this.httpClient.post<ResponsePayloadDTO<number>>(`${environment.saleApiBaseUrl}/Resources`, resource);

  }
}
