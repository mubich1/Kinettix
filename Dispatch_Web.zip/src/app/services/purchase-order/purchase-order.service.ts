import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AssignTechnician, TechnicianTableFilters } from 'src/app/models/assign-technician/assign-technician';
import { POScope, PurchaseOrder, PurchaseOrderPlatform } from 'src/app/models/purchaseOrder/purchase-order';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { TechnicianDTO } from 'src/app/models/vendor-technicians/technicians';
import { environment } from 'src/environments/environment';
import { EmailContent } from 'src/app/models/utility/email-content';

@Injectable({
  providedIn: 'root'
})
export class PurchaseOrderService {

  constructor(private httpClient: HttpClient) { }

  getPoById(poId: number) {
    return this.httpClient.get<ResponsePayloadDTO<PurchaseOrder>>(`${environment.workOrderApiBaseUrl}/purchaseorder/${poId}`);
  }

  getPoDetailsById(poId: number) {
    return this.httpClient.get<ResponsePayloadDTO<PurchaseOrder>>(`${environment.workOrderApiBaseUrl}/purchaseorder/${poId}/poDetails`);
  }

  assignTechnician(technician: AssignTechnician) {
    return this.httpClient.put<TechnicianDTO>(`${environment.workOrderApiBaseUrl}/purchaseorder/assigntechnician`, technician);
  }
  getPoNotesLogs(queryParams: any, poId: number) {
    return this.httpClient.get<any>(`${environment.workOrderApiBaseUrl}/PurchaseOrder/${poId}/notes`, { params: queryParams });
  }

  getPoCallLogs(queryParams: any, poId: number) {
    return this.httpClient.get<any>(`${environment.workOrderApiBaseUrl}/PurchaseOrder/${poId}/Calllogs`, { params: queryParams });
  }

  getAllVendorPedors(queryParams: any, ticketId: number) {
    return this.httpClient.get<any>(`${environment.workOrderApiBaseUrl}/PurchaseOrder/${ticketId}/recommendedtechnicians`, { params: queryParams });
  }

  addPONotes(id: number, notes: string) {
    return this.httpClient.post<any>(`${environment.workOrderApiBaseUrl}/PurchaseOrder/${id}/notes`, notes)
  }

  lastDateCallPurchaseOrder(id: number, payload: any) {
    return this.httpClient.post<any>(`${environment.workOrderApiBaseUrl}/PurchaseOrder/${id}/calllog`, payload)
  }

  getPoScope(poId: number) {
    return this.httpClient.get<any>(`${environment.workOrderApiBaseUrl}/PurchaseOrder/${poId}/Scope`);
  }

  addPoScope(payload: POScope, poId: number) {
    return this.httpClient.put<any>(`${environment.workOrderApiBaseUrl}/PurchaseOrder/${poId}/Scope`, payload)
  }

  getActivityCompetencies(id: number) {
    return this.httpClient.get<any>(`${environment.workOrderApiBaseUrl}/Tickets/${id}/ticketactivitycompetencylist`);
  }

  getPOActivitiesByIdAsync(poId: number) {
    return this.httpClient.get<any>(`${environment.workOrderApiBaseUrl}/PurchaseOrder/${poId}/activities`);
  }

  updatePOSpecialConditionsById(id: number, PurchaseOrder: PurchaseOrder) {
    return this.httpClient.put<any>(`${environment.workOrderApiBaseUrl}/PurchaseOrder/${id}/special-conditions`, PurchaseOrder);
  }

  getPlatformByPoId(id: number) {
    return this.httpClient.get<any>(`${environment.workOrderApiBaseUrl}/PurchaseOrder/${id}/platforms`);
  }

  addOrUpdatePlatform(purchaseOrderPlatform: PurchaseOrderPlatform) {
    return this.httpClient.post<any>(`${environment.workOrderApiBaseUrl}/PurchaseOrder/${purchaseOrderPlatform.pOId}/platforms`, purchaseOrderPlatform);
  }

  updatePO(po: PurchaseOrder) {
    return this.httpClient.put<any>(`${environment.workOrderApiBaseUrl}/PurchaseOrder`, po);
  }
  updatePOActivityResources(payload: any) {
    return this.httpClient.put<any>(`${environment.workOrderApiBaseUrl}/PurchaseOrder/updatepoactivityresource`, payload);
  }

  deletePOResources(ticketActivities: number[], poId: number) {
    let options = {
      body: ticketActivities
    };
    return this.httpClient.delete<any>(`${environment.workOrderApiBaseUrl}/PurchaseOrder/${poId}/resources`, options);
  }
  getPoMilestoneByPOId(poId: number) {
    return this.httpClient.get<any>(`${environment.workOrderApiBaseUrl}/potasks/${poId}/pomilestones`);
  }
  getPurchaseOrderFile(poId: number, file: string, reassign: boolean): string {
    return `${environment.workOrderApiBaseUrl}/PurchaseOrder/${poId}/file/${file}?reassign=${reassign}`;
  }
  updatePOStage(podetail: any) {
    return this.httpClient.put<any>(`${environment.workOrderApiBaseUrl}/PurchaseOrder/stage`, podetail);
  }
  getVendorByPoId(poId: number) {
    return this.httpClient.get<any>(`${environment.workOrderApiBaseUrl}/PurchaseOrder/vendor/${poId}`);
  }
  getAttachementFile(emailContent: EmailContent, poId: number, file: String) {
    return this.httpClient.post<any>(`${environment.workOrderApiBaseUrl}/PurchaseOrder/${poId}/attachementFile/${file}`, emailContent)
  }

}
