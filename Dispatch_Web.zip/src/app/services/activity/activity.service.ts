import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Activity } from 'src/app/models/activity/activity';
import { ActivityCategory } from 'src/app/models/activity/activity-category';
import { ActivityStatus } from 'src/app/models/activity/activity-status';
import { ActivityType } from 'src/app/models/activity/activity-type';
import { Currency } from 'src/app/models/activity/currency';
import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class ActivityService {
  constructor(private httpClient: HttpClient) {}

  getActivityById(id: number): Observable<ResponsePayloadDTO<Activity>> {
    return this.httpClient.get<ResponsePayloadDTO<Activity>>(
      `${environment.projectApiBaseUrl}/contract-activities/` + id
    );
  }

  getAllGlobelActivities(showApprovedOnly = false): Observable<ResponsePayloadDTO<Activity[]>> {
    var res = this.httpClient.get<ResponsePayloadDTO<Activity[]>>(
      `${environment.configurationsApiBaseUrl}/activities?showApprovedOnly=${showApprovedOnly}`
    );
    return res;
  }

  getCurrencies(): Observable<ResponsePayloadDTO<Currency[]>> {
    return this.httpClient.get<ResponsePayloadDTO<Currency[]>>(
      `${environment.configurationsApiBaseUrl}/currencies`
    );
  }

  updateActivity(activity: Activity): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.put<ResponsePayloadDTO<boolean>>(
      `${environment.projectApiBaseUrl}/contract-activities`,
      activity
    );
  }

  getActivityCategories(): Observable<ResponsePayloadDTO<ActivityCategory[]>> {
    return this.httpClient.get<ResponsePayloadDTO<ActivityCategory[]>>(
      `${environment.configurationsApiBaseUrl}/activitycatagories`
    );
  }

  getActivityStatuses(): Observable<ResponsePayloadDTO<ActivityStatus[]>> {
    return this.httpClient.get<ResponsePayloadDTO<ActivityStatus[]>>(
      `${environment.configurationsApiBaseUrl}/activity-statuses`
    );
  }

  saveActivity(activity: Activity): Observable<ResponsePayloadDTO<number>> {
    return this.httpClient.post<ResponsePayloadDTO<number>>(
      `${environment.projectApiBaseUrl}/contract-activities`,
      activity
    );
  }

  deleteActivityByActivityId(
    id: number
  ): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.delete<ResponsePayloadDTO<boolean>>(
      `${environment.projectApiBaseUrl}/contract-activities/${id}`
    );
  }
  getActivityTypes(): Observable<ResponsePayloadDTO<ActivityType[]>> {
    return this.httpClient.get<ResponsePayloadDTO<ActivityType[]>>(`${environment.configurationsApiBaseUrl}/activities/types`);
  }

  saveActivities(activities: Activity[]): Observable<ResponsePayloadDTO<number>> {
    return this.httpClient.post<ResponsePayloadDTO<number>>(
      `${environment.projectApiBaseUrl}/contract-activities/multiple`,
      activities
    );
  }

  getContractActivitiesByContractId(contractId: number): Observable<ResponsePayloadDTO<Activity[]>> {
    return this.httpClient.get<ResponsePayloadDTO<Activity[]>>(
      `${environment.projectApiBaseUrl}/contract-activities/contract/${contractId}`
    );
  }
}
