import { HttpClient,HttpEvent, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { UserNote } from 'src/app/models/usernote/usernote';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UsernoteService {
    private controllerName = "usernote";
    private baseUrl = `${environment.configurationsApiBaseUrl}`;
    private fullUrl = `${this.baseUrl}/${this.controllerName}`;
    private httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    constructor(private http:HttpClient) {
    }

    public get () : Observable<any>{
        return this.http.get<any>(this.fullUrl);
    }

    public getById (note : any) : Observable<any>{
        return this.http.get<any>(`${this.fullUrl}/details`);
    }

    create(note : any) : Observable<any>{
        var res = this.http.post<any>(this.fullUrl,note,this.httpOptions);
        return res;
    }

    update(note: any) : Observable<any>{
        return this.http.put<any>(this.fullUrl, note, this.httpOptions);
    }
}
