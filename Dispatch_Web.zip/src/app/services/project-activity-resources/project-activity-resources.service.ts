import { HttpClient } from '@angular/common/http';

import { Injectable } from '@angular/core';

import { BehaviorSubject, Observable, Subject } from 'rxjs';

import { Resource } from 'src/app/models/activity/activity-resource';
import { ClientContractsGetDto } from 'src/app/models/project/project';
import { ContractActivityResourceMainDto } from 'src/app/models/resources/resource';

import { ResponsePayloadDTO } from 'src/app/models/salesAPIResponse';

import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class ProjectActivityResourceService {
  constructor(private httpClient: HttpClient) {}
  private tech: Subject<ClientContractsGetDto> = new BehaviorSubject<ClientContractsGetDto>({});
  getResourceCategories(): Observable<ResponsePayloadDTO<any[]>> {
    return this.httpClient.get<ResponsePayloadDTO<any[]>>(
      `${environment.configurationsApiBaseUrl}/resource-categories`
    );
  }

  getResourcesByCategoryId(categoryName: any): Observable<ResponsePayloadDTO<any[]>> {
    return this.httpClient.get<ResponsePayloadDTO<any[]>>(
      `${environment.configurationsApiBaseUrl}/resources/category/${categoryName}`
    );
  }

  addActivityResource(
    contractActivityResources:ContractActivityResourceMainDto
  ): Observable<ResponsePayloadDTO<number>> {
    return this.httpClient.post<ResponsePayloadDTO<number>>(
      `${environment.projectApiBaseUrl}/contract-activity-resources`,
      contractActivityResources
    );
  }
  updateProjectActivityresources(contractActivityResources:ContractActivityResourceMainDto): Observable<ResponsePayloadDTO<number>> {
    return this.httpClient.put<ResponsePayloadDTO<number>>(
      `${environment.projectApiBaseUrl}/contract-activity-resources`,
      contractActivityResources
    );
  }

  deleteResourceByResourceId(
    id: number
  ): Observable<ResponsePayloadDTO<boolean>> {
    return this.httpClient.delete<ResponsePayloadDTO<boolean>>(
      `${environment.projectApiBaseUrl}/contract-activity-resources/${id}`
    );
  }

  getProjectActivityResourcesByActivityId(
    activityId: number
  ): Observable<ResponsePayloadDTO<any>> {
    return this.httpClient.get<ResponsePayloadDTO<any>>(
      `${environment.projectApiBaseUrl}/contract-activities/${activityId}/resources`
    );
  }
  getClientContratsByClientId(clientId: number,ContractClosed:boolean): Observable<ResponsePayloadDTO<ClientContractsGetDto[]>> {
    return this.httpClient.get<ResponsePayloadDTO<ClientContractsGetDto[]>>(`${environment.projectApiBaseUrl}/contract/${clientId}/contracts?showClosedContract=${ContractClosed}`);
  }
  getContractByContractId(id: number): Observable<ResponsePayloadDTO<ClientContractsGetDto>> {
    return this.httpClient.get<ResponsePayloadDTO<ClientContractsGetDto>>(`${environment.projectApiBaseUrl}/contract/contracts/${id}`);
  }

  getContractServiceInfo() {
    return this.tech.asObservable();
  }
  shareContractInfo(data: ClientContractsGetDto) {
    this.tech.next(data);
  }
}
