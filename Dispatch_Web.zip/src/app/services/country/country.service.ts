import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Country } from 'src/app/models/country/country';
import { TableFilters } from 'src/app/shared/common/tableFilters';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CountryService {

  constructor(private httpClient: HttpClient) { }

  createCountry(obj: Country): Observable<any> {
    return this.httpClient.post(`${environment.configurationsApiBaseUrl}/countries`, obj);
  }

  updateCountry(obj: Country): Observable<any> {
    return this.httpClient.put(`${environment.configurationsApiBaseUrl}/countries`, obj);
  }

  deleteCountry(id: number | undefined): Observable<any> {
    return this.httpClient.delete(`${environment.configurationsApiBaseUrl}/countries/${id}`)
  }

  getCountryById(id: number): Observable<any> {
    return this.httpClient.get<any>(`${environment.configurationsApiBaseUrl}/countries/${id}`);
  }

  getPagedCountries(payload: TableFilters): Observable<any> {
    return this.httpClient.get<any>(`${environment.configurationsApiBaseUrl}/countries?sort=${payload.sort}&search=${payload.search}&page=${payload.page}&pageSize=${payload.pageSize}&isAscending=${payload.isAscending}`);
  }

  getRegionsDropDown(): Observable<any> {
    return this.httpClient.get<any>(`${environment.configurationsApiBaseUrl}/regions-dropdown`);
  }
}
