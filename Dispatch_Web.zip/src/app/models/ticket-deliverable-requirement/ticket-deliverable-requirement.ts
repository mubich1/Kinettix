export class TicketDeliverablesRequirement {
    id: number;
    ticketId: number;
    pOId: number;
    noOfFiles: number;
    deliverableType: string | null;
    deliverableTypeId: number;
    createdDate: string;
    createdBy: string | null;
    modifiedDate: string;
    deleted: boolean | null;
}