export interface EmailContent {
    toemails: ToEmail[];
    ccemails: CCEmail[];
    subject: string;
    fromemail: string;
    fromemaildisplayname: string;
    body: string;
    isBodyHtml: boolean;
    attacheddocs: EmailAttachment[];
    reassign: boolean;
}


export interface ToEmail {
    emailid: string;
    name: string;
}

export interface CCEmail {
    emailid: string;
    name: string;
}

export interface EmailAttachment {
    contenttype: string;
    filename: string;
    filecontentAsbase64string: string;
}
