import { Deal } from '../deals/deal';
import {
  ContractCategory,
  ContractStatus,
  ContractType,
} from '../project/project';
import { Ticket } from '../tickets/tickets';

export interface ClientContract extends Contract{
  coordinatorId:string | null,
  contractCode:string | null,
  categoryId:number,
  typeId:number,
  pmoleadId:number | null,
  fsoleadId:number | null,
  preVisitTeamId:number | null,
  dayOfVisitTeamId:number | null,
  platform:number | null,
  secondaryClient:number | null,
  onsiteEntity:number | null,
  createdDate:Date,
  modifiedDate:Date,
  createdBy: number | null,
  deal:Deal
  type:ContractType,
  statusNavigation:ContractStatus,
  tickets: Ticket[] | null
  totalTickets: number;
}

export interface Contract extends ContractRequest {
  created: string;
  isDeleted: boolean;
  startDate: string | null;

  modifiedBy: string | null;
  modifiedAt: Date | null;
  totolPrice: number;
  platform: number | null;
  secondaryClient: number | null;
  onsiteEntity: number | null;

  entityToInvoice: number | null;
  accountExecutive: number | null;
  signedDocumentID: number | null;
}

export interface ContractRequest {
  id: number | null;
  clientId: number;
  endClientId: number | null;
  sow: string | null;
  terms: string | null;
  title: string;
  status: ContractStatus;
  dealId: number;
  category: ContractCategory;
  // type: ContractType;
  versionId: number;
  version: number;
  current: boolean;
}

export enum ProposalStageEnum {
  Build = 1,
  Sent = 2,
  Rejected = 3,
  Archived = 4,
  Accepted = 5,
}

export interface ProposalActivities {
  id: number;
  versionID: number;
  activityTitle: string;
  displayTitle: string;
  marginAmount: string;
  totalPrice: string;
}

export interface ContractDocument {
  id: number;
  contractId: number;
  name: string;
  url: string;
  documentType: string;
  created: Date;
}
export interface ContractStageUpdateDetail {
  contractRequest: ContractRequest | null;
}
