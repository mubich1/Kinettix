export interface INewProposalVersion {
  name: string,
  productTypeId: number,
  version: {
    contractId: number,
  },
}
