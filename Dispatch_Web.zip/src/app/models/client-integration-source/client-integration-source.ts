import { BaseDto } from "src/app/shared/common/base-dto";
export interface ClientIntegrationSource extends BaseDto{
    clientName: string;
    clientId: number;
    integrationSourceId: number;
    developmentURL: string;
    liveURL: string;
    qA1URL: string;
    qA2URL: string;
    developmentUsername: string;
    developmentPassword: string;
    qaUsername: string;
    qaPassword: string;
    liveUsername: string;
    livePassword: string;
    qaRequestManagerUsername: string;
    qaRequestManagerPassword: string;
    liveRequestManagerUsername: string;
    liveRequestManagerPassword: string;
    integrationPushPOSTContentType: string;
    integrationSourceName: string;
}

export interface ClientDropdown {
    id: number;
    name: string;
}