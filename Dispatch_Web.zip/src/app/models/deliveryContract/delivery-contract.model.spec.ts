import { DeliveryContract } from './delivery-contract.model';

describe('DeliveryContract', () => {
  it('should create an instance', () => {
    expect(new DeliveryContract()).toBeTruthy();
  });
});
