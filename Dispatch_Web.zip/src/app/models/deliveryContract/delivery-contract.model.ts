import { ActivityCategory } from "../activity/activity-category";
import { ActivityResource } from "../activity/activity-resource";
import { ActivityStatus } from "../activity/activity-status";


export interface GetAllDeliveryContract {
    id: number;
    title: string;
    number: number;
    totalPrice: number;
    totalAssignCost: number;
    assignVendors: string;
    locatioName: string;
    invoiceNumber: string;
    clientPo: string;
    endClientName: string | null;
    locationName: string | null;
    locationAddress: string | null;
    createdDate: string;
    tools: string | null;
    deliverableComments: string | null;
    billingInstructions: string | null;
    arrivalInstructions: string | null;
    referenceType: string | null;
    referenceId: number | null;
    assignVednor: string;
    ticketStatus:string;
    ticketLabel:string;
}

export interface ContractTicketRequest {
    id: number;
    clientId: number;
    endClientId?: number | undefined;
    clientSiteId?: number| undefined;
    projectManagerId: string;
    contractId: number;
    accountExecutiveId: string;
    coordinatorId: string;
    title: string;
    tools: string;
    deliverableComments: string;
    billingInstructions: string;
    arrivalInstructions: string;
    referenceType: string;
    referenceId: number;
    categoryId: number;
    contractTickets: TicketActivity[];
    contractTicketSchedule: ContractTicketSchedule | null;
}

export interface TicketActivity {
    id: number | null,
    versionId: number | null,
    TicketId: number,
    name: string,
    displayName: string | null,
    quantity: number,
    categoryId: number |null,
    statusId: number,
    billable: boolean,
    scope: string | null,
    assumptions: string | null,
    currencyId: number | null,
    currentDollarValue: number | null,
    platformFeePercent: number,
    riskPercent: number,
    financeFeePercent: number;
    roundingAmount: number;
    parentActivityId: number | null,
    category: ActivityCategory | null,
    status: ActivityStatus |null,
     resourcesses: ActivityResource[] | null ,
     totalLaborCost: number | 0;
     totalMaterialBudget: number| 0;
     totalTavelCost:number |0;
}

export interface ContractTicketSchedule {
    id: number;
    ticketId: number;
    scheduleArival: Date;
    scheduleEnd: Date;
    isDefault: boolean;
    createdBy? : string;
    modifiedBy? : string;
}

export interface TicketFinancialsDto {
    authorizeDto: AuthorizeDto;
    budgetDto: BudgetDto;
    deltaDto: DeltaDto;
}

export interface DeltaDto {
    grossProfitDiffInAmount: number | null;
    grossMarginDiffInPercent: number | null;
    netIncomeDiffInAmount: number | null;
    netMarginDiffInPercent: number | null;
}

export interface BudgetDto {
    totalBudgetPrice: number | null;
    totalVariableBudget: number | null;
    totalRiskBudget: number | null;
    budgetCOGS: number | null;
    budgetGrossProfit: number | null;
    variableMarginPercent: number | null;
    totalLoadedBudget: number | null;
    totalFixedBudget: number | null;
    totalBudgetExpenses: number | null;
    budgetIncome: number | null;
    budgetNetMarginPercent: number | null;
}

export interface AuthorizeDto {
    totalTicketPrice: number | null;
    totalAuthCost: number | null;
    totalAuthRisk: number | null;
    totalUnallocatedCost: number | null;
    cogs: number | null;
    grossProfit: number | null;
    authMarginPercent: number | null;
    totalLoadedCost: number | null;
    totalFixedCost: number | null;
    totalExpenses: number | null;
    riskPool: number | null;
    income: number | null;
    netMarginPercent: number | null;
    netIncome: number | null;
}



