export interface activitycatagores {
  id: any,
  name: string
}

export interface ActivityCatagoryRequest {
  id: any,
  name: string,
  createdBy?: number,
  modifiedBy?: number
}
