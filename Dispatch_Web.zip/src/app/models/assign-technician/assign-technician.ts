export interface AssignTechnician {
    poId: number,
    vendorId: number,
    techId: number
}


export interface RecommendedTechnician {
  id: number;
  name: string;
  technicianEmail?:string;
  weightedScore: number;
  distance: number;
  nearestJob?:number;
  vendorId?: number;
  technicianId?:number;
  technicianName?: string;
  poNotes?:string;
  poLastCallDate: string | Date;
  vendorName?: string;
  rating?:number;
  businessPhone?: string;
  techRecentJobDate?: string | Date | undefined;
  totalJobCount?: number;
  clientJobCount?:number;
  negotiatedCost?: number;
  poAverage?: number;
}
export class TechnicianTableFilters {
  radius: number = 50;
  search?: string = '';
}

export const RadiusMiles = [
  { key: '25 Miles', value: 25 },
  { key: '50 Miles', value: 50 },
  { key: '75 Miles', value: 75 },
  { key: '100 Miles', value: 100 }
]
