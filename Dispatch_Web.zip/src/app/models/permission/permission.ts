import { InformationSquareFilledDirective } from "@carbon/icons-angular";

export interface Permission {
    category:     string;
    id:           number;
    name:         string;
    scope:        string;
    section:      string;
    isActive:     boolean;
    deleted:      boolean;
    createdDate:  Date;
    modifiedDate: Date;
    createdBy:    string;
    modifiedBy:   string;
    isAdd:        boolean;
}

export interface PermissionGroup {
    section:      string;
    categories:   string[];
    permissions:  Permission[];
    isAllView:    boolean;
    isAllAdd:     boolean;
    isAllEdit:    boolean;
    isAllDelete:  boolean;
    isAll:        boolean;
}

export interface PermissionPayload {
    id:     number, 
    isAdd:  boolean
}

export enum PermissionScope {
    Add =    "Add", 
    Delete = "Delete",
    Edit =   "Edit",
    View =   "View"
}

export enum PermissionSection {
    AgreementTemplate   = "Agreement Template",
    Client              = "Client",
    Contract            = "Contract",
    Deal                = "Deal",
    Delivery            = "Delivery",
    GlobalTerms         = "Global Terms",
    PurchaseOrder       = "PurchaseOrder",
    Settings            = "Settings",
    Team                = "Team",
    Vendor              = "Vendor"
}