export class UserNote{
    id? : Number;
    userId? : String;
    clientId? : Number;
    vendorId? :Number;
    noteTitle? : String = '';
    noteBody? : String = '';
    createdBy? : String = '';
    createdDate? : Date;
    modifiedBy? : String = '';
    modifiedDate? : Date;
    deleted? : Boolean = false;
}