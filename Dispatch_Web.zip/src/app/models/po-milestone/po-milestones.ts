export class PoTaskDto {
  taskId: number;
  poId: number;
  taskName: string;
  statusName: string;
  poMilestones: GetPoTaskMilestoneDto[];
  isExpand: boolean = false;
}

export class GetPoTaskMilestoneDto {
  id: number;
  poId: number;
  milestoneID: number;
  milestoneName: string;
  taskId: number;
  taskName: string;
  mileStoneDate: Date;
  completedBy: string;
  completedDate: Date;
  actualDate: Date;
  createdBy: string;
  createdDate: Date;
  modifiedBy: string;
  modifiedDate: Date;
  assignTo: string;
  assignName: string;
  assignDate: Date;
  failReason: string;
  failDate: Date;
  milestoneOrder: number;
  milestonePriority: string;

}
export class SavePoTaskAssignUserDto {
  poId?: number;
  taskId?: number;
  milestoneId?: number;
  assignTo?: string;
  ticketId?: number;
  ticketTaskId?: number
  statusId?: number
  ticketMilestoneId?: number;
}
export class SavePoMilestoneFailDto {
  poId?: number;
  taskId: number;
  milestoneId: number;
  failDate: Date | null;
  failReason: string;
  ticketId?: number
  ticketTaskId?: number
  statusId?: number
  ticketMilestoneId?: number;
  milestoneIndex?: number;
}
export class SavePoMilestoneCompleteDto {
  poId?: number;
  taskId: number;
  milestoneId: number;
  completedDate: Date | null;
  ticketId?: number
  ticketTaskId?: number
  statusId?: number
  ticketMilestoneId?: number;
  milestoneIndex?: number;

}
export enum TaskStatusEnum {
  Completed = 'Completed',
  Failed = 'Failed',
  Active = 'Active',
  Pending = 'Pending'
}

export enum TaskStatusIdEnum {
  Active = 1,
  Failed = 2,
  Completed = 3,
  Pending = 4
}

export enum MilestoneStatusEnum {
  Completed = 'Completed',
  InWork = 'In-Work ',
  Pending = 'Pending'
}

export enum MilestoneStatusIdEnum {
  Staged = 1,
  InWork = 2,
  WrapUp = 3,
  Complete = 4
}

export enum POStatus {
  Draft = "Draft",
  InWork = "InWork",
  WrapUp = "WrapUp",
  Complete = "Complete",
  Closed = "Closed",
  Sent = "Sent"
}

