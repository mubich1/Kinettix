export interface Breadcrumb {
    url:string
}