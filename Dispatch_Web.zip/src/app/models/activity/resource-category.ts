export interface ResourceCategory {
    id: number;
    name: string | null;
}