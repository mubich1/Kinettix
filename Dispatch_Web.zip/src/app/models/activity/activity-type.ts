
export interface ActivityType {
    id: number,    
    type: string, 
  }


  export enum ActivityTypeEnum {
    Fixed = "Fixed",
    Hourly = "Hourly", 
  }