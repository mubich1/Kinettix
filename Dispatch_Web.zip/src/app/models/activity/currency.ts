import { BaseDto } from "src/app/shared/common/base-dto";

export interface Currency extends BaseDto {
  name: string,
  currencySign: string | null,
  dollarValue: string,
}