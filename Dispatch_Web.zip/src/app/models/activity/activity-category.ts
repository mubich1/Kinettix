export interface ActivityCategory {
    id: number,    
    name: string | null,    
  }