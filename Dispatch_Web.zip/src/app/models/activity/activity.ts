import { MilestoneDTO } from "../milestoneDTO/milestoneDTO";
import { Competency } from "../vendor/vendor";
import { ActivityCategory } from "./activity-category";
import { ActivityResource } from "./activity-resource";
import { ActivityStatus } from "./activity-status";

export interface Activity {
    id: number | null,
    versionId: number | null,
    contractId: number,
    activityId?: number | null,
    name: string,
    categoryId?: number | null,
    displayName: string | null,
    quantity: number,
    instances?: number,
    typeId: number,
    statusId: number,
    scope: string | null,
    type?: ActivityType | null,
    assumptions: string | null,
    currencyId: number | null,
    totalVariableCost: number | null;
    totalFixedCost: number | null;
    budgetMargin: number | null;
    cogs: number | null;
    grossProfit: number | null;
    variableMarginPercent: number | null;
    totalBudgetExpenses: number | null;
    budgetIncome: number | null;
    budgetNetMarginPercent: number | null;
    authorizedCost: number | null;
    targetCost: number | null;
    platformFeePercent: number;
    riskPercent: number;
    financeFeePercent: number;
    currentDollarValue: number | null,
    roundingAmount: number;
    parentActivityId: number | null,
    status: ActivityStatus | null,
    resources: ActivityResource[],
    activityResources?:ActivityResource[] | null,
    activityCompetencies: Competency[],
    activityMilestones: MilestoneDTO[],
    totalLaborCost: number | 0;
    totalMaterialBudget: number | 0;
    totalTavelCost: number | 0;
    isUsed: boolean | false;
    isBillAble: number | 0;
    isNonBillAble: number | 0;
    numberofTimeUsed: number | 0;
    budget: number | 0;
    riskFee: number | 0;
    price: number | 0;
    regionId: number | null,
    responseIntervalId: number | null;
    technicianLevelId: number | null;
    region?: string | null,
    responseInterval?: ResponseInterval | null,
    technicianLevel?: string | null,
    currency?: string | null,
    totalRevenue: number | null,
    category?: ActivityCategory | null,
    activityTypeName? : string | null,
    categoryName? : string | null,
    technicianLevelName? : string | null,
    responseIntervalName? : string | null,
    regionName? : string | null,
    currencyName? : string | null,
    parentActivity? : Activity | null,
    isContractActivity? : boolean
}

export interface ActivityExtended extends Activity{
    deactivated : boolean | false
}

export interface ResponseInterval {
  id: number,
  name: string,
  maximumResponseTime: number,
}

export interface TechnicianLevel {
    id: number,
    name: string,
    deleted : Boolean
}

export interface ActivityType {
  id: number,
  type: string,
}
