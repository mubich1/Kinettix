export interface ActivityStatus {
    id: number,    
    name: string | null,    
  }