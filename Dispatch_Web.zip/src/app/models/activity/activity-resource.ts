import { ResourceCategory } from './resource-category';

export interface ActivityResource {
  id: number | null;
  contractActivityId: number;
  resourceId: number;
  quantity: number;
  unitCost: number;
  uplift: number;
  upliftedCost: number | null;
  directCost: number | null;
  marginPercent: number;
  margin: number | null;
  platformFee: number;
  riskFee: number;
  financeFee: number;
  totalCost: number | null;
  isDeleted: boolean;
  materialType: string | null;
  techPercent: number | null;
  price: number | null;
  roundedPrice: number | null;
  category: ResourceCategory;
  categoryId:number | null;

 
}
export interface Resource {
  id: number;
  contractActivityId: number;
  resourceId: number;
  categoryId: number;
  quantity: number;
  unitCost: number;
  directCost: number | null;
  marginPercent: number;
  margin: number | null;
  platformFee: number;
  riskFee: number;
  financeFee: number;
  totalCost: number | null;
  materialType: string | null;
  price: number | null;
  rouncedPrice: number | null;
  createdBy: number | null;
  modifiedBy: number | null;
}
