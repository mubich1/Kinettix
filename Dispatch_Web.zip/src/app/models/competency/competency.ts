export interface Competency extends CompetencyRequest {
  createdAt: Date | null,
  deletedAt: Date | null,
  type: CompetencyType | null,
}

export interface CompetencyRequest {
  id: number | null,
  categoryId: number | null,
  typeId: number | null,
  name: string,
  description: string,
}

export interface CompetencyType {
  id: number,
  name: string,
  created: Date | null,
  modified: Date | null,
  isExpirable: boolean,
}
