import { Injectable } from "@angular/core";
import * as numeral from "numeral";

@Injectable()
export class KinettixMath {


    DirectCost(cost, qty) {
        return this.RoundNumber((parseFloat(cost) * parseFloat(qty)), 2);
    }

    RoundNumber(num, scale) {
        var parsed = parseFloat(numeral(num).format('0[.]00'));
        return parsed.toFixed(scale);
    }

    PlatformFee(directCost, platformFeeInPerc) {
        return this.RoundNumber((parseFloat(directCost) * (parseFloat(platformFeeInPerc) / 100)), 2);
    }

    RiskFee(directCost, platformFee, riskFeeInPerc) {
       return this.RoundNumber(((parseFloat(directCost) + parseFloat(platformFee)) * (parseFloat(riskFeeInPerc) / 100)), 2);
    }
    DirectCostForProjectManagement(techRate, totalLaborQty, cost) {
        var calculatePercentage = parseFloat(techRate) / 100;
        return this.RoundNumber((parseFloat(calculatePercentage.toString()) * parseFloat(totalLaborQty) * parseFloat(cost)), 2);
    }
    MarginAmount(directCost,financeFee, platformFee, riskFee, resourceMargin) {
        var sumOfFee = parseFloat(directCost) + parseFloat(platformFee) + parseFloat(riskFee) +  parseFloat(financeFee);
        var remainingPercentForFinanceFee = 1 - (parseFloat(resourceMargin) / 100);
        var result = (parseFloat(sumOfFee.toString()) / parseFloat(remainingPercentForFinanceFee.toString())) - parseFloat(sumOfFee.toString());
        return this.RoundNumber(result, 2);
    }
    FinanceFee( directCost, platformFee, riskFee, ActivityFinanceFee) {
        return this.RoundNumber(((parseFloat(directCost) + parseFloat(platformFee) + parseFloat(riskFee) ) * (parseFloat(ActivityFinanceFee) / 100)), 2);
    }

    TotalCost( platformFee, riskFee, financeFee, quantity,budget) {
      let totalCost
      if(quantity > 0){
        let fees =  this.RoundNumber(((parseFloat(platformFee) + parseFloat(riskFee) + parseFloat(financeFee))), 2);
        totalCost = ((parseFloat(budget) * parseFloat(quantity))) + parseFloat(fees);
      }
      return this.RoundNumber(totalCost,2) ?? 0.00;
    }

    TotalPrice(totalCost, marginAmount) {
        return this.RoundNumber((parseFloat(totalCost) + parseFloat(marginAmount)), 2);
    }
    MarginPercentage(totalCost, totalPrice) {
        var totalClientPrice = parseFloat(totalPrice);
        return totalClientPrice > 0 ? (((parseFloat(totalPrice) - parseFloat(totalCost)) / totalClientPrice) * 100).toFixed(2) : "0.0";
    }
    ToFixed(num, scale) {
        return parseFloat(num).toFixed(scale);
    }
    TotalPriceHavingZeroCost(Qty, Price) {
        return this.RoundNumber(parseFloat(numeral(Qty).format('0[.]00')) * parseFloat(numeral(Price).format('0[.]00')), 2);
    }


    price(marign, cost) {
        let marginvalue = (100 - marign) / 100;
        var price = cost / marginvalue
        return this.RoundNumber(price, 2);
    }

    CalculateBudgetMargin(roundingAmount,totalVariableCost,riskPercent){
        let totalBudgetExpenses=totalVariableCost+riskPercent;
        let amount=(roundingAmount-totalBudgetExpenses)*100;
        let budgetMargin=amount/roundingAmount;
        return this.RoundNumber(budgetMargin, 2);

    }

    CalculateMarginPercentage(targetCost,price){
        let totalPrice=(price-targetCost)/price;
        let totalTargetMargin=100*totalPrice;
          return this.RoundNumber(totalTargetMargin, 2);

    }

}
