import { BaseDto } from "src/app/shared/common/base-dto";

export interface Region extends BaseDto {
    name: string;
    description: string;
}