export interface Ticket {
  id: number;
  title: string;
  number: string;
  deliverableComments: string | null,
  tools: string | null,
  createdDate: Date | string;
  BillingInstructions: string | null;
  referenceId: number | null,
  clientId: number,
  contractId: number,
  endClientId: number,
  clientSiteId: number | null,
  referenceType: string,
  arrivalInstructions: string,
  createdBy: number | null,
  modifiedBy: number | null,
  modifiedDate: Date | null,
  contractTickets: ContractTicketsActivities[];
  siteInfo: TicketSiteInfo;
  contractTicketSchedule?: ContractTicketSchedule;
  ticketStatus: string;
}

export interface TicketSiteInfo {
  id: number;
  clientId: number;
  address: string;
  city: string | null;
  name: string;
  phone: string | null;
  postalCode: string | null;
  siteNumber: string | null;
  state: string | null;
  timeZone: string | null;
  latitude: string;
  longitude: string;
  country: string;
}

export interface ContractTicketSchedule {
  id: number;
  ticketId: number | null;
  scheduleArival: string | null;
  scheduleEnd: string | null;
  isDefault: boolean | null;
}

export interface TicketNotes {
  id: number;
  ticketId?: number;
  name: string;
  description: string;
  internalOnly?: boolean;
  createdBy?: string;
  modifiedBy?: string;
  createdDate?: Date;
  modifiedDate?: Date;
}
export interface TicketDocuments {
  id: number;
  ticketId: number;
  name: string;
  documentType: number;
  url: string;
  description: string;
  expiration: Date | null;
  clientFacing: boolean;
  techFacing: boolean;
  createdDate?: Date;
  modifiedDate?: Date;
  createdBy?: string;
  modifiedBy?: string;
  isInternal?: Boolean | true;
}



export interface ContractTicketsActivities {
  id: number;
  versionId: number | null;
  authorizedCost: number | null,
  ticketId: number;
  name: string;
  displayName: string | null;
  quantity: number;
  categoryId: number | null;
  statusId: number;
  billable: boolean | null;
  scope: string | null;
  assumptions: string | null;
  currencyId: number | null;
  currentDollarValue: number | null;
  platformFeePercent: number;
  riskPercent: number;
  financeFeePercent: number;
  roundingAmount: number;
  budgetMargin: number | null;
  isDeleted: boolean;
  createdDate: string;
  createdBy: string | null;
  mofidiedDate: string;
  modifiedBy: number | null;
  parentActivityId: number | null;
  targetCost: number | null;
  cOGS: number | null;
  grossProfit: number | null;
  variableMarginPercent: number | null;
  totalBudgetExpenses: number | null;
  budgetIncome: number | null;
  budgetNetMarginPercent: number | null;
  price: number | null;
  totalPrice?: number;
  totalVariableCost: number | null;
  totalFixedCost: number | null;
  poId: number | null;
  totalVariableCostCalculatedWithQuantity: number | null;
  ticketActivityResources: TicketActivityResourcesDto[];
  unionMultiplier: number;
  afterHoursMultiplier: number;
  activityTotalPrice: number;
}

export interface TicketActivityResourcesDto {
  id: number;
  ticketActivityId: number | null;
  resourceId: number;
  categoryId: number | null;
  categoryName: string;
  quantity: number;
  unitCost: number;
  uplift: number;
  upliftedCost: number | null;
  directCost: number | null;
  marginPercent: number;
  margin: number | null;
  platformFee: number;
  riskFee: number;
  financeFee: number;
  totalCost: number | null;
  afterHours: boolean;
  isDeleted: boolean;
  materialType: string | null;
  techPercent: number | null;
  price: number | null;
  roundedPrice: number | null;
  currencyId: number | null;
  createdDate: string;
  modifiedDate: string;
  createdBy: string | null;
  modifiedBy: string | null;
  resource: Resource;
  poExtendedCost: number | null;
  poAuthorizedQuantity: number | null;
  poAuthorizedCost: number | null;
  poId: number | null;
  poStatus: string | null;
  poVendorName: string | null;
  poTechName: string | null;
  poScheduleDate: Date | null;
  scheduleTime: Date | null;
}

export interface TicketScheduleInput {
  id: number;
  scheduleArival: string;
  scheduleEnd: string;
}

export interface Resource {
  id: number;
  displayName: string;
  name: string;
}
export interface UpdateTicketSite {
  endClientId: number;
  ticketId: number;
  siteId: number;
}

export interface GetTicketLabel {
  id: number;
  labelId: number;
  ticketId: number;
  note: string | null;
  label: any;
}

export interface TicketLabel {
  id: number;
  labelId: number;
  ticketId: number;
  note: string | null;
}
export interface TicketFinancialsDto {
  authorizeDto: AuthorizeDto;
  budgetDto: BudgetDto;
  deltaDto: DeltaDto;
}

export interface DeltaDto {
  grossProfitDiffInAmount: number | null;
  grossMarginDiffInPercent: number | null;
  netIncomeDiffInAmount: number | null;
  netMarginDiffInPercent: number | null;
}

export interface BudgetDto {
  totalBudgetPrice: number | null;
  totalVariableBudget: number | null;
  totalRiskBudget: number | null;
  budgetCOGS: number | null;
  budgetGrossProfit: number | null;
  variableMarginPercent: number | null;
  totalLoadedBudget: number | null;
  totalFixedBudget: number | null;
  totalBudgetExpenses: number | null;
  budgetIncome: number | null;
  budgetNetMarginPercent: number | null;
}

export interface AuthorizeDto {
  totalTicketPrice: number | null;
  totalAuthCost: number | null;
  totalAuthRisk: number | null;
  totalUnallocatedCost: number | null;
  cogs: number | null;
  grossProfit: number | null;
  authMarginPercent: number | null;
  totalLoadedCost: number | null;
  totalFixedCost: number | null;
  totalExpenses: number | null;
  riskPool: number | null;
  income: number | null;
  netMarginPercent: number | null;
  netIncome: number | null;
}

export interface TicketReview {
  id: number;
  ticketId: number;
  reviewerId?: string;
  reviewDate: Date | null;
  status?: string;
  comments?: string;
  overall?: string;
  quality?: string;
  professionalism?: string;
  communication?: string;
  rating?: number;
  userId?: string;
  vendorId: number | null;
  createdDate?: Date;
  modifiedDate?: Date;
  createdBy?: string;
  modifiedBy?: string;
  deleted?: boolean;
}

export interface TicketAddReview {
  id: number;
}

export interface TicketVendors {
  ticketID: number;
  contractID: number;
  vendorID: number;
  vendorName: string;
}

export interface ReviewResponsePayload {
  data: TicketReview[];
  ticketVendors: TicketVendors[];
}
export interface RequestTicketTile {
  title: string;
  ticketId: number;
  contractId: number;
}
export enum TicketTaskStatus {
  Staged = 1,
  InWork = 2,
  WrapUp = 3
}

export enum TicketStatus {
  Draft = "Draft",
  InWork = "In-Work",
  WrapUp = "Wrap-Up",
  Complete = "Complete"
}

export enum EPaymentType {
  TimeAndMaterials = 'Time & Materials',
  FixedPrice = 'Fixed Price'
}

export enum EPoStatus {
  Draft = 1,
  In_Work = 2,
  Complete = 3,
  Closed = 4,
}
export interface RequestTicketClient {
  secondaryClientId: number;
  endClientId: number;
  ticketId: number;
  contractId: number;
}

export enum ShowTicketStatus {
  Draft = "Staged",
  InWork = "In Work",
  WrapUp = "Wrap Up",
  Complete = "Complete"
}

export const UnionMultipliers = [
  { key: "1.0 (No Uplift / Not Union)", value: 1.0 },
  { key: "2.0 (Union)", value: 2 },
]
export const AfterHoursMultipliers = [
  { key: "1.0 (No Uplift / RBH)", value: 1.0 },
  { key: "1.5 (After Hours / Saturday)", value: 1.5 },
  { key: "2.0 (Sunday / Holiday)", value: 2.0 }
]
