export interface CustomParams  {
    id:number;
    pageNumber:number;
    name: string;
    orderby: string;
    sort: string;
}
