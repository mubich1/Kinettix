export interface Contact {
    id: number;
    employeeId: number | null;
    businessPhone: string | null;
    email: string | null;
    address: string | null;
    firstName: string | null;
    lastName: string | null;
    mobileNumber: string | null;
    fullName: string | null;
    contactTypeId: number | null;
    hubSpotContactId: string | null;
}