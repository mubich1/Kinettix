export interface UserAccountInfo {
  UserId: string;
}
export class ProfileType {
  givenName?: string = '';
  surname?: string = '';
  userPrincipalName?: string = '';
  displayName?: string = '';
  id?: string = '';
  businessPhones?: string = '';
  jobTitle?: string = '';
  mail?: string = '';
  mobilePhone?: string = '';
  officeLocation?: string = '';
  preferredLanguage?: string = '';
  password?: string = '';
  applicationTypes?: {id: number, name: string}[] | null;
  active?: boolean = false;
}

export enum ApplicationType {
  DISPATCH_3 = 'Dispatch 3.0',
  VENDOR_PORTAL = 'Vendor Portal',
  CLIENT_PORTAL = 'Client Portal',
  SALES_PORTAL = 'Sales Portal'
}
export enum ApplicationTypeId {
  DISPATCH_Id = 1,
  VENDOR_PORTAL_Id = 2,
  CLIENT_PORTAL_Id = 3,
  SALES_PORTAL_Id = 4
}
