export interface MilestoneDTO {
    id: number | null
    name: string | null
    isRequiredToWorkflow: boolean | null
    isActive: boolean | null
    createdDate: Date | null
    modifiedDate: Date | null
    isDefaultMilestone: boolean | null
    taskLevel: string | null
    productType: number | null
    escalationDays: number | null
    priority: string | null
    defaultForStatus: number | null
    isSystemMilestone: boolean | null
    isInternal?: boolean | null
}

export interface DefaultMilestoneInput {
    isFromDefaultMilestone: boolean
    taskLevel: string
    productType: number

}

export enum MilestoneStatus {
    Staged = 1,
    Wrapup = 3,
    Complete = 4,
    InWork = 2

}