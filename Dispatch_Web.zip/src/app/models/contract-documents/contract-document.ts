export interface contractDocuments {
  id: number;
  contractId: number;
  name: string;
  documentType: number;
  url: string;
  expiration: Date | null;
  createdDate?: Date;
  modifiedDate?: Date;
  createdBy?: string;
  modifiedBy?: string;
  isInternal? : Boolean | true;
}
export interface ContractDocumentsType {
  id: number;
  name: string;
}
