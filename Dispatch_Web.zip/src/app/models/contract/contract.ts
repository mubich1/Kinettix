import { Employee } from "../employee/employee";
import { Team } from "../team/team";

export interface Contracts {
    id: number,
    clientId?: number,
    endClientId?: number,
    coordinatorId?: string,
    pmoleadId?: string,
    pmoleadName?: string,
    backupPmoleadId?: string,
    backupPmoleadName?: string,
    accMgrId?: string,
    accMgrName?: string,
    accExecutiveId?: string,
    accExecutiveName?: string,
    fsoleadId?: string,
    fsoleadName?: string,
    preVisitTeamId?: number,
    preVisitTeamName?: string,
    dayOfVisitTeamId?: number,
    dayOfVisitTeamName?: string,
    modifiedBy?: string,
    title?: string;
    startDate?: Date | null;
    endDate?: Date | null;
    onsiteEntity?: number;
    secondaryClient?: number;
    platform?: number;
    onSiteEntityName?: string;
    secondryClientName?: string;
    platFromClientName?: string;
    overView?: string;
    productType?: string;
    productTypeValue?: string;
    statusName?: string;
    primaryClient?: string;
    dealId?: string;
    numberOfPilotSites?: number;
    totalNumberOfSites?: number;
    engagementInstructions?: string;
    riskActualization?: number;
    updateType?: string;
    minimumLaborHours?: number;
    minimumTravelHours?: number;
    productTypeId?:number;
}

export enum ContractMilestoneStatus {
    Staged = 2,
    InWork = 3,
    WrapUp = 4,
    Complete = 5
}
export enum ContractTasksStatusIdEnum {
    Active = 1,
    Completed = 3,
    Pending = 4,
    Failed = 5
}

export enum ContractStatus {
    Staged = "Staged",
    In_Work = "In Work",
    Wrap_up = "Wrap Up",
    Completed = "Complete",
    Closed = "Closed",
    Proposal = "Proposal"
}


export enum RiskActualization {
    Monthly = 1,
    Cumulative = 2,
}
