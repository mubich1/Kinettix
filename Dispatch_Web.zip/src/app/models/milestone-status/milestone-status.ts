export interface MilestoneStatus {
    id: number | null;
    name: string | null;
    isActive: boolean | null;
    createdDate: Date | null;
    modifiedDate: Date | null;
}