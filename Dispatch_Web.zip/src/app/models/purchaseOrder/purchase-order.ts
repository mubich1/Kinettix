import { constants } from "buffer";
import { BaseDto } from "src/app/shared/common/base-dto";
import { Platform } from "../platform/platform";
import { ContractTicketsActivities } from "../tickets/tickets";
export interface PurchaseOrder extends BaseDto {
    ticketId: number;
    poNumber?: string;
    wonumber?: string;
    vendorId?: number;
    techId?: number;
    onSiteDateTime?: Date;
    statusId: number;
    scheduleDate?: Date;
    specialInstructions: string;
    totalAuthLabor: number | null;
    totalAuthTravel: number | null;
    totalAuthMaterial: number | null;
    totalAuthFreight: number | null;
    totalBudget: number | null;
    totalCost: number | null;
    totalAuthPayment: number | null;
    assignmentId?: number | null;
}

export interface POScope {
    ticketScheduleId: number;
    scope?: string;
    activityCompetencyIds?: ActivityCompetency[];
    specialInstructions?: string;
    competencies?: ActivityCompetency[];
}

export interface ActivityCompetency {
    id?: number;
    name?: string;
    group?: string;
    activityCompetencyId?: number;
}
export interface PurchaseOrderPlatform {
    pOId: number;
    platforms: Platform[] | null;
}


export interface POActivityResource {
    contractTicketsActivitiesDto: ContractTicketsActivities[];
    POResourceDto: POResource[];
}

export interface POResource {
    id: number;
    name: string | null;
    createdDate: Date;
    modifiedDate: Date;
    createdBy: string | null;
    modifiedBy: string | null;
    deleted: boolean;
    poid: number;
    ticketActivityResourceId: number;
    ticketActivityId: number;
}

export enum TicketActivityResourceDetail {
    labor = 'Labor',
    materials = 'Materials',
    freight = 'Freight',
    travel = 'Travel',
    Internallabor = 'Internal Labor',
    Externallabor = 'External Labor',
}
export interface SendPOModalData {
    header: string;
    question: string;
    confirmationButtoText: string;
    cancelButtonText: string;
    downloadOption: string;
    data: any | null;
    confirm: boolean;
    obs: any;
    isClosed: boolean;
    selectedOption: string,
    downloadType: string,
    emailMessage: string | null,
    recipientEmailList: string[] | null,
    ccEmailList: string[] | null,
    subject: string,
}


export enum SendPOOptionsEnum {
    Download = 1,
    Email = 2,
}
export enum DownloadPOOptionsEnum {
    PurchaseOrder = 1,
    WorkOrder = 2,
    Both = 3,
}
export enum POWOSTatusDropdown {
    Send = 1,
    Reissue = 2,
    Reassign = 3,
    Complete = 4,
    History = 5
}
export enum PoExceptionStatus {
    Approve = 1,
    Decline = 2
}
export interface POScope {
    scope?: string;
    activityCompetencyIds?: ActivityCompetency[];
    specialInstructions?: string;
}

export interface ActivityCompetency {
    id?: number;
    text?: string;
}

export class PoTicketActivityDto {
    poId: number;
    totalAuthLabor: number = 0;
    totalAuthTravel: number = 0;
    totalAuthMaterial: number = 0;
    totalAuthFreight: number = 0;
    targetCost: number = 0;
    totalBudget: number = 0;
    totalAuthPayment: number = 0;
    paymentType: string = 'Time & Materials';
    specialConditions: string = "";
    oosLaborRate: number = 0;
    poExceptionStatusId: number = 0;
    totalTicketRisk: number = 0;
    unAllocatedCost: number = 0;
    totalCost: number = 0;
    poTicketActivities: PoTicketActivitiesDto[] = [];
}

export class PoTicketActivitiesDto {
    isExpand?: boolean = false
    ticketActivityId?: number = 0;
    name?: string = "";
    budget?: number = 0;
    targetCost?: number = 0;
    authorizedCost?: number = 0;
    riskPercent?: number = 0;
    selected?: boolean = false;
    ticketRisk?: number = 0;
    ticketActivityResources?: TicketActivityResourceDto[] = [];
    actualBudget?: number = 0;
    showActivityCheckbox: boolean = true;
}

export class TicketActivityResourceDto {
    ticketActivityResourceId: number = 0;
    ticketActivityId: number;
    poResourceId?: number;
    quantity?: number = 0;
    budget?: number = 0;
    type?: string = "";
    name?: string = "";
    authorizedCost?: number = 0;
    selected?: boolean = false;
    extendedCost?: number = 0;
    riskFee?: number = 0;
    unAllocatedCost?: number = 0;
    isEnable?: boolean;
}

export enum PriceType{
    PerHour='per_hour'
}

export enum PoStatus {
    Draft = 'Draft',
    InWork = 'In_Work',
    Complete = 'Complete',
    Closed = 'Closed',
    Sent = 'Sent'
}

export enum PriceMode{
    Spend='spend'
}
