export interface clientworkorders{
    title:string,
    number:number | null,
    endClientId:number |null,
    createdBy:number | null,
    createdDate:Date | null,
    modifiedBy:number | null,
    modifiedDate:Date | null,
    tools:string |null,
    deliverableComments:string|null,
    billingInstructions:string|null,
    arrivalInstructions:string|null,
    
}