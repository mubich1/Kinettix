export interface Platform {
    id: number,
    name: string
}