export interface ContractVersion{
    id: number;
    version:number;
    contractId:number | null;
    current:boolean | null;
  }