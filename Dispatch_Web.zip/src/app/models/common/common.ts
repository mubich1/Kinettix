export interface Filters {
  pageNumber?: number;
  name?: string;
  city?: string;
  state?: string;
  country?: string;
  orderBy?: string;
  sort?: string;
  isShowArchivedVendor?: boolean;
}

export interface SubHeading {
  name: string;
  URL: string;
}

export interface DynmaicList {
  name: string;
  iconName: string;
  subHeading: SubHeading[];
}

export interface SettingUrls {
  dynmaicList: DynmaicList[];
}

export interface Dropdown {
  text: string;
  value: any;
}
export class AllowdDocTypes {
  static extensions = [".pdf", ".doc", ".docx", ".xls", ".xlsx", ".jpg", ".png", ".gif"];
}
