export interface Notes {
    id: number;
    name: string;
    description: string;
    clientName?: string;
    clientId?: number;
    vendorName?: string;
    vendorId?: number;
    TechnicianId?: number;
    TechnicianName?: string;
    createdDate: Date;
    createdBy: number;
    modifiedDate: Date | null;
}

export interface NotesRequest {
    id: number | undefined,
    clientId?: number | undefined,
    vendorId?: number | undefined,
    techId?: number | undefined,
    name: string,
    description: string,
    createdBy?: number | undefined,
}