export enum GeoLocation {
    minLatitude = -90,
    maxLatitude = 90,
    minLongitude = -15069,
    maxLongitude = 15069
}
