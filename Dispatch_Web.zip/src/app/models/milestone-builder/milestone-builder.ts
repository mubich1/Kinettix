import { TaskGroup } from "../milestone-group/milestone-group"
import { TaskDTO } from "../taskDTO/taskDTO"
import { MilestoneDTO } from "../milestoneDTO/milestoneDTO"

export interface MilestoneBuilder extends MilestoneDTO {
    tasks: TaskWorkflowBuilder[]
}

export interface MilestoneGroupWorkflowBuilder extends TaskGroup {
    order: number | null
    tasks: TaskWorkflowBuilder[]
}

export interface TaskWorkflowBuilder extends TaskDTO {    
    order: number | null
    isRequired: boolean | null
    isAllowDateEntry: boolean | false
    isAllowTimeEntry: boolean | false
    priority: string | null
    allowVendorCompletion: boolean | false
}