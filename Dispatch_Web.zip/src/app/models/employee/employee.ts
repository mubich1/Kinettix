export interface Employee{
    id: number;
    name:string;
    email:string;
    profileImage:string;
    hubSpotContactId:string;
    employeePermissions:any;
    employeeRoles:any;
  }