export interface DealDocumentRequest {
    id: number;
    dealId: number;
    dealDocumentTypeId?: number;
    name: string | null;
    url: string | null;
    doctype:string
}