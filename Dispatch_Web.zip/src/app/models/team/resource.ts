export interface Employee {
    
    id:number ;
    name:string;
    profileImage:string;
    role:string;
    email:string;
}
