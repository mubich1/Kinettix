
export class Team {
    constructor(
      public  id:number ,
      public name:string,
      public description:string,
      public teamMembers:TeamMember[],
     
     ) {}
   }

   export class TeamMember {
    constructor(
      public  id:number ,
      public userId:string,
      public teamId:number,
      public isAdmin:boolean,
      public name:string
     
     ) {}
   }

   export interface Employee {
    
       id:number ;
       name:string;
       profileImage:string;
       role:string;
       email:string;
     
     
   }
