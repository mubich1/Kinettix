export interface SendESignRequest {
    contractID: number;
    toEmails: string[] | null;
    cCEmails: string[] | null;
}