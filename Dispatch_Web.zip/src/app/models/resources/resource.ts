import { Resource } from "../activity/activity-resource";
import { Competency } from "../vendor/vendor";

export interface ResourceRequest {
    id: number;
    name: string;
    displayName: string;
    categoryId: number;
    statusId: number;
    cost: number;
    price: number;
    margin: number;
    partNumber: string;
    upLift: number;
    percentageOfTech: number;
    quoteDocument: any | null;
    isInternal: boolean;
}
export interface ResourceResponse {
    id: number;
    name: string;
    displayName: string;
    categoryId: number;
    statusId: number;
    cost: number;
    price: number;
    margin: number;
    isDeleted: boolean;
    partNumber: string;
    upLift: number;
    percentageOfTech: number;
    createdDate: Date;
    status:StatusesResponse;
    category:CategoryResponse;
    isInternal: boolean;
    quoteDocument: ResourceDocument;
}
export interface StatusesResponse {
    id: number;
    name: string;

}
export interface CategoryResponse {
    id: number;
    name: string;

}
export interface ActivityResourceMainDto{
    resource: ActivityResourceRequest[],
    resourceTotal:ActivityResourcesTotalDto
}

export interface ContractActivityResourceMainDto{
    resource:Resource[],
    resourceTotal:ActivityResourcesTotalDto
}

export interface ActivityResourceRequest {
    id: number;
    activityId: number | undefined;
    resourceId: number | undefined;
    categoryId: number | undefined;
    quantity: number | 0;
    unitCost: number | 0;
    uplift: number | 0;
    upliftedCost: number | 0;
    directCost: number | 0;
    marginPercent: number | 0;
    margin: number | 0;
    platformFeePercent: number | 0;
    platformFee: number | 0;
    riskFeePercent: number | 0;
    riskFee: number | 0;
    financeFeePercent: number | 0;
    financeFee: number | 0;
    totalCost: number | 0;
    afterHours: boolean | 0;
    materialType: string | null;
    techPercent: number | null;
    price: number | 0;
    roundedPrice: number | 0;
    categoryName:string | '';
}

export interface ActivityRequest {
    id: number |0;
    name: string | "";
    categoryId: number;
    displayName: string | "";
    typeId: number | 0;
    statusId: number | 0;
    scope: string | "";
    assumptions: string | "";
    currencyId: number | 0;
    countryId: number | 0;
    isDeleted: boolean | false;
    activityCompetencies: Competency[] ,
    activityMilestones: Task[],
    regionId: number | null,
    responseIntervalId: number | null;
    technicianLevelId: number | null;
}

export interface ActivitiesResponse {
    id: number;
    name: string;
    displayName: string;
    typeId: number;
    statusId: number;
    scope: string;
    assumptions: string;
    currencyId: number;
    countryId: number;
    platformFeePercent: number;
    riskPercent: number;
    financeFeePercent: number;
    roundingAmount: number;
    isDeleted: boolean;
}


export interface ResourceDocument {
    id: number,
    resourceId: number,
    name: string,
    url: string
}

export class ActivityResourcesTotalDto {
    id:number | 0;
    totalVariableCost: number | 0;
    totalFixedCost: number | 0;
    budgetMargin: number | 0;
    cogs: number | 0;
    grossProfit: number | 0;
    variableMarginPercent: number | 0;
    totalBudgetExpenses: number | 0;
    budgetIncome: number | 0;
    budgetNetMarginPercent: 0 | 0;
    authorizedCost: number | 0;
    targetCost: number | 0;
    platformFeePercent: number | 0;
    riskPercent: number | 0;
    financeFeePercent: number| 0;
    roundingAmount: number| 0;
}
