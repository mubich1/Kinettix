export interface PaymentTerm {
    id: Number;
    name: string;
}

export interface PaymentType {
    id: Number;
    name: string;
}