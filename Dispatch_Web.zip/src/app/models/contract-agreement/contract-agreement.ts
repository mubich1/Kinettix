export interface ContractAgreement {
  id: number;
  contractId: number;
  title: string;
  agreement: string | null;
  referenceNumber: number | null;
}
