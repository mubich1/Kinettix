import { Client } from "../client/client";

export interface GlobalTermLibrary extends GlobalTermLibraryRequest {
    createdDate: Date | null;
    deletedAt: Date | null;
    client: Client| null,
    clientName: string | null,
  }


  
export interface GlobalTermLibraryRequest {
  id: number | null,
  name: string,
  detail: string,
}
