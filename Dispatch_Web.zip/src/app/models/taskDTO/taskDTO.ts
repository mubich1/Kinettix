export interface TaskDTO {
    id: number | null
    name: string | null
    isRequiredToWorkflow?: boolean | null
    estimatedTrackingTimeInMinutes?: number | null
    isActive?: boolean | null
    createdDate?: Date | null
    modifiedDate?: Date | null
    taskLevel: string | null
    isSystemTask?: boolean | null
}
export enum TaskLevel {
    Ticket = "Ticket",
    Contract = "Contract",
}
export interface GetMilestoneOptions {
    recordsPerPage?: number | null,
}
