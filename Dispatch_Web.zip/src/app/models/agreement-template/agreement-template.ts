import { Client } from "../client/client";

export interface AgreementTemplate extends AgreementTemplateRequest {
  createdAt: Date | null,
  deletedAt: Date | null,
  client: Client | null
}


export interface AgreementTemplateRequest {
  id: number | null,
  clientId: number | null,
  name: string,
  template: string,
}

