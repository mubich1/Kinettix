export interface TaskGroup {
    id: number | null
    name: string | null
    isActive: boolean | null
    createdDate: Date | null
    modifiedDate: Date | null
}