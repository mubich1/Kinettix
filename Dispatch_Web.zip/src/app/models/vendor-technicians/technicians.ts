
export interface TechnicianDTO {
    id?: number;
    userId?: string | null;
    vendorId?: number | null;
    email?: string;
    name?: string;
    phone?: string;
    technicianComments?: string;
    passedBackgroundCheck?: boolean | null;
    passedDrugScreen?: boolean | null;
    profilePicURL?: string;
    rating?: number | null;
    whatsapp?: string;
    weChat?: string;
    skype?: string;
    education?: string;
    employment?: string;
    laborClouds?: string;
    address1?: string;
    address2?: string;
    city?: string;
    stateOrProvince?: string;
    postalCode?: string;
    timeZone?: string;
    carryingClientProductsOrparts?: boolean | null;
    countryId?: number | null;
    preferedMethodOfCommunication?: string;
    skills?: CompetencyViewModel[];
    certifications?: CompetencyViewModel[];
    tools?: CompetencyViewModel[];
    products?: CompetencyViewModel[];
    industries?: CompetencyViewModel[];
    vendorCoveredCities?: TechCoveredCitiesViewDetailsModel[];
    longitude?: string;
    latitude?: string;
}
export interface ImagePickerConf {
    width?: string;
    height?: string;
    borderRadius?: string;
    aspectRatio?: number | null; 
    objectFit?: 'cover' | 'contain' | 'fill' | 'revert' | 'scale-down';
    compressInitial?: number; // Range from [1-100]
    language?: string;
    hideDeleteBtn?: boolean;
    hideDownloadBtn?: boolean;
    hideEditBtn?: boolean;
    hideAddBtn?: boolean;
  }
export interface TechnicianBasicInfoDTO {
    id: number;
    vendorId: number | null;
    email: string;
    name: string;
    phone: string;
    profilePicURL: string;
    technicianTypeId: number | null;
    city: string;
    stateOrProvince: string;
    postalCode: string;
    countryId: number | null;
    preferedMethodOfCommunication: string;
    whatsapp: string;
    weChat: string;
    technicianComments: string;
    skills: CompetencyViewModel[];
    certifications: CompetencyViewModel[];
    tools: CompetencyViewModel[];
    products: CompetencyViewModel[];
    industries: CompetencyViewModel[];
}

export interface TechDocumentRequest {
    id: number;
    techId: number;
    name: string;
    url: string;
    documentType: number;
    createdDate: string | null;
}

export interface TechnicianTypeViewModel {
    id: number | null;
    technicianType: string;
}

export interface TechnicianCountriesViewModel {
    countryId: number | null;
}

export interface TechCoveredCitiesViewDetailsModel {
    iD: number | null;
    cityORTown: string;
    countryName: string;
    technicianID: number | null;
    estimatedTravelTime: string;
    transportationType: string;
    travelCost: string;
    ziporpostalCode: string;
    countryId: number | null;
    vendorGlobalRateId: number | null;
}

export interface UserInfoDTO {
    id: string;
    clientId: number;
    name: string;
    email: string;
    phoneNumber: string;
    country: string;
    state: string;
    city: string;
    address: string | null;
    picture: string | null;
    pictureBase64: string | null;
    address2: string | null;
    zipCode: number | null;
    role: string;
    havePermission: boolean;
    application: string;
}
export interface CompetencyViewModel {
    id: number | null;
    compentency: string;
    // category: string;
    type: string;
    isExpireable:boolean | null;
    expireDate:Date | null;
}
export interface UserInfoRequestDTO {
    clientIds: number[];
}

export interface TechContract {
    id:number;
    category:string | null,
    contractCode: string | null,
    title: string | null,
    tickets : TechTicket[]
}

export interface TechTicket {
    id: number,
    contractId:number,
    title:string,
    number:number | null,
    referenceType:string | null,
    referenceId: number | null,
}