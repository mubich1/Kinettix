import { ContractTicketSchedule, TicketSiteInfo } from "../tickets/tickets"

export interface AssignmentTemplate {
    template_id: string,
    name: string,
    client_id: number | null,
}

export interface LaborCloud {
    id: any | null,
    identifier: string,
    name: string,
    description: string,
    members: number,
    active: boolean,
    deleted: any | null
    selected?: boolean
}

export interface AvailableTech {
    resourceId: number,
    technicianName: string,
    selected?: boolean
}

export interface TicketPricing {
    pricingMaxNumberOfHours: number,
    pricingPerHourPrice: number,
    pricingMode: string,
    pricingType: string,
    autoInvite: boolean,
    pricingFlatPrice: number,
}

export interface CreateAssignment {
    template_id?: number,
    title: string,
    description: string,
    instructions: string,
    private_instructions?: string,
    industry_id: number,
    desired_skills?: string,
    assign_to_first_to_accept?: boolean,
    auto_invite: boolean,
    scheduled_start_date: string | Date | null,
    scheduled_end_date: string | Date | null,
    pricing_mode: string,
    pricing_type: string,
    pricing_flat_price: string,
    pricing_per_hour_price: string,
    pricing_max_number_of_hours: string,
    techs_id: string,
    show_in_work_feed?: boolean,
    location_id: string,
    location_name: string,
    location_number: string,
    location_address1: string,
    location_city: string,
    location_state: string,
    location_zip: string,
    location_country: string,
    location_latitude: string,
    location_longitude: string
    laborclouds: string,
    location_contacts: LocationContacts[]
}

export interface LocationContacts {
    first_name: string,
    last_name: string,
    phone: string,
    email: string,
    id: number,
}
export interface AssignmentJobDetails {
    id: number,
    clientId: number,
    endClientId: number | null,
    clientSiteId: number | null,
    createdBy: string,
    modifiedBy: string | null,
    projectManagerId: number | null,
    contractId: number,
    accountExecutiveId: number | null,
    coordinatorId: number,
    title: string,
    scope: string | null,
    number: string | null,
    createdDate: string,
    modifiedDate: string | null,
    tools: string,
    deliverableComments: string,
    billingInstructions: string,
    arrivalInstructions: string,
    referenceType: string,
    referenceId: number | null,
    categoryId: number | null,
    ticketStatusId: number,
    siteInfo: TicketSiteInfo,
    ticketSchedule: ContractTicketSchedule,
    pricing: TicketPricing,
    ticketScheduleId: number,
    totalAuthorizedPayment: number,
    isPoResurces: boolean,
}

export interface AssignmentTemplate {
    template_id: string,
    name: string,
    client_id: number | null,
}

export interface TemplateDetails {
    shortUrl: any | null,
    status: string,
    substatuses: any | null,
    labels: any | null,
    resolution: any | null,
    activeResource: any | null,
    payment: TemplatePayment,
    history: any[],
    template_id: string,
    title: string,
    description: string,
    instructions: any,
    desired_skills: any,
    client: number | null,
    internal_owner: string,
    internal_owner_details: TemplateInternalOwnerDetails,
    sent_worker_count: number,
    assignment_window_start: number,
    assignment_window_start_date: string,
    assignment_window_end: number,
    assignment_window_end_date: string,
    scheduled_time: any,
    scheduled_time_date: any,
    scheduled_start: any,
    scheduled_end: any,
    reschedule_request: any,
    budget_increase_request: any,
    expense_reimbursement_request: any,
    bonus_request: any,
    industry: string,
    time_zone: string,
    required_attachments: number,
    location: TemplateLocation,
    location_offsite: boolean,
    location_contact: TemplateLocationContact,
    support_contact: TemplateSupportContact,
    pricing: TemplatePricing,
    invoice_number: any,
    attachments: any[],
    created_on: any,
    last_modified_on: any,
    notes: any[],
    custom_fields: any[],
    parts_group: any,
    pending_offers: any[],
    declined_resources: any[],
    questions: any[],
    deliverables_fulfilled: boolean,
    template_name: string,
    template_description: string
}

export interface TemplatePayment {
    max_spend_limit: number,
    actual_spend_limit: number,
    buyer_fee: number,
    total_cost: number,
    hours_worked: number,
    paid_on: number,
    payment_due_on: number
}

export interface TemplateInternalOwnerDetails {
    first_name: string,
    last_name: string
}

export interface TemplateLocation {
    id: number,
    name: string,
    location_number: string,
    instructions: any,
    address_1: string,
    address_2: string,
    city: string,
    state: string,
    zip: string,
    country: string,
    latitude: string,
    longitude: string
}

export interface TemplateLocationContact {
    first_name: string,
    last_name: string,
    phone: string,
    email: string,
    id: number,
}

export interface TemplateSupportContact {
    id: string,
    first_name: string,
    last_name: string,
    email: string,
    phone_numbers: any[]
}

export interface TemplatePricing {
    type: string,
    spend_limit: number,
    budget_increases: string,
    expense_reimbursements: number,
    bonuses: number,
    additional_expenses: number,
    flat_price: any,
    per_hour_price: number | null,
    max_number_of_hours: number | null,
    per_unit_price: any,
    max_number_of_units: any,
    initial_per_hour_price: any,
    initial_number_of_hours: any,
    additional_per_hour_price: any,
    max_blended_number_of_hours: any
}