import { Observable } from 'rxjs';

export interface ConfirmationDialog {
  header: string;
  question: string;
  confirmationButtonText: string;
  cancelButtonText: string;
  data: any | null;
  confirm: boolean;
  obs: any;
  isClosed: boolean;
}
