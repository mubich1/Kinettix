export interface SendAgreement {
  header: string;
  question: string;
  confirmationButtonText: string;
  cancelButtonText: string;
  data: any | null;
  confirm: boolean;
  obs: any;
  isClosed: boolean;
  selectedOption: string,
  selectedDownloadFormatOption: string,
  emailMessage: string,
  recipientEmailList: string[] | null
  ccEmailList: string[] | null,
  attachmentFormat: string | null,
  agreementDocumentPath: string | null,
}


export enum SendAgreementOptionsEnum {
  Download = 1,
  ESign = 2,
  Email = 3,
  UploadAgreement = 4,
}


export enum AgreementFormatOptionsEnum {
  PDF = 1,
  WORD = 2,
}
