import { Observable } from "rxjs";
import { CompetencyViewModel } from "../vendor-technicians/technicians";

export interface InputDialog {
    header: string,
    label: string,
    value: string | null,
    confirmationButtonText: string,
    cancelButtonText: string,
    data: any| null,

    confirm: boolean,
    obs: any
}


export interface InputDialogCompenticies  {
    header: string,
    label: string,
    valueArray: any | null,
    confirmationButtonText: string,
    cancelButtonText: string,
    data: any| null,
    confirm: boolean,
    obs: any
}

export interface ActivityDialog  {
    header: string,
    confirmationButtonText: string,
    cancelButtonText: string,
    data: any| null,
    confirm: boolean,
    obs: any
}

export interface LocationDialog  {
    header: string,
    confirmationButtonText: string,
    cancelButtonText: string,
    data: any| null,
    confirm: boolean,
    obs: any
}