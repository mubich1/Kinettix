export interface ContractCategory {
    id: number | null,
    category: string
}

export interface ContractType {
    id: number | null,
    type: string
}

export interface ContractStatus {
    id: number;
    status: string;
}

export interface ClientContractsGetDto {
  id?: number;
  clientId?: number;
  endClientId?: number | null;
  coordinatorId?: number | null;
  category?: string;
  created?: string;
  isDeleted?: boolean;
  contractCode?: string;
  sow?: string;
  terms?: string;
  startDate?: string | null;
  title?: string;
  status?: number;
  stage?: number;
  dealId?: number | null;
  categoryId?: number | null;
  typeId?: number | null;

  pmoleadId?: number | null;
  fsoleadId?: number | null;
  preVisitTeamId?: number | null;
  dayOfVisitTeamId?: number | null;
  platform?: number | null;
  secondaryClient?: number | null;
  onsiteEntity?: number | null;
  modifiedBy?: number | null;
  modifiedAt?: string | null;
}
