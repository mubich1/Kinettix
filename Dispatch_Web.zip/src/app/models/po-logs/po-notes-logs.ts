export interface PoNotesLogs {
    id: number;
    notes: string;
    vendorName: string;
    techName: string;
    purchaseOrderId: number;
    userName?: string;

    vendorId: number;
    techId: number;
    createdDate: string | null;
    createdBy: string;
    modifiedDate: string | null;
    modifiedBy: string;
    deleted: boolean | null;
}
