export interface PoCallLogs {
    id:number;
    vendorName: string;
    techName: string;
    lastCallDate: Date | string;
    purchaseOrderId: number;
    userName?: string;

    vendorId: number;
    techId: number;
    createdDate: string | null;
    createdBy: string;
    modifiedDate: string | null;
    modifiedBy: string;
    deleted: boolean | null;
}
