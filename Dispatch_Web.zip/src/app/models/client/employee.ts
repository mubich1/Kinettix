export interface Employee {
    id: number;
    roleId: string;
    email: string;
    name: string;
    isActive: string;
  }