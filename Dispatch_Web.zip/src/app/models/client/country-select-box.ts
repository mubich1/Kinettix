export interface Countrylist {
    value: number;
    text: string;
    region: string;
  }
  export interface countrySelectBox{
    value:number,
    text:string
}
