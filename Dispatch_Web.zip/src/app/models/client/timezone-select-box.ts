export interface timeZonelist {
    id: string;
    standardName: string;
  }
  export interface timeZoneSelectBox{
    id: string;
    standardName: string;
}
export interface timeZoneDropdown{
  value:string,
  text:string
}