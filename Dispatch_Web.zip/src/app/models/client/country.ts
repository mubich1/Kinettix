export interface Country {
    id: number;
    name: string;
    region: string;
  }
  export interface SelectBox{
    id:number,
    name:string
}