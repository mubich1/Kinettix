export interface ClientSite {
    id: number;
    name: string;
    city: string;
    state: string;
    countryId: number;
    siteNumber: string;
    countryName: string;
    address:string;
    postalCode:string;
    phone: string;
    timeZone: string;
    clientId?: number;
    hqAddress:boolean;
    longitude: string;
    latitude: string;
  }
