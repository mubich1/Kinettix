export interface Client {
  id: number;
  name: string;
  logoUrl: string;
  city: string;
  state: string;
  countryId: number;
  isSync: boolean;
  countryName: string;
  email: string;
  phone: string;
  address: string;
  website: string;
  postalCode: string;
  accountExecutiveId: string;
  accountantId: string;
  projectManagerId: string;
  verticalDefinitionId?: number;
  status: number;
  hasEndClient: boolean;
  parentID?: number;
  relationshipTypeID?: number;
  statusName?: string;
  endClients: EndClient[] | null
}

export interface EndClient {
  id?: number;
  endClientId: number;
  name: string
}

export interface ClientDocument {
  id: number;
  clientId: number;
  documentType: number;
  name: string | null;
  url: string | null;
  filebase64string: string | null;
  created: string;
  modified: string | null;
  deleted: string | null;
  expiration: string | null;
  createdDate?: Date | null;
  isInternal?: Boolean | true;
}

export interface ClientDocumentsType {
  id: number;
  name: string;
}

export interface ClientDocumentRequest {
  id?: number;
  clientId?: number;
  name: string;
  description?: string;
  url?: string;
  documentType: number;
  created?: Date;
  signatureDate: Date | null;
  poNumber: string | null,
  poValue: number | null,
  expiration: Date | null;
  isInternal?: Boolean | true;
}
export interface ClientUserDocumentRequest {
  id?: number;
  clientUserId: number;
  name: string;
  description?: string;
  url?: string;
  documentType: number;
  created?: string;
  signatureDate: Date | null;
  poNumber: string | null,
  poValue: number | null,
  expiration: Date | null;
  isInternal?: Boolean | true;
}
export interface ClientUserDocument {
  id: number;
  clientUserId: number;
  documentType: number;
  name: string | null;
  url: string | null;
  filebase64string: string | null;
  created: string;
  modified: string | null;
  deleted: string | null;
  expiration: string | null;
  createdDate?: Date | null;
  isInternal?: Boolean | true;
}

export interface ClientRelationshipType {
  id?: number;
  name?: string;
}

export interface AssociatedEntities {
  entitiesToInvoice: AccociatedClients[];
  platforms: AccociatedClients[];
  onsiteEntities: AccociatedClients[];
  secondaryClients: AccociatedClients[];
  clientContacts: AssociatedUsers[];
}

export interface AccociatedClients {
  id: number;
  name: string | null;
  phone: string | null;
  email: string;
  address: string | null;
}

export interface AssociatedUsers {
  id: number;
  email: string | null;
  fullName: string | null;
  address: string | null;
  businessPhone: string | null;
  mobileNumber: string | null;
  firstName: string | null;
  lastName: string | null;
}

export interface UpdateAssociatedClients {
  dealID: number | null;
  contractID: number | null;
  clientID: number | null;
  userID: number | null;
  associationType: string;
}

export interface UpdateAssociatedEntities {
  entityToInvoice: UpdateAssociatedClients;
  clientContacts: UpdateAssociatedClients;
  secondaryClient: UpdateAssociatedClients;
  platform: UpdateAssociatedClients;
  onsiteEntity: UpdateAssociatedClients;
}
