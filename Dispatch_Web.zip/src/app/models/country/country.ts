import { BaseDto } from "src/app/shared/common/base-dto"
import { Region } from "../region/region";

export interface Country extends BaseDto {
    name: string;
    countryCode?: string;
    targetRate?: number;
    twilioSMSNumber?: string;
    twilioWhatsAppNumber?: string;
    regionId: number;
    regionName: string;
}
