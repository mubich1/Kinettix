export interface IntegrationSource {
    id: number | null;
    name: string | null;
    isDeleted: boolean | null;
    createdDate: Date | null;
    modifiedDate: Date | null;
}