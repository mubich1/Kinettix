export interface Status {
  id: number;
  status: string;
  dealId:number;
  reason:string | null;
}