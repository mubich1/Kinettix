import { Client } from "../client/client";
import { Contact } from "../contact/contact";


export interface Deal {
    id: number;
    saleOwnerId: number | null,
    ownerId: number | null,
    endClientId: number ,
    referenceNumber: number | null;
    name: string | null;
    description: string | null;
    reason: string | null;
    amount: number | null;
    atRisk: boolean;
    amountInCompanyCurrency: number | null;
    dueDate: Date | null;
    type: DealType | null;
    clientId: number| null;
    client: Client;
    priority: DealPriority | null;
    status: DealStatus | null;
    contact: Contact;
}



export interface DealSearch{
    types:string[],
    startDate:Date | null,
    endDate:Date | null,
    client:number | null,
    amount:number | null
}



export interface DealStatus {
    id: number;
    dealId: number;
    status: string ;
    reason: string;
}

export interface DealPriority {
    id: number;
    dealId: number;
    priority: string;
}


export interface DealType {
    id: number;
    dealId: number;
    type: string;
}

export interface SearchDealResponse{
    id:number,
    referenceNumber:number | null,
    name:string,
    description:string |null,
    priority:number|null,
    amount:number | null
    amountInCompanyCurrency:number |null
    dueDate:Date | null,
    type:string | null,
    client:string | null,
    status: DealStatus | null,
    atRisk: boolean
}


export interface DealDocument {
    id: number;
    dealId: number;
    documentType: DocumentDefinitionType;
    name: string | null;
    url: string | null;
    filebase64string: string | null;
    created: string;
    modified: string | null;
    deleted: string | null;
    expiration: string | null;
    documentTypeNavigation: any| null,
}

export interface DealDocumentsType{
    id:number,
    type:string
}

export interface DocumentDefinitionType{
    id:number,
    definitionId:number,
    name:string,
    priority:number | null,
    isActive:boolean | null,
    isDeleted:boolean | null
}


export interface TurnoverRequirementCheckDto{
    isInvoicingEntityAssigned:boolean;
    isAccountExecutiveAssigned:boolean;
    isActivityAssigned:boolean;
    isSignedDocumentUploaded:boolean;
}
