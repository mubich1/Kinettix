export interface incidentCategories {
    id: number;
    name: string;
    createdBy?: string;
    modifiedBy?: string;
  }
