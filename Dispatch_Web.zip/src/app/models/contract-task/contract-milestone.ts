export interface ContractMilestone {
    id: number;
    contractId: number;
    contractTaskId: number | null;
    taskStatusId: number | null;
    taskId: number;
    milestoneId: number;
    milestoneDate: string;
    completedBy: string;
    completedDate: Date;
    actualDate: string;
    createdDate: string;
    modifiedDate: string;
    createdby: string;
    modifiedby: string;
    deleted: boolean;
    assignTo: string;
    assignDate: Date;
    milestoneOrder: number;
    taskName: string;
    milestoneName: string;
    assignedToDisplayName: string;
    contractMilestoneCompletedDate: string;
}