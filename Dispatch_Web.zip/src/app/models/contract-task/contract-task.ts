export class ContractTask {
    id: number;
    contractId: number;
    taskStatusId: number | null;
    taskId: number;
    createdDate: string;
    modifiedDate: string;
    createdBy: string;
    modifiedBy: string;
    deleted: boolean;
    completedBy: string;
    completedDate : string;

    taskName:string;
    createdByDisplayName: string;
    contractStatusName : string;
    milestoneName : string;
    assignedToDisplayName : string;
    milestoneOrder : number;
    contractMilestoneCompletedDate : string;

    //not mapped properties
    isExpand : boolean | false;
    isInitialSave : boolean | false;
}