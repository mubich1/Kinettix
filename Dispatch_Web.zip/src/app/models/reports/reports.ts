export enum ReportNameEnum {
  QBR = 'QBR',
  COATES = 'Coates',
  PROJECTJOBS = 'Project Jobs',
  TICKET = 'ticket',
  PROJECT = 'project',
  GENERAL = 'general'
}
