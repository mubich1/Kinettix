import { Component, OnInit } from '@angular/core';
import { IconService } from 'carbon-components-angular';

import Notification20 from '@carbon/icons/es/notification/20';
import UserAvatar20 from '@carbon/icons/es/user--avatar/20';
import View20 from '@carbon/icons/es/view/20';
import Edit16 from '@carbon/icons/es/edit/16';
import Location16 from '@carbon/icons/es/location/16';
import Launch16 from '@carbon/icons/es/launch/16';
import Phone16 from '@carbon/icons/es/phone/16';
import Email16 from '@carbon/icons/es/email/16';
import Filter16 from '@carbon/icons/es/filter/16';
import Search16 from '@carbon/icons/es/search/16';
import TrashCan16 from '@carbon/icons/es/trash-can/16';
import Information20 from '@carbon/icons/es/information/20';
import {
  ChevronLeft20,
  TrashCan20,
  Edit20,
  FaceAdd20,
  DocumentAdd20,
  Add20,
  UserIdentification20,
  LicenseMaintenance20,
  OperationsRecord20,
  IbmCloudPakIntegration20,
  ExpandAll20,
  SendAlt16,
  Archive16,
  DirectionStraightFilled16,
  CheckmarkOutline20,
  CloseOutline20,
  ChangeCatalog16,
  Ticket16,
  Dashboard16,
  DocumentBlank16,
  Screen16
} from '@carbon/icons';
import { MsalService } from '@azure/msal-angular';
import { Router, NavigationEnd } from '@angular/router';
import { UserService } from './services/user/user.service';
import { UtilityService } from './services/utility/utility.service';
// import AppSwitcher20 from '@carbon/icons/es/app-swi/tcher/20';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  title = 'Sales Portal';
  isLoggedIn: boolean;

  constructor(protected iconService: IconService, private router: Router,
    private msalService: MsalService, private userService: UserService, private utility: UtilityService) { }

  ngOnInit() {
    this.checkAuthentication();
    this.router.events.subscribe(value => {
      if (value instanceof NavigationEnd) {
        this.checkAuthentication();
      }
    });


    this.iconService.registerAll([
      Notification20,
      UserAvatar20,
      View20,
      Edit16,
      Location16,
      Launch16,
      Phone16,
      Email16,
      Filter16,
      Search16,
      TrashCan16,
      ChevronLeft20,
      TrashCan20,
      Edit20,
      FaceAdd20,
      DocumentAdd20,
      Add20,
      UserIdentification20,
      LicenseMaintenance20,
      OperationsRecord20,
      IbmCloudPakIntegration20,
      ExpandAll20,
      SendAlt16,
      Archive16,
      DirectionStraightFilled16,
      CheckmarkOutline20,
      CloseOutline20,
      ChangeCatalog16,
      Ticket16,
      Dashboard16,
      DocumentBlank16,
      Screen16,
      Information20,
      // AppSwitcher20
    ]);
  }

  checkAuthentication() {
    const accessToken = JSON.parse(localStorage.getItem('idToken') as any) || '';
    const jwtToken = JSON.parse(localStorage.getItem('jwtToken') as any) || '';

    if (this.router.url !== '/login' && this.router.url !== '/') {
      if ((!this.msalService.instance?.getAllAccounts()?.length || !accessToken?.length || !jwtToken?.length) || !this.utility.applicationAccessEnabled()) {
        this.userService.logout();
        this.router.navigate(['/login']);
      }
    }
  }
}
