import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './core/AuthGuard/auth.guard';
import { SalesLayoutComponent } from './core/layout/sales-layout/sales-layout/sales-layout.component';
import { SiteLayoutComponent } from './core/layout/site-layout.component';
import { Permission,PermmissionSection } from './services/utility/permission-constant';
import { LoginComponent } from './views/login/login.component';
import { ProfileComponent } from './views/profile/profile.component';
import { UnauthorizedComponent } from './views/unauthorized/unauthorized.component';

const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent,
  },
  {
  path: '',
  component: LoginComponent,
},
{
  path: 'unauthorized',
  component: UnauthorizedComponent,
},
{
  path: 'profile',
  component: SiteLayoutComponent,
  children:
  [
    {
      path:'',
    component: ProfileComponent,
    }
  ]

},
// {
//   path: 'tickets',
//   component: SiteLayoutComponent,
//   //canActivate: [AppMaintenanceAuthGuard, AuthGuard],
//   loadChildren: () => import('./views/ticket/ticket.module').then(m => m.TicketModule)
// }
// ,
  { path: 'clients', component: SiteLayoutComponent, loadChildren: () => import('./views/client/client.module').then(c => c.ClientModule), canActivate: [AuthGuard] ,  data: {permission: Permission.ViewClient}},
  { path: 'vendors', component: SiteLayoutComponent, loadChildren: () => import('./views/vendor/vendor.module').then(c => c.VendorModule), canActivate: [AuthGuard] , data: {permission: Permission.ViewVendor}},
  { path: 'vendors/:id', component: SiteLayoutComponent, loadChildren: () => import('./views/vendor-technicians/vendor-technicians.module').then(c => c.VendorTechniciansModule),canActivate:[AuthGuard], data:{permission:Permission.ViewVendorTechnicians}},
  { path: 'sales/dashboard',component: SiteLayoutComponent, loadChildren: () => import('./views/sales-portal-dashboard/sales-portal-dashboard.module').then(c => c.SalesPortalDashboardModule)},
  { path: 'client-dashboard',component: SiteLayoutComponent, loadChildren: () => import('./views/dashboard/dashboard.module').then(c => c.DashboardModule)},
  { path: 'sales/deal', component: SiteLayoutComponent,loadChildren: () => import('./views/deal/deal.module').then(c => c.DealModule),canActivate:[AuthGuard], data:{permission: Permission.ViewDeal}},
  { path: 'sales/project', component:SiteLayoutComponent,loadChildren: () => import('./views/project/prospects.module').then(c => c.ProspectsModule)},
  { path: 'sales/settings', component: SiteLayoutComponent,loadChildren: () => import('./views/settings/settings.module').then(c => c.SettingsModule)},
  { path: 'client/settings', component: SiteLayoutComponent,loadChildren: () => import('./views/settings/settings.module').then(c => c.SettingsModule)},
  { path: 'sales/activities', component: SiteLayoutComponent,loadChildren: () => import('./views/activities/activities.module').then(c => c.ActivitiesModule)},
  { path: 'dashboard',component: SiteLayoutComponent, loadChildren: () => import('./views/dashboard/dashboard.module').then(c => c.DashboardModule)},
  { path: 'client',component: SiteLayoutComponent, loadChildren: () => import('./views/client/client.module').then(c => c.ClientModule)},
  { path: 'delivery', component: SiteLayoutComponent, loadChildren: () => import('./views/contract/contract.module').then(c => c.ContractModule), canActivate:[AuthGuard], data: {permission: Permission.ViewDelivery}},
  { path: 'contracts/:contractId/tickets/:ticketId', component: SiteLayoutComponent, loadChildren: () => import('./views/ticket/ticket.module').then(c => c.TicketModule)},
  { path: 'catalog/settings',component: SiteLayoutComponent, loadChildren: () => import('./views/settings/settings.module').then(c => c.SettingsModule)},
  { path: 'client/settings',component: SiteLayoutComponent, loadChildren: () => import('./views/settings/settings.module').then(c => c.SettingsModule)},
  { path: 'users/settings',component: SiteLayoutComponent, loadChildren: () => import('./views/settings/settings.module').then(c => c.SettingsModule)},
  { path: 'general/settings',component: SiteLayoutComponent, loadChildren: () => import('./views/settings/settings.module').then(c => c.SettingsModule)},
  { path: 'usernotes',component: SiteLayoutComponent, loadChildren: () => import('./views/usernote/usernote.module').then(c => c.UsernoteModule)},
  { path: 'reports',component:SiteLayoutComponent, loadChildren: () => import('./views/reports/report.module').then(c=>c.ReportModule)},
  { path: 'delivery-dashboard', component: SiteLayoutComponent, loadChildren: () => import('./views/delivery-dashboard/delivery-dashboard.module').then(c => c.DeliveryDashboardModule)},
  { path: 'search', component: SiteLayoutComponent, loadChildren: () => import('./views/search/search.module').then(c => c.SearchModule), canActivate: [AuthGuard] ,  data: {permission: Permission.ViewClient}},
  { path: '**', redirectTo: 'login'  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
