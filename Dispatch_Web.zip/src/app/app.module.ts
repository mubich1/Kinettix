import { DEFAULT_CURRENCY_CODE, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {
  MsalGuard,
  MsalInterceptor,
  MsalModule,
  MsalRedirectComponent,
  MsalService,
} from '@azure/msal-angular';
import {
  InteractionType,
  IPublicClientApplication,
  PublicClientApplication,
} from '@azure/msal-browser';
import { CoreModule } from './core/core.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { environment } from '../environments/environment';
import { ProfileComponent } from './views/profile/profile.component';

import { ToastrModule } from 'ngx-toastr';
import { CurrencyPipe, DatePipe } from '@angular/common';
import { IconModule, ModalModule } from 'carbon-components-angular';
import { SharedModule } from './shared/shared.module';
import { LoaderService } from './services/loader/loader.service';
import { UnauthorizedComponent } from './views/unauthorized/unauthorized.component';
import { ReactiveFormsModule } from '@angular/forms';
import { msalConfig } from './core/msal/msal.config';
import { NgxsModule } from '@ngxs/store';
import { ContractsState } from './state/contracts/contracts.state';

@NgModule({
  declarations: [AppComponent, ProfileComponent, UnauthorizedComponent],
  imports: [
    BrowserModule,
    ModalModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    IconModule,
    HttpClientModule,
    ToastrModule.forRoot(), // ToastrModule added
    MsalModule.forRoot(
      new PublicClientApplication(msalConfig),
      {
        interactionType: InteractionType.Redirect,
        authRequest: {
          scopes: environment.b2cScopes,
        },
      },
      {
        interactionType: InteractionType.Redirect, // MSAL Interceptor Configuration
        protectedResourceMap: new Map([
          [environment.identityBaseUrl, environment.b2cScopes],
        ]),
      }
    ),
    CoreModule,
    SharedModule,
    ReactiveFormsModule,
    NgxsModule.forRoot([ContractsState], {
      developmentMode: !environment.production,
    }),
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: MsalInterceptor,
      multi: true,
    },
    LoaderService,
    MsalService,
    MsalGuard,
    CurrencyPipe,
    DatePipe,
    { provide: DEFAULT_CURRENCY_CODE, useValue: 'USD' },
  ],
  bootstrap: [AppComponent,  MsalRedirectComponent],
})
export class AppModule {}
